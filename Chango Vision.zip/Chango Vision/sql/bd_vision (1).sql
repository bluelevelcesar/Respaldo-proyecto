-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 11-11-2026 a las 19:39:04
-- Versión del servidor: 8.0.30
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bd_vision`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `barrio`
--

CREATE TABLE `barrio` (
  `id_barrio` int NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `estado` enum('Activo','Inactivo') DEFAULT 'Activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `barrio`
--

INSERT INTO `barrio` (`id_barrio`, `nombre`, `estado`) VALUES
(12, 'Chima', 'Activo'),
(13, 'Villa reguina', 'Activo'),
(14, 'Villa reguina', 'Activo'),
(15, 'La Plaza', 'Activo'),
(16, 'sacsc', 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `id` int NOT NULL,
  `codigo_cliente` varchar(20) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `apellido` varchar(100) DEFAULT NULL,
  `dni` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `estado` varchar(20) DEFAULT 'Activo',
  `estado_pago` enum('pendiente','pagado','suspendido') DEFAULT 'pendiente',
  `observacion_pago` text,
  `observacion` text,
  `id_servicio` int DEFAULT NULL,
  `id_barrio` int DEFAULT NULL,
  `fecha_ultimo_pago` date DEFAULT NULL,
  `foto_dni` varchar(255) DEFAULT NULL,
  `no_local` tinyint(1) DEFAULT '0',
  `id_tipo` int DEFAULT NULL,
  `dias_mora` int DEFAULT '0',
  `eliminado` tinyint(1) DEFAULT '0',
  `fecha_eliminacion` datetime DEFAULT NULL,
  `motivo_eliminacion` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`id`, `codigo_cliente`, `nombre`, `apellido`, `dni`, `email`, `telefono`, `estado`, `estado_pago`, `observacion_pago`, `observacion`, `id_servicio`, `id_barrio`, `fecha_ultimo_pago`, `foto_dni`, `no_local`, `id_tipo`, `dias_mora`, `eliminado`, `fecha_eliminacion`, `motivo_eliminacion`) VALUES
(119, 'VD1', 'Valeria', 'Díaz', '36555444', 'valeria.diaz@hotmail.com', '3825421100', 'Inactivo', 'suspendido', '', NULL, 96, 15, '2026-09-04', '0', 0, 1, 0, 1, '2026-09-08 22:38:44', NULL),
(125, 'VM1', 'Valentina', 'Mercado', '41777888', 'valen.mercado@gmail.com', '3825466778', 'Inactivo', 'suspendido', '', NULL, 102, 13, '2026-10-01', '0', 0, 3, 0, 1, '2026-09-08 22:07:31', 'Eliminado por administrador'),
(133, 'TD1', 'Tiziano', 'Dias', '43920439', 'tisiano@gmail.com', '382563829', 'Inactivo', 'suspendido', '', NULL, 110, 15, '2026-08-21', '', 0, 2, 0, 1, '2026-09-08 21:53:31', 'por moroso'),
(162, 'WH1', 'werwwrwr', 'hf', '6284798', 'syudbhnj@e.we', '6827389', 'Inactivo', 'suspendido', '', 'wewe', 139, 16, '2027-02-01', '0', 0, 2, 0, 1, '2026-09-08 22:39:06', NULL),
(163, 'EG1', 'efsefs', 'gseseeg', '23458757', 'tdhgnwrtgs@fe.ef', '6357465768', 'Inactivo', 'suspendido', '', 'ds', 140, 15, NULL, '0', 0, 2, 0, 1, '2026-09-01 23:51:32', 'boludo'),
(164, 'CP1', 'Carlos', 'peres', '63675357', 'vrv@efe.ef', '2546246', 'Inactivo', 'pendiente', '', 'vfdvf', 141, 13, '2026-07-30', '0', 0, 6, 0, 1, '2026-09-08 22:39:40', NULL),
(165, 'CF1', 'Cesar', 'fwe', '63537573', 'verhethwe@fe.fe', '264274624', 'Inactivo', 'suspendido', '', 'tr', 142, 12, NULL, '0', 0, 3, 0, 1, '2026-09-08 22:52:49', NULL),
(166, 'AQ1', 'Alexis', 'Quiroga', '52352624', 'adewfr@fe.ef', '24624624', 'Inactivo', 'suspendido', '', 'hthtr', 143, 16, NULL, '0', 0, 6, 0, 1, '2026-09-08 22:45:01', NULL),
(167, 'BB1', 'Bauty', 'Barionuevo', '7534262', 'etjhejyw@de.de', '8643572', 'Inactivo', 'suspendido', '', 'utyd u r', 144, 12, '2026-07-30', '0', 0, 6, 0, 1, '2026-09-08 22:44:03', NULL),
(168, 'JV1', 'JUan', 'villca', '2646356', 'thrrhtt@de.de', '34675247', 'Inactivo', 'suspendido', '', 'ikujeh yhytjuk', 145, 14, '2026-07-30', '0', 1, 3, 0, 1, '2026-09-08 22:53:56', NULL),
(169, 'EK1', 'ewrteyrut', 'kuyje', '23565725', 'etjndgd@de.de', '6857427', 'Inactivo', 'suspendido', '', 'yh', 146, 16, NULL, '0', 0, 2, 0, 1, '2026-09-08 23:09:27', 'Eliminado por administrador'),
(170, 'CU1', 'cesar', 'urterhg', '67546264', 'thgfde@fr.fr', '365357357', 'Inactivo', 'suspendido', '', '5ytrhf', 147, 13, '2026-11-01', '0', 0, 2, 0, 1, '2026-09-08 23:39:30', 'hy'),
(171, 'AF1', 'Alexis', 'fwdvfsbsfb', '2647535', 'hethethe@fe.fe', '86753537', 'Inactivo', 'suspendido', '', 'tyj', 148, 13, NULL, '0', 0, 2, 0, 1, '2026-09-08 23:40:24', 'r'),
(172, 'SF1', 'shtdjs', 'fbsf', '7353535', 'hrsfst@fe.fe', '2653674', 'Inactivo', 'suspendido', '', 'ythr', 149, 14, NULL, '0', 0, 1, 0, 1, '2026-09-08 23:52:27', 'cesar'),
(173, 'MW1', 'MArcos', 'wrwrg', '73535738', 'gwrgw@e.f', '3573853', 'Inactivo', 'suspendido', '', 'eth', 150, 16, '2026-04-15', '0', 0, 1, 0, 1, '2026-09-09 22:09:41', 'esace'),
(174, 'CG1', 'cesargas', 'gsratj', '3573357', 'thdh@thr.th', '73555555524', 'Inactivo', 'suspendido', '', 'rth', 151, 16, '2026-01-15', '0', 0, 2, 0, 1, '2026-09-22 19:25:16', 'se demro mucho'),
(175, 'HP1', 'Humberto', 'Prmeño', '22222222', '222fefe@gmail.com', '3825222222', 'Inactivo', 'suspendido', '', 'dwefwef', 152, 12, '2026-02-15', '0', 0, 2, 250, 1, '2026-09-22 22:20:56', 'moroso'),
(176, 'SS1', 'Stefano', 'Sanguineti', '62463635', 'bruno@gmail.com', '6246242', 'Inactivo', 'suspendido', '', '', 153, 14, '2026-01-15', '0', 0, 2, 0, 1, '2026-09-23 22:03:38', 'fe'),
(177, 'WF1', 'wrwrgg', 'fweef', '13543524', 'cdqwdcd@de.ed', '22222222', 'Inactivo', 'suspendido', '', 'x', 154, 15, '2026-01-15', '0', 0, 3, 0, 1, '2026-09-23 22:03:33', 'fewef'),
(178, 'AQ2', 'Alexis', 'Quiroga', '67676767', 'csdcw@dw.dw', '54524524', 'Inactivo', 'suspendido', '', 'dscsd', 155, 13, '2027-06-01', '0', 0, 2, 0, 1, '2026-09-23 23:09:21', 'ew'),
(179, 'MY1', 'Marcos', 'Yaleva', '11223344', 'sefsefq@fe.fe', '2642464', 'Inactivo', 'suspendido', '', 'ds', 156, 14, '2027-06-01', '0', 0, 2, 0, 1, '2026-09-25 14:51:45', 'edwefwe'),
(180, 'CP2', 'Carlos', 'PEpe', '24624644', 'fesesfq@ef.fe', '24524624', 'Inactivo', 'suspendido', '', 'de', 157, 13, '2027-06-01', '0', 0, 2, 0, 1, '2026-09-25 19:31:49', 'dfsdfsfsd'),
(181, 'CD1', 'Cesar', 'dwewe', '24747256', 'esdcsfrefrfr@de.de', '24524644', 'Inactivo', 'suspendido', '', 'ferferfe', 158, 16, '2026-11-17', '0', 0, 6, 0, 1, '2026-09-25 12:50:07', 'sede'),
(182, 'YS1', 'Yair', 'Sullca', '25452454', 'fwefefw@fe.ef', '357572565', 'Inactivo', 'suspendido', '', 'dfgegerger', 159, 13, '2026-11-17', '0', 0, 6, 0, 1, '2026-10-02 23:49:28', 'bgfbfg'),
(183, 'SV1', 'Señor', 'veintidos', '24546242', 'dfsdgwrg@ef.ef', '54245245', 'Inactivo', 'suspendido', '', 'grer', 160, 14, '2027-05-01', '0', 0, 2, 0, 1, '2026-10-02 23:49:17', 'utyt'),
(184, 'JS1', 'Jose', 'Sanches', '54356545', 'jose@gmail.cpm', '28324343', 'Inactivo', 'suspendido', '', 'df', 161, 16, '2027-06-17', '0', 0, 6, 0, 1, '2026-09-25 19:39:09', 'fsd'),
(186, 'BS1', 'Brump', 'Samguineti', '53456345', 'dcdscdw@cs.cd', '45634656', 'Inactivo', 'suspendido', '', 'dsasdas', 163, 13, '2026-12-17', '0', 0, 6, 0, 1, '2026-10-02 23:49:23', 'nytynty'),
(187, 'PP1', 'Pedro', 'Pony', '23423523', 'gdgrrdrdg@wdw.fe', '3436555', 'Inactivo', 'suspendido', '', 'grrttr', 164, 13, '2027-01-31', 'dni_1790985028_5490.jpg', 1, 2, 264, 1, '2026-10-06 23:29:23', 'desfse'),
(188, 'DP1', 'Dani', 'Perro', '84562462', 'dsvyjyte@efef.ef', '36475245', 'Inactivo', 'suspendido', '', 'rthrthrtrt h rthtrhwrth', 165, 13, NULL, '0', 1, 2, 0, 1, '2026-10-06 19:20:35', 'sacs'),
(189, 'LM1', 'Lionel', 'Messi', '53453643', 'fewefewfg@ef.ef', '2643743', 'Inactivo', 'suspendido', '', 'gerger', 166, 14, '2026-04-07', '0', 0, 3, 0, 1, '2026-10-07 22:22:25', 'cascas'),
(190, 'SJ1', 'Sanchez', 'jose', '5323436', 'fergresg@fefe.fe', '63463655', 'Inactivo', 'suspendido', '', 'gdfgdfher', 167, 13, '2026-11-17', '0', 0, 6, 0, 1, '2026-10-07 22:22:37', 'cds'),
(191, 'PY1', 'pepe', 'Yaleva', '63573573', 'gerggeg@ede.e', '7954544356', 'Inactivo', 'suspendido', '', 'dvssd', 168, 16, '2026-04-07', '0', 0, 6, 265, 1, '2026-10-07 22:30:34', 'cdscds'),
(192, 'PM1', 'POzo', 'Mauricio', '46353563', 'vdfvdfvfd@dw.de', '3453565', 'Inactivo', 'suspendido', '', 'dvdfvdfv', 169, 13, '2026-11-23', '0', 0, 1, 0, 1, '2026-10-07 22:49:07', 'da'),
(201, 'BB2', 'Bauty', 'baurfe', '43534634', 'fwefwefe@dede.de', '524624624', 'Inactivo', 'suspendido', '', 'dfsdgdfg df', 178, 16, '2026-12-15', '0', 0, 1, 0, 1, '2026-11-03 23:51:06', 'csdsd'),
(202, 'JS2', 'Jose', 'Sanchez', '52452452', 'dscsdgwe@dw.de', '63563565', 'Inactivo', 'suspendido', '[13/10/2026 22:50 - Cobrador (NO PAGÓ)]: crack', 'efwfwee\n[13/10/2026 22:50 - Cobrador (NO PAGÓ)]: crack', 179, 14, '2026-12-15', '0', 0, 3, 0, 1, '2026-11-03 23:51:33', 'jtyjty'),
(203, 'CF2', 'cesar', 'fwefse', '62462442', 'sdscdfds@dwd.wd', '52452454', 'Inactivo', 'suspendido', '', 'sdfsrwg', 180, 14, '2027-01-01', '0', 0, 2, 0, 1, '2026-11-03 23:51:21', 'tyjy'),
(204, 'AD1', 'Alexis', 'Dias', '4325264', 'fefee@fe.fe', '65356565', 'Inactivo', 'suspendido', '[16/10/2026 22:04 - Cobrador (NO PAGÓ)]: cdsd', 'grrgrr\n[16/10/2026 22:04 - Cobrador (NO PAGÓ)]: cdsd', 181, 13, '2026-12-15', '0', 0, 2, 0, 1, '2026-11-03 23:51:01', 'dsc'),
(205, 'HY1', 'humberto', 'Yaleva', '53446246', 'efwgweq@de.de', '27464576', 'Inactivo', 'suspendido', '[16/10/2026 23:29 - Cobrador (NO PAGÓ)]: no pago', 'frer\n[16/10/2026 23:29 - Cobrador (NO PAGÓ)]: no pago', 182, 14, '2026-12-15', '0', 0, 2, 0, 1, '2026-11-03 23:51:27', 'jtyj'),
(206, 'SF2', 'svsf', 'fsgsfgsf', '46356356', 'gtdtgdte@wd.de', '76475645', 'Activo', 'pagado', '', 'yergert', 183, 13, '2027-01-01', '0', 0, 2, 0, 0, NULL, NULL),
(207, 'AP1', 'Alex', 'Perea', '76546677', 'alex@gmail.com', '34236446', 'Activo', 'pendiente', '', 'dcsd', 184, 12, NULL, '0', 0, 3, 0, 0, NULL, NULL),
(208, 'PD1', 'Peres', 'dcsdc', '5474535', 'rdfgrw@dde.e', '43635665', 'Activo', 'pendiente', '', 'dc', 185, 12, NULL, 'dni_1794422222_7478.jpeg', 1, 3, 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_pago`
--

CREATE TABLE `historial_pago` (
  `id_historial` int NOT NULL,
  `id_cliente` int DEFAULT NULL,
  `id_servicio` int DEFAULT NULL,
  `fecha` datetime DEFAULT CURRENT_TIMESTAMP,
  `accion` varchar(50) DEFAULT 'PAGO',
  `detalle` text,
  `monto` decimal(10,2) DEFAULT NULL,
  `metodo` varchar(50) DEFAULT 'EFECTIVO',
  `id_usuario` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `historial_pago`
--

INSERT INTO `historial_pago` (`id_historial`, `id_cliente`, `id_servicio`, `fecha`, `accion`, `detalle`, `monto`, `metodo`, `id_usuario`) VALUES
(18, NULL, 69, '2026-07-29 20:13:32', 'PAGO', 'Pago registrado por humvevo - Juan Villca', 50000.00, 'efectivo', 58),
(19, NULL, 71, '2026-07-31 19:06:44', 'PAGO', 'Pago registrado por humvevo - cesar sullca fsfes', 30000.00, 'efectivo', 58),
(20, NULL, 72, '2026-07-31 21:02:42', 'PAGO', 'Pago registrado por lucas123 - humberto ght', 50000.00, 'efectivo', 57),
(21, NULL, 73, '2026-07-31 21:09:18', 'PAGO', 'Pago registrado por lucas123 - rfgefwre srgsrg', 50000.00, 'efectivo', 57),
(22, NULL, 74, '2026-07-31 21:10:33', 'PAGO', 'Pago registrado por lucas123 - Damiel Sullca', 30000.00, 'efectivo', 57),
(23, NULL, 75, '2026-08-01 10:11:17', 'PAGO', 'Pago registrado por humvevo - grgd gsrgsr', 50000.00, 'efectivo', 58),
(24, NULL, 78, '2026-08-05 18:38:49', 'PAGO', 'Pago registrado por alexis21 - dfdrgdrg rgergergr', 5000.00, 'efectivo', NULL),
(25, NULL, 82, '2026-08-05 19:04:26', 'PAGO', 'Pago registrado por alexis21 - Yair Sullca', 50000.00, 'efectivo', NULL),
(26, NULL, 84, '2026-08-11 10:37:46', 'PAGO', 'Pago registrado por humvevo - Alex Cruz', 50000.00, 'efectivo', 58),
(27, NULL, 101, '2026-08-12 18:44:24', 'PAGO', 'Pago registrado por humvevo - Benjamín Páez', 50000.00, 'efectivo', 58),
(28, 119, 96, '2026-08-13 10:37:00', 'PAGO', 'Pago registrado por humvevo - Valeria Díaz', 30000.00, 'efectivo', 58),
(29, NULL, 94, '2026-08-14 18:31:40', 'PAGO', 'Pago registrado por humvevo - Lucía Alvarez', 5000.00, 'efectivo', 58),
(30, NULL, 93, '2026-08-25 18:32:38', 'PAGO', 'Pago registrado por humvevo - Gonzalo Romero', 45000.00, 'efectivo', 58),
(31, NULL, 92, '2026-08-25 18:45:05', 'PAGO', 'Pago registrado por humvevo - Sofía Morales', 30000.00, 'efectivo', 58),
(32, NULL, 91, '2026-08-25 18:47:42', 'PAGO', 'Pago registrado por humvevo - Lucas Benítez', 45000.00, 'efectivo', 58),
(33, NULL, 90, '2026-08-25 18:48:36', 'PAGO', 'Pago registrado por humvevo - Mariana Fernández', 45000.00, 'efectivo', 58);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `log`
--

CREATE TABLE `log` (
  `id_log` int NOT NULL,
  `id_usuario` int DEFAULT NULL,
  `usuario` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `tipo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'info',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `pagina` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `log`
--

INSERT INTO `log` (`id_log`, `id_usuario`, `usuario`, `accion`, `descripcion`, `tipo`, `ip_address`, `user_agent`, `pagina`, `fecha_registro`) VALUES
(1, 2, 'juan123', 'Editar cliente', 'cesar sullca', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '/ChangoVision2/html/admin_cliente.php', '2026-05-19 22:37:29'),
(2, 2, 'juan123', 'Cambiar estado cliente', 'Cesar - Activado', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '/ChangoVision2/html/admin_cliente.php', '2026-05-19 22:37:44'),
(3, 2, 'juan123', 'Cambiar estado cliente', 'Cesar - Desactivado', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '/ChangoVision2/html/admin_cliente.php', '2026-05-19 22:37:50'),
(4, 2, 'juan123', 'Cambio de estado de cliente', 'Se activado la cuenta del cliente \'Cesar\'', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '/ChangoVision2/html/admin_cliente.php', '2026-05-19 22:46:39'),
(5, 2, 'juan123', 'Cambio de estado de cliente', 'Se desactivado la cuenta del cliente \'Cesar\'', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '/ChangoVision2/html/admin_cliente.php', '2026-05-19 22:46:41'),
(6, 2, 'juan123', 'Edición de cliente', 'Se editó la información del cliente: Cesar', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '/ChangoVision2/html/admin_cliente.php', '2026-05-19 22:47:29'),
(7, 2, 'juan123', 'Eliminación de cliente', 'Se eliminó al cliente \'Cesar Sullca\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '/ChangoVision2/html/admin_cliente.php', '2026-05-19 22:48:14'),
(8, 2, 'juan123', 'Eliminación de cliente', 'Se eliminó al cliente \'cesar sullca\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '/ChangoVision2/html/admin_cliente.php', '2026-05-19 22:48:16'),
(9, 2, 'juan123', 'Registro de cliente', 'Se registró un nuevo cliente: humberto', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '/ChangoVision2/html/admin_cliente.php', '2026-05-19 22:48:32'),
(10, 2, 'juan123', 'Edición de cliente', 'Se editó la información del cliente: humberto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '/ChangoVision2/html/admin_cliente.php', '2026-05-19 22:48:57'),
(11, 2, 'juan123', 'Cierre de sesión', 'El usuario \'juan123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '/ChangoVision2/html/logout.php', '2026-05-19 23:38:58'),
(12, 2, 'juan123', 'Cierre de sesión', 'El usuario \'juan123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '/ChangoVision2/html/logout.php', '2026-05-19 23:40:42'),
(13, 2, 'juan123', 'Cierre de sesión', 'El usuario \'juan123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/ChangoVision2/html/logout.php', '2026-05-26 23:55:20'),
(14, 2, 'juan123', 'Cierre de sesión', 'El usuario \'juan123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/ChangoVision2/html/logout.php', '2026-05-26 23:58:30'),
(15, 2, 'juan123', 'Cambio de estado de cliente', 'Se desactivado la cuenta del cliente \'lucas\'', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-05-29 20:20:43'),
(16, 2, 'juan123', 'Cambio de estado de cliente', 'Se activado la cuenta del cliente \'lucas\'', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-05-29 20:20:48'),
(17, 2, 'juan123', 'Registro de cliente', 'Se registró un nuevo cliente: lucas', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-05-29 20:21:07'),
(18, 2, 'juan123', 'Edición de cliente', 'Se editó la información del cliente: lucas fwe', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-05-29 20:21:17'),
(19, 2, 'juan123', 'Eliminación de cliente', 'Se eliminó al cliente \'lucas fwe\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-05-29 20:21:21'),
(20, 2, 'juan123', 'Eliminación de cliente', 'Se eliminó al cliente \'lucas\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-05-29 20:21:30'),
(21, 2, 'juan123', 'Cierre de sesión', 'El usuario \'juan123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-05-29 20:29:04'),
(22, 2, 'juan123', 'Cierre de sesión', 'El usuario \'juan123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-02 22:10:09'),
(23, 2, 'juan123', 'Cierre de sesión', 'El usuario \'juan123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-02 22:21:01'),
(24, 2, 'juan123', 'Cierre de sesión', 'El usuario \'juan123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-02 23:06:36'),
(25, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-03 22:13:23'),
(26, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-03 22:15:32'),
(27, 2, 'juan123', 'Cierre de sesión', 'El usuario \'juan123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-03 22:15:41'),
(28, 56, 'cesar12', 'Cambio de estado de cliente', 'Se activado la cuenta del cliente \'Valentin\'', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-03 22:16:17'),
(29, 56, 'cesar12', 'Cambio de estado de cliente', 'Se desactivado la cuenta del cliente \'Valentin\'', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-03 22:16:29'),
(30, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-03 22:24:52'),
(31, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-03 22:48:23'),
(32, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-03 23:13:20'),
(33, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-03 23:15:10'),
(34, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-04 14:22:23'),
(35, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-04 15:11:36'),
(36, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-05 22:21:44'),
(37, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-05 23:57:57'),
(38, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-09 17:02:33'),
(39, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-09 21:49:10'),
(40, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0', '/Chango%20Vision/logout.php', '2026-06-09 21:50:13'),
(41, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-09 22:43:16'),
(42, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-09 22:59:59'),
(43, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-09 23:11:36'),
(44, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-09 23:12:06'),
(45, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-09 23:12:38'),
(46, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-11 14:32:37'),
(47, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-11 14:33:15'),
(48, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-11 14:50:01'),
(49, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-12 18:04:10'),
(50, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-12 18:07:17'),
(51, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-12 18:48:09'),
(52, 56, 'cesar12', 'Edición de cliente', 'Se editó la información del cliente: humberto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-12 18:49:34'),
(53, 56, 'cesar12', 'Edición de cliente', 'Se editó la información del cliente: Valentin', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-12 18:49:42'),
(54, 56, 'cesar12', 'Edición de cliente', 'Se editó la información del cliente: Cesar', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-12 18:49:51'),
(55, 56, 'cesar12', 'Edición de cliente', 'Se editó la información del cliente: Cesar', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-12 18:49:59'),
(56, 56, 'cesar12', 'Edición de cliente', 'Se editó la información del cliente: Dias Tisiano', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-12 18:50:10'),
(57, 56, 'cesar12', 'Edición de cliente', 'Se editó la información del cliente: Alexis Quiroga', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-12 18:50:19'),
(58, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'Jose Sullca\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-12 18:50:28'),
(59, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'Diaz Tisiano\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-12 18:50:33'),
(60, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-12 22:11:15'),
(61, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-12 22:44:10'),
(62, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-12 22:57:49'),
(63, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-12 22:58:13'),
(64, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-12 23:00:22'),
(65, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-12 23:06:37'),
(66, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-13 16:17:25'),
(67, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-13 16:17:48'),
(68, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-13 16:21:29'),
(69, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-13 21:30:52'),
(70, 56, 'cesar12', 'Edición de cliente', 'Se editó la información del cliente: humberto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-13 21:31:30'),
(71, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-13 21:32:14'),
(72, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-17 14:37:19'),
(73, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-17 14:54:32'),
(74, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-17 15:03:11'),
(75, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-17 15:04:16'),
(76, 56, 'cesar12', 'Edición de cliente', 'Se editó la información del cliente: humberto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-17 15:05:31'),
(77, 56, 'cesar12', 'Cambio de estado de cliente', 'Se activado la cuenta del cliente \'Cesar\'', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-17 15:05:54'),
(78, 56, 'cesar12', 'Edición de cliente', 'Se editó la información del cliente: Cesar', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-17 15:06:19'),
(79, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-17 21:23:06'),
(80, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-17 21:30:25'),
(81, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-17 22:11:48'),
(82, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-17 22:22:53'),
(83, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-17 22:24:47'),
(84, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-17 22:25:47'),
(85, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-17 22:26:59'),
(86, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'humberto\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-17 22:27:19'),
(87, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'Valentin\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-17 22:27:21'),
(88, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'Cesar\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-17 22:27:23'),
(89, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'Alexis Quiroga\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-17 22:27:25'),
(90, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'Cesar\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-17 22:27:27'),
(91, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'Dias Tisiano\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-17 22:27:29'),
(92, 56, 'cesar12', 'Registro de cliente', 'Se registró un nuevo cliente: humberto ormeño', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-17 22:29:31'),
(93, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-17 22:29:47'),
(94, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-17 22:30:29'),
(95, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-17 22:44:01'),
(96, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'humberto ormeño\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-17 22:44:25'),
(97, 56, 'cesar12', 'Registro de cliente', 'Se registró un nuevo cliente: Lucas Peña', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-17 22:44:54'),
(98, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-17 22:46:28'),
(99, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-17 23:13:57'),
(100, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'Lucas Peña\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-19 22:05:36'),
(101, 56, 'cesar12', 'Registro de cliente', 'Se registró un nuevo cliente: Ormeño Humberto', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-19 22:47:09'),
(102, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-19 22:48:36'),
(103, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-19 22:49:59'),
(104, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'Ormeño Humberto\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-19 22:50:16'),
(105, 56, 'cesar12', 'Registro de cliente', 'Se registró un nuevo cliente: luis', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-19 22:50:41'),
(106, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-19 22:59:12'),
(107, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-19 22:59:53'),
(108, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-19 23:01:50'),
(109, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-19 23:02:19'),
(110, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'luis\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-19 23:02:45'),
(111, 56, 'cesar12', 'Registro de cliente', 'Se registró un nuevo cliente: Valentin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-19 23:03:53'),
(112, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-19 23:03:59'),
(113, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-20 20:52:27'),
(114, 56, 'cesar12', 'Registro de cliente', 'Se registró un nuevo cliente: proyector benq', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-20 21:00:17'),
(115, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'proyector benq\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-20 21:06:57'),
(116, 56, 'cesar12', 'Registro de cliente', 'Se registró un nuevo cliente: proyector benq', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-20 21:07:25'),
(117, 56, 'cesar12', 'Registro de cliente', 'Se registró un nuevo cliente: bger', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-20 21:11:44'),
(118, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'bger\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-20 21:28:11'),
(119, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'proyector benq\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-20 21:28:23'),
(120, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'Valentin\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-20 21:29:25'),
(121, 56, 'cesar12', 'Registro de cliente', 'Se registró un nuevo cliente: Internet Premium', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-20 21:29:41'),
(122, 56, 'cesar12', 'Registro de cliente', 'Se registró un nuevo cliente: Valentin Caliva', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-20 21:30:41'),
(123, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-20 22:19:01'),
(124, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-22 16:42:47'),
(125, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-22 17:03:38'),
(126, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-22 17:04:19'),
(127, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'Valentin Caliva\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-22 17:04:39'),
(128, 56, 'cesar12', 'Eliminación de cliente', 'Se eliminó al cliente \'Internet Premium\' del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-22 17:04:42'),
(129, 56, 'cesar12', 'Registro de cliente', 'Se registró un nuevo cliente: cesar sullca', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-22 17:05:42'),
(130, 56, 'cesar12', 'Registro de cliente', 'Se registró un nuevo cliente: Yenni', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-22 17:06:21'),
(131, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-22 17:07:55'),
(132, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-22 18:32:20'),
(133, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-22 18:32:37'),
(134, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-22 18:34:28'),
(135, 4, 'carlos123', 'Cierre de sesión', 'El usuario \'carlos123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-22 19:07:26'),
(136, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-22 20:32:55'),
(137, 4, 'carlos123', 'Cierre de sesión', 'El usuario \'carlos123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-22 20:33:06'),
(138, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-22 20:48:18'),
(139, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-22 20:49:57'),
(140, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-22 20:50:28'),
(141, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-22 20:50:57'),
(142, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-22 21:45:19'),
(143, 56, 'cesar12', 'Edición de cliente', 'Se editó la información del cliente: cesar sullca', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-23 22:36:59'),
(144, 56, 'cesar12', 'Edición de cliente', 'Se editó la información del cliente: cesar sullca', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-23 22:37:05'),
(145, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-23 22:52:11'),
(146, 4, 'carlos123', 'Cierre de sesión', 'El usuario \'carlos123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-06-23 22:53:22'),
(147, 56, 'cesar12', 'Registro de cliente', 'Se registró un nuevo cliente: cesar', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-24 00:51:04'),
(148, 56, 'cesar12', 'Edición de cliente', 'Se editó la información del cliente: cesar', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-06-24 01:54:29'),
(149, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-24 19:07:21'),
(150, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-30 18:53:23'),
(151, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-30 18:54:06'),
(152, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-30 20:24:13'),
(153, 4, 'carlos123', 'Cierre de sesión', 'El usuario \'carlos123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-30 20:28:23'),
(154, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-30 20:47:04'),
(155, 4, 'carlos123', 'Cierre de sesión', 'El usuario \'carlos123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-06-30 20:53:00'),
(156, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-01 19:14:24'),
(157, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-07-01 20:23:33'),
(158, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-07-01 20:24:02'),
(159, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-07-01 20:35:26'),
(160, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-07-01 21:18:09'),
(161, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-07-03 20:06:14'),
(162, 3, 'maria123', 'Cierre de sesión', 'El usuario \'maria123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-03 20:07:03'),
(163, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-07-03 20:08:52'),
(164, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-04 21:04:19'),
(165, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-04 21:04:49'),
(166, 4, 'carlos123', 'Cierre de sesión', 'El usuario \'carlos123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-04 21:11:06'),
(167, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-08 21:45:34'),
(168, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-08 21:56:32'),
(169, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-08 21:59:38'),
(170, 4, 'carlos123', 'Cierre de sesión', 'El usuario \'carlos123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-08 22:11:21'),
(171, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-07-09 21:39:35'),
(172, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 OPR/132.0.0.0', '/Chango%20Vision/logout.php', '2026-07-09 21:44:59'),
(173, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-10 12:43:39'),
(174, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-10 12:43:51'),
(175, 57, 'lucas123', 'Cierre de sesión', 'El usuario \'lucas123\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-10 13:12:59');
INSERT INTO `log` (`id_log`, `id_usuario`, `usuario`, `accion`, `descripcion`, `tipo`, `ip_address`, `user_agent`, `pagina`, `fecha_registro`) VALUES
(176, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-10 16:29:08'),
(177, 56, 'cesar12', 'Cierre de sesión', 'El usuario \'cesar12\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-28 14:25:54'),
(178, 58, 'humvevo', 'Cierre de sesión', 'El usuario \'humvevo\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-28 21:28:58'),
(179, 60, 'juan21', 'Cierre de sesión', 'El usuario \'juan21\' cerró su sesión', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/logout.php', '2026-07-28 21:49:54'),
(180, 57, 'lucas123', 'Cerrar Sesión', 'Usuario: lucas123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-28 22:32:01'),
(181, 60, 'juan21', 'Editar Cliente', 'Cliente: prueba hsdtdth (ID: 79) - DNI: 7635225 - Teléfono: 985726246 - Barrio ID: 13', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-07-28 22:55:02'),
(182, 60, 'juan21', 'Editar Cliente', 'Se editó el cliente: sexsar mretnrb', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-07-28 22:58:50'),
(183, 60, 'juan21', 'Crear Cliente', 'Se creó el cliente: Marcos Yaleva (Código: MY1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-07-28 23:00:01'),
(184, 60, 'juan21', 'Eliminar Cliente', 'Se eliminó el cliente:   (Código: )', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-07-28 23:03:24'),
(185, 60, 'juan21', 'Eliminar Cliente', 'Se eliminó el cliente:   (Código: )', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-07-28 23:03:53'),
(186, 60, 'juan21', 'Eliminar Cliente', 'Se eliminó el cliente:   (Código: )', 'warning', '::1', 'Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-07-28 23:04:04'),
(187, 60, 'juan21', 'Eliminar Cliente', 'Se eliminó el cliente:   (Código: )', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-07-28 23:09:23'),
(188, 60, 'juan21', 'Eliminar Cliente', 'Se eliminó el cliente:   (Código: )', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-07-28 23:09:24'),
(189, 60, 'juan21', 'Eliminar Cliente', 'Se eliminó el cliente:   (Código: )', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-07-28 23:09:26'),
(190, 60, 'juan21', 'Eliminar Cliente', 'Se eliminó el cliente:   (Código: )', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-07-28 23:09:30'),
(191, 60, 'juan21', 'Crear Cliente', 'Se creó el cliente: JOse Sanchex (Código: JS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-07-28 23:09:57'),
(192, 60, 'juan21', 'Registrar Pago', 'Se registró un pago de $30.000 para: JOse Sanchex - Método: efectivo - PRIMER PAGO', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-07-28 23:10:03'),
(193, 57, 'lucas123', 'Editar Usuario', 'Se editó el usuario: maria123 (Rol: )', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-28 23:18:38'),
(194, 57, 'lucas123', 'Editar Usuario', 'Se editó el usuario: maria123 (Rol: )', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-28 23:18:43'),
(195, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: pedro dewfwef', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 12:30:54'),
(196, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Jose Sanchex', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 12:31:07'),
(197, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: lucas aertnerta', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 12:32:13'),
(198, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/logout.php', '2026-07-29 12:32:28'),
(199, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente:   (Código: )', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 12:34:01'),
(200, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente:   (Código: )', 'warning', '::1', 'Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 12:34:23'),
(201, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Jose Sanchex (Código: JS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 12:36:32'),
(202, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Yoni Sullca (Código: YS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 12:38:14'),
(203, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Yona Sullca', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 12:38:36'),
(204, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $50.000 para: Yona Sullca - Método: efectivo - PRIMER PAGO', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 12:38:54'),
(205, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Yona Sullca (Código: YS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 12:39:11'),
(206, 57, 'lucas123', 'Eliminar Usuario', 'Se eliminó el usuario: pepe21', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-29 12:53:16'),
(207, 57, 'lucas123', 'Crear Usuario', 'Se creó el usuario: efwewe (Rol: tecnico)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-29 12:53:53'),
(208, 57, 'lucas123', 'Editar Usuario', 'Se editó el usuario: efwewe (Rol: tecnico)', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-29 12:55:07'),
(209, 57, 'lucas123', 'Eliminar Usuario', 'Se eliminó el usuario: efwewe', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-29 12:56:35'),
(210, 57, 'lucas123', 'Eliminar Usuario', 'Se eliminó el usuario: juan21', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-29 12:57:52'),
(211, 57, 'lucas123', 'Crear Usuario', 'Se creó el usuario: efwfwe (Rol: cobrador)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-29 12:58:26'),
(212, 57, 'lucas123', 'Reenviar Correo', 'Se reenvió el correo a: efwfwe - Email: 34634dgrdr@f.fe', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-29 12:58:36'),
(213, 57, 'lucas123', 'Cerrar Sesión', 'Usuario: lucas123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/logout.php', '2026-07-29 13:22:54'),
(214, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/logout.php', '2026-07-29 13:24:41'),
(215, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/logout.php', '2026-07-29 13:25:01'),
(216, 57, 'lucas123', 'Eliminar Usuario', 'Se eliminó el usuario: efwfwe', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-29 21:24:46'),
(217, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: lucas aertnerta (Código: FA1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 21:47:13'),
(218, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: pedro dewfwef (Código: PD1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 21:47:16'),
(219, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Alex Perea (Código: AP1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 21:48:32'),
(220, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Marcos Yaleva (Código: MY1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 21:51:04'),
(221, 4, 'carlos123', 'Crear Solicitud', 'Solicitud: Sin cable - Cliente ID: 90 - Prioridad: baja', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-07-29 21:52:10'),
(222, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Jose Sanchez (Código: JS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 21:53:25'),
(223, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Juan Villca (Código: JV1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 21:54:25'),
(224, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Bruno Samguinatei (Código: BS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 22:09:02'),
(225, 57, 'lucas123', 'Cambiar Estado Solicitud', 'Solicitud ID: 19 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-07-29 22:22:54'),
(226, 58, 'humvevo', 'Crear Solicitud', 'Solicitud: router fallando - Cliente ID: 93 - Prioridad: alta', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-07-29 22:26:47'),
(227, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/logout.php', '2026-07-29 22:30:03'),
(228, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $30.000 para: Bruno Samguinatei - Método: efectivo - PRIMER PAGO', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 22:30:24'),
(229, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-29 22:35:12'),
(230, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Brunos Samguinatei', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 22:39:00'),
(231, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Bruno Samguinatei', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 22:39:11'),
(232, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Bruno Samguinatei (Código: BS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 22:40:53'),
(233, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/logout.php', '2026-07-29 22:41:08'),
(234, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $50.000 para: Alex Perea - Método: efectivo - PRIMER PAGO', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 22:54:36'),
(235, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Alexis Perea', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 22:54:42'),
(236, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $30.000 para: Jose Sanchez - Método: efectivo - PRIMER PAGO', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 23:08:47'),
(237, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $50.000 para: Juan Villca - Método: efectivo - PRIMER PAGO', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-29 23:13:32'),
(238, 57, 'lucas123', 'Editar Usuario', 'Se editó el usuario: humvevo (Rol: admin)', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-30 12:38:56'),
(239, 57, 'lucas123', 'Crear Usuario', 'Se creó el usuario: luis432 (Rol: tecnico)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-30 12:39:48'),
(240, 57, 'lucas123', 'Editar Usuario', 'Se editó el usuario: luis432 (Rol: tecnico)', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-30 12:39:57'),
(241, 57, 'lucas123', 'Eliminar Usuario', 'Se eliminó el usuario: luis432', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-30 12:40:14'),
(242, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: cesar sullca fsfes (Código: CF1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-30 13:44:15'),
(243, 57, 'lucas123', 'Crear Usuario', 'Se creó el usuario: fefe2 (Rol: tecnico)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-30 13:53:47'),
(244, 57, 'lucas123', 'Reenviar Correo', 'Se reenvió el correo a: fefe2 - Email: fferr@feef.fe', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-30 13:53:57'),
(245, 57, 'lucas123', 'Eliminar Usuario', 'Se eliminó el usuario: fefe2', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/usuarios.php', '2026-07-30 13:53:58'),
(246, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-30 14:00:01'),
(247, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-30 14:07:30'),
(248, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $30.000 para: cesar sullca fsfes - Método: efectivo - PRIMER PAGO', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-31 22:06:44'),
(249, 58, 'humvevo', 'Crear Solicitud', 'Solicitud: rfe - Cliente ID: 91 - Prioridad: alta', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-07-31 22:10:53'),
(250, 58, 'humvevo', 'Asignar Técnico', 'Solicitud ID: 21 → Técnico ID: 4', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-07-31 22:11:01'),
(251, 58, 'humvevo', 'Crear Solicitud', 'Solicitud: vr rvr - Cliente ID: 89 - Prioridad: baja', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-07-31 22:11:53'),
(252, 4, 'carlos123', 'Crear Solicitud', 'Solicitud: frerfer f - Cliente ID: 94 - Prioridad: media', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-07-31 22:13:59'),
(253, 4, 'carlos123', 'Crear Solicitud', 'Solicitud: cen - Cliente ID: 89 - Prioridad: media - Técnico ID: 4', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-07-31 22:43:37'),
(254, 58, 'humvevo', 'Crear Solicitud', 'Solicitud: brtdrt - Cliente ID: 92 - Prioridad: media - Técnico ID: 4', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-07-31 22:44:22'),
(255, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/logout.php', '2026-07-31 23:19:54'),
(256, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Marcos Yaleva (Código: MY1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-31 23:20:21'),
(257, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-07-31 23:20:35'),
(258, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: humberto ght (Código: HG1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-31 23:36:42'),
(259, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: sgrrg srgsrg (Código: SS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-07-31 23:46:50'),
(260, 57, 'lucas123', 'Editar Cliente', 'Se editó el cliente: rfgefwre srgsrg', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-07-31 23:55:46'),
(261, 57, 'lucas123', 'Registrar Pago', 'Se registró un pago de $50.000 para: humberto ght - Método: efectivo - PRIMER PAGO', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-01 00:02:42'),
(262, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-01 00:04:21'),
(263, 57, 'lucas123', 'Crear Tarea Soporte', 'Tarea de conexión creada para: rfgefwre srgsrg (Primer pago) - Cliente ID: 96', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-01 00:09:18'),
(264, 57, 'lucas123', 'Registrar Pago', 'Se registró un pago de $50.000 para: rfgefwre srgsrg - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-01 00:09:18'),
(265, 57, 'lucas123', 'Crear Cliente', 'Se creó el cliente: Damiel Sullca (Código: DS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-01 00:10:21'),
(266, 57, 'lucas123', 'Crear Tarea Soporte', 'Tarea de conexión creada para: Damiel Sullca (Primer pago) - Cliente ID: 97', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-01 00:10:33'),
(267, 57, 'lucas123', 'Registrar Pago', 'Se registró un pago de $30.000 para: Damiel Sullca - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-01 00:10:33'),
(268, 57, 'lucas123', 'Cerrar Sesión', 'Usuario: lucas123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/logout.php', '2026-08-01 12:49:11'),
(269, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: grgd gsrgsr (Código: GG1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-01 13:09:22'),
(270, 58, 'humvevo', 'Crear Tarea Soporte', 'Tarea de conexión creada para: grgd gsrgsr (Primer pago) - Cliente ID: 98', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-01 13:11:17'),
(271, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $50.000 para: grgd gsrgsr - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-01 13:11:17'),
(272, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: humberto ght (Código: HG1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-01 13:51:43'),
(273, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: humberto fsaese (Código: HF1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-01 13:52:15'),
(274, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: humberto fsaese (Código: HF2)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-01 13:52:47'),
(275, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Alexisrew Perea', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-01 13:53:09'),
(276, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Alexisrew Perea', 'info', '::1', 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-01 13:53:19'),
(277, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Alexisrew Perea', 'info', '::1', 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-01 13:56:15'),
(278, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: dfdrgdrg rgergergr (Código: DR1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-01 13:56:37'),
(279, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Damiel Sullca (Código: DS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-01 13:57:01'),
(280, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 26 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-01 13:58:12'),
(281, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: grgd gsrgsr (Código: GG1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-01 14:00:17'),
(282, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-01 14:03:14'),
(283, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 23 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-01 14:17:29'),
(284, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 22 → pendiente', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-01 14:24:34'),
(285, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 22 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-01 14:24:43'),
(286, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 24 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-01 14:24:51'),
(287, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 21 → pendiente', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-01 14:31:16'),
(288, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 21 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-01 14:31:19'),
(289, 57, 'lucas123', 'Cerrar Sesión', 'Usuario: lucas123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-01 14:54:44'),
(290, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Alexisrew Perea', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-01 14:56:05'),
(291, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Pedro gdrsdr (Código: PG1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-01 15:05:19'),
(292, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: gaewragesrg gadrgad (Código: GG1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-01 15:10:29'),
(293, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Perea Alex (Código: PA1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-01 15:21:01'),
(294, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-05 21:17:46'),
(295, 57, 'lucas123', 'Crear Usuario', 'Se creó el usuario: alexis21 (Rol: admin)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/usuarios.php', '2026-08-05 21:22:33'),
(296, 66, 'alexis21', 'Crear Tarea Soporte', 'Tarea de conexión creada para: dfdrgdrg rgergergr (Primer pago) - Cliente ID: 101', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-05 21:38:49'),
(297, 66, 'alexis21', 'Registrar Pago', 'Se registró un pago de $5.000 para: dfdrgdrg rgergergr - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-05 21:38:49'),
(298, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: Jose Sanchez (Código: JS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-05 21:52:41'),
(299, 66, 'alexis21', 'Crear Cliente', 'Se creó el cliente: Yair Sullca (Código: YS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-05 22:04:02'),
(300, 66, 'alexis21', 'Crear Tarea Soporte', 'Tarea de conexión creada para: Yair Sullca (Primer pago) - Cliente ID: 105', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php?pagina=3', '2026-08-05 22:04:26'),
(301, 66, 'alexis21', 'Registrar Pago', 'Se registró un pago de $50.000 para: Yair Sullca - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/admin_cliente.php?pagina=3', '2026-08-05 22:04:26'),
(302, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: Alexisrew Perea (Código: AP1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 12:47:14'),
(303, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: cesar sullca fsfes (Código: CF1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 12:47:18'),
(304, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: dfdrgdrg rgergergr (Código: DR1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 12:47:21'),
(305, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: gaewragesrg gadrgad (Código: GG1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 12:47:25'),
(306, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: humberto fsaese (Código: HF1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 12:47:29'),
(307, 66, 'alexis21', 'Crear Cliente', 'Se creó el cliente: alrx Cruz (Código: AC1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 12:47:57'),
(308, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: alrx Cruz (Código: AC1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 12:48:03'),
(309, 66, 'alexis21', 'Crear Cliente', 'Se creó el cliente: Alex Cruz (Código: AC1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 12:48:45'),
(310, 66, 'alexis21', 'Editar Cliente', 'Se editó el cliente: Alex Cruz', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 12:49:48'),
(311, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: humberto fsaese (Código: HF2)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 13:05:01'),
(312, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: Juan Villca (Código: JV1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 13:05:04'),
(313, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: Pedro gdrsdr (Código: PG1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 13:05:07'),
(314, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: Perea Alex (Código: PA1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 13:05:10'),
(315, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: rfgefwre srgsrg (Código: SS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 13:05:14'),
(316, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: Yair Sullca (Código: YS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 13:05:17'),
(317, 66, 'alexis21', 'Crear Cliente', 'Se creó el cliente: Cesar Sullca (Código: CS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 13:06:01'),
(318, 66, 'alexis21', 'Editar Cliente', 'Se editó el cliente: Cesar Sullca', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 13:06:18'),
(319, 66, 'alexis21', 'Crear Cliente', 'Se creó el cliente: Jose Sullca (Código: JS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 13:18:17'),
(320, 66, 'alexis21', 'Editar Cliente', 'Se editó el cliente: Jose Sullca', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 13:18:38'),
(321, 66, 'alexis21', 'Crear Cliente', 'Se creó el cliente: Daniel Sullca (Código: DS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 13:19:22'),
(322, 66, 'alexis21', 'Crear Cliente', 'Se creó el cliente: Yair Suññca (Código: YS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 13:25:51'),
(323, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: Yair Suññca (Código: YS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 13:26:14'),
(324, 66, 'alexis21', 'Eliminar Cliente', 'Se eliminó el cliente: Daniel Sullca (Código: DS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-06 13:26:18'),
(325, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-11 12:57:40'),
(326, 58, 'humvevo', 'Crear Solicitud', 'Solicitud: ergerger - Cliente ID: 109 - Prioridad: media - Técnico ID: 4', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-11 12:58:52'),
(327, 58, 'humvevo', 'Cambiar Estado Solicitud', 'Solicitud ID: 31 → resuelto - Comentario: ya se pudo resolver el problema', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-11 12:59:34'),
(328, 57, 'lucas123', 'Cerrar Sesión', 'Usuario: lucas123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-11 13:36:22'),
(329, 58, 'humvevo', 'Crear Tarea Soporte', 'Tarea de conexión creada para: Alex Cruz (Primer pago) - Cliente ID: 107', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-11 13:37:46'),
(330, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $50.000 para: Alex Cruz - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-11 13:37:46'),
(331, 57, 'lucas123', 'Cerrar Sesión', 'Usuario: lucas123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-11 21:21:56'),
(332, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Alex Cruz (Código: AC1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-11 22:07:44'),
(333, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Cesar Sullca (Código: CS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-11 22:07:47'),
(334, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Jose Sullca (Código: JS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-11 22:07:52'),
(335, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Carlos Gómez (Código: CG1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-11 22:08:33'),
(336, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Mariana Fernández (Código: MF1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-11 22:10:55'),
(337, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Lucas Benítez (Código: LB1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-11 22:24:53'),
(338, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Sofía Morales (Código: SM1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-11 22:26:06'),
(339, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Gonzalo Romero (Código: GR1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-12 21:18:10'),
(340, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Lucía Alvarez (Código: LA1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-12 21:21:16'),
(341, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Mateo Castro (Código: MC1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-12 21:22:32'),
(342, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Valeria Díaz (Código: VD1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-12 21:24:08'),
(343, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Facundo Silva (Código: FS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-12 21:25:16'),
(344, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Camila Rojas (Código: CR1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-12 21:27:08');
INSERT INTO `log` (`id_log`, `id_usuario`, `usuario`, `accion`, `descripcion`, `tipo`, `ip_address`, `user_agent`, `pagina`, `fecha_registro`) VALUES
(345, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Mauricio Pozito (Código: MP1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-12 21:28:48'),
(346, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Micaela Peralta (Código: MP2)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-12 21:33:47'),
(347, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Benjamín Páez (Código: BP1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-12 21:34:38'),
(348, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Valentina Mercado (Código: VM1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-12 21:35:15'),
(349, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Benjamín Páez', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-12 21:35:29'),
(350, 58, 'humvevo', 'Crear Solicitud', 'Solicitud: sin señal de internet - Cliente ID: 115 - Prioridad: media - Técnico ID: 4', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-12 21:43:33'),
(351, 58, 'humvevo', 'Crear Tarea Soporte', 'Tarea de conexión creada para: Benjamín Páez (Primer pago) - Cliente ID: 124', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-12 21:44:24'),
(352, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $50.000 para: Benjamín Páez - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-12 21:44:24'),
(353, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-12 22:02:11'),
(354, 57, 'lucas123', 'Crear Usuario', 'Se creó el usuario: cesar21 (Rol: tecnico)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/usuarios.php', '2026-08-12 22:05:09'),
(355, 57, 'lucas123', 'Crear Solicitud', 'Solicitud: internte - Cliente ID: 123 - Prioridad: baja - Técnico ID: 67', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-12 22:07:07'),
(356, 57, 'lucas123', 'Cerrar Sesión', 'Usuario: lucas123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-12 22:07:19'),
(357, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 34 → resuelto - Comentario: fr', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-12 22:07:38'),
(358, 67, 'cesar21', 'Cambiar Estado Solicitud', 'Solicitud ID: 35 → resuelto - Comentario: ege', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-12 22:07:47'),
(359, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-12 22:09:43'),
(360, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $30.000 para: Valeria Díaz - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=3', '2026-08-13 13:37:00'),
(361, 67, 'cesar21', 'Cerrar Sesión', 'Usuario: cesar21 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0', '/Chango%20Vision/logout.php', '2026-08-13 13:42:43'),
(362, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Benjamín Páez', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-13 13:47:04'),
(363, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Camila Rojas', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-13 13:47:18'),
(364, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Carlos Gómez', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-13 13:47:34'),
(365, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Gonzalo Romero', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-13 13:47:44'),
(366, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Facundo Silva', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-13 13:47:55'),
(367, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Mauricio Pozito', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-13 13:49:05'),
(368, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: HUmberto Homeño (Código: HH1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-14 00:51:56'),
(369, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: HUmberto Homeño (Código: HH1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 00:52:28'),
(370, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Humberto Ormeño (Código: HO1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 00:53:04'),
(371, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Humberto Ormeño', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 00:53:59'),
(372, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Humberto Ormeño (Código: HO1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 00:54:20'),
(373, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Hmberto Ormeño (Código: HO1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 00:55:07'),
(374, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Hmberto Ormeño (Código: HO1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 01:03:52'),
(375, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: humberto Ormeño (Código: HO1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 01:05:36'),
(376, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: humberto Ormeño', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 01:05:53'),
(377, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: humberto Ormeño (Código: HO1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 01:06:23'),
(378, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Humbeto ORmeño (Código: HO1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 01:07:12'),
(379, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Humbeto ORmeño (Código: HO1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 01:08:12'),
(380, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: humbeto pes (Código: HP1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 01:08:49'),
(381, 58, 'humvevo', 'Crear Solicitud', 'Solicitud ID: 36 - Cliente ID: 131 - Prioridad: baja - Sin técnico asignado', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 02:05:07'),
(382, 58, 'humvevo', 'Crear Solicitud', 'Solicitud ID: 37 - Cliente ID: 121 - Prioridad: alta - Tarea general de técnicos', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 02:46:30'),
(383, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 37 → en_progreso - Comentario: casi', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 02:46:57'),
(384, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 37 → cerrado', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 02:47:14'),
(385, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 37 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 02:47:21'),
(386, 58, 'humvevo', 'Crear Solicitud', 'Solicitud ID: 38 - Cliente ID: 120 - Prioridad: baja - Tarea general de técnicos', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:19:24'),
(387, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 38 → en_progreso - Comentario: revisar tood', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:19:52'),
(388, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 38 → cerrado - Comentario: el señor no se eunctra en domiciolio', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:20:09'),
(389, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 36 → en_progreso - Comentario: proento', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:21:24'),
(390, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 37 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:21:44'),
(391, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 34 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:21:47'),
(392, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 33 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:21:50'),
(393, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 38 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:21:54'),
(394, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 36 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:21:57'),
(395, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 35 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:21:59'),
(396, 58, 'humvevo', 'Crear Solicitud', 'Solicitud ID: 39 - Cliente ID: 124 - Prioridad: media - Tarea general de técnicos', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:53:44'),
(397, 58, 'humvevo', 'Crear Solicitud', 'Solicitud ID: 40 - Cliente ID: 120 - Prioridad: media - Tarea general de técnicos', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:54:37'),
(398, 58, 'humvevo', 'Crear Solicitud', 'Solicitud ID: 41 - Cliente ID: 118 - Prioridad: media - Tarea general de técnicos', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:54:52'),
(399, 58, 'humvevo', 'Crear Solicitud', 'Solicitud ID: 42 - Cliente ID: 131 - Prioridad: media - Tarea general de técnicos', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:55:49'),
(400, 58, 'humvevo', 'Crear Solicitud', 'Solicitud ID: 43 - Cliente ID: 118 - Prioridad: baja - Tarea general de técnicos', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:56:32'),
(401, 4, 'carlos123', 'Crear Solicitud', 'Solicitud ID: 44 - Cliente ID: 116 - Prioridad: alta - Tarea general de técnicos', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:58:13'),
(402, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 41 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:58:22'),
(403, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 44 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:58:31'),
(404, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 42 → en_progreso - Comentario: fe fes', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 13:59:27'),
(405, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-14 14:00:00'),
(406, 67, 'cesar21', 'Cerrar Sesión', 'Usuario: cesar21 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-14 14:01:22'),
(407, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Benjamín Páez (Código: BP1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-14 14:34:27'),
(408, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Benamisn Paes (Código: BP1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-14 14:35:20'),
(409, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Mateo Castro', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 14:48:26'),
(410, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Benamisn Paes', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-14 14:49:04'),
(411, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: humbeto pes', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 14:49:29'),
(412, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Lucas Benítez', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 14:49:38'),
(413, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Mateo Castro', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 14:49:46'),
(414, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Mariana Fernández', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 14:50:05'),
(415, 58, 'humvevo', 'Crear Tarea Corte', 'Tarea de corte creada para: humbeto pes (Motivo: Falta de pago) - Cliente ID: 131', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 14:54:51'),
(416, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: humbeto pes (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 14:54:51'),
(417, 57, 'lucas123', 'Cerrar Sesión', 'Usuario: lucas123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-14 21:19:26'),
(418, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Tiziano Dias (Código: TD1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-14 21:24:56'),
(419, 58, 'humvevo', 'Crear Tarea Soporte', 'Tarea de conexión creada para: Lucía Alvarez (Primer pago) - Cliente ID: 117', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 21:31:40'),
(420, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $5.000 para: Lucía Alvarez - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-14 21:31:40'),
(421, 58, 'humvevo', 'Crear Solicitud', 'Solicitud ID: 47 - Cliente ID: 133 - Prioridad: alta - Tarea general de técnicos', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 21:56:24'),
(422, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-14 22:09:53'),
(423, 57, 'lucas123', 'Cerrar Sesión', 'Usuario: lucas123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-14 22:11:39'),
(424, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 46 → resuelto - Comentario: solucionado', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-08-14 22:14:26'),
(425, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Benamisn Paes', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 OPR/134.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-15 14:03:28'),
(426, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: cesar sullca (Código: CS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-15 14:19:31'),
(427, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Cesar sullca', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-15 14:19:45'),
(428, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Cesar sullca (Código: CS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-15 14:19:52'),
(429, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Jose Sanchez (Código: JS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-21 21:47:04'),
(430, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Jose Sanchez', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-21 21:47:23'),
(431, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Jose Sanchez (Código: JS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-21 21:48:06'),
(432, 58, 'humvevo', 'Registrar Pago', 'Pago de $50.000 para: Jose Sanchez', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-21 21:48:17'),
(433, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: juan Sanchez', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-21 21:49:07'),
(434, 58, 'humvevo', 'Registrar Pago', 'Pago de $50.000 para: juan Sanchez', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-21 22:52:36'),
(435, 58, 'humvevo', 'Registrar Pago', 'Pago de $50.000 para: Tiziano Dias', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-21 22:52:42'),
(436, 58, 'humvevo', 'Registrar Pago', 'Pago de $540.000 (12 meses) para: Mauricio Pozito', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-21 22:56:17'),
(437, 58, 'humvevo', 'Registrar Pago', 'Pago de $45.000 para: Mateo Castro', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-25 16:22:49'),
(438, 58, 'humvevo', 'Registrar Pago', 'Pago de $45.000 para: Mateo Castro', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-25 16:22:53'),
(439, 58, 'humvevo', 'Error al Registrar Pago', 'Error al registrar pago para cliente ID: 136 - Error: Column \'nombre\' in field list is ambiguous', 'error', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 20:36:25'),
(440, 58, 'humvevo', 'Error al Registrar Pago', 'Error al registrar pago para cliente ID: 136 - Error: Column \'nombre\' in field list is ambiguous', 'error', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 20:36:32'),
(441, 58, 'humvevo', 'Error al Registrar Pago', 'Error al registrar pago para cliente ID: 123 - Error: Column \'nombre\' in field list is ambiguous', 'error', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 20:41:15'),
(442, 58, 'humvevo', 'Error al Registrar Pago', 'Error al registrar pago para cliente ID: 123 - Error: Column \'nombre\' in field list is ambiguous', 'error', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 20:41:22'),
(443, 58, 'humvevo', 'Error al Registrar Pago', 'Error al registrar pago para cliente ID: 123 - Error: Column \'nombre\' in field list is ambiguous', 'error', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 20:41:36'),
(444, 58, 'humvevo', 'Error al Registrar Pago', 'Error al registrar pago para cliente ID: 136 - Error: Column \'nombre\' in field list is ambiguous', 'error', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 21:26:52'),
(445, 58, 'humvevo', 'Error al Registrar Pago', 'Error al registrar pago para cliente ID: 136 - Error: Column \'nombre\' in field list is ambiguous', 'error', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 21:29:11'),
(446, 58, 'humvevo', 'Error al Registrar Pago', 'Error al registrar pago para cliente ID: 125 - Error: Column \'nombre\' in field list is ambiguous', 'error', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 21:30:06'),
(447, 58, 'humvevo', 'Error al Registrar Pago', 'Error al registrar pago para cliente ID: 125 - Error: Column \'nombre\' in field list is ambiguous', 'error', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 21:30:18'),
(448, 58, 'humvevo', 'Crear Tarea Soporte', 'Tarea de conexión creada para: Gonzalo Romero (Primer pago) - Cliente ID: 116', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-25 21:32:38'),
(449, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $45.000 para: Gonzalo Romero - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-25 21:32:38'),
(450, 58, 'humvevo', 'Crear Tarea Soporte', 'Tarea de conexión creada para: Sofía Morales (Primer pago) - Cliente ID: 115', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-25 21:45:05'),
(451, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $30.000 para: Sofía Morales - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-25 21:45:05'),
(452, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $45.000 para: Lucas Benítez - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-25 21:47:42'),
(453, 58, 'humvevo', 'Registrar Pago', 'Se registró un pago de $45.000 para: Mariana Fernández - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-25 21:48:36'),
(454, 58, 'humvevo', 'Registrar Pago', 'Pago de $90.000 para: Facundo Silva (2 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-25 22:05:38'),
(455, 58, 'humvevo', 'Registrar Pago', 'Pago de $135.000 para: Carlos Gómez (3 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-25 22:05:51'),
(456, 58, 'humvevo', 'Registrar Pago', 'Pago de $45.000 para: Camila Rojas (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-25 22:42:02'),
(457, 58, 'humvevo', 'Registrar Pago', 'Pago de $45.000 para: Facundo Silva (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-25 22:43:13'),
(458, 58, 'humvevo', 'Registrar Pago', 'Pago de $5.000 para: Micaela Peralta (1 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=3', '2026-08-25 22:48:02'),
(459, 58, 'humvevo', 'Registrar Pago', 'Pago de $5.000 para: Micaela Peralta (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=3', '2026-08-25 22:50:27'),
(460, 58, 'humvevo', 'Registrar Pago', 'Pago de $5.000 para: Valentina Mercado (1 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=4', '2026-08-25 22:50:37'),
(461, 58, 'humvevo', 'Registrar Pago', 'Pago de $135.000 para: Facundo Silva (3 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 22:51:18'),
(462, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Facundo Silva (Código: FS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 22:51:28'),
(463, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Benamisn Paes (Código: BP1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 22:51:32'),
(464, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Camila Rojas (Código: CR1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 22:51:34'),
(465, 58, 'humvevo', 'Registrar Pago', 'Pago de $45.000 para: Carlos Gómez (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-25 22:51:45'),
(466, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Carlos Gómez (Código: CG1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-25 22:51:51'),
(467, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Gonzalo Romero (Código: GR1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-25 22:52:55'),
(468, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: humbeto pes (Código: HP1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-25 22:52:59'),
(469, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: juan Sanchez (Código: JS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-25 22:53:01'),
(470, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Mariana Fernández (Código: MF1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-25 22:53:05'),
(471, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Luis sullca (Código: LS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-25 22:53:36'),
(472, 58, 'humvevo', 'Registrar Pago', 'Pago de $150.000 para: Luis sullca (3 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-25 22:53:44'),
(473, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Luis sullca (Código: LS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 22:54:10'),
(474, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Lucía Alvarez (Código: LA1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 22:54:12'),
(475, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Mateo Castro (Código: MC1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 22:54:17'),
(476, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Lucas Benítez (Código: LB1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 22:54:20'),
(477, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Micaela Peralta (Código: MP2)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 22:54:23'),
(478, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Lucas Peña (Código: LP1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 22:56:44'),
(479, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Sofía Morales (Código: SM1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 23:12:02'),
(480, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: pepe santos (Código: PS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 23:12:39'),
(481, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: pepe santos (Código: PS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-25 23:14:04'),
(482, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Luis Sullca (Código: LS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 00:42:02'),
(483, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Luis Sullca (Código: LS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 00:49:48'),
(484, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: luis sullca (Código: LS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 00:50:35'),
(485, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: luis sullca', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 00:58:31'),
(486, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Cesar Sullca (Código: CS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 00:59:13'),
(487, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Cesar Sullca (Código: CS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 01:03:58'),
(488, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Cesar Sullca (Código: CS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 01:04:32'),
(489, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Cesar Sullca (Código: CS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 01:05:51'),
(490, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: cesar pepe (Código: CP1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 01:06:18'),
(491, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: cesar pepe (Código: CP1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 15:27:00'),
(492, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Cesars Sullca (Código: CS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 15:27:29'),
(493, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Cesars Sullca', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 15:28:37'),
(494, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Cesars Sullca', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 17:32:34'),
(495, 58, 'humvevo', 'Registrar Pago', 'Pago de $60.000 para: Lucas Peña (12 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 18:41:37'),
(496, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Cesars Sullca (Código: CS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 18:41:49'),
(497, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: luis sullca (Código: LS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 18:41:57'),
(498, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Cesar Sullca (Código: CS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 18:42:34'),
(499, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Cesar Sullca', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 18:42:46'),
(500, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Cesar Sullca (Código: CS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 18:45:47'),
(501, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Luis Sullca (Código: LS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 18:46:22'),
(502, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: cesar Sullcfe (Código: CS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 18:47:18'),
(503, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: cesar Sullcfe', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-26 18:47:35'),
(504, 58, 'humvevo', 'Registrar Pago', 'Pago de $60.000 para: Luis Sullca (2 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-27 00:48:50'),
(505, 58, 'humvevo', 'Eliminar Cliente (Lógico)', 'Se marcó como eliminado al cliente: Luis Sullca (Código: LS1) - Motivo: Eliminación manual', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-27 00:49:05'),
(506, 58, 'humvevo', 'Registrar Pago', 'Pago de $90.000 para: cesar Sullcfe (3 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-08-27 00:49:28'),
(507, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Peña lucas (Código: PL1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=2', '2026-08-27 00:52:06');
INSERT INTO `log` (`id_log`, `id_usuario`, `usuario`, `accion`, `descripcion`, `tipo`, `ip_address`, `user_agent`, `pagina`, `fecha_registro`) VALUES
(508, 58, 'humvevo', 'Eliminar Cliente (Lógico)', 'Se marcó como eliminado al cliente: Lucas Peña (Código: LP1) - Motivo: Eliminación manual', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-27 01:02:07'),
(509, 58, 'humvevo', 'Eliminar Cliente (Lógico)', 'Se marcó como eliminado al cliente: Mauricio Pozito (Código: MP1) - Motivo: Eliminación manual', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-27 01:02:10'),
(510, 58, 'humvevo', 'Registrar Pago', 'Pago de $50.000 para: Peña lucas (1 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-28 22:35:35'),
(511, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: cesar Sullcfe (Código: CS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-28 22:35:41'),
(512, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Cesar Sullca (Código: CS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-28 22:36:21'),
(513, 58, 'humvevo', 'Registrar Pago', 'Pago de $200.000 para: Cesar Sullca (4 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-28 23:09:49'),
(514, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: cesar sadadef (Código: CS2)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 13:40:33'),
(515, 58, 'humvevo', 'Registrar Pago', 'Pago de $135.000 para: cesar sadadef (3 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 13:40:56'),
(516, 58, 'humvevo', 'Registrar Pago', 'Pago de $180.000 para: cesar sadadef (4 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 14:31:17'),
(517, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-29 14:49:23'),
(518, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-08-29 15:56:17'),
(519, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Cesar Sullca (Código: CS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:36:07'),
(520, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Lucas Peña (Código: LP1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:36:13'),
(521, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Luis Sullca (Código: LS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:36:17'),
(522, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: cesar sadadef (Código: CS2)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:36:28'),
(523, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Cesar sullca (Código: CS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:37:14'),
(524, 58, 'humvevo', 'Registrar Pago', 'Pago de $200.000 para: Cesar sullca (4 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:37:30'),
(525, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Cesar sullca (Código: CS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:37:42'),
(526, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Mauricio Pozito (Código: MP1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:37:47'),
(527, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Peña lucas (Código: PL1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:37:51'),
(528, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: luis sullca (Código: LS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:39:33'),
(529, 58, 'humvevo', 'Registrar Pago', 'Pago de $540.000 para: luis sullca (12 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:39:43'),
(530, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: cesar Asa (Código: CA1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:40:44'),
(531, 58, 'humvevo', 'Registrar Pago', 'Pago de $225.000 para: cesar Asa (5 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:41:05'),
(532, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: cesar Asa (Código: CA1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:41:22'),
(533, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: jose sullca (Código: JS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:51:48'),
(534, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: jose sullca', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 18:52:04'),
(535, 58, 'humvevo', 'Registrar Pago', 'Pago de $35.000 para: jose sullca (7 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 20:35:06'),
(536, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: cesar sullca (Código: CS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 20:36:14'),
(537, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: cesar sullca', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 20:38:00'),
(538, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: cesar sullca (Código: CS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 20:50:37'),
(539, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: pepe torres (Código: PT1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 20:51:21'),
(540, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: pepe torres (Código: PT1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 20:53:53'),
(541, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Alex hbggh (Código: AH1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 20:54:38'),
(542, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Alex hbggh', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 20:56:37'),
(543, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Alex hbggh', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 20:56:52'),
(544, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: carlos feef (Código: CF1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-08-29 21:03:10'),
(545, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: jose asasklm (Código: JA1) - Foto DNI: dni_1788221781_2775.jpg', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-01 00:16:21'),
(546, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Alex hbggh (Código: AH1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-01 00:29:05'),
(547, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: carlos feef (Código: CF1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-01 00:29:09'),
(548, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: jose sullca (Código: JS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-01 00:29:14'),
(549, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: jose asasklm (Código: JA1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-01 00:29:19'),
(550, 58, 'humvevo', 'Eliminar Cliente (Borrado Lógico)', 'Se eliminó al cliente: luis sullca (Código: LS1) - Motivo: Eliminado por administrador', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-01 00:34:14'),
(551, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: cersda asdhyiasnd (Código: CA1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-01 00:34:55'),
(552, 58, 'humvevo', 'Eliminar Cliente (Borrado Lógico)', 'Se eliminó al cliente: cersda asdhyiasnd (Código: CA1) - Motivo: Eliminado por administrador', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-01 00:35:02'),
(553, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: werwwrwr hf (Código: WH1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-01 00:36:53'),
(554, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: cersda asdhyiasnd (Código: CA1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?ajax=get_deudas_cliente&id=1', '2026-09-01 01:02:24'),
(555, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: luis sullca (Código: LS1)', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?ajax=get_deudas_cliente&id=1', '2026-09-01 01:02:28'),
(556, 58, 'humvevo', 'Registrar Pago', 'Pago de $200.000 para: werwwrwr hf (4 meses) - Método: transferencia - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-01 21:49:13'),
(557, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: efsefs gseseeg (Código: EG1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-01 23:51:12'),
(558, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: efsefs gseseeg (Código: EG1) - Motivo: boludo', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-01 23:51:32'),
(559, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Tiziano Dias (Código: TD1) - Motivo: por moroso', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-08 21:53:31'),
(560, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Valentina Mercado (Código: VM1) - Motivo: Eliminado por administrador', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-08 22:07:31'),
(561, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Carlos peres (Código: CP1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-08 22:09:08'),
(562, 58, 'humvevo', 'Registrar Pago', 'Pago de $45.000 para: Carlos peres (1 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-08 22:36:29'),
(563, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Valeria Díaz (Código: VD1) - Motivo: Sin motivo especificado', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-08 22:38:44'),
(564, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: werwwrwr hf (Código: WH1) - Motivo: Sin motivo especificado', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-08 22:39:06'),
(565, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Carlos peres (Código: CP1) - Motivo: Sin motivo especificado', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 22:39:40'),
(566, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Cesar fwe (Código: CF1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 22:41:02'),
(567, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Alexis Quiroga (Código: AQ1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 22:41:25'),
(568, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Bauty Barionuevo (Código: BB1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 22:41:57'),
(569, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: JUan villca (Código: JV1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 22:42:31'),
(570, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Bauty Barionuevo (Código: BB1) - Motivo: Sin motivo especificado', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 22:44:03'),
(571, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Alexis Quiroga (Código: AQ1) - Motivo: Sin motivo especificado', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 22:45:01'),
(572, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Cesar fwe (Código: CF1) - Motivo: Sin motivo especificado', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 22:52:49'),
(573, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: JUan villca (Código: JV1) - Motivo: Sin motivo especificado', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 22:53:56'),
(574, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: ewrteyrut kuyje (Código: EK1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 23:07:56'),
(575, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: ewrteyrut kuyje (Código: EK1) - Motivo: Eliminado por administrador', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 23:09:27'),
(576, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: cesar urterhg (Código: CU1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 23:09:55'),
(577, 58, 'humvevo', 'Registrar Pago', 'Pago de $50.000 para: cesar urterhg (1 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 23:39:12'),
(578, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: cesar urterhg (Código: CU1) - Motivo: hy', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 23:39:30'),
(579, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Alexis fwdvfsbsfb (Código: AF1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 23:40:08'),
(580, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Alexis fwdvfsbsfb (Código: AF1) - Motivo: r', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 23:40:24'),
(581, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: shtdjs fbsf (Código: SF1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 23:43:30'),
(582, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: shtdjs fbsf (Código: SF1) - Motivo: cesar', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 23:52:27'),
(583, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: MArcos wrwrg (Código: MW1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-08 23:53:02'),
(584, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: MArcos wrwrg (Motivo: Mora extendida) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-09 00:00:02'),
(585, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: MArcos wrwrg (Código: MW1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-09-09 00:00:08'),
(586, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: cesargas gsratj (Código: CG1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-09 22:09:26'),
(587, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: MArcos wrwrg (Código: MW1) - Motivo: esace', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-09 22:09:41'),
(588, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: cesargas gsratj (Motivo: Mora extendida) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-09 23:08:35'),
(589, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: cesargas gsratj (Código: CG1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-09 23:10:46'),
(590, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: cesargas gsratj (Código: CG1) - Motivo: se demro mucho', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-22 19:25:16'),
(591, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Humberto Prmeño (Código: HP1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-22 19:29:13'),
(592, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Stefano Sanguineti (Código: SS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-22 19:30:14'),
(593, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Humberto Prmeño (Código: HP1) - Motivo: moroso', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-22 22:20:56'),
(594, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: wrwrgg fweef (Código: WF1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-22 22:37:16'),
(595, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Stefano Sanguineti (Motivo: Mora extendida) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-22 22:50:02'),
(596, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: Stefano Sanguineti (Código: SS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-22 22:50:27'),
(597, 58, 'humvevo', 'Registrar Pago', 'Pago de $10.000 para: wrwrgg fweef (2 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-22 22:57:42'),
(598, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-09-22 23:23:49'),
(599, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 74 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-09-22 23:30:46'),
(600, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 73 → cerrado', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-09-22 23:32:59'),
(601, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: wrwrgg fweef (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 22:03:17'),
(602, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: wrwrgg fweef (Código: WF1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 22:03:23'),
(603, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: wrwrgg fweef (Código: WF1) - Motivo: fewef', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 22:03:33'),
(604, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Stefano Sanguineti (Código: SS1) - Motivo: fe', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 22:03:38'),
(605, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Alexis Quiroga (Código: AQ2)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 22:28:27'),
(606, 58, 'humvevo', 'Registrar Pago', 'Pago de $400.000 para: Alexis Quiroga (8 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 22:47:58'),
(607, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Alexis Quiroga (Código: AQ2) - Motivo: ew', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 23:09:21'),
(608, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Marcos Yaleva (Código: MY1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 23:10:04'),
(609, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Marcos Yaleva (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 23:39:20'),
(610, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: Marcos Yaleva (Código: MY1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 23:39:26'),
(611, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Carlos PEpe (Código: CP2)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 23:50:35'),
(612, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Carlos PEpe (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 23:51:09'),
(613, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: Carlos PEpe (Código: CP2)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 23:51:14'),
(614, 58, 'humvevo', 'Registrar Pago', 'Pago de $400.000 para: Marcos Yaleva (8 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 23:59:29'),
(615, 58, 'humvevo', 'Registrar Pago', 'Pago de $400.000 para: Carlos PEpe (8 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-23 23:59:35'),
(616, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Cesar dwewe (Código: CD1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-24 23:46:49'),
(617, 58, 'humvevo', 'Registrar Pago', 'Pago de $45.000 para: Cesar dwewe (1 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-24 23:46:57'),
(618, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Cesar dwewe (Código: CD1) - Motivo: sede', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 12:50:07'),
(619, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Yair Sullca (Código: YS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 12:50:51'),
(620, 58, 'humvevo', 'Registrar Pago', 'Pago de $45.000 para: Yair Sullca (1 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 12:50:58'),
(621, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 78 → en_progreso', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-09-25 14:17:29'),
(622, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 78 → cerrado', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-09-25 14:17:37'),
(623, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Marcos Yaleva (Código: MY1) - Motivo: edwefwe', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 14:51:45'),
(624, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Señor veintidos (Código: SV1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 14:52:13'),
(625, 58, 'humvevo', 'Registrar Pago', 'Pago de $50.000 para: Señor veintidos (1 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 14:52:19'),
(626, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Carlos PEpe (Código: CP2) - Motivo: dfsdfsfsd', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 19:31:49'),
(627, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Jose Sanches (Código: JS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 19:35:11'),
(628, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Jose Sanches (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 19:36:13'),
(629, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: Jose Sanches (Código: JS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 19:36:19'),
(630, 58, 'humvevo', 'Registrar Pago', 'Pago de $360.000 para: Jose Sanches (8 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 19:39:00'),
(631, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Jose Sanches (Código: JS1) - Motivo: fsd', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 19:39:09'),
(632, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-09-25 19:40:00'),
(633, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-09-25 19:40:17'),
(634, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-09-25 19:49:04'),
(635, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Juan Villca (Código: JV2)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 19:50:12'),
(636, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Brump Samguineti (Código: BS1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 19:53:54'),
(637, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Señor veintidos (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 19:54:50'),
(638, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: Señor veintidos (Código: SV1) - Tarea de reconexión creada en Soporte Técnico', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 19:54:53'),
(639, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-09-25 20:03:38'),
(640, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Señor veintidos (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 20:20:54'),
(641, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: Señor veintidos (Código: SV1) - Tarea de reconexión creada en Soporte Técnico', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-25 20:20:58'),
(642, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 84 → cerrado', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-09-25 20:36:03'),
(643, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 73 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php?pagina=3&estado=todos&prioridad=todas&barrio=todos', '2026-09-25 20:41:08'),
(644, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 84 → cerrado', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-09-25 20:41:14'),
(645, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 78 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php?pagina=2', '2026-09-25 20:41:22'),
(646, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 83 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-09-25 20:41:29'),
(647, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-09-25 20:51:49'),
(648, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-09-25 20:52:37'),
(649, 58, 'humvevo', 'Registrar Pago', 'Pago de $45.000 para: Brump Samguineti (1 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-29 22:34:38'),
(650, 58, 'humvevo', 'Registrar Pago', 'Pago de $50.000 para: Juan Villca (1 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-29 22:36:05'),
(651, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-09-29 23:49:15'),
(652, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-09-30 22:19:26'),
(653, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 88 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php?pagina=4', '2026-09-30 22:27:40'),
(654, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 82 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-09-30 22:27:50'),
(655, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-09-30 22:42:18'),
(656, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-09-30 22:44:50'),
(657, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-09-30 23:15:50'),
(658, 58, 'humvevo', 'Registrar Pago', 'Pago de $350.000 para: Señor veintidos (7 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-30 23:32:56'),
(659, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-09-30 23:34:02'),
(660, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-09-30 23:36:26'),
(661, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-09-30 23:52:10'),
(662, 58, 'humvevo', 'Registrar Pago', 'Pago de $45.000 para: Brump Samguineti (1 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-09-30 23:52:31'),
(663, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-09-30 23:53:43'),
(664, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-02 22:16:39'),
(665, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-02 22:17:13'),
(666, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-02 22:17:43'),
(667, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-02 22:18:39'),
(668, 57, 'lucas123', 'Cerrar Sesión', 'Usuario: lucas123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-02 22:20:16'),
(669, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Juan Villca (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 22:24:29');
INSERT INTO `log` (`id_log`, `id_usuario`, `usuario`, `accion`, `descripcion`, `tipo`, `ip_address`, `user_agent`, `pagina`, `fecha_registro`) VALUES
(670, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: Juan Villca (Código: JV2) - Tarea de reconexión creada en Soporte Técnico', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 22:24:32'),
(671, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Juan Villca (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:31:25'),
(672, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: Juan Villca (Código: JV2) - Tarea de reconexión creada en Soporte Técnico', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:33:18'),
(673, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Juan Villca (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:35:00'),
(674, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: Juan Villca (Código: JV2) - Tarea de reconexión creada en Soporte Técnico', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:35:07'),
(675, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Juan Villca (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:35:26'),
(676, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: Juan Villca (Código: JV2) - Tarea de reconexión creada en Soporte Técnico', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:35:33'),
(677, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Juan Villca (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:46:55'),
(678, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: Juan Villca (Código: JV2) - Tarea de reconexión creada en Soporte Técnico', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:46:58'),
(679, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Señor veintidos (Código: SV1) - Motivo: utyt', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:49:17'),
(680, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Brump Samguineti (Código: BS1) - Motivo: nytynty', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:49:23'),
(681, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Yair Sullca (Código: YS1) - Motivo: bgfbfg', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:49:28'),
(682, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Pedro Pony (Código: PP1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:50:07'),
(683, 58, 'humvevo', 'Editar Cliente', 'Se editó el cliente: Pedro Pony', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:50:28'),
(684, 58, 'humvevo', 'Registrar Pago', 'Pago de $150.000 para: Pedro Pony (3 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:50:40'),
(685, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Dani Perro (Código: DP1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-02 23:51:46'),
(686, 58, 'humvevo', 'Registrar Pago', 'Pago de $150.000 para: Dani Perro (3 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-06 18:48:49'),
(687, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Dani Perro (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-06 18:56:59'),
(688, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: Dani Perro (Código: DP1) - Tarea de reconexión creada en Soporte Técnico', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-06 18:57:03'),
(689, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Dani Perro (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-10-06 19:07:36'),
(690, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: Dani Perro (Código: DP1) - Tarea de reconexión creada en Soporte Técnico', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-10-06 19:07:39'),
(691, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Dani Perro (Código: DP1) - Motivo: sacs', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php?pagina=1', '2026-10-06 19:20:35'),
(692, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Pedro Pony (Código: PP1) - Motivo: desfse', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-06 23:29:24'),
(693, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Lionel Messi (Código: LM1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-06 23:29:57'),
(694, 58, 'humvevo', 'Registrar Pago', 'Pago de $5.000 para: Lionel Messi (1 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-06 23:30:02'),
(695, 58, 'humvevo', 'Registrar Pago', 'Pago de $5.000 para: Lionel Messi (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:13:57'),
(696, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Sanchez jose (Código: SJ1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:15:04'),
(697, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Sanchez jose (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:22:07'),
(698, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: Sanchez jose (Código: SJ1) - Tarea de reconexión creada en Soporte Técnico', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:22:09'),
(699, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Lionel Messi (Código: LM1) - Motivo: cascas', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:22:25'),
(700, 58, 'humvevo', 'Registrar Pago', 'Pago de $45.000 para: Sanchez jose (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:22:32'),
(701, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Sanchez jose (Código: SJ1) - Motivo: cds', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:22:37'),
(702, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: pepe Yaleva (Código: PY1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:23:38'),
(703, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: pepe Yaleva (Código: PY1) - Motivo: cdscds', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:30:34'),
(704, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: POzo Mauricio (Código: PM1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:31:43'),
(705, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: POzo Mauricio (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:36:41'),
(706, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: POzo Mauricio (Código: PM1) - Tarea de reconexión creada en Soporte Técnico', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:36:44'),
(707, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: POzo Mauricio (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:44:21'),
(708, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: POzo Mauricio (Días de mora recalculados: 14) - Tarea de reconexión creada en Soporte Técnico', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:44:25'),
(709, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: POzo Mauricio (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:44:31'),
(710, 58, 'humvevo', 'Reactivar Servicio', 'Se reactivó el servicio de: POzo Mauricio (Días de mora recalculados: 14) - Tarea de reconexión creada en Soporte Técnico', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:44:34'),
(711, 58, 'humvevo', 'Registrar Pago', 'Pago de $30.000 para: POzo Mauricio (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:47:39'),
(712, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Sullca cesar (Código: SC1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:48:42'),
(713, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: POzo Mauricio (Código: PM1) - Motivo: da', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:49:07'),
(714, 58, 'humvevo', 'Cortar Servicio', 'Se cortó el servicio de: Sullca cesar (Motivo: Falta de pago) - Tarea de corte creada en Soporte Técnico', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:49:53'),
(715, 58, 'humvevo', 'Registrar Pago', 'Pago de $300.000 para: Sullca cesar (6 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 22:50:10'),
(716, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Marcos Yaleva (Código: MY2)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 23:28:27'),
(717, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: dgsrthsrth trshtsrt (Código: DT1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 23:31:32'),
(718, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: carlo enrique (Código: CE1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 23:33:53'),
(719, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: dgsrthsrth trshtsrt (Código: DT1) - Motivo: fer', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 23:43:23'),
(720, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Marcos Yaleva (Código: MY2) - Motivo: fre', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 23:43:28'),
(721, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: fsefse esfsefse (Código: FE1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 23:44:09'),
(722, 58, 'humvevo', 'Error al Registrar Pago', 'Error al registrar pago para cliente ID: 197 - Error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near \'abrirModalPago 3 ORDER BY id_usuario ASC LIMIT 1\' at line 1', 'error', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 23:44:18'),
(723, 58, 'humvevo', 'Registrar Pago', 'Pago de $45.000 para: fsefse esfsefse (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 23:44:24'),
(724, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: gergr egrgrge (Código: GE1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-07 23:50:19'),
(725, 3, 'maria123', 'Observación de Cobro', 'Cobrador registró observación (PAGÓ) para cliente ID: 196 - dvsvds', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-08 22:34:59'),
(726, 3, 'maria123', 'Observación de Cobro', 'Cobrador registró observación (PAGÓ) para cliente ID: 196 - fe', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-08 22:35:19'),
(727, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Alex Perea (Código: AP1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-08 22:35:58'),
(728, 58, 'humvevo', 'Error al Registrar Pago', 'Error al registrar pago para cliente ID: 199 - Error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near \'abrirModalPago 3 ORDER BY id_usuario ASC LIMIT 1\' at line 1', 'error', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-08 22:37:40'),
(729, 58, 'humvevo', 'Registrar Pago', 'Pago de $30.000 para: Alex Perea (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-08 22:37:42'),
(730, 58, 'humvevo', 'Error al Registrar Pago', 'Error al registrar pago para cliente ID: 198 - Error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near \'abrirModalPago 3 ORDER BY id_usuario ASC LIMIT 1\' at line 1', 'error', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-08 22:37:46'),
(731, 58, 'humvevo', 'Registrar Pago', 'Pago de $30.000 para: gergr egrgrge (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-08 22:37:55'),
(732, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Lionel Quiroga (Código: LQ1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-08 22:44:48'),
(733, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Bauty baurfe (Código: BB2)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-08 22:47:44'),
(734, 3, 'maria123', 'Registrar Pago', 'Pago de $30.000 para: Bauty baurfe (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-09 22:17:38'),
(735, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Jose Sanchez (Código: JS2)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-09 22:42:01'),
(736, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-10-09 23:49:18'),
(737, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-10-09 23:54:41'),
(738, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-13 21:53:11'),
(739, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-10-13 21:56:50'),
(740, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-10-13 22:23:38'),
(741, 3, 'maria123', 'Observación de Cobro', 'Cobrador registró observación (NO PAGÓ) para cliente ID: 202 - crack', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-13 22:50:01'),
(742, 3, 'maria123', 'Registrar Pago', 'Pago de $5.000 para: Jose Sanchez (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-13 22:50:23'),
(743, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-14 18:52:16'),
(744, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-14 22:06:58'),
(745, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-14 22:51:48'),
(746, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-10-14 23:24:51'),
(747, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-14 23:26:31'),
(748, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-14 23:48:33'),
(749, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-14 23:59:00'),
(750, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-15 13:50:07'),
(751, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-10-15 14:19:19'),
(752, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-15 14:50:26'),
(753, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: cesar fwefse (Código: CF2)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-15 14:51:33'),
(754, 58, 'humvevo', 'Error al Registrar Pago', 'Error al registrar pago para cliente ID: 203 - Error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near \'abrirModalPago 3 ORDER BY id_usuario ASC LIMIT 1\' at line 1', 'error', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-15 14:51:41'),
(755, 58, 'humvevo', 'Registrar Pago', 'Pago de $50.000 para: cesar fwefse (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-15 14:51:45'),
(756, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-15 14:52:25'),
(757, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-10-15 14:53:03'),
(758, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 118 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:55:16'),
(759, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 117 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:55:19'),
(760, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 116 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:55:22'),
(761, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 115 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:55:25'),
(762, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 114 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:55:37'),
(763, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 111 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:55:40'),
(764, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 112 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:55:44'),
(765, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 110 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:55:47'),
(766, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 108 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:55:50'),
(767, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 109 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:55:54'),
(768, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 113 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:55:57'),
(769, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 107 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:55:59'),
(770, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 105 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:02'),
(771, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 106 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:05'),
(772, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 104 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:08'),
(773, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 93 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:12'),
(774, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 92 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:15'),
(775, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 86 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:19'),
(776, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 85 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:23'),
(777, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 84 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:26'),
(778, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 81 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:29'),
(779, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 80 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:34'),
(780, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 79 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:37'),
(781, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 76 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:41'),
(782, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 77 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:43'),
(783, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 75 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:46'),
(784, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 72 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:49'),
(785, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 71 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:53'),
(786, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 70 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:56:56'),
(787, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 69 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-15 14:57:01'),
(788, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 90 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php?pagina=3', '2026-10-15 14:57:08'),
(789, 58, 'humvevo', 'Eliminar Solicitud', 'Solicitud ID: 56 - Solicitud eliminada del sistema', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/soporte_tecnico.php?pagina=1', '2026-10-15 14:57:22'),
(790, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-15 19:16:06'),
(791, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-10-15 19:21:35'),
(792, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-15 22:03:45'),
(793, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-10-16 22:01:41'),
(794, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Alexis Dias (Código: AD1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-16 22:02:26'),
(795, 3, 'maria123', 'Observación de Cobro', 'Cobrador registró observación (NO PAGÓ) para cliente ID: 204 - cdsd', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-16 22:04:42'),
(796, 3, 'maria123', 'Registrar Pago', 'Pago de $50.000 para: Alexis Dias (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-16 22:04:47'),
(797, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-16 22:05:03'),
(798, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-10-16 22:05:29'),
(799, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 68 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-16 22:39:38'),
(800, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 124 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-16 22:39:55'),
(801, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 125 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-16 22:39:59'),
(802, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 126 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php?pagina=2', '2026-10-16 22:40:14'),
(803, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 123 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php?pagina=2', '2026-10-16 22:40:20'),
(804, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 122 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-16 22:40:29'),
(805, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 121 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-16 22:40:31'),
(806, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 91 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php?pagina=2', '2026-10-16 22:40:39'),
(807, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 127 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-16 22:44:01'),
(808, 4, 'carlos123', 'Cambiar Estado Solicitud', 'Solicitud ID: 49 → resuelto', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/soporte_tecnico.php', '2026-10-16 22:44:13'),
(809, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-16 22:49:00'),
(810, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: humberto Yaleva (Código: HY1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-16 22:49:33'),
(811, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-16 23:29:11'),
(812, 3, 'maria123', 'Observación de Cobro', 'Cobrador registró observación (NO PAGÓ) para cliente ID: 205 - no pago', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-10-16 23:29:41'),
(813, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-16 23:34:27'),
(814, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-16 23:36:33'),
(815, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 OPR/136.0.0.0', '/Chango%20Vision/logout.php', '2026-10-20 13:44:02'),
(816, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-20 22:41:42'),
(817, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-10-20 22:43:32'),
(818, 57, 'lucas123', 'Cerrar Sesión', 'Usuario: lucas123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 OPR/137.0.0.0', '/Chango%20Vision/logout.php', '2026-10-20 22:48:03'),
(819, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 OPR/137.0.0.0', '/Chango%20Vision/logout.php', '2026-10-20 22:53:30'),
(820, 57, 'lucas123', 'Cerrar Sesión', 'Usuario: lucas123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 OPR/137.0.0.0', '/Chango%20Vision/logout.php', '2026-10-20 23:34:27'),
(821, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 OPR/137.0.0.0', '/Chango%20Vision/logout.php', '2026-10-20 23:35:10'),
(822, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 OPR/137.0.0.0', '/Chango%20Vision/logout.php', '2026-10-20 23:42:18'),
(823, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 OPR/137.0.0.0', '/Chango%20Vision/logout.php', '2026-10-20 23:47:23'),
(824, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 OPR/137.0.0.0', '/Chango%20Vision/logout.php', '2026-10-20 23:48:30'),
(825, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 OPR/138.0.0.0', '/Chango%20Vision/logout.php', '2026-10-28 20:47:09'),
(826, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: svsf fsgsfgsf (Código: SF2)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-11-03 22:01:00'),
(827, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 OPR/138.0.0.0', '/Chango%20Vision/logout.php', '2026-11-03 22:22:43'),
(828, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Alexis Dias (Código: AD1) - Motivo: dsc', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-11-03 23:51:01'),
(829, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Bauty baurfe (Código: BB2) - Motivo: csdsd', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-11-03 23:51:06'),
(830, 58, 'humvevo', 'Registrar Pago', 'Pago de $50.000 para: svsf fsgsfgsf (1 meses) - Método: efectivo - PRIMER PAGO - Tarea de conexión creada', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-11-03 23:51:10'),
(831, 58, 'humvevo', 'Registrar Pago', 'Pago de $50.000 para: humberto Yaleva (1 meses) - Método: efectivo - Pago mensual', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-11-03 23:51:15');
INSERT INTO `log` (`id_log`, `id_usuario`, `usuario`, `accion`, `descripcion`, `tipo`, `ip_address`, `user_agent`, `pagina`, `fecha_registro`) VALUES
(832, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: cesar fwefse (Código: CF2) - Motivo: tyjy', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-11-03 23:51:21'),
(833, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: humberto Yaleva (Código: HY1) - Motivo: jtyj', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-11-03 23:51:27'),
(834, 58, 'humvevo', 'Eliminar Cliente', 'Se eliminó el cliente: Jose Sanchez (Código: JS2) - Motivo: jtyjty', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-11-03 23:51:33'),
(835, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 OPR/138.0.0.0', '/Chango%20Vision/logout.php', '2026-11-03 23:51:50'),
(836, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-11-04 17:50:22'),
(837, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-11-04 17:51:03'),
(838, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-11-04 17:52:04'),
(839, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-11-04 22:10:24'),
(840, 57, 'lucas123', 'Cerrar Sesión', 'Usuario: lucas123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-11-04 22:31:04'),
(841, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-11-04 22:34:52'),
(842, 57, 'lucas123', 'Cerrar Sesión', 'Usuario: lucas123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 OPR/138.0.0.0', '/Chango%20Vision/logout.php', '2026-11-04 22:47:52'),
(843, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 OPR/138.0.0.0', '/Chango%20Vision/logout.php', '2026-11-04 22:55:50'),
(844, 57, 'lucas123', 'Eliminar Usuario', 'Se eliminó el usuario: alexis21', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/pages/usuarios.php', '2026-11-04 23:33:08'),
(845, 57, 'lucas123', 'Crear Usuario', 'Se creó el usuario: dvfvdfv (Rol: cobrador)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/pages/usuarios.php', '2026-11-04 23:47:51'),
(846, 57, 'lucas123', 'Borrado Lógico de Usuario', 'Se desactivó lógicamente el usuario: dvfvdfv', 'warning', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '/Chango%20Vision/pages/usuarios.php', '2026-11-04 23:47:59'),
(847, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-11-06 22:20:54'),
(848, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-11-06 22:22:44'),
(849, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Alex Perea (Código: AP1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-11-06 22:32:51'),
(850, 58, 'humvevo', 'Crear Cliente', 'Se creó el cliente: Peres dcsdc (Código: PD1)', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '/Chango%20Vision/pages/admin_cliente.php', '2026-11-11 18:37:02'),
(851, 58, 'humvevo', 'Cerrar Sesión', 'Usuario: humvevo - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-11-11 18:48:42'),
(852, 3, 'maria123', 'Cerrar Sesión', 'Usuario: maria123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-11-11 18:48:57'),
(853, 4, 'carlos123', 'Cerrar Sesión', 'Usuario: carlos123 - Sesión cerrada', 'info', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '/Chango%20Vision/logout.php', '2026-11-11 18:49:10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pago`
--

CREATE TABLE `pago` (
  `id_pago` int NOT NULL,
  `id_cliente` int NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `mes` int NOT NULL,
  `anio` int NOT NULL,
  `estado` enum('Pagado','Pendiente') DEFAULT 'Pendiente',
  `fecha_pago` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `metodo_pago` varchar(50) DEFAULT 'efectivo',
  `observaciones` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `pago`
--

INSERT INTO `pago` (`id_pago`, `id_cliente`, `monto`, `mes`, `anio`, `estado`, `fecha_pago`, `metodo_pago`, `observaciones`) VALUES
(62, 119, 5000.00, 6, 2026, 'Pagado', '2026-08-13 13:34:45', 'efectivo', 'Pago de prueba'),
(64, 119, 30000.00, 8, 2026, 'Pagado', '2026-08-13 13:37:00', 'efectivo', ''),
(74, 133, 50000.00, 8, 2026, 'Pagado', '2026-08-21 22:52:42', 'efectivo', ''),
(99, 125, 5000.00, 8, 2026, 'Pagado', '2026-08-25 22:50:37', 'efectivo', ''),
(149, 162, 50000.00, 10, 2026, 'Pagado', '2026-09-01 21:49:13', 'transferencia', 'cesar\r\nr'),
(150, 162, 50000.00, 11, 2026, 'Pagado', '2026-09-01 21:49:13', 'transferencia', 'cesar\r\nr'),
(151, 162, 50000.00, 12, 2026, 'Pagado', '2026-09-01 21:49:13', 'transferencia', 'cesar\r\nr'),
(152, 162, 50000.00, 1, 2027, 'Pagado', '2026-09-01 21:49:13', 'transferencia', 'cesar\r\nr'),
(155, 164, 5000.00, 8, 2026, 'Pagado', '2026-09-08 22:37:15', 'efectivo', 'Pago de prueba'),
(156, 164, 5000.00, 7, 2026, 'Pagado', '2026-09-08 22:37:27', 'efectivo', 'Pago de prueba'),
(157, 167, 5000.00, 8, 2026, 'Pagado', '2026-09-08 22:43:31', 'efectivo', 'Pago de prueba'),
(158, 167, 5000.00, 7, 2026, 'Pagado', '2026-09-08 22:43:35', 'efectivo', 'Pago de prueba'),
(159, 168, 5000.00, 8, 2026, 'Pagado', '2026-09-08 22:53:40', 'efectivo', 'Pago de prueba'),
(160, 168, 5000.00, 7, 2026, 'Pagado', '2026-09-08 22:53:42', 'efectivo', 'Pago de prueba'),
(161, 170, 50000.00, 10, 2026, 'Pagado', '2026-09-08 23:39:12', 'efectivo', ''),
(162, 173, 30000.00, 9, 2026, 'Pendiente', '2026-09-08 23:58:06', 'efectivo', 'DEUDA - Septiembre 2026'),
(167, 174, 50000.00, 2, 2026, 'Pagado', '2026-02-15 13:00:00', 'efectivo', 'Pago de febrero 2026'),
(168, 174, 50000.00, 1, 2026, 'Pagado', '2026-01-15 13:00:00', 'efectivo', 'Pago de enero 2026'),
(169, 175, 50000.00, 1, 2026, 'Pagado', '2026-01-15 13:00:00', 'efectivo', 'Pago de enero 2026'),
(170, 176, 50000.00, 1, 2026, 'Pagado', '2026-01-15 13:00:00', 'efectivo', 'Pago de enero 2026'),
(171, 177, 5000.00, 10, 2026, 'Pagado', '2026-09-22 22:57:42', 'efectivo', ''),
(172, 177, 5000.00, 11, 2026, 'Pagado', '2026-09-22 22:57:42', 'efectivo', ''),
(173, 177, 50000.00, 1, 2026, 'Pagado', '2026-01-15 13:00:00', 'efectivo', 'Pago de enero 2026'),
(175, 178, 50000.00, 1, 2026, 'Pagado', '2026-01-15 13:00:00', 'efectivo', 'Pago de enero 2026'),
(176, 178, 50000.00, 10, 2026, 'Pagado', '2026-09-23 22:47:58', 'efectivo', ''),
(177, 178, 50000.00, 11, 2026, 'Pagado', '2026-09-23 22:47:58', 'efectivo', ''),
(178, 178, 50000.00, 12, 2026, 'Pagado', '2026-09-23 22:47:58', 'efectivo', ''),
(179, 178, 50000.00, 1, 2027, 'Pagado', '2026-09-23 22:47:58', 'efectivo', ''),
(180, 178, 50000.00, 2, 2027, 'Pagado', '2026-09-23 22:47:58', 'efectivo', ''),
(181, 178, 50000.00, 3, 2027, 'Pagado', '2026-09-23 22:47:58', 'efectivo', ''),
(182, 178, 50000.00, 4, 2027, 'Pagado', '2026-09-23 22:47:58', 'efectivo', ''),
(183, 178, 50000.00, 5, 2027, 'Pagado', '2026-09-23 22:47:58', 'efectivo', ''),
(184, 179, 50000.00, 1, 2026, 'Pagado', '2026-01-15 13:00:00', 'efectivo', 'Pago de enero 2026'),
(185, 180, 50000.00, 1, 2026, 'Pagado', '2026-01-15 13:00:00', 'efectivo', 'Pago de enero 2026'),
(186, 179, 50000.00, 10, 2026, 'Pagado', '2026-09-23 23:59:29', 'efectivo', ''),
(187, 179, 50000.00, 11, 2026, 'Pagado', '2026-09-23 23:59:29', 'efectivo', ''),
(188, 179, 50000.00, 12, 2026, 'Pagado', '2026-09-23 23:59:29', 'efectivo', ''),
(189, 179, 50000.00, 1, 2027, 'Pagado', '2026-09-23 23:59:29', 'efectivo', ''),
(190, 179, 50000.00, 2, 2027, 'Pagado', '2026-09-23 23:59:29', 'efectivo', ''),
(191, 179, 50000.00, 3, 2027, 'Pagado', '2026-09-23 23:59:29', 'efectivo', ''),
(192, 179, 50000.00, 4, 2027, 'Pagado', '2026-09-23 23:59:29', 'efectivo', ''),
(193, 179, 50000.00, 5, 2027, 'Pagado', '2026-09-23 23:59:29', 'efectivo', ''),
(194, 180, 50000.00, 10, 2026, 'Pagado', '2026-09-23 23:59:35', 'efectivo', ''),
(195, 180, 50000.00, 11, 2026, 'Pagado', '2026-09-23 23:59:35', 'efectivo', ''),
(196, 180, 50000.00, 12, 2026, 'Pagado', '2026-09-23 23:59:35', 'efectivo', ''),
(197, 180, 50000.00, 1, 2027, 'Pagado', '2026-09-23 23:59:35', 'efectivo', ''),
(198, 180, 50000.00, 2, 2027, 'Pagado', '2026-09-23 23:59:35', 'efectivo', ''),
(199, 180, 50000.00, 3, 2027, 'Pagado', '2026-09-23 23:59:35', 'efectivo', ''),
(200, 180, 50000.00, 4, 2027, 'Pagado', '2026-09-23 23:59:35', 'efectivo', ''),
(201, 180, 50000.00, 5, 2027, 'Pagado', '2026-09-23 23:59:35', 'efectivo', ''),
(202, 181, 45000.00, 10, 2026, 'Pagado', '2026-09-24 23:46:57', 'efectivo', ''),
(203, 182, 45000.00, 10, 2026, 'Pagado', '2026-09-25 12:50:58', 'efectivo', ''),
(204, 183, 50000.00, 10, 2026, 'Pagado', '2026-09-25 14:52:19', 'efectivo', ''),
(205, 184, 50000.00, 2, 2026, 'Pagado', '2026-02-15 13:00:00', 'efectivo', 'Pago de febrero 2026'),
(206, 184, 45000.00, 10, 2026, 'Pagado', '2026-09-25 19:39:00', 'efectivo', ''),
(207, 184, 45000.00, 11, 2026, 'Pagado', '2026-09-25 19:39:00', 'efectivo', ''),
(208, 184, 45000.00, 12, 2026, 'Pagado', '2026-09-25 19:39:00', 'efectivo', ''),
(209, 184, 45000.00, 1, 2027, 'Pagado', '2026-09-25 19:39:00', 'efectivo', ''),
(210, 184, 45000.00, 2, 2027, 'Pagado', '2026-09-25 19:39:00', 'efectivo', ''),
(211, 184, 45000.00, 3, 2027, 'Pagado', '2026-09-25 19:39:00', 'efectivo', ''),
(212, 184, 45000.00, 4, 2027, 'Pagado', '2026-09-25 19:39:00', 'efectivo', ''),
(213, 184, 45000.00, 5, 2027, 'Pagado', '2026-09-25 19:39:00', 'efectivo', ''),
(214, 183, 50000.00, 2, 2026, 'Pagado', '2026-02-15 13:00:00', 'efectivo', 'Pago de febrero 2026'),
(217, 183, 50000.00, 11, 2026, 'Pagado', '2026-09-30 23:32:56', 'efectivo', ''),
(218, 183, 50000.00, 12, 2026, 'Pagado', '2026-09-30 23:32:56', 'efectivo', ''),
(219, 183, 50000.00, 1, 2027, 'Pagado', '2026-09-30 23:32:56', 'efectivo', ''),
(220, 183, 50000.00, 2, 2027, 'Pagado', '2026-09-30 23:32:56', 'efectivo', ''),
(221, 183, 50000.00, 3, 2027, 'Pagado', '2026-09-30 23:32:56', 'efectivo', ''),
(222, 183, 50000.00, 4, 2027, 'Pagado', '2026-09-30 23:32:56', 'efectivo', ''),
(223, 186, 45000.00, 11, 2026, 'Pagado', '2026-09-30 23:52:31', 'efectivo', ''),
(224, 187, 50000.00, 10, 2026, 'Pagado', '2026-10-02 23:50:40', 'efectivo', ''),
(225, 187, 50000.00, 12, 2026, 'Pagado', '2026-10-02 23:50:40', 'efectivo', ''),
(226, 188, 50000.00, 10, 2026, 'Pagado', '2026-10-06 18:48:49', 'efectivo', ''),
(227, 188, 50000.00, 12, 2026, 'Pagado', '2026-10-06 18:48:49', 'efectivo', ''),
(228, 188, 1200.00, 1, 2025, 'Pendiente', '2026-10-06 18:56:06', 'efectivo', 'Deuda mes enero 2025'),
(229, 188, 1200.00, 2, 2025, 'Pendiente', '2026-10-06 18:56:06', 'efectivo', 'Deuda mes febrero 2025'),
(230, 188, 1200.00, 3, 2025, 'Pendiente', '2026-10-06 18:56:06', 'efectivo', 'Deuda mes marzo 2025'),
(231, 188, 1200.00, 4, 2025, 'Pendiente', '2026-10-06 18:56:06', 'efectivo', 'Deuda mes abril 2025'),
(232, 188, 1200.00, 5, 2025, 'Pendiente', '2026-10-06 18:56:06', 'efectivo', 'Deuda mes mayo 2025'),
(233, 188, 1200.00, 6, 2025, 'Pendiente', '2026-10-06 18:56:06', 'efectivo', 'Deuda mes junio 2025'),
(234, 187, 50000.00, 2, 2027, 'Pendiente', '2026-10-06 19:23:27', 'efectivo', 'Deuda generada automáticamente'),
(235, 187, 50000.00, 1, 2026, 'Pendiente', '2026-10-06 19:37:53', 'efectivo', 'Deuda masiva acumulada para el mes 1/2026'),
(236, 187, 50000.00, 2, 2026, 'Pendiente', '2026-10-06 19:37:53', 'efectivo', 'Deuda masiva acumulada para el mes 2/2026'),
(237, 187, 50000.00, 3, 2026, 'Pendiente', '2026-10-06 19:37:53', 'efectivo', 'Deuda masiva acumulada para el mes 3/2026'),
(238, 187, 50000.00, 4, 2026, 'Pendiente', '2026-10-06 19:37:53', 'efectivo', 'Deuda masiva acumulada para el mes 4/2026'),
(239, 187, 50000.00, 5, 2026, 'Pendiente', '2026-10-06 19:37:53', 'efectivo', 'Deuda masiva acumulada para el mes 5/2026'),
(240, 187, 50000.00, 6, 2026, 'Pendiente', '2026-10-06 19:37:53', 'efectivo', 'Deuda masiva acumulada para el mes 6/2026'),
(241, 187, 50000.00, 7, 2026, 'Pendiente', '2026-10-06 19:37:53', 'efectivo', 'Deuda masiva acumulada para el mes 7/2026'),
(242, 187, 50000.00, 8, 2026, 'Pendiente', '2026-10-06 19:37:53', 'efectivo', 'Deuda masiva acumulada para el mes 8/2026'),
(243, 187, 50000.00, 9, 2026, 'Pendiente', '2026-10-06 19:37:53', 'efectivo', 'Deuda masiva acumulada para el mes 9/2026'),
(250, 189, 5000.00, 10, 2026, 'Pagado', '2026-10-06 23:30:02', 'efectivo', ''),
(251, 189, 5000.00, 1, 2026, 'Pendiente', '2026-10-06 23:31:21', 'efectivo', 'Deuda masiva acumulada para el mes 1/2026'),
(252, 189, 5000.00, 2, 2026, 'Pendiente', '2026-10-06 23:31:21', 'efectivo', 'Deuda masiva acumulada para el mes 2/2026'),
(253, 189, 5000.00, 3, 2026, 'Pendiente', '2026-10-06 23:31:21', 'efectivo', 'Deuda masiva acumulada para el mes 3/2026'),
(254, 189, 5000.00, 4, 2026, 'Pendiente', '2026-10-06 23:31:21', 'efectivo', 'Deuda masiva acumulada para el mes 4/2026'),
(255, 189, 5000.00, 5, 2026, 'Pendiente', '2026-10-06 23:31:21', 'efectivo', 'Deuda masiva acumulada para el mes 5/2026'),
(256, 189, 5000.00, 6, 2026, 'Pendiente', '2026-10-06 23:31:21', 'efectivo', 'Deuda masiva acumulada para el mes 6/2026'),
(257, 189, 5000.00, 7, 2026, 'Pendiente', '2026-10-06 23:31:21', 'efectivo', 'Deuda masiva acumulada para el mes 7/2026'),
(258, 189, 5000.00, 8, 2026, 'Pendiente', '2026-10-06 23:31:21', 'efectivo', 'Deuda masiva acumulada para el mes 8/2026'),
(259, 189, 5000.00, 9, 2026, 'Pendiente', '2026-10-06 23:31:21', 'efectivo', 'Deuda masiva acumulada para el mes 9/2026'),
(266, 189, 5000.00, 12, 2026, 'Pagado', '2026-10-07 22:13:57', 'efectivo', ''),
(267, 190, 45000.00, 1, 2026, 'Pendiente', '2026-10-07 22:15:53', 'efectivo', 'Deuda masiva acumulada para el mes 1/2026'),
(268, 190, 45000.00, 2, 2026, 'Pendiente', '2026-10-07 22:15:53', 'efectivo', 'Deuda masiva acumulada para el mes 2/2026'),
(269, 190, 45000.00, 3, 2026, 'Pendiente', '2026-10-07 22:15:53', 'efectivo', 'Deuda masiva acumulada para el mes 3/2026'),
(270, 190, 45000.00, 4, 2026, 'Pendiente', '2026-10-07 22:15:53', 'efectivo', 'Deuda masiva acumulada para el mes 4/2026'),
(271, 190, 45000.00, 5, 2026, 'Pendiente', '2026-10-07 22:15:53', 'efectivo', 'Deuda masiva acumulada para el mes 5/2026'),
(272, 190, 45000.00, 6, 2026, 'Pendiente', '2026-10-07 22:15:53', 'efectivo', 'Deuda masiva acumulada para el mes 6/2026'),
(273, 190, 45000.00, 7, 2026, 'Pendiente', '2026-10-07 22:15:53', 'efectivo', 'Deuda masiva acumulada para el mes 7/2026'),
(274, 190, 45000.00, 8, 2026, 'Pendiente', '2026-10-07 22:15:53', 'efectivo', 'Deuda masiva acumulada para el mes 8/2026'),
(275, 190, 45000.00, 9, 2026, 'Pendiente', '2026-10-07 22:15:53', 'efectivo', 'Deuda masiva acumulada para el mes 9/2026'),
(276, 190, 45000.00, 10, 2026, 'Pagado', '2026-10-07 22:15:53', 'efectivo', ''),
(282, 191, 45000.00, 1, 2026, 'Pendiente', '2026-10-07 22:24:22', 'efectivo', 'Deuda masiva acumulada para el mes 1/2026'),
(283, 191, 45000.00, 2, 2026, 'Pendiente', '2026-10-07 22:24:22', 'efectivo', 'Deuda masiva acumulada para el mes 2/2026'),
(284, 191, 45000.00, 3, 2026, 'Pendiente', '2026-10-07 22:24:22', 'efectivo', 'Deuda masiva acumulada para el mes 3/2026'),
(285, 191, 45000.00, 4, 2026, 'Pendiente', '2026-10-07 22:24:22', 'efectivo', 'Deuda masiva acumulada para el mes 4/2026'),
(286, 191, 45000.00, 5, 2026, 'Pendiente', '2026-10-07 22:24:22', 'efectivo', 'Deuda masiva acumulada para el mes 5/2026'),
(287, 191, 45000.00, 6, 2026, 'Pendiente', '2026-10-07 22:24:22', 'efectivo', 'Deuda masiva acumulada para el mes 6/2026'),
(288, 191, 45000.00, 7, 2026, 'Pendiente', '2026-10-07 22:24:22', 'efectivo', 'Deuda masiva acumulada para el mes 7/2026'),
(289, 191, 45000.00, 8, 2026, 'Pendiente', '2026-10-07 22:24:22', 'efectivo', 'Deuda masiva acumulada para el mes 8/2026'),
(290, 191, 45000.00, 9, 2026, 'Pendiente', '2026-10-07 22:24:22', 'efectivo', 'Deuda masiva acumulada para el mes 9/2026'),
(291, 191, 45000.00, 10, 2026, 'Pendiente', '2026-10-07 22:24:22', 'efectivo', 'Deuda masiva acumulada para el mes 10/2026'),
(297, 192, 30000.00, 4, 2026, 'Pendiente', '2026-10-07 22:32:05', 'efectivo', 'Deuda masiva acumulada para 04/2026'),
(298, 192, 30000.00, 5, 2026, 'Pendiente', '2026-10-07 22:32:05', 'efectivo', 'Deuda masiva acumulada para 05/2026'),
(299, 192, 30000.00, 6, 2026, 'Pendiente', '2026-10-07 22:32:05', 'efectivo', 'Deuda masiva acumulada para 06/2026'),
(300, 192, 30000.00, 7, 2026, 'Pendiente', '2026-10-07 22:32:05', 'efectivo', 'Deuda masiva acumulada para 07/2026'),
(301, 192, 30000.00, 8, 2026, 'Pendiente', '2026-10-07 22:32:05', 'efectivo', 'Deuda masiva acumulada para 08/2026'),
(302, 192, 30000.00, 9, 2026, 'Pendiente', '2026-10-07 22:32:05', 'efectivo', 'Deuda masiva acumulada para 09/2026'),
(304, 192, 30000.00, 10, 2026, 'Pagado', '2026-10-07 22:47:38', 'efectivo', ''),
(329, 201, 45000.00, 10, 2026, 'Pagado', '2026-10-08 13:00:00', 'efectivo', 'Primer pago de instalación'),
(330, 201, 30000.00, 11, 2026, 'Pagado', '2026-10-09 22:17:38', 'efectivo', ''),
(331, 202, 45000.00, 10, 2026, 'Pagado', '2026-10-08 13:00:00', 'efectivo', 'Primer pago de instalación'),
(332, 202, 5000.00, 11, 2026, 'Pagado', '2026-10-13 22:50:23', 'efectivo', ''),
(333, 203, 50000.00, 10, 2026, 'Pagado', '2026-10-15 14:51:41', 'efectivo', ''),
(334, 203, 50000.00, 12, 2026, 'Pagado', '2026-10-15 14:51:45', 'efectivo', ''),
(335, 204, 45000.00, 10, 2026, 'Pagado', '2026-10-08 13:00:00', 'efectivo', 'Primer pago de instalación'),
(336, 204, 50000.00, 11, 2026, 'Pagado', '2026-10-16 22:04:47', 'efectivo', ''),
(337, 205, 45000.00, 10, 2026, 'Pagado', '2026-10-08 13:00:00', 'efectivo', 'Primer pago de instalación'),
(338, 206, 50000.00, 12, 2026, 'Pagado', '2026-11-03 23:51:10', 'efectivo', ''),
(339, 205, 50000.00, 11, 2026, 'Pagado', '2026-11-03 23:51:15', 'efectivo', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_producto` int NOT NULL,
  `codigo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `precio` decimal(10,2) NOT NULL DEFAULT '0.00',
  `stock` int DEFAULT '0',
  `estado` enum('Activo','Inactivo') COLLATE utf8mb4_unicode_ci DEFAULT 'Activo',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `codigo`, `nombre`, `descripcion`, `precio`, `stock`, `estado`, `fecha_creacion`, `fecha_actualizacion`) VALUES
(1, 'PROD-001', 'Router WiFi', 'Router inalámbrico de alta velocidad', 45000.00, 15, 'Activo', '2026-08-29 15:19:49', '2026-08-29 15:19:49'),
(2, 'PROD-002', 'Decodificador HD', 'Decodificador para televisión HD', 35000.00, 20, 'Activo', '2026-08-29 15:19:49', '2026-08-29 15:19:49'),
(3, 'PROD-003', 'Cable Ethernet 10m', 'Cable de red categoría 6', 8000.00, 50, 'Activo', '2026-08-29 15:19:49', '2026-08-29 15:19:49'),
(4, 'PROD-004', 'Antena WiFi', 'Antena externa para mejor señal', 25000.00, 10, 'Activo', '2026-08-29 15:19:49', '2026-08-29 15:19:49'),
(5, 'PROD-005', 'Fuente de poder', 'Fuente de poder para router', 12000.00, 30, 'Activo', '2026-08-29 15:19:49', '2026-08-29 15:19:49');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE `rol` (
  `id_rol` int NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`id_rol`, `nombre`) VALUES
(1, 'admin'),
(2, 'cobrador'),
(3, 'tecnico'),
(4, 'admin_red');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicio`
--

CREATE TABLE `servicio` (
  `id_servicio` int NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `dia_facturacion` varchar(10) DEFAULT '15',
  `dia_corte` int DEFAULT '15',
  `estado_pago` enum('pendiente','pagado','vencido') DEFAULT 'pendiente',
  `fecha_pago` date DEFAULT NULL,
  `observacion` text,
  `id_cliente` int DEFAULT NULL,
  `id_tipo` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `servicio`
--

INSERT INTO `servicio` (`id_servicio`, `nombre`, `precio`, `dia_facturacion`, `dia_corte`, `estado_pago`, `fecha_pago`, `observacion`, `id_cliente`, `id_tipo`) VALUES
(8, 'Internet Premium', 40000.00, '18', 21, 'pagado', '2026-07-01', '', NULL, NULL),
(21, 'premiun', 50000.00, '15', 31, 'pagado', '2026-07-01', NULL, NULL, NULL),
(22, 'Cable', 5000.00, '15', 31, 'pagado', '2026-07-01', NULL, NULL, NULL),
(23, 'Cable', 5000.00, '15', 31, 'pagado', '2026-07-01', NULL, NULL, NULL),
(24, 'Cable', 5000.00, '15', 31, 'pagado', '2026-07-01', NULL, NULL, NULL),
(25, 'Cable', 5000.00, '15', 31, 'pagado', '2026-07-01', NULL, NULL, NULL),
(26, 'Cable', 5000.00, '15', 31, 'pagado', '2026-07-01', NULL, NULL, NULL),
(27, 'Cable', 5000.00, '15', 31, 'pagado', '2026-07-01', NULL, NULL, NULL),
(28, 'Cable', 5000.00, '15', 31, 'pagado', '2026-07-01', NULL, NULL, NULL),
(29, 'Cable', 5000.00, '15', 31, 'pagado', '2026-07-01', NULL, NULL, NULL),
(30, 'Cable', 5000.00, '15', 31, 'pagado', '2026-07-01', NULL, NULL, NULL),
(31, 'Cable', 5000.00, '15', 31, 'pagado', '2026-07-01', NULL, NULL, NULL),
(32, 'Cable', 5000.00, '15', 31, 'pagado', '2026-07-01', NULL, NULL, NULL),
(33, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(34, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(35, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(36, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(37, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(38, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(39, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(40, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(41, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(42, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(43, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(44, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(45, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(46, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(47, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(48, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(49, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(50, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(51, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(52, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(53, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(54, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(55, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(56, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(57, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(58, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(59, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(60, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(61, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(62, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(63, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(64, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(65, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(66, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(67, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(68, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(69, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(70, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(71, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(72, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(73, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(74, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(75, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(76, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(77, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(78, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(79, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(80, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(81, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(82, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(83, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(84, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(85, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(86, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(87, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(88, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(89, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(90, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(91, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(92, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(93, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(94, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(95, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(96, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, 119, NULL),
(97, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(98, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(99, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(100, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(101, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(102, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, 125, NULL),
(103, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(104, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(105, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(106, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(107, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(108, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(109, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(110, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 133, NULL),
(111, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(112, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(113, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(114, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(115, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(116, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(117, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(118, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(119, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(120, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(121, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(122, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(123, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(124, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(125, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(126, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(127, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(128, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, NULL, NULL),
(129, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(130, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, NULL, NULL),
(131, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, NULL, NULL),
(132, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(133, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(134, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(135, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(136, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, NULL, NULL),
(137, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(138, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(139, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 162, NULL),
(140, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 163, NULL),
(141, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, 164, NULL),
(142, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, 165, NULL),
(143, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, 166, NULL),
(144, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, 167, NULL),
(145, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, 168, NULL),
(146, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 169, NULL),
(147, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 170, NULL),
(148, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 171, NULL),
(149, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, 172, NULL),
(150, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, 173, NULL),
(151, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 174, NULL),
(152, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 175, NULL),
(153, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 176, NULL),
(154, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, 177, NULL),
(155, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 178, NULL),
(156, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 179, NULL),
(157, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 180, NULL),
(158, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, 181, NULL),
(159, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, 182, NULL),
(160, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 183, NULL),
(161, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, 184, NULL),
(162, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(163, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, 186, NULL),
(164, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 187, NULL),
(165, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 188, NULL),
(166, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, 189, NULL),
(167, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, 190, NULL),
(168, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, 191, NULL),
(169, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, 192, NULL),
(170, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(171, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(172, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(173, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, NULL, NULL),
(174, 'prueba', 45000.00, '15', 17, 'pendiente', NULL, NULL, NULL, NULL),
(175, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(176, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, NULL, NULL),
(177, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, NULL, NULL),
(178, 'tv', 30000.00, '15', 23, 'pendiente', NULL, NULL, 201, NULL),
(179, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, 202, NULL),
(180, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 203, NULL),
(181, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 204, NULL),
(182, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 205, NULL),
(183, 'premiun', 50000.00, '15', 31, 'pendiente', NULL, NULL, 206, NULL),
(184, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, 207, NULL),
(185, 'Cable', 5000.00, '15', 31, 'pendiente', NULL, NULL, 208, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sistema_logs`
--

CREATE TABLE `sistema_logs` (
  `id_log` int NOT NULL,
  `id_usuario` int DEFAULT NULL,
  `usuario` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `tipo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'info',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `pagina` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `sistema_logs`
--

INSERT INTO `sistema_logs` (`id_log`, `id_usuario`, `usuario`, `accion`, `descripcion`, `tipo`, `ip_address`, `user_agent`, `pagina`, `fecha_registro`) VALUES
(1, NULL, 'cesar12', 'CAMBIAR_ESTADO', 'Cambió estado del cliente ID 26 - qfeas a Inactivo', 'INFO', NULL, NULL, 'admin_cliente.php', '2026-06-23 22:48:14'),
(2, NULL, 'cesar12', 'CAMBIAR_ESTADO', 'Cambió estado del cliente ID 30 - cesar sullca a Activo', 'INFO', NULL, NULL, 'admin_cliente.php', '2026-06-23 22:57:09');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `soporte`
--

CREATE TABLE `soporte` (
  `id_soporte` int NOT NULL,
  `cliente_id` int DEFAULT NULL,
  `tecnico_id` int DEFAULT NULL,
  `creador_id` int DEFAULT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  `descripcion` text,
  `ubicacion_url` varchar(500) DEFAULT NULL,
  `estado` enum('pendiente','en_progreso','resuelto','cerrado') DEFAULT 'pendiente',
  `prioridad` enum('baja','media','alta') DEFAULT 'media',
  `comentario` text,
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_resolucion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `soporte`
--

INSERT INTO `soporte` (`id_soporte`, `cliente_id`, `tecnico_id`, `creador_id`, `titulo`, `descripcion`, `ubicacion_url`, `estado`, `prioridad`, `comentario`, `fecha_creacion`, `fecha_resolucion`) VALUES
(49, 133, 4, NULL, 'Nueva conexión - Tiziano Dias', 'Realizar la conexión del servicio para el cliente: Tiziano Dias', NULL, 'resuelto', 'alta', '', '2026-08-21 22:52:42', '2026-10-16'),
(68, 162, 4, NULL, 'Nueva conexión - werwwrwr hf', 'Realizar la conexión del servicio para el cliente: werwwrwr hf. Pagó 4 mes(es) por adelantado.', NULL, 'resuelto', 'alta', '', '2026-09-01 21:49:13', '2026-10-16'),
(73, 176, 4, NULL, 'Corte de servicio - Stefano Sanguineti', 'Realizar el corte del servicio por: Mora extendida. Cliente: Stefano Sanguineti.', NULL, 'resuelto', 'alta', '', '2026-09-22 22:50:02', '2026-09-25'),
(74, 177, 4, NULL, 'Nueva conexión - wrwrgg fweef', 'Realizar la conexión del servicio para el cliente: wrwrgg fweef. Pagó 2 mes(es) por adelantado.', NULL, 'resuelto', 'alta', '', '2026-09-22 22:57:42', '2026-09-22'),
(78, 181, 4, NULL, 'Nueva conexión - Cesar dwewe', 'Realizar la conexión del servicio para el cliente: Cesar dwewe. Pagó 1 mes(es) por adelantado.', NULL, 'resuelto', 'alta', '', '2026-09-24 23:46:57', '2026-09-25'),
(82, 183, 4, NULL, 'Corte de servicio - Señor veintidos', 'Realizar el corte del servicio por: Falta de pago. Cliente: Señor veintidos.', NULL, 'resuelto', 'alta', '', '2026-09-25 19:54:50', '2026-09-30'),
(83, 183, 4, NULL, 'Reactivación de servicio - Señor veintidos', 'Realizar la reconexión del servicio para el cliente: Señor veintidos.', NULL, 'resuelto', 'alta', '', '2026-09-25 19:54:53', '2026-09-25'),
(88, 183, 4, NULL, NULL, 'señor veintidos', 'https://www.google.com/maps?q=-29.1766272,-67.4955264', 'resuelto', 'media', '', '2026-09-30 22:16:30', '2026-09-30'),
(91, 182, 4, NULL, NULL, 'efsef', 'https://www.google.com/maps?q=-29.307741275239746,-67.5001229722863', 'resuelto', 'baja', '', '2026-09-30 22:42:53', '2026-10-16'),
(121, 202, 4, NULL, NULL, 'pruebads dasd a', NULL, 'resuelto', 'media', '', '2026-10-15 14:37:12', '2026-10-16'),
(122, 202, 4, NULL, NULL, 'actualizar de', NULL, 'resuelto', 'media', '', '2026-10-15 14:37:59', '2026-10-16'),
(123, 201, 4, NULL, NULL, 'Reclamo: segunda prueba', NULL, 'resuelto', 'baja', '', '2026-10-15 14:50:11', '2026-10-16'),
(124, 203, 4, NULL, NULL, 'Reclamo: reclamo', NULL, 'resuelto', 'media', '', '2026-10-15 14:52:13', '2026-10-16'),
(125, 203, 4, NULL, NULL, 'Reclamo: prueba', NULL, 'resuelto', 'media', '', '2026-10-15 14:53:29', '2026-10-16'),
(126, 203, 4, NULL, NULL, 'terces coso de prueba', 'https://www.google.com/maps?q=-29.30772782041003,-67.50021559703346', 'resuelto', 'baja', '', '2026-10-15 19:32:46', '2026-10-16'),
(127, 204, 4, NULL, 'Reclamo', 'segudna prueba', NULL, 'resuelto', 'baja', '', '2026-10-16 22:24:34', '2026-10-16'),
(128, 204, NULL, 3, 'Reclamo', 'frerer', NULL, 'pendiente', 'baja', NULL, '2026-10-16 22:29:55', NULL),
(129, 206, 4, NULL, 'Nueva conexión - svsf fsgsfgsf', 'Realizar la conexión del servicio para el cliente: svsf fsgsfgsf.', NULL, 'pendiente', 'alta', NULL, '2026-11-03 23:51:10', NULL),
(130, 206, NULL, 3, 'Reclamo', 'prueba grafico red', NULL, 'pendiente', 'media', NULL, '2026-11-04 23:07:38', NULL),
(131, 206, NULL, 3, 'Reclamo', 'todo', NULL, 'pendiente', 'baja', NULL, '2026-11-06 22:21:55', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_servicio`
--

CREATE TABLE `tipo_servicio` (
  `id_tipo` int NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text,
  `precio_base` decimal(10,2) NOT NULL,
  `dia_facturacion` int DEFAULT '15',
  `dia_corte` int DEFAULT '20',
  `estado` enum('Activo','Inactivo') DEFAULT 'Activo',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `tipo_servicio`
--

INSERT INTO `tipo_servicio` (`id_tipo`, `nombre`, `descripcion`, `precio_base`, `dia_facturacion`, `dia_corte`, `estado`, `created_at`) VALUES
(1, 'tv', 'ceses', 30000.00, 22, 23, 'Activo', '2026-06-22 17:02:09'),
(2, 'premiun', 'mas rapido', 50000.00, 29, 31, 'Activo', '2026-06-22 18:33:22'),
(3, 'Cable', 'lento', 5000.00, 30, 31, 'Activo', '2026-06-30 18:54:02'),
(6, 'prueba', 'fefes', 45000.00, 15, 17, 'Activo', '2026-08-13 13:45:37');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) DEFAULT NULL,
  `dni` int DEFAULT NULL,
  `localidad` varchar(100) DEFAULT NULL,
  `telefono` bigint DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `id_rol` int DEFAULT NULL,
  `contrasena` varchar(100) DEFAULT NULL,
  `usuario` varchar(50) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_expira` datetime DEFAULT NULL,
  `nueva_password_temp` varchar(255) DEFAULT NULL,
  `estado` varchar(20) DEFAULT 'Activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nombre`, `apellido`, `dni`, `localidad`, `telefono`, `email`, `id_rol`, `contrasena`, `usuario`, `reset_token`, `reset_expira`, `nueva_password_temp`, `estado`) VALUES
(3, 'Mariana', 'Gomez', 23456789, 'Nonogasta', 3825987654, 'maria@mail.com', 2, '$2y$10$m6ERXUeqS7b6n9Y4xl5a1O5CC3pjUxSY52oaI81Llttl5NvW9iePy', 'maria123', NULL, NULL, NULL, 'Activo'),
(4, 'Carlos', 'Lopez', 34567890, 'La Rioja', 3825123987, 'carlos@mail.com', 3, '$2y$10$s1mMj6o1eGKI4xJ0Esbm5eFD5h8Nqlp/1nmu237X5p8DuB0zTM9Xi', 'carlos123', NULL, NULL, NULL, 'Activo'),
(55, 'Alex', 'Perea', 123456789, 'nonogasta', 3867888888, 'aperea@cen.edu.ar', 1, '$2y$10$T1v1T5Kfl.dstTnrZxklcu0ue0wsa/YeMTBqr2q4ca.Ko00n99n/m', 'aperea', NULL, NULL, NULL, 'Activo'),
(57, 'Lucas', 'Diaz', 34567349, 'nonogasta', 386788888, 'cesarsu@gmail.com', 4, '$2y$10$4x6xIvoJ4mP2PgntS1/xz.bAF.TeFWerG4mROVuhFydxPTvja.CG6', 'lucas123', NULL, NULL, NULL, 'Activo'),
(58, 'humbertos', 'Ormeño', 43453454, 'dsad', 6424624, 'sullcaquispecesar@gmail.com', 1, '$2y$10$fMV/.gt69TeiCum0Itzoy.6a2Oxn/K3k7fE0F5m/NK8Q2IjXyD3TO', 'humvevo', NULL, NULL, NULL, 'Activo'),
(67, 'cesar', 'Sullca', 533253, 'Nonogasta', 64624642, 'pruebasegunda987@gmail.com', 3, '$2y$10$UhHXVVYZbK/nrf85zsiG7uoeR3BaOTIioaDlgTH/Ds0zT7j15/hIq', 'cesar21', NULL, NULL, NULL, 'Activo'),
(68, 'dvdfv', 'dfvdf', 453636, 'vfdfvdf', 3563563, 'eregre@ede.de', 2, NULL, 'dvfvdfv', '8557cccf0e240222206c65ac8791ff22cba85880062f451474e9512653f647f5', '2026-11-05 00:47:44', NULL, 'Inactivo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `barrio`
--
ALTER TABLE `barrio`
  ADD PRIMARY KEY (`id_barrio`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_servicio` (`id_servicio`),
  ADD KEY `id_barrio` (`id_barrio`),
  ADD KEY `idx_codigo_cliente` (`codigo_cliente`),
  ADD KEY `id_tipo` (`id_tipo`);

--
-- Indices de la tabla `historial_pago`
--
ALTER TABLE `historial_pago`
  ADD PRIMARY KEY (`id_historial`),
  ADD KEY `id_cliente` (`id_cliente`),
  ADD KEY `id_servicio` (`id_servicio`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id_log`),
  ADD KEY `idx_usuario` (`usuario`),
  ADD KEY `idx_tipo` (`tipo`),
  ADD KEY `idx_fecha` (`fecha_registro`);

--
-- Indices de la tabla `pago`
--
ALTER TABLE `pago`
  ADD PRIMARY KEY (`id_pago`),
  ADD UNIQUE KEY `unique_pago_mes` (`id_cliente`,`mes`,`anio`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto`),
  ADD UNIQUE KEY `uk_producto_codigo` (`codigo`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id_rol`);

--
-- Indices de la tabla `servicio`
--
ALTER TABLE `servicio`
  ADD PRIMARY KEY (`id_servicio`),
  ADD KEY `id_cliente` (`id_cliente`),
  ADD KEY `id_tipo` (`id_tipo`);

--
-- Indices de la tabla `sistema_logs`
--
ALTER TABLE `sistema_logs`
  ADD PRIMARY KEY (`id_log`),
  ADD KEY `idx_usuario` (`usuario`),
  ADD KEY `idx_tipo` (`tipo`),
  ADD KEY `idx_fecha` (`fecha_registro`),
  ADD KEY `idx_accion` (`accion`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `soporte`
--
ALTER TABLE `soporte`
  ADD PRIMARY KEY (`id_soporte`),
  ADD KEY `cliente_id` (`cliente_id`),
  ADD KEY `tecnico_id` (`tecnico_id`);

--
-- Indices de la tabla `tipo_servicio`
--
ALTER TABLE `tipo_servicio`
  ADD PRIMARY KEY (`id_tipo`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `usuario` (`usuario`),
  ADD KEY `id_rol` (`id_rol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `barrio`
--
ALTER TABLE `barrio`
  MODIFY `id_barrio` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=209;

--
-- AUTO_INCREMENT de la tabla `historial_pago`
--
ALTER TABLE `historial_pago`
  MODIFY `id_historial` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT de la tabla `log`
--
ALTER TABLE `log`
  MODIFY `id_log` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=854;

--
-- AUTO_INCREMENT de la tabla `pago`
--
ALTER TABLE `pago`
  MODIFY `id_pago` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=340;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id_producto` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `rol`
--
ALTER TABLE `rol`
  MODIFY `id_rol` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `servicio`
--
ALTER TABLE `servicio`
  MODIFY `id_servicio` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=186;

--
-- AUTO_INCREMENT de la tabla `sistema_logs`
--
ALTER TABLE `sistema_logs`
  MODIFY `id_log` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `soporte`
--
ALTER TABLE `soporte`
  MODIFY `id_soporte` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;

--
-- AUTO_INCREMENT de la tabla `tipo_servicio`
--
ALTER TABLE `tipo_servicio`
  MODIFY `id_tipo` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`id_servicio`) REFERENCES `servicio` (`id_servicio`) ON DELETE SET NULL,
  ADD CONSTRAINT `cliente_ibfk_2` FOREIGN KEY (`id_barrio`) REFERENCES `barrio` (`id_barrio`),
  ADD CONSTRAINT `cliente_ibfk_3` FOREIGN KEY (`id_barrio`) REFERENCES `barrio` (`id_barrio`),
  ADD CONSTRAINT `cliente_ibfk_4` FOREIGN KEY (`id_tipo`) REFERENCES `tipo_servicio` (`id_tipo`);

--
-- Filtros para la tabla `historial_pago`
--
ALTER TABLE `historial_pago`
  ADD CONSTRAINT `historial_pago_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `historial_pago_ibfk_2` FOREIGN KEY (`id_servicio`) REFERENCES `servicio` (`id_servicio`) ON DELETE SET NULL,
  ADD CONSTRAINT `historial_pago_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE SET NULL;

--
-- Filtros para la tabla `pago`
--
ALTER TABLE `pago`
  ADD CONSTRAINT `pago_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `servicio`
--
ALTER TABLE `servicio`
  ADD CONSTRAINT `servicio_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `servicio_ibfk_2` FOREIGN KEY (`id_tipo`) REFERENCES `tipo_servicio` (`id_tipo`);

--
-- Filtros para la tabla `sistema_logs`
--
ALTER TABLE `sistema_logs`
  ADD CONSTRAINT `sistema_logs_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE SET NULL;

--
-- Filtros para la tabla `soporte`
--
ALTER TABLE `soporte`
  ADD CONSTRAINT `soporte_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `soporte_ibfk_2` FOREIGN KEY (`tecnico_id`) REFERENCES `usuario` (`id_usuario`) ON DELETE SET NULL;

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
