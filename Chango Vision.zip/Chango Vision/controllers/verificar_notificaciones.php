<?php
// controllers/verificar_notificacion.php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 2) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

include __DIR__ . '/../config/conexion.php';

$hoy = date('j');

$sql = "SELECT 
            s.id_servicio,
            c.nombre as cliente,
            s.nombre as servicio,
            s.dia_corte,
            c.direccion,
            c.id as id_cliente
        FROM servicio s
        INNER JOIN cliente c ON s.id_cliente = c.id
        WHERE s.estado_pago = 'pendiente' 
        AND s.dia_corte = ?
        AND c.estado = 'Activo'";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $hoy);
$stmt->execute();
$result = $stmt->get_result();

$cortes = [];

while ($row = $result->fetch_assoc()) {
    $cortes[] = [
        'id' => $row['id_servicio'],
        'id_cliente' => $row['id_cliente'],
        'cliente' => $row['cliente'],
        'servicio' => $row['servicio'],
        'dia_corte' => $row['dia_corte'],
        'direccion' => $row['direccion'] ?? 'Sin dirección'
    ];
}

echo json_encode(['success' => true, 'cortes' => $cortes]);
$conexion->close();
?>