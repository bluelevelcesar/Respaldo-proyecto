<?php
// =============================================
// FUNCIONES REUTILIZABLES PARA USUARIOS
// =============================================

// ✅ INCLUIR PHPMailer DESDE LA RAÍZ
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require_once __DIR__ . '/../PHPMailer/src/Exception.php';
require_once __DIR__ . '/../PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer/src/SMTP.php';

function enviarCorreoCreacionCuenta($email, $nombre, $token) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        ? "https://"
        : "http://";
    $host = $_SERVER['HTTP_HOST'];
    $enlace = $protocol . $host . '/Chango%20Vision/pages/reset_contra.php?token=' . $token;
    
    $mail = new PHPMailer(true);
    
    try {
        // Configuración SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'chagovision.system@gmail.com';
        $mail->Password = 'jonqhfkqidoblbyx'; // Contraseña de aplicación
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->CharSet = 'UTF-8';
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ];
        
        // Remitente y destinatario
        $mail->setFrom('chagovision.system@gmail.com', 'Chango Vision');
        $mail->addAddress($email, $nombre);
        
        // Contenido del correo
        $mail->isHTML(true);
        $mail->Subject = "Bienvenido a Chango Vision - Crear tu contraseña";
        $mail->Body = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 10px; }
                .header { background: #0f2b3d; color: white; padding: 15px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { padding: 20px; }
                .btn { display: inline-block; padding: 12px 30px; background: #0f2b3d; color: white; text-decoration: none; border-radius: 30px; font-weight: 600; }
                .footer { margin-top: 20px; font-size: 12px; color: #94a3b8; text-align: center; border-top: 1px solid #e2e8f0; padding-top: 15px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2 style='margin:0;'>📡 Chango Vision</h2>
                </div>
                <div class='content'>
                    <h3>¡Bienvenido <strong>{$nombre}</strong>!</h3>
                    <p>Se ha creado una cuenta para ti en el sistema de <strong>Chango Vision</strong>.</p>
                    <p>Para poder acceder al sistema, debes crear tu propia contraseña. Haz clic en el siguiente enlace:</p>
                    <p style='text-align: center;'>
                        <a href='{$enlace}' class='btn'>
                            🔐 Crear mi contraseña
                        </a>
                    </p>
                    <p><small>⚠️ Este enlace expirará en 1 hora.</small></p>
                    <p><small>Si no solicitaste esta cuenta, ignora este mensaje.</small></p>
                </div>
                <div class='footer'>
                    <p>© 2026 Chango Vision - Todos los derechos reservados</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        $mail->AltBody = "
        Bienvenido a Chango Vision {$nombre}
        
        Se ha creado una cuenta para ti en el sistema.
        
        Para crear tu contraseña, ingresa al siguiente enlace:
        {$enlace}
        
        Este enlace expirará en 1 hora.
        ";
        
        $mail->send();
        return true;
        
    } catch (Exception $e) {
        error_log("❌ Error al enviar correo: " . $mail->ErrorInfo);
        return false;
    }
}

// =============================================
// CREAR USUARIO (SIN CONTRASEÑA)
// =============================================
function crearUsuarioSinPassword($conexion, $nombre, $apellido, $email, $usuario, $id_rol, $telefono = null, $localidad = null, $dni = null) {
    // ✅ VALIDAR Y LIMPIAR DNI
    if (!empty($dni)) {
        $dni = preg_replace('/[^0-9]/', '', $dni);
        if (strlen($dni) > 20) {
            $dni = substr($dni, 0, 20);
        }
    }
    
    // ✅ VALIDAR Y LIMPIAR TELÉFONO
    if (!empty($telefono)) {
        $telefono = preg_replace('/[^0-9]/', '', $telefono);
        if (strlen($telefono) > 20) {
            $telefono = substr($telefono, 0, 20);
        }
    }
    
    // ✅ Generar token
    $token = bin2hex(random_bytes(32));
    $expiracion = date('Y-m-d H:i:s', strtotime('+1 hour'));
    
    // ✅ Insertar usuario (sin contraseña)
    $sql = "INSERT INTO usuario (nombre, apellido, email, usuario, id_rol, telefono, localidad, dni, reset_token, reset_expira) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "ssssisssss", 
        $nombre, $apellido, $email, $usuario, $id_rol, $telefono, $localidad, $dni, $token, $expiracion
    );
    
    if (mysqli_stmt_execute($stmt)) {
        $id_usuario = mysqli_insert_id($conexion);
        mysqli_stmt_close($stmt);
        
        // ✅ Enviar correo con el token (USANDO PHPMailer)
        $correo_enviado = enviarCorreoCreacionCuenta($email, $nombre, $token);
        
        if ($correo_enviado) {
            return ['success' => true, 'id' => $id_usuario, 'token' => $token, 'email_enviado' => true];
        } else {
            return ['success' => true, 'id' => $id_usuario, 'token' => $token, 'email_enviado' => false, 'error' => 'No se pudo enviar el correo'];
        }
    } else {
        $error = mysqli_error($conexion);
        mysqli_stmt_close($stmt);
        return ['success' => false, 'error' => $error];
    }
}
?>