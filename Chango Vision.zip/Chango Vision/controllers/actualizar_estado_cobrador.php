<?php
// controllers/actualizar_estado_cobrador.php
session_start();
header('Content-Type: application/json');

// =============================================
// ACTIVAR ERRORES PARA VER EL PROBLEMA
// =============================================
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 2) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

include __DIR__ . '/../config/conexion.php';

if (!$conexion) {
    echo json_encode(['success' => false, 'error' => 'Error de conexión']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$id_cliente = $data['id'] ?? 0;

if (!$id_cliente) {
    echo json_encode(['success' => false, 'error' => 'ID de cliente no proporcionado']);
    exit;
}

// =============================================
// OBTENER DATOS DEL CLIENTE
// =============================================
$sql = "SELECT c.id, c.nombre, c.apellido, c.estado_pago, c.id_servicio, c.id_tipo, c.direccion, c.telefono
        FROM cliente c 
        WHERE c.id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$cliente = $stmt->get_result()->fetch_assoc();

if (!$cliente) {
    echo json_encode(['success' => false, 'error' => 'Cliente no encontrado']);
    exit;
}

if ($cliente['estado_pago'] === 'pagado') {
    echo json_encode(['success' => false, 'error' => 'Este cliente ya pagó este mes']);
    exit;
}

// =============================================
// VERIFICAR SI ES PRIMER PAGO
// =============================================
$sql_check = "SELECT COUNT(*) as total FROM pago WHERE id_cliente = ?";
$stmt_check = $conexion->prepare($sql_check);
$stmt_check->bind_param("i", $id_cliente);
$stmt_check->execute();
$result_check = $stmt_check->get_result();
$count = $result_check->fetch_assoc()['total'];
$stmt_check->close();

$es_primer_pago = ($count == 0);

// =============================================
// OBTENER PRECIO Y NOMBRE DEL SERVICIO
// =============================================
$sql_tipo = "SELECT nombre, precio_base FROM tipo_servicio WHERE id_tipo = ?";
$stmt_tipo = $conexion->prepare($sql_tipo);
$stmt_tipo->bind_param("i", $cliente['id_tipo']);
$stmt_tipo->execute();
$tipo = $stmt_tipo->get_result()->fetch_assoc();
$monto = $tipo['precio_base'] ?? 0;
$nombre_servicio = $tipo['nombre'] ?? 'Sin servicio';
$stmt_tipo->close();

// =============================================
// ACTUALIZAR CLIENTE
// =============================================
$updateCliente = $conexion->prepare("UPDATE cliente SET estado_pago = 'pagado', fecha_ultimo_pago = CURDATE() WHERE id = ?");
$updateCliente->bind_param("i", $id_cliente);

if (!$updateCliente->execute()) {
    echo json_encode(['success' => false, 'error' => 'Error al actualizar cliente: ' . $conexion->error]);
    $conexion->close();
    exit;
}

// =============================================
// ACTUALIZAR SERVICIO (si tiene)
// =============================================
if ($cliente['id_servicio']) {
    $updateServicio = $conexion->prepare("UPDATE servicio SET estado_pago = 'pagado', fecha_pago = CURDATE() WHERE id_servicio = ?");
    $updateServicio->bind_param("i", $cliente['id_servicio']);
    $updateServicio->execute();
}

// =============================================
// REGISTRAR EN TABLA PAGO
// =============================================
$mes = date('n');
$anio = date('Y');

$sql_pago = "INSERT INTO pago (id_cliente, monto, mes, anio, estado, fecha_pago) 
             VALUES (?, ?, ?, ?, 'Pagado', NOW())";
$stmt_pago = $conexion->prepare($sql_pago);
$stmt_pago->bind_param("diii", $id_cliente, $monto, $mes, $anio);

if (!$stmt_pago->execute()) {
    error_log("Error al insertar en pago: " . $conexion->error);
}
$stmt_pago->close();

// =============================================
// NOTIFICACIÓN AL TÉCNICO - PRIMER PAGO
// =============================================
if ($es_primer_pago) {
    $nombre_cliente = trim($cliente['nombre'] . ' ' . ($cliente['apellido'] ?? ''));
    $direccion = $cliente['direccion'] ?? 'Sin dirección';
    $telefono = $cliente['telefono'] ?? 'Sin teléfono';
    
    $mensaje = "========================================\n";
    $mensaje .= "🔌 NUEVA CONEXIÓN PENDIENTE\n";
    $mensaje .= "========================================\n";
    $mensaje .= "Cliente: $nombre_cliente\n";
    $mensaje .= "Dirección: $direccion\n";
    $mensaje .= "Teléfono: $telefono\n";
    $mensaje .= "Servicio: $nombre_servicio\n";
    $mensaje .= "Monto pagado: $" . number_format($monto, 0, ',', '.') . "\n";
    $mensaje .= "Fecha de pago: " . date('d/m/Y') . "\n";
    $mensaje .= "========================================\n";
    $mensaje .= "✅ El cliente realizó su PRIMER PAGO.\n";
    $mensaje .= "🔧 Realizar conexión e instalación.\n";
    $mensaje .= "========================================\n";
    
    $log_dir = __DIR__ . '/../logs/';
    if (!file_exists($log_dir)) mkdir($log_dir, 0777, true);
    
    $archivo = $log_dir . 'notificacion_tecnico_conexion.txt';
    $fecha_log = date('Y-m-d H:i:s');
    $contenido = "[$fecha_log]\n" . $mensaje . "\n";
    file_put_contents($archivo, $contenido, FILE_APPEND);
}

// =============================================
// REGISTRAR EN HISTORIAL_PAGO
// =============================================
$detalle = "Pago registrado por " . ($_SESSION['usuario'] ?? 'cobrador') . " - " . $cliente['nombre'];
$log = $conexion->prepare("INSERT INTO historial_pago (id_cliente, accion, detalle, fecha) 
                           VALUES (?, 'PAGO', ?, NOW())");
$log->bind_param("is", $id_cliente, $detalle);
$log->execute();

// =============================================
// RESPUESTA
// =============================================
$mensaje_exito = "✅ Pago registrado: {$cliente['nombre']} - $" . number_format($monto, 0, ',', '.');
if ($es_primer_pago) {
    $mensaje_exito .= " 🔔 Se notificó al técnico para la conexión.";
}

echo json_encode([
    'success' => true,
    'message' => $mensaje_exito,
    'primer_pago' => $es_primer_pago
]);

$conexion->close();
?>