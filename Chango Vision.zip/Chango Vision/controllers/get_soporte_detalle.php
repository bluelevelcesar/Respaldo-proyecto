<?php
// =============================================
// get_soporte_detalle.php - OBTENER DETALLE DE TAREA DE SOPORTE
// =============================================
session_start();

header('Content-Type: application/json; charset=utf-8');

// Verificar autenticación de usuario
if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['status' => 'error', 'message' => 'No autorizado']);
    exit;
}

include __DIR__ . '/../config/conexion.php';

$id = intval($_GET['id'] ?? 0);

if ($id <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'ID inválido']);
    exit;
}

// Se agrega c.codigo_cliente a la consulta SQL
$sql = "SELECT s.*, 
               c.codigo_cliente,
               c.nombre as cliente_nombre, 
               c.apellido as cliente_apellido,
               c.telefono as cliente_telefono,
               b.nombre as cliente_barrio,
               u.nombre as tecnico_nombre,
               u.apellido as tecnico_apellido
        FROM soporte s
        LEFT JOIN cliente c ON s.cliente_id = c.id
        LEFT JOIN barrio b ON c.id_barrio = b.id_barrio
        LEFT JOIN usuario u ON s.tecnico_id = u.id_usuario
        WHERE s.id_soporte = ?";

$stmt = mysqli_prepare($conexion, $sql);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if ($data) {
    echo json_encode(['status' => 'success', 'data' => $data]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Solicitud no encontrada']);
}
?>