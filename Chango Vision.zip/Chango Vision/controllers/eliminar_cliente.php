<?php
session_start();
header('Content-Type: application/json');

// Verificar sesión
if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 1) {
    echo json_encode(["status" => "error", "message" => "No autorizado"]);
    exit;
}

// RUTA CORRECTA a conexion.php
include __DIR__ . '/../config/conexion.php';

if (!$conexion) {
    echo json_encode(["status" => "error", "message" => "Error de conexión"]);
    exit;
}

// Verificar que se haya recibido el ID
if (!isset($_POST['id']) || empty($_POST['id'])) {
    echo json_encode(["status" => "error", "message" => "ID no proporcionado"]);
    exit;
}

$id = intval($_POST['id']);
$nombre = $_POST['nombre'] ?? '';

// Obtener el id_servicio del cliente
$sql = "SELECT id_servicio FROM cliente WHERE id = $id";
$result = mysqli_query($conexion, $sql);
$cliente = mysqli_fetch_assoc($result);
$id_servicio = $cliente['id_servicio'] ?? 0;

// Iniciar transacción
mysqli_begin_transaction($conexion);

try {
    // 1. ELIMINAR CLIENTE (baja física)
    $sql = "DELETE FROM cliente WHERE id = $id";
    if (!mysqli_query($conexion, $sql)) {
        throw new Exception(mysqli_error($conexion));
    }

    // 2. ELIMINAR SERVICIO ASOCIADO
    if ($id_servicio > 0) {
        $sql = "DELETE FROM servicio WHERE id_servicio = $id_servicio";
        if (!mysqli_query($conexion, $sql)) {
            throw new Exception(mysqli_error($conexion));
        }
    }

    mysqli_commit($conexion);

    echo json_encode([
        "status" => "success",
        "message" => "Cliente eliminado correctamente"
    ]);

} catch (Exception $e) {
    mysqli_rollback($conexion);
    echo json_encode([
        "status" => "error",
        "message" => "Error: " . $e->getMessage()
    ]);
}

mysqli_close($conexion);
?>