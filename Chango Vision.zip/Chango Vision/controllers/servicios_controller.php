<?php
// controllers/servicios_controller.php
session_start();
header('Content-Type: application/json');

error_reporting(0);
ini_set('display_errors', 0);

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'mensaje' => 'No autorizado']);
    exit;
}

include __DIR__ . '/../config/conexion.php';

if (!$conexion) {
    echo json_encode(['success' => false, 'mensaje' => 'Error de conexión a BD']);
    exit;
}

$accion = $_POST['accion'] ?? $_GET['accion'] ?? '';

// =============================================
// LISTAR SERVICIOS
// =============================================
if ($accion === 'listar') {
    $result = $conexion->query("SELECT * FROM servicio ORDER BY id_servicio ASC");
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode(['success' => true, 'data' => $data]);
    exit;
}

// =============================================
// OBTENER UN SERVICIO POR ID
// =============================================
if ($accion === 'obtener') {
    $id = intval($_GET['id'] ?? 0);
    
    if ($id <= 0) {
        echo json_encode(['success' => false, 'mensaje' => 'ID no válido']);
        exit;
    }
    
    $stmt = $conexion->prepare("SELECT * FROM servicio WHERE id_servicio = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $servicio = $result->fetch_assoc();
    
    if ($servicio) {
        echo json_encode(['success' => true, 'data' => $servicio]);
    } else {
        echo json_encode(['success' => false, 'mensaje' => 'Servicio no encontrado']);
    }
    exit;
}

// =============================================
// CREAR SERVICIO
// =============================================
if ($accion === 'crear') {
    $nombre = trim($_POST['nombre'] ?? '');
    $precio = floatval($_POST['precio'] ?? 0);
    $dia_facturacion = intval($_POST['dia_facturacion'] ?? 15);
    $dia_corte = intval($_POST['dia_corte'] ?? 15);
    $observacion = trim($_POST['observacion'] ?? '');
    
    if (empty($nombre) || $precio <= 0) {
        echo json_encode(['success' => false, 'mensaje' => 'Complete todos los campos obligatorios']);
        exit;
    }
    
    $stmt = $conexion->prepare("INSERT INTO servicio (nombre, precio, dia_facturacion, dia_corte, observacion, estado_pago) VALUES (?, ?, ?, ?, ?, 'pendiente')");
    $stmt->bind_param("sdiis", $nombre, $precio, $dia_facturacion, $dia_corte, $observacion);
    
    if ($stmt->execute()) {
        $id = $stmt->insert_id;
        echo json_encode([
            'success' => true, 
            'mensaje' => 'Servicio creado con día de corte: ' . $dia_corte,
            'id' => $id
        ]);
    } else {
        echo json_encode(['success' => false, 'mensaje' => 'Error al crear: ' . $conexion->error]);
    }
    $stmt->close();
    exit;
}

// =============================================
// EDITAR SERVICIO
// =============================================
if ($accion === 'editar') {
    $id = intval($_POST['id_servicio'] ?? 0);
    $nombre = trim($_POST['nombre'] ?? '');
    $precio = floatval($_POST['precio'] ?? 0);
    $dia_facturacion = intval($_POST['dia_facturacion'] ?? 15);
    $dia_corte = intval($_POST['dia_corte'] ?? 15);
    $observacion = trim($_POST['observacion'] ?? '');
    
    if ($id <= 0 || empty($nombre) || $precio <= 0) {
        echo json_encode(['success' => false, 'mensaje' => 'Complete todos los campos obligatorios']);
        exit;
    }
    
    $stmt = $conexion->prepare("UPDATE servicio SET 
                                nombre = ?, 
                                precio = ?, 
                                dia_facturacion = ?, 
                                dia_corte = ?, 
                                observacion = ? 
                                WHERE id_servicio = ?");
    $stmt->bind_param("sdiisi", $nombre, $precio, $dia_facturacion, $dia_corte, $observacion, $id);
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true, 
            'mensaje' => 'Servicio actualizado. Nuevo día de corte: ' . $dia_corte
        ]);
    } else {
        echo json_encode(['success' => false, 'mensaje' => 'Error al actualizar: ' . $conexion->error]);
    }
    $stmt->close();
    exit;
}

// =============================================
// ELIMINAR SERVICIO
// =============================================
if ($accion === 'eliminar') {
    $id = intval($_POST['id_servicio'] ?? 0);
    
    if ($id <= 0) {
        echo json_encode(['success' => false, 'mensaje' => 'ID no válido']);
        exit;
    }
    
    // Verificar si tiene clientes asignados
    $check = $conexion->query("SELECT COUNT(*) as total FROM cliente WHERE id_servicio = $id");
    $row = $check->fetch_assoc();
    $total = $row['total'] ?? 0;
    
    if ($total > 0) {
        echo json_encode([
            'success' => false, 
            'mensaje' => "No se puede eliminar. Tiene $total cliente(s) asignado(s)."
        ]);
        exit;
    }
    
    $stmt = $conexion->prepare("DELETE FROM servicio WHERE id_servicio = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'mensaje' => 'Servicio eliminado correctamente']);
    } else {
        echo json_encode(['success' => false, 'mensaje' => 'Error al eliminar: ' . $conexion->error]);
    }
    $stmt->close();
    exit;
}

// =============================================
// CAMBIAR ESTADO DE PAGO (para cobrador)
// =============================================
if ($accion === 'cambiar_estado_pago') {
    $id = intval($_POST['id_servicio'] ?? 0);
    $estado = $_POST['estado'] ?? '';
    
    if ($id <= 0 || !in_array($estado, ['pendiente', 'pagado', 'vencido'])) {
        echo json_encode(['success' => false, 'mensaje' => 'Datos inválidos']);
        exit;
    }
    
    // Verificar tolerancia (día de corte + 1)
    $hoy = new DateTime();
    $mesActual = intval($hoy->format('n'));
    $anioActual = intval($hoy->format('Y'));
    
    $stmt = $conexion->prepare("SELECT dia_corte FROM servicio WHERE id_servicio = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $servicio = $result->fetch_assoc();
    $stmt->close();
    
    if (!$servicio) {
        echo json_encode(['success' => false, 'mensaje' => 'Servicio no encontrado']);
        exit;
    }
    
    $dia_corte = intval($servicio['dia_corte'] ?? 15);
    $fechaTolerancia = new DateTime("$anioActual-$mesActual-" . ($dia_corte + 1));
    
    if ($estado === 'pagado' && $hoy > $fechaTolerancia) {
        echo json_encode([
            'success' => false, 
            'mensaje' => "❌ Período de pago cerrado. El corte fue el día $dia_corte. Tienes hasta el día " . ($dia_corte + 1) . " para pagar."
        ]);
        exit;
    }
    
    $stmt = $conexion->prepare("UPDATE servicio SET estado_pago = ?, fecha_pago = CURDATE() WHERE id_servicio = ?");
    $stmt->bind_param("si", $estado, $id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'mensaje' => 'Estado de pago actualizado a: ' . $estado]);
    } else {
        echo json_encode(['success' => false, 'mensaje' => 'Error al actualizar: ' . $conexion->error]);
    }
    $stmt->close();
    exit;
}

// =============================================
// OBTENER CLIENTES PARA COBRADOR
// =============================================
if ($accion === 'get_cobrador') {
    // Solo cobradores (id_rol = 2)
    if ($_SESSION['id_rol'] != 2) {
        echo json_encode(['success' => false, 'mensaje' => 'No autorizado']);
        exit;
    }
    
    $sql = "SELECT 
                s.id_servicio as id,
                c.nombre,
                c.direccion,
                s.estado_pago as estado,
                s.observacion,
                s.nombre as servicio_nombre,
                s.precio,
                s.dia_corte,
                s.dia_facturacion
            FROM servicio s
            INNER JOIN cliente c ON s.id_cliente = c.id
            WHERE c.estado = 'Activo' 
            AND s.estado_pago = 'pendiente'
            ORDER BY c.nombre ASC";
    
    $result = $conexion->query($sql);
    
    if (!$result) {
        echo json_encode(['success' => false, 'mensaje' => $conexion->error]);
        exit;
    }
    
    $clientes = [];
    $hoy = new DateTime();
    $mesActual = intval($hoy->format('n'));
    $anioActual = intval($hoy->format('Y'));
    
    while ($row = $result->fetch_assoc()) {
        $diaCorte = intval($row['dia_corte'] ?? 15);
        $fechaTolerancia = new DateTime("$anioActual-$mesActual-" . ($diaCorte + 1));
        
        // Solo mostrar si está dentro de la tolerancia
        if ($hoy <= $fechaTolerancia) {
            $clientes[] = [
                'id' => intval($row['id']),
                'nombre' => $row['nombre'],
                'direccion' => $row['direccion'] ?? 'Sin dirección',
                'estado' => $row['estado'] ?? 'pendiente',
                'observacion' => $row['observacion'] ?? '',
                'servicio_nombre' => $row['servicio_nombre'] ?? 'Sin Servicio',
                'precio' => floatval($row['precio'] ?? 0),
                'dia_corte' => $diaCorte,
                'dia_facturacion' => $row['dia_facturacion'] ?? '15'
            ];
        }
    }
    
    echo json_encode(['success' => true, 'clientes' => $clientes]);
    exit;
}

// =============================================
// ACCIÓN NO VÁLIDA
// =============================================
echo json_encode(['success' => false, 'mensaje' => 'Acción no válida']);
$conexion->close();
?>