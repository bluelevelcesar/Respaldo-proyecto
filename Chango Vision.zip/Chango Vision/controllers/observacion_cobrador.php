<?php
// controllers/observacion_cobrador.php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 2) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

include __DIR__ . '/../config/conexion.php';

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'] ?? 0;
$observacion = $data['observacion'] ?? '';

$stmt = $conexion->prepare("UPDATE cliente SET observacion_pago = ? WHERE id = ?");
$stmt->bind_param("si", $observacion, $id);
$stmt->execute();
$stmt->close();
$conexion->close();

echo json_encode(['success' => true]);
?>