<?php
// controllers/verificar_vencimientos.php

function verificarYProcesarVencimientos($conexion) {
    if (!$conexion) return;
    
    $diaActual = intval(date('j'));
    
    // DÍA 1: Poner en PAGADO
    if ($diaActual == 1) {
        @$conexion->query("UPDATE cliente SET estado_pago = 'pagado', fecha_ultimo_pago = CURDATE() WHERE estado = 'Activo'");
        @$conexion->query("UPDATE servicio SET estado_pago = 'pagado', fecha_pago = CURDATE()");
    }
    
    // DÍA 15: Poner en PENDIENTE
    if ($diaActual == 15) {
        @$conexion->query("UPDATE cliente SET estado_pago = 'pendiente' WHERE estado = 'Activo' AND estado_pago = 'pagado'");
        @$conexion->query("UPDATE servicio SET estado_pago = 'pendiente' WHERE estado_pago = 'pagado'");
    }
}
?>