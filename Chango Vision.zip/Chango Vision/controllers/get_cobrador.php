<?php
// controllers/get_cobrador.php

ini_set('display_errors', 0);
error_reporting(0);

session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 2) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

include __DIR__ . '/../config/conexion.php';

if (!$conexion) {
    echo json_encode(['success' => false, 'error' => 'Error de conexión']);
    exit;
}

// =============================================
// CONSULTA: OBTENER CLIENTES CON SERVICIOS PENDIENTES
// =============================================
$sql = "SELECT 
            c.id,
            c.nombre,
            c.apellido,
            c.direccion,
            c.estado_pago as estado,
            c.observacion_pago as observacion,
            c.id_servicio,
            c.id_tipo,
            s.id_servicio as servicio_id,
            s.nombre as servicio_nombre,
            s.precio,
            s.dia_corte,
            s.estado_pago as servicio_estado
        FROM cliente c
        LEFT JOIN servicio s ON c.id_servicio = s.id_servicio
        WHERE c.estado = 'Activo' 
        AND c.estado_pago = 'pendiente'
        ORDER BY c.nombre ASC";

$result = $conexion->query($sql);

if (!$result) {
    echo json_encode(['success' => false, 'error' => 'Error SQL: ' . $conexion->error]);
    $conexion->close();
    exit;
}

$clientes = [];

while ($row = $result->fetch_assoc()) {
    // Si el cliente no tiene servicio, obtener datos del tipo_servicio
    $servicio_nombre = $row['servicio_nombre'];
    $precio = floatval($row['precio'] ?? 0);
    $dia_corte = intval($row['dia_corte'] ?? 15);
    $servicio_id = intval($row['servicio_id'] ?? 0);
    
    // Si no tiene servicio, intentar obtener datos del tipo_servicio
    if (!$servicio_id && $row['id_tipo']) {
        $sql_tipo = "SELECT nombre, precio_base, dia_corte FROM tipo_servicio WHERE id_tipo = ?";
        $stmt_tipo = $conexion->prepare($sql_tipo);
        $stmt_tipo->bind_param("i", $row['id_tipo']);
        $stmt_tipo->execute();
        $tipo = $stmt_tipo->get_result()->fetch_assoc();
        if ($tipo) {
            $servicio_nombre = $tipo['nombre'];
            $precio = floatval($tipo['precio_base'] ?? 0);
            $dia_corte = intval($tipo['dia_corte'] ?? 15);
        }
    }
    
    $clientes[] = [
        'id' => intval($row['id']),
        'servicio_id' => $servicio_id,
        'nombre' => trim($row['nombre'] . ' ' . ($row['apellido'] ?? '')),
        'direccion' => $row['direccion'] ?? 'Sin dirección',
        'estado' => $row['estado'] ?? 'pendiente',
        'observacion' => $row['observacion'] ?? '',
        'servicio_nombre' => $servicio_nombre ?? 'Sin Servicio',
        'precio' => $precio,
        'dia_corte' => $dia_corte
    ];
}

echo json_encode(['success' => true, 'clientes' => $clientes]);
$conexion->close();
?>