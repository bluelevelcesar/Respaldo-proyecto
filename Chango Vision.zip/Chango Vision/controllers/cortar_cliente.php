<?php
// controllers/cortar_cliente.php
session_start();

if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 3) {
    header('Location: login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';

$id_cliente = $_GET['id'] ?? 0;

if ($id_cliente) {
    // Cambiar estado a "Cortado"
    $stmt = $conexion->prepare("UPDATE cliente SET estado = 'Cortado', fecha_corte = NOW() WHERE id = ?");
    $stmt->bind_param("i", $id_cliente);
    $stmt->execute();
    
    // Registrar en historial
    $log = $conexion->prepare("INSERT INTO historial_pago (id_cliente, accion, detalle) VALUES (?, 'CORTE_MANUAL', 'Corte realizado por técnico')");
    $log->bind_param("i", $id_cliente);
    $log->execute();
}

header("Location: ../pages/clientes_a_cortar.php");
exit;
?><?php
// controllers/cortar_cliente.php
session_start();

if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 3) {
    header('Location: login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';

$id_cliente = $_GET['id'] ?? 0;

if ($id_cliente) {
    // Cambiar estado a "Cortado"
    $stmt = $conexion->prepare("UPDATE cliente SET estado = 'Cortado', fecha_corte = NOW() WHERE id = ?");
    $stmt->bind_param("i", $id_cliente);
    $stmt->execute();
    
    // Registrar en historial
    $log = $conexion->prepare("INSERT INTO historial_pago (id_cliente, accion, detalle) VALUES (?, 'CORTE_MANUAL', 'Corte realizado por técnico')");
    $log->bind_param("i", $id_cliente);
    $log->execute();
}

header("Location: ../pages/clientes_a_cortar.php");
exit;
?>