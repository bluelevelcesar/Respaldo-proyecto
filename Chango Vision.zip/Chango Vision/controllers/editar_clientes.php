<?php
session_start();
header('Content-Type: application/json');

// Verificar sesión
if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 1) {
    echo json_encode(["status" => "error", "message" => "No autorizado"]);
    exit;
}

include __DIR__ . '/../config/conexion.php';

if (!$conexion) {
    echo json_encode(["status" => "error", "message" => "Error de conexión"]);
    exit;
}

// Obtener la acción
$accion = $_POST['accion'] ?? '';

// =============================================
// 1. CAMBIAR ESTADO (Activo ↔ Inactivo)
// =============================================
if ($accion === 'cambiar_estado') {
    $id = intval($_POST['id'] ?? 0);
    $estado = $_POST['estado'] ?? '';
    $nombre = $_POST['nombre'] ?? '';

    if ($id <= 0 || empty($estado)) {
        echo json_encode(["status" => "error", "message" => "Datos incompletos"]);
        exit;
    }

    if (!in_array($estado, ['Activo', 'Inactivo'])) {
        echo json_encode(["status" => "error", "message" => "Estado no válido"]);
        exit;
    }

    $sql = "UPDATE cliente SET estado = '$estado' WHERE id = $id";

    if (mysqli_query($conexion, $sql)) {
        // Registrar en log
        $usuario = $_SESSION['usuario'] ?? 'admin';
        $descripcion = "Cambió estado del cliente ID $id - $nombre a $estado";
        
        $log = $conexion->prepare("INSERT INTO sistema_logs (id_usuario, usuario, accion, descripcion, tipo, pagina) 
                                   VALUES (?, ?, 'CAMBIAR_ESTADO', ?, 'INFO', 'admin_cliente.php')");
        $log->bind_param("iss", $_SESSION['id_usuario'], $usuario, $descripcion);
        $log->execute();
        
        $mensaje = $estado === 'Activo' ? "Cliente activado correctamente" : "Cliente desactivado correctamente";
        
        echo json_encode([
            "status" => "success",
            "message" => $mensaje,
            "nuevo_estado" => $estado
        ]);
    } else {
        echo json_encode([
            "status" => "error",
            "message" => mysqli_error($conexion)
        ]);
    }

    mysqli_close($conexion);
    exit;
}

// =============================================
// 2. EDITAR CLIENTE (datos personales)
// =============================================
if ($accion === 'editar') {
    $id = intval($_POST['id'] ?? 0);
    $nombre = trim($_POST['nombre'] ?? '');
    $dni = trim($_POST['dni'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $direccion = trim($_POST['direccion'] ?? '');
    $id_barrio = intval($_POST['id_barrio'] ?? 0);
    $id_tipo = intval($_POST['id_tipo'] ?? 0);

    if ($id <= 0 || empty($nombre) || empty($email)) {
        echo json_encode(["status" => "error", "message" => "Datos incompletos"]);
        exit;
    }

    // Obtener el servicio actual del cliente
    $sql = "SELECT id_servicio FROM cliente WHERE id = $id";
    $result = mysqli_query($conexion, $sql);
    $cliente = mysqli_fetch_assoc($result);
    $id_servicio = $cliente['id_servicio'] ?? 0;

    // Actualizar el tipo de servicio si cambió
    if ($id_servicio > 0 && $id_tipo > 0) {
        $sql = "UPDATE servicio SET id_tipo = $id_tipo WHERE id_servicio = $id_servicio";
        mysqli_query($conexion, $sql);
    }

    // Actualizar cliente (NO se modifica el estado)
    $sql = "UPDATE cliente SET 
                nombre = '$nombre', 
                dni = '$dni', 
                email = '$email', 
                telefono = '$telefono', 
                direccion = '$direccion', 
                id_barrio = $id_barrio 
            WHERE id = $id";

    if (mysqli_query($conexion, $sql)) {
        // Registrar en log
        $usuario = $_SESSION['usuario'] ?? 'admin';
        $descripcion = "Editó el cliente ID $id - $nombre";
        
        $log = $conexion->prepare("INSERT INTO sistema_logs (id_usuario, usuario, accion, descripcion, tipo, pagina) 
                                   VALUES (?, ?, 'EDITAR_CLIENTE', ?, 'INFO', 'admin_cliente.php')");
        $log->bind_param("iss", $_SESSION['id_usuario'], $usuario, $descripcion);
        $log->execute();
        
        echo json_encode(["status" => "success", "message" => "Cliente actualizado correctamente"]);
    } else {
        echo json_encode(["status" => "error", "message" => mysqli_error($conexion)]);
    }

    mysqli_close($conexion);
    exit;
}

// =============================================
// 3. ACCIÓN NO VÁLIDA
// =============================================
echo json_encode(["status" => "error", "message" => "Acción no válida"]);
mysqli_close($conexion);
?>