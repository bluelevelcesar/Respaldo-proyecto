<?php
// controllers/get_log.php
session_start();
header('Content-Type: application/json');

error_reporting(E_ALL);
ini_set('display_errors', 1);

$respuesta = ['success' => false, 'error' => 'Error desconocido'];

if (!isset($_SESSION['id_usuario'])) {
    $respuesta['error'] = 'No autorizado - Inicie sesión';
    echo json_encode($respuesta);
    exit;
}

$conexion_path = __DIR__ . '/../config/conexion.php';

if (!file_exists($conexion_path)) {
    $respuesta['error'] = 'No se encuentra conexion.php en: ' . $conexion_path;
    echo json_encode($respuesta);
    exit;
}

include $conexion_path;

if (!$conexion) {
    $respuesta['error'] = 'Error de conexión a la base de datos';
    echo json_encode($respuesta);
    exit;
}

$check = $conexion->query("SHOW TABLES LIKE 'log'");
if (!$check || $check->num_rows == 0) {
    $respuesta['error'] = 'La tabla log no existe.';
    echo json_encode($respuesta);
    exit;
}

// =============================================
// PAGINACIÓN
// =============================================
$registros_por_pagina = 10;
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$pagina_actual = max(1, $pagina_actual);
$offset = ($pagina_actual - 1) * $registros_por_pagina;

// Estadísticas
$totalLogs = 0;
$result = $conexion->query("SELECT COUNT(*) as total FROM log");
if ($result) {
    $totalLogs = $result->fetch_assoc()['total'];
}

$logsHoy = 0;
$result = $conexion->query("SELECT COUNT(*) as total FROM log WHERE DATE(fecha_registro) = CURDATE()");
if ($result) {
    $logsHoy = $result->fetch_assoc()['total'];
}

// Logs con paginación
$logs = [];
$result = $conexion->query("
    SELECT 
        usuario, 
        accion, 
        descripcion, 
        DATE(fecha_registro) as fecha, 
        TIME(fecha_registro) as hora 
    FROM log 
    ORDER BY fecha_registro DESC 
    LIMIT $offset, $registros_por_pagina
");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $logs[] = [
            'administrador' => $row['usuario'] ?? 'Sistema',
            'accion' => $row['accion'] ?? '-',
            'afectado' => $row['descripcion'] ?? '-',
            'fecha' => $row['fecha'] ?? '-',
            'hora' => $row['hora'] ?? '-'
        ];
    }
}

// Servicios
$totalServicios = 0;
$result = $conexion->query("SELECT COUNT(*) as total FROM servicio");
if ($result) {
    $totalServicios = $result->fetch_assoc()['total'];
}

// Tickets
$totalTickets = 0;
$result = $conexion->query("SELECT COUNT(*) as total FROM soporte WHERE estado IN ('pendiente', 'en_progreso')");
if ($result) {
    $totalTickets = $result->fetch_assoc()['total'];
}

$total_paginas = ceil($totalLogs / $registros_por_pagina);

echo json_encode([
    'success' => true,
    'logs' => $logs,
    'estadisticas' => [
        'total' => $totalLogs,
        'hoy' => $logsHoy
    ],
    'totalServicios' => $totalServicios,
    'totalTickets' => $totalTickets,
    'paginacion' => [
        'pagina_actual' => $pagina_actual,
        'total_paginas' => $total_paginas,
        'registros_por_pagina' => $registros_por_pagina,
        'total_registros' => $totalLogs
    ]
]);
exit;
?>