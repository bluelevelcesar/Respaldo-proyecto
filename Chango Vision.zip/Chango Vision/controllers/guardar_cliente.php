<?php
session_start();
header('Content-Type: application/json');

// Verificar sesión
if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 1) {
    echo json_encode(["status" => "error", "message" => "No autorizado"]);
    exit;
}

include __DIR__ . '/../config/conexion.php';

if (!$conexion) {
    echo json_encode(["status" => "error", "message" => "Error de conexión"]);
    exit;
}

$accion = $_POST['accion'] ?? '';

// =============================================
// REGISTRAR CLIENTE (versión mejorada)
// =============================================
if ($accion === 'registrar') {
    $nombre = trim($_POST['nombre'] ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $dni = trim($_POST['dni'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $direccion = trim($_POST['direccion'] ?? '');
    $id_barrio = intval($_POST['id_barrio'] ?? 0);
    $id_tipo = intval($_POST['id_tipo'] ?? 0);
    $fecha_primer_cobro = $_POST['fecha_primer_cobro'] ?? date('Y-m-d');
    $no_local = isset($_POST['no_local']) ? 1 : 0;
    $estado_pago = 'pendiente';

    // Validaciones
    if (empty($nombre) || empty($apellido) || empty($dni) || $id_barrio <= 0 || $id_tipo <= 0) {
        echo json_encode(["status" => "error", "message" => "Complete todos los campos obligatorios"]);
        exit;
    }

    // Generar código de cliente (INICIALES + NÚMERO)
    $inicial_nombre = strtoupper(substr(trim($nombre), 0, 1));
    $inicial_apellido = strtoupper(substr(trim($apellido), 0, 1));
    if (empty($inicial_nombre)) $inicial_nombre = 'X';
    if (empty($inicial_apellido)) $inicial_apellido = 'X';
    $base = $inicial_nombre . $inicial_apellido;
    
    $sql = "SELECT codigo_cliente FROM cliente WHERE codigo_cliente LIKE '$base%' ORDER BY codigo_cliente DESC";
    $result = mysqli_query($conexion, $sql);
    $max_numero = 0;
    while ($row = mysqli_fetch_assoc($result)) {
        $numero = intval(substr($row['codigo_cliente'], 2));
        if ($numero > $max_numero) $max_numero = $numero;
    }
    $codigo_cliente = $base . ($max_numero + 1);

    // Procesar foto DNI
    $foto_dni = '';
    if ($no_local == 1 && isset($_FILES['foto_dni']) && $_FILES['foto_dni']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = __DIR__ . '/../uploads/dni/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        $ext = pathinfo($_FILES['foto_dni']['name'], PATHINFO_EXTENSION);
        $foto_dni = 'dni_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
        move_uploaded_file($_FILES['foto_dni']['tmp_name'], $upload_dir . $foto_dni);
    }

    // Insertar cliente
    $sql = "INSERT INTO cliente (codigo_cliente, nombre, apellido, dni, email, telefono, direccion, id_barrio, id_tipo, foto_dni, fecha_primer_cobro, estado_pago, no_local) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "sssssssiissii", $codigo_cliente, $nombre, $apellido, $dni, $email, $telefono, $direccion, $id_barrio, $id_tipo, $foto_dni, $fecha_primer_cobro, $estado_pago, $no_local);

    if (mysqli_stmt_execute($stmt)) {
        echo json_encode([
            "status" => "success",
            "message" => "✅ Cliente registrado correctamente. Código: $codigo_cliente"
        ]);
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "❌ Error al registrar: " . mysqli_error($conexion)
        ]);
    }
    mysqli_stmt_close($stmt);
    mysqli_close($conexion);
    exit;
}

echo json_encode(["status" => "error", "message" => "Acción no válida"]);
mysqli_close($conexion);
?>