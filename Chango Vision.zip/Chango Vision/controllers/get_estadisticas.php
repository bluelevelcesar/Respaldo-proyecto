<?php
session_start();

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

include __DIR__ . '/../config/conexion.php';

// 1. TOTAL CLIENTES
$sql_total = "SELECT COUNT(*) as total FROM cliente";
$result_total = mysqli_query($conexion, $sql_total);
$total_clientes = mysqli_fetch_assoc($result_total)['total'] ?? 0;

// 2. PAGARON (estado_pago = 'pagado')
$sql_pagaron = "SELECT COUNT(*) as total FROM cliente WHERE estado_pago = 'pagado'";
$result_pagaron = mysqli_query($conexion, $sql_pagaron);
$pagaron = mysqli_fetch_assoc($result_pagaron)['total'] ?? 0;

// 3. PENDIENTES
$sql_pendientes = "SELECT COUNT(*) as total FROM cliente WHERE estado_pago = 'pendiente'";
$result_pendientes = mysqli_query($conexion, $sql_pendientes);
$pendientes = mysqli_fetch_assoc($result_pendientes)['total'] ?? 0;

// 4. CORTADOS (suspendidos)
$sql_cortados = "SELECT COUNT(*) as total FROM cliente WHERE estado_pago = 'suspendido'";
$result_cortados = mysqli_query($conexion, $sql_cortados);
$cortados = mysqli_fetch_assoc($result_cortados)['total'] ?? 0;

// 5. TOTAL GANANCIAS
$sql_ganancias = "SELECT SUM(monto) as total FROM pago WHERE estado = 'Pagado'";
$result_ganancias = mysqli_query($conexion, $sql_ganancias);
$total_ganancias = mysqli_fetch_assoc($result_ganancias)['total'] ?? 0;

// 6. GANANCIAS MENSUALES (últimos 6 meses)
$meses = [];
$ganancias_mensuales = [];
for ($i = 5; $i >= 0; $i--) {
    $mes = date('m', strtotime("-$i months"));
    $anio = date('Y', strtotime("-$i months"));
    $nombre_mes = date('M', strtotime("-$i months"));
    $meses[] = $nombre_mes;
    
    $sql = "SELECT SUM(monto) as total FROM pago WHERE mes = $mes AND anio = $anio AND estado = 'Pagado'";
    $result = mysqli_query($conexion, $sql);
    $ganancias_mensuales[] = mysqli_fetch_assoc($result)['total'] ?? 0;
}

// 7. CLIENTES POR BARRIO
$sql_barrios = "SELECT b.nombre as barrio, COUNT(c.id) as cantidad 
                FROM cliente c
                LEFT JOIN barrio b ON c.id_barrio = b.id_barrio
                GROUP BY c.id_barrio
                ORDER BY cantidad DESC";
$result_barrios = mysqli_query($conexion, $sql_barrios);
$clientes_por_barrio = mysqli_fetch_all($result_barrios, MYSQLI_ASSOC);

// 8. FECHA DE ACTUALIZACIÓN
$fecha_actualizacion = date('d/m/Y H:i:s');

echo json_encode([
    'success' => true,
    'total_clientes' => $total_clientes,
    'pagaron' => $pagaron,
    'pendientes' => $pendientes,
    'cortados' => $cortados,
    'total_ganancias' => $total_ganancias,
    'meses' => $meses,
    'ganancias_mensuales' => $ganancias_mensuales,
    'clientes_por_barrio' => $clientes_por_barrio,
    'fecha_actualizacion' => $fecha_actualizacion
]);
?>