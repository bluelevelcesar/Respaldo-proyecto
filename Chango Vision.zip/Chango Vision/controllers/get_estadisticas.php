<?php
error_reporting(E_ALL);
ini_set('display_errors', '0');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
header('Content-Type: application/json; charset=utf-8');

try {
    if (!isset($_SESSION['id_usuario'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'No autorizado'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    require __DIR__ . '/../config/conexion.php';
    if (!isset($conexion) || !($conexion instanceof mysqli)) {
        throw new RuntimeException('No se encontró una conexión MySQL válida en config/conexion.php');
    }

    $mes_actual = (int)date('n');
    $anio_actual = (int)date('Y');

    // 1. Tarjetas principales
    $res = $conexion->query("SELECT COUNT(*) AS total FROM cliente WHERE estado = 'Activo'");
    $total_clientes = (int)($res->fetch_assoc()['total'] ?? 0);

    $stmt = $conexion->prepare("SELECT COUNT(DISTINCT id_cliente) AS total FROM pago WHERE mes = ? AND anio = ? AND estado = 'Pagado'");
    $stmt->bind_param('ii', $mes_actual, $anio_actual);
    $stmt->execute();
    $pagaron = (int)($stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $stmt->close();

    $stmt = $conexion->prepare("SELECT COUNT(DISTINCT id_cliente) AS total FROM pago WHERE mes = ? AND anio = ? AND estado = 'Pendiente'");
    $stmt->bind_param('ii', $mes_actual, $anio_actual);
    $stmt->execute();
    $pendientes = (int)($stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $stmt->close();

    $res = $conexion->query("SELECT COUNT(*) AS total FROM cliente WHERE LOWER(estado_pago) = 'suspendido' AND estado = 'Activo'");
    $cortados = (int)($res->fetch_assoc()['total'] ?? 0);

    $stmt = $conexion->prepare("SELECT COALESCE(SUM(monto), 0) AS total FROM pago WHERE mes = ? AND anio = ? AND estado = 'Pagado'");
    $stmt->bind_param('ii', $mes_actual, $anio_actual);
    $stmt->execute();
    $total_ganancias = (float)($stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $stmt->close();

    // 2. Últimos 12 meses y precio mensual por tipo de servicio.
    // Importante: pago.monto conserva el monto registrado para ese mes.
    // No se reemplazan meses sin pagos por el precio actual; se muestran como null.
    $nombres_meses = [1=>'Ene', 2=>'Feb', 3=>'Mar', 4=>'Abr', 5=>'May', 6=>'Jun', 7=>'Jul', 8=>'Ago', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dic'];
    $meses = [];
    $periodos = [];
    for ($i = 11; $i >= 0; $i--) {
        $time = strtotime("first day of -$i months");
        $m = (int)date('n', $time);
        $a = (int)date('Y', $time);
        $meses[] = $nombres_meses[$m] . ' ' . $a;
        $periodos[] = ['mes' => $m, 'anio' => $a];
    }

    $tipos = [];
    $res = $conexion->query("SELECT id_tipo, nombre, precio_base FROM tipo_servicio WHERE estado = 'Activo' ORDER BY nombre");
    while ($row = $res->fetch_assoc()) {
        $tipos[] = ['id_tipo' => (int)$row['id_tipo'], 'nombre' => $row['nombre'], 'precio_base' => (float)$row['precio_base']];
    }

    // Consulta mensual de pagos por el tipo actual del cliente.
    // Como pago no guarda id_tipo, la relación se hace mediante cliente.id_tipo.
    // Se incluyen Pagado y Pendiente porque ambos tienen monto mensual registrado.
    $stmt = $conexion->prepare(
        "SELECT c.id_tipo, p.mes, p.anio, AVG(p.monto) AS precio_mes, COUNT(*) AS cantidad
         FROM pago p
         INNER JOIN cliente c ON c.id = p.id_cliente
         INNER JOIN tipo_servicio ts ON ts.id_tipo = c.id_tipo
         WHERE p.mes BETWEEN 1 AND 12
           AND p.anio BETWEEN ? AND ?
           AND p.estado IN ('Pagado', 'Pendiente')
         GROUP BY c.id_tipo, p.anio, p.mes"
    );
    $anio_inicio = $periodos[0]['anio'];
    $anio_fin = $periodos[count($periodos)-1]['anio'];
    $stmt->bind_param('ii', $anio_inicio, $anio_fin);
    $stmt->execute();
    $res = $stmt->get_result();
    $precios = [];
    while ($row = $res->fetch_assoc()) {
        $key = (int)$row['id_tipo'] . '-' . (int)$row['anio'] . '-' . (int)$row['mes'];
        $precios[$key] = round((float)$row['precio_mes'], 2);
    }
    $stmt->close();

    $colores = ['#06b6d4', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#3b82f6', '#84cc16'];
    $datasets_servicios = [];
    foreach ($tipos as $index => $tipo) {
        $datos = [];
        foreach ($periodos as $p) {
            $key = $tipo['id_tipo'] . '-' . $p['anio'] . '-' . $p['mes'];
            // null produce un hueco en la línea, en lugar de inventar un precio histórico.
            $datos[] = array_key_exists($key, $precios) ? $precios[$key] : null;
        }
        $color = $colores[$index % count($colores)];
        $datasets_servicios[] = [
            'label' => $tipo['nombre'],
            'data' => $datos,
            'borderColor' => $color,
            'backgroundColor' => $color,
            'borderWidth' => 3,
            'fill' => false,
            'tension' => 0.25,
            'spanGaps' => false,
            'pointRadius' => 4
        ];
    }

// 3. Clientes activos por barrio agrupados por nombre y con clientes surtidos aleatoriamente
    $res = $conexion->query(
        "SELECT MIN(c.id_barrio) AS id_barrio, b.nombre AS barrio, COUNT(c.id) AS cantidad
         FROM cliente c
         LEFT JOIN barrio b ON c.id_barrio = b.id_barrio
         WHERE c.estado = 'Activo'
         GROUP BY b.nombre
         ORDER BY cantidad DESC"
    );
    $barrios_raw = $res->fetch_all(MYSQLI_ASSOC);
    
    $clientes_por_barrio = [];
    foreach ($barrios_raw as $b) {
        $id_barrio = $b['id_barrio'];
        $nombre_barrio = $b['barrio'];
        
        // Consultar únicamente clientes activos de este barrio específico de forma surtida
        if ($nombre_barrio !== null) {
            $stmt_cli = $conexion->prepare("SELECT c.nombre, c.apellido FROM cliente c LEFT JOIN barrio b ON c.id_barrio = b.id_barrio WHERE b.nombre = ? AND c.estado = 'Activo' ORDER BY RAND()");
            $stmt_cli->bind_param('s', $nombre_barrio);
        } else {
            $stmt_cli = $conexion->prepare("SELECT nombre, apellido FROM cliente WHERE id_barrio IS NULL AND estado = 'Activo' ORDER BY RAND()");
        }
        $stmt_cli->execute();
        $res_cli = $stmt_cli->get_result();
        $clientes_lista = $res_cli->fetch_all(MYSQLI_ASSOC);
        $stmt_cli->close();
        
        $clientes_por_barrio[] = [
            'id_barrio' => $id_barrio,
            'barrio' => $nombre_barrio ?? 'Sin Barrio',
            'cantidad' => (int)$b['cantidad'],
            'clientes' => $clientes_lista
        ];
    }

    echo json_encode([
        'success' => true,
        'total_clientes' => $total_clientes,
        'pagaron' => $pagaron,
        'pendientes' => $pendientes,
        'cortados' => $cortados,
        'total_ganancias' => round($total_ganancias, 2),
        'meses' => $meses,
        'datasets_servicios' => $datasets_servicios,
        'clientes_por_barrio' => $clientes_por_barrio,
        'fecha_actualizacion' => date('d/m/Y H:i:s')
    ], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
} catch (Throwable $e) {
    error_log('[get_estadisticas.php] ' . $e->getMessage() . ' en ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Error al cargar estadísticas: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
}
