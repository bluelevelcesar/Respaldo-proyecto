<?php
// controllers/funcion_log.php

class SistemaLog {

    private $conexion;

    public function __construct($conexion) {
        $this->conexion = $conexion;
    }

    // ==================================================
    // REGISTRO GENERAL (PRIVADO)
    // ==================================================
    private function registrar($id_usuario, $nombre_usuario, $accion, $afectado, $descripcion = '', $tipo = 'info') {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $pagina = $_SERVER['REQUEST_URI'] ?? '';

        $sql = "INSERT INTO log (id_usuario, usuario, accion, descripcion, tipo, ip_address, user_agent, pagina) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $this->conexion->prepare($sql);

        if (!$stmt) {
            return false;
        }

        $id_usuario_null = empty($id_usuario) ? null : $id_usuario;
        $mensaje_completo = $afectado . ($descripcion ? " - " . $descripcion : "");

        $stmt->bind_param(
            "isssssss",
            $id_usuario_null,
            $nombre_usuario,
            $accion,
            $mensaje_completo,
            $tipo,
            $ip,
            $userAgent,
            $pagina
        );

        return $stmt->execute();
    }

    // ==================================================
    // ✅ MÉTODO GENÉRICO PARA REGISTRAR CUALQUIER ACCIÓN
    // ==================================================
    public function registrarAccion($id_usuario, $nombre_usuario, $accion, $afectado, $descripcion = '', $tipo = 'info') {
        return $this->registrar($id_usuario, $nombre_usuario, $accion, $afectado, $descripcion, $tipo);
    }

    // ==================================================
    // ✅ SESIÓN
    // ==================================================
    public function loginExitoso($id_usuario, $nombre_usuario, $rol) {
        return $this->registrar($id_usuario, $nombre_usuario, 'Inicio de Sesión', "Usuario: $nombre_usuario", "Rol: $rol", 'success');
    }

    public function loginFallido($email, $razon) {
        return $this->registrar(null, 'Sistema', 'Intento de Login Fallido', "Email: $email", "Razón: $razon", 'warning');
    }

    public function cerrarSesion($id_usuario, $nombre_usuario) {
        return $this->registrar($id_usuario, $nombre_usuario, 'Cerrar Sesión', "Usuario: $nombre_usuario", 'Sesión cerrada', 'info');
    }

    // ==================================================
    // ✅ CLIENTES (desde admin_cliente.php)
    // ==================================================
    public function crearCliente($id_usuario, $nombre_usuario, $cliente_nombre, $codigo, $dni = '') {
        return $this->registrar($id_usuario, $nombre_usuario, 'Crear Cliente', 
            "Cliente: $cliente_nombre (Código: $codigo)", "DNI: $dni", 'success');
    }

    public function editarCliente($id_usuario, $nombre_usuario, $cliente_nombre, $codigo, $dni = '') {
        return $this->registrar($id_usuario, $nombre_usuario, 'Editar Cliente', 
            "Cliente: $cliente_nombre (Código: $codigo)", "DNI: $dni", 'info');
    }

    public function eliminarCliente($id_usuario, $nombre_usuario, $cliente_nombre, $codigo) {
        return $this->registrar($id_usuario, $nombre_usuario, 'Eliminar Cliente', 
            "Cliente: $cliente_nombre (Código: $codigo)", 'Cliente eliminado del sistema', 'warning');
    }

    public function registrarPago($id_usuario, $nombre_usuario, $cliente_nombre, $codigo, $monto, $metodo = 'efectivo') {
        return $this->registrar($id_usuario, $nombre_usuario, 'Registrar Pago', 
            "Cliente: $cliente_nombre (Código: $codigo)", 
            "Monto: $" . number_format($monto, 0, ',', '.') . " - Método: $metodo", 'success');
    }

    public function cortarServicio($id_usuario, $nombre_usuario, $cliente_nombre, $codigo, $motivo) {
        return $this->registrar($id_usuario, $nombre_usuario, 'Cortar Servicio', 
            "Cliente: $cliente_nombre (Código: $codigo)", "Motivo: $motivo", 'warning');
    }

    // ==================================================
    // ✅ USUARIOS (desde usuarios.php)
    // ==================================================
    public function crearUsuario($id_usuario, $nombre_usuario, $usuario_nombre, $rol) {
        return $this->registrar($id_usuario, $nombre_usuario, 'Crear Usuario', 
            "Usuario: $usuario_nombre", "Rol: $rol", 'success');
    }

    public function editarUsuario($id_usuario, $nombre_usuario, $usuario_nombre) {
        return $this->registrar($id_usuario, $nombre_usuario, 'Editar Usuario', 
            "Usuario: $usuario_nombre", 'Datos actualizados', 'info');
    }

    public function eliminarUsuario($id_usuario, $nombre_usuario, $usuario_nombre) {
        return $this->registrar($id_usuario, $nombre_usuario, 'Eliminar Usuario', 
            "Usuario: $usuario_nombre", 'Usuario eliminado del sistema', 'warning');
    }

    public function reenviarCorreo($id_usuario, $nombre_usuario, $usuario_nombre, $email) {
        return $this->registrar($id_usuario, $nombre_usuario, 'Reenviar Correo', 
            "Usuario: $usuario_nombre", "Correo reenviado a: $email", 'info');
    }

    // ==================================================
    // ✅ USUARIO (cambiar datos personales)
    // ==================================================
    public function cambiarDatos($id_usuario, $nombre_usuario) {
        return $this->registrar($id_usuario, $nombre_usuario, 'Cambiar Datos Personales', 
            "Usuario: $nombre_usuario", 'Datos personales actualizados', 'info');
    }

    public function cambiarPassword($id_usuario, $nombre_usuario) {
        return $this->registrar($id_usuario, $nombre_usuario, 'Cambiar Contraseña', 
            "Usuario: $nombre_usuario", 'Contraseña actualizada', 'info');
    }

    // ==================================================
    // ✅ SERVICIOS (desde admin_red.php o admin.php)
    // ==================================================
    public function crearServicio($id_usuario, $nombre_usuario, $servicio_nombre) {
        return $this->registrar($id_usuario, $nombre_usuario, 'Crear Servicio', 
            "Servicio: $servicio_nombre", 'Nuevo servicio creado', 'success');
    }

    public function editarServicio($id_usuario, $nombre_usuario, $servicio_nombre) {
        return $this->registrar($id_usuario, $nombre_usuario, 'Editar Servicio', 
            "Servicio: $servicio_nombre", 'Servicio actualizado', 'info');
    }

    public function eliminarServicio($id_usuario, $nombre_usuario, $servicio_nombre) {
        return $this->registrar($id_usuario, $nombre_usuario, 'Eliminar Servicio', 
            "Servicio: $servicio_nombre", 'Servicio eliminado', 'warning');
    }

    // ==================================================
    // ✅ BARRIOS (desde admin_red.php o admin.php)
    // ==================================================
    public function crearBarrio($id_usuario, $nombre_usuario, $barrio_nombre) {
        return $this->registrar($id_usuario, $nombre_usuario, 'Crear Barrio', 
            "Barrio: $barrio_nombre", 'Nuevo barrio creado', 'success');
    }

    // ==================================================
    // ✅ OBTENER LOGS
    // ==================================================
    public function obtenerLogsRecientes($limite = 50) {
        $sql = "SELECT 
                    usuario as administrador, 
                    accion, 
                    descripcion as afectado, 
                    DATE(fecha_registro) as fecha, 
                    TIME(fecha_registro) as hora,
                    tipo,
                    pagina
                FROM log
                ORDER BY fecha_registro DESC
                LIMIT ?";

        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("i", $limite);
        $stmt->execute();
        $resultado = $stmt->get_result();
        return $resultado->fetch_all(MYSQLI_ASSOC);
    }

    public function getEstadisticas() {
        $stats = [];
        $result = $this->conexion->query("SELECT COUNT(*) as total FROM log");
        $stats['total'] = $result->fetch_assoc()['total'];
        
        $result = $this->conexion->query("SELECT COUNT(*) as total FROM log WHERE DATE(fecha_registro) = CURDATE()");
        $stats['hoy'] = $result->fetch_assoc()['total'];
        
        return $stats;
    }
}
?>