<?php
session_start();

if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../login.php');
    exit;
}

// ✅ SOLO ADMINISTRADOR (id_rol = 1) PUEDE ACCEDER
if ($_SESSION['id_rol'] != 1) {
    header('Location: ../login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';

// =============================================
// FILTROS
// =============================================
$fecha_inicio = $_GET['fecha_inicio'] ?? date('Y-m-01');
$fecha_fin = $_GET['fecha_fin'] ?? date('Y-m-d');
$tipo_reporte = $_GET['tipo_reporte'] ?? 'pagos';
$estado_cliente = $_GET['estado_cliente'] ?? 'todos';

// =============================================
// OBTENER DATOS SEGÚN EL TIPO DE REPORTE
// =============================================
$reporte_data = [];
$titulo_reporte = '';

// 1. REPORTE DE PAGOS (Adaptado a tu tabla 'pago')
if ($tipo_reporte === 'pagos') {
    $titulo_reporte = 'Historial y Reporte de Pagos';
    $sql = "SELECT 
                p.id_pago as id_historial,
                p.fecha_pago as fecha,
                p.monto,
                p.metodo_pago as metodo,
                p.mes,
                p.anio,
                p.estado,
                p.observaciones as detalle,
                c.nombre as cliente,
                c.apellido as cliente_apellido,
                s.nombre as servicio
            FROM pago p
            LEFT JOIN cliente c ON p.id_cliente = c.id
            LEFT JOIN servicio s ON c.id_servicio = s.id_servicio
            WHERE DATE(p.fecha_pago) BETWEEN '$fecha_inicio' AND '$fecha_fin'
            ORDER BY p.fecha_pago DESC";
    $result = mysqli_query($conexion, $sql);
    $reporte_data = $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];

    // Totales específicos para pagos
    $sql_total = "SELECT COALESCE(SUM(monto), 0) as total FROM pago";
    $result_total = mysqli_query($conexion, $sql_total);
    $total_recaudado = $result_total ? (float)mysqli_fetch_assoc($result_total)['total'] : 0;

    $sql_hoy = "SELECT COALESCE(SUM(monto), 0) as total FROM pago WHERE DATE(fecha_pago) = CURDATE()";
    $result_hoy = mysqli_query($conexion, $sql_hoy);
    $total_hoy = $result_hoy ? (float)mysqli_fetch_assoc($result_hoy)['total'] : 0;
}

// 2. REPORTE DE CLIENTES
elseif ($tipo_reporte === 'clientes') {
    $titulo_reporte = 'Reporte de Clientes';
    $estado_filtro = $estado_cliente !== 'todos' ? "AND c.estado = '$estado_cliente'" : '';
    $sql = "SELECT 
                c.id,
                c.nombre,
                c.dni,
                c.email,
                c.telefono,
                c.estado,
                c.estado_pago,
                c.fecha_ultimo_pago,
                s.nombre as servicio,
                s.precio,
                s.dia_corte,
                s.estado_pago as servicio_estado,
                ts.nombre as tipo_servicio
            FROM cliente c
            LEFT JOIN servicio s ON c.id_servicio = s.id_servicio
            LEFT JOIN tipo_servicio ts ON s.id_tipo = ts.id_tipo
            WHERE 1=1 $estado_filtro
            ORDER BY c.id DESC";
    $result = mysqli_query($conexion, $sql);
    $reporte_data = $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];
}

// 3. REPORTE DE ESTADÍSTICAS
elseif ($tipo_reporte === 'estadisticas') {
    $titulo_reporte = 'Estadísticas Generales';
    
    $sql_totales = "SELECT 
                        COUNT(CASE WHEN estado = 'Activo' THEN 1 END) as activos,
                        COUNT(CASE WHEN estado = 'Inactivo' THEN 1 END) as inactivos,
                        COUNT(CASE WHEN estado_pago = 'pagado' THEN 1 END) as pagados,
                        COUNT(CASE WHEN estado_pago = 'pendiente' THEN 1 END) as pendientes
                    FROM cliente";
    $result = mysqli_query($conexion, $sql_totales);
    $totales = mysqli_fetch_assoc($result);
    
    $sql_metodos = "SELECT metodo_pago as metodo, COUNT(*) as cantidad, SUM(monto) as total 
                    FROM pago 
                    WHERE DATE(fecha_pago) BETWEEN '$fecha_inicio' AND '$fecha_fin'
                    GROUP BY metodo_pago";
    $result = mysqli_query($conexion, $sql_metodos);
    $metodos_pago = $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];
    
    $sql_mensual = "SELECT 
                        DATE_FORMAT(fecha_pago, '%Y-%m') as mes,
                        COUNT(*) as cantidad,
                        SUM(monto) as total
                    FROM pago
                    WHERE fecha_pago >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                    GROUP BY DATE_FORMAT(fecha_pago, '%Y-%m')
                    ORDER BY mes DESC";
    $result = mysqli_query($conexion, $sql_mensual);
    $pagos_mensuales = $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];
    
    $reporte_data = [
        'totales' => $totales,
        'metodos_pago' => $metodos_pago,
        'pagos_mensuales' => $pagos_mensuales
    ];
}

// 4. REPORTE DE SERVICIOS
elseif ($tipo_reporte === 'servicios') {
    $titulo_reporte = 'Reporte de Servicios';
    $sql = "SELECT 
                s.id_servicio,
                s.nombre as servicio,
                s.precio,
                s.dia_facturacion,
                s.dia_corte,
                s.estado_pago,
                COUNT(c.id) as total_clientes,
                SUM(CASE WHEN c.estado = 'Activo' THEN 1 ELSE 0 END) as clientes_activos
            FROM servicio s
            LEFT JOIN cliente c ON s.id_servicio = c.id_servicio
            GROUP BY s.id_servicio
            ORDER BY s.id_servicio DESC";
    $result = mysqli_query($conexion, $sql);
    $reporte_data = $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];
}

$total_registros = is_array($reporte_data) && $tipo_reporte !== 'estadisticas' ? count($reporte_data) : 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reportes y Pagos - Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background: #f0f4f8; padding: 2rem; }
        .container { max-width: 1400px; margin: 0 auto; background: white; border-radius: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); overflow: hidden; }
        
        .header { background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white; padding: 1.5rem 2rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; }
        .header h1 { font-size: 1.5rem; display: flex; align-items: center; gap: 12px; }
        .header-actions { display: flex; gap: 12px; flex-wrap: wrap; }
        .btn-primary { background: white; border: none; padding: 0.6rem 1.3rem; border-radius: 40px; font-weight: 600; color: #1b4f6e; cursor: pointer; transition: 0.2s; display: flex; align-items: center; gap: 8px; }
        .btn-primary:hover { background: #e6f7ff; transform: scale(0.97); }
        .btn-outline-light { background: transparent; border: 1px solid rgba(255,255,255,0.5); padding: 0.6rem 1.3rem; border-radius: 40px; font-weight: 500; color: white; cursor: pointer; display: flex; align-items: center; gap: 8px; text-decoration: none; }
        .btn-outline-light:hover { background: rgba(255,255,255,0.15); }
        .btn-success { background: #10b981; color: white; border: none; padding: 0.6rem 1.3rem; border-radius: 40px; font-weight: 600; cursor: pointer; transition: 0.2s; display: inline-flex; align-items: center; gap: 8px; }
        .btn-success:hover { background: #059669; }

        .filtros { padding: 1.5rem 2rem; background: #f8fafc; border-bottom: 1px solid #e2e8f0; display: flex; flex-wrap: wrap; gap: 1rem; align-items: flex-end; }
        .filtros .form-group { display: flex; flex-direction: column; gap: 4px; }
        .filtros .form-group label { font-size: 0.7rem; font-weight: 600; color: #1b4f6e; text-transform: uppercase; letter-spacing: 0.5px; }
        .filtros .form-group input, .filtros .form-group select { padding: 8px 12px; border: 1.5px solid #dce5ec; border-radius: 10px; font-size: 0.9rem; background: white; outline: none; }
        .filtros .form-group input:focus, .filtros .form-group select:focus { border-color: #1b4f6e; box-shadow: 0 0 0 3px rgba(27,79,110,0.1); }
        .btn-filtro { background: #1b4f6e; color: white; border: none; padding: 8px 24px; border-radius: 10px; font-weight: 600; cursor: pointer; transition: 0.3s; height: 40px; display: inline-flex; align-items: center; gap: 6px; }
        .btn-filtro:hover { background: #0f2b3d; }

        .stats-container { padding: 1.5rem 2rem 0.5rem 2rem; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; }
        .stat-card { background: #f9fafc; padding: 1rem 1.2rem; border-radius: 16px; border-left: 4px solid #1b4f6e; text-align: center; }
        .stat-card .stat-title { font-size: 0.65rem; text-transform: uppercase; color: #64748b; font-weight: 600; }
        .stat-card .stat-number { font-size: 1.6rem; font-weight: 700; color: #0f2b3d; margin-top: 4px; }
        .stat-card .stat-number.success { color: #10b981; }
        .stat-card .stat-number.warning { color: #f59e0b; }
        .stat-card .stat-number.danger { color: #ef4444; }
        .stat-card .stat-number.info { color: #3b82f6; }

        .search-container { display: flex; gap: 15px; margin: 1.5rem 2rem 0 2rem; flex-wrap: wrap; align-items: center; }
        .search-box { flex: 1; min-width: 250px; position: relative; }
        .search-box input { width: 100%; padding: 10px 15px 10px 40px; border-radius: 40px; border: 1px solid #ddd; font-size: 0.9rem; outline: none; }
        .search-box input:focus { border-color: #1b4f6e; box-shadow: 0 0 0 3px rgba(27,79,110,0.1); }
        .search-box i { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #999; }

        .table-wrapper { padding: 1.5rem 2rem 2rem 2rem; overflow-x: auto; }
        .section-title { font-weight: 700; font-size: 1.1rem; color: #1e2a41; margin-bottom: 1rem; display: flex; align-items: center; gap: 8px; justify-content: space-between; flex-wrap: wrap; }
        .section-title .badge-total { background: #e2e8f0; padding: 4px 12px; border-radius: 30px; font-size: 0.75rem; color: #475569; }
        
        .report-table { width: 100%; border-collapse: collapse; background: white; border-radius: 20px; overflow: hidden; min-width: 800px; }
        .report-table th { text-align: left; padding: 0.8rem; background: #f8fafd; font-weight: 600; color: #2c3e66; font-size: 0.7rem; text-transform: uppercase; border-bottom: 1px solid #e2e8f0; white-space: nowrap; }
        .report-table td { padding: 0.8rem; border-bottom: 1px solid #edf2f7; color: #1f2b48; font-size: 0.8rem; vertical-align: middle; }
        .report-table tr:hover td { background: #f8fafc; }

        .badge { padding: 3px 10px; border-radius: 30px; font-size: 0.65rem; font-weight: 600; display: inline-flex; align-items: center; gap: 4px; white-space: nowrap; }
        .badge-activo { background: #dcfce7; color: #16a34a; }
        .badge-inactivo { background: #fee2e2; color: #dc2626; }
        .badge-pagado { background: #dcfce7; color: #16a34a; }
        .badge-pendiente { background: #fef3c7; color: #d97706; }
        .badge-fecha { background: #dbeafe; color: #1e40af; }

        .resumen-card { background: #f8fafc; padding: 1rem; border-radius: 12px; margin-bottom: 1rem; border: 1px solid #e2e8f0; }
        .resumen-card .row { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid #e2e8f0; }
        .resumen-card .row:last-child { border-bottom: none; }
        .resumen-card .label { color: #64748b; font-size: 0.85rem; }
        .resumen-card .value { font-weight: 600; color: #0f2b3d; font-size: 0.85rem; }

        .empty { text-align: center; padding: 40px; color: #94a3b8; }
        .empty i { font-size: 2rem; display: block; margin-bottom: 10px; }
        .footer { background: #f1f5f9; padding: 0.8rem 2rem; text-align: center; color: #64748b; font-size: 0.7rem; border-top: 1px solid #e2e8f0; }

        @media (max-width: 768px) {
            body { padding: 1rem; }
            .header { flex-direction: column; text-align: center; }
            .filtros { flex-direction: column; align-items: stretch; }
            .filtros .form-group { width: 100%; }
            .stats-grid { grid-template-columns: 1fr 1fr; }
        }
    </style>
</head>
<body>

<div class="container">
    <!-- HEADER -->
    <div class="header">
        <h1><i class="fas fa-file-invoice-dollar"></i> Reportes y Pagos</h1>
        <div class="header-actions">
            <button class="btn-primary" onclick="location.reload()">
                <i class="fas fa-sync-alt"></i> Actualizar
            </button>
            <button class="btn-success" onclick="window.print()">
                <i class="fas fa-print"></i> Imprimir
            </button>
            <a href="admin.php" class="btn-outline-light">
                <i class="fas fa-arrow-left"></i> Volver
            </a>
        </div>
    </div>

    <!-- FILTROS PRINCIPALES -->
    <div class="filtros">
        <div class="form-group">
            <label><i class="fas fa-calendar-alt"></i> Fecha Inicio</label>
            <input type="date" id="fecha_inicio" value="<?= $fecha_inicio ?>">
        </div>
        <div class="form-group">
            <label><i class="fas fa-calendar-alt"></i> Fecha Fin</label>
            <input type="date" id="fecha_fin" value="<?= $fecha_fin ?>">
        </div>
        <div class="form-group">
            <label><i class="fas fa-file-alt"></i> Módulo / Tipo</label>
            <select id="tipo_reporte">
                <option value="pagos" <?= $tipo_reporte === 'pagos' ? 'selected' : '' ?>>Historial de Pagos</option>
                <option value="clientes" <?= $tipo_reporte === 'clientes' ? 'selected' : '' ?>>Clientes</option>
                <option value="estadisticas" <?= $tipo_reporte === 'estadisticas' ? 'selected' : '' ?>>Estadísticas Generales</option>
                <option value="servicios" <?= $tipo_reporte === 'servicios' ? 'selected' : '' ?>>Servicios</option>
            </select>
        </div>
        <div class="form-group" id="grupo_estado" style="display: none;">
            <label><i class="fas fa-user-check"></i> Estado Cliente</label>
            <select id="estado_cliente">
                <option value="todos" <?= $estado_cliente === 'todos' ? 'selected' : '' ?>>Todos</option>
                <option value="Activo" <?= $estado_cliente === 'Activo' ? 'selected' : '' ?>>Activos</option>
                <option value="Inactivo" <?= $estado_cliente === 'Inactivo' ? 'selected' : '' ?>>Inactivos</option>
            </select>
        </div>
        <button class="btn-filtro" onclick="aplicarFiltros()">
            <i class="fas fa-search"></i> Filtrar
        </button>
        <button class="btn-filtro" style="background:#6c757d;" onclick="limpiarFiltros()">
            <i class="fas fa-times"></i> Limpiar
        </button>
    </div>

    <!-- BUSCADOR RÁPIDO -->
    <?php if ($tipo_reporte !== 'estadisticas'): ?>
    <div class="search-container">
        <div class="search-box">
            <i class="fas fa-search"></i>
            <input type="text" id="searchInput" placeholder="Búsqueda rápida en los registros visibles...">
        </div>
    </div>
    <?php endif; ?>

    <!-- CONTENIDO SEGÚN LA SELECCIÓN -->
    <?php if ($tipo_reporte === 'pagos'): ?>
        <div class="stats-container">
            <div class="stats-grid">
                <?php 
                $total_monto_filtrado = array_sum(array_column($reporte_data, 'monto'));
                $total_pagos_filtrado = count($reporte_data);
                ?>
                <div class="stat-card" style="border-color: #10b981;">
                    <div class="stat-title"><i class="fas fa-coins"></i> Recaudado (Período)</div>
                    <div class="stat-number success">$<?= number_format($total_monto_filtrado, 0, ',', '.') ?></div>
                </div>
                <div class="stat-card" style="border-color: #3b82f6;">
                    <div class="stat-title"><i class="fas fa-calendar-day"></i> Pagos de Hoy</div>
                    <div class="stat-number info">$<?= number_format($total_hoy ?? 0, 0, ',', '.') ?></div>
                </div>
                <div class="stat-card" style="border-color: #f59e0b;">
                    <div class="stat-title"><i class="fas fa-receipt"></i> Cantidad de Pagos</div>
                    <div class="stat-number warning"><?= $total_pagos_filtrado ?></div>
                </div>
            </div>
        </div>

        <div class="table-wrapper">
            <div class="section-title">
                <span><i class="fas fa-history"></i> Registro Detallado de Pagos</span>
                <span class="badge-total">Total Registros: <?= $total_registros ?></span>
            </div>
            <table class="report-table">
                <thead>
                    <tr>
                        <th><i class="fas fa-hashtag"></i> ID</th>
                        <th><i class="fas fa-user"></i> Cliente</th>
                        <th><i class="fas fa-wifi"></i> Servicio</th>
                        <th><i class="fas fa-calendar-alt"></i> Fecha y Hora</th>
                        <th><i class="fas fa-calendar"></i> Período (Mes/Año)</th>
                        <th><i class="fas fa-dollar-sign"></i> Monto</th>
                        <th><i class="fas fa-credit-card"></i> Método</th>
                        <th><i class="fas fa-info-circle"></i> Estado</th>
                        <th><i class="fas fa-comment"></i> Observaciones</th>
                    </tr>
                </thead>
                <tbody id="tablaBody">
                    <?php if (empty($reporte_data)): ?>
                        <tr><td colspan="9" class="empty"><i class="fas fa-inbox"></i> No hay pagos registrados en este período</td></tr>
                    <?php else: ?>
                        <?php foreach ($reporte_data as$p): ?>
                        <tr>
                            <td><?= $p['id_historial'] ?></td>
                            <td><strong><?= htmlspecialchars($p['cliente'] ?? 'N/A') ?> <?= htmlspecialchars($p['cliente_apellido'] ?? '') ?></strong></td>
                            <td><?= htmlspecialchars($p['servicio'] ?? 'N/A') ?></td>
                            <td><span class="badge badge-fecha"><?= date('d/m/Y H:i', strtotime($p['fecha'])) ?></span></td>
                            <td><?= $p['mes'] ?>/<?=$p['anio'] ?></td>
                            <td><strong>$<?= number_format($p['monto'] ?? 0, 0, ',', '.') ?></strong></td>
                            <td><span class="badge badge-pagado"><i class="fas fa-check-circle"></i> <?= strtoupper(htmlspecialchars($p['metodo'] ?? 'EFECTIVO')) ?></span></td>
                            <td>
                                <span class="badge <?= strtolower($p['estado'] ?? '') === 'pagado' ? 'badge-pagado' : 'badge-pendiente' ?>">
                                    <?= ucfirst($p['estado'] ?? 'Pendiente') ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars($p['detalle'] ?? '-') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    <?php elseif ($tipo_reporte === 'clientes'): ?>
        <div class="stats-container">
            <div class="stats-grid">
                <?php
                $activos = count(array_filter($reporte_data, function($c) { return ($c['estado'] ?? '') === 'Activo'; }));
                $inactivos = count(array_filter($reporte_data, function($c) { return ($c['estado'] ?? '') === 'Inactivo'; }));
                ?>
                <div class="stat-card" style="border-color: #10b981;">
                    <div class="stat-title">Clientes Activos</div>
                    <div class="stat-number success"><?= $activos ?></div>
                </div>
                <div class="stat-card" style="border-color: #ef4444;">
                    <div class="stat-title">Clientes Inactivos</div>
                    <div class="stat-number danger"><?= $inactivos ?></div>
                </div>
                <div class="stat-card" style="border-color: #3b82f6;">
                    <div class="stat-title">Total Clientes</div>
                    <div class="stat-number info"><?= count($reporte_data) ?></div>
                </div>
            </div>
        </div>

        <div class="table-wrapper">
            <div class="section-title">
                <span><i class="fas fa-users"></i> Listado de Clientes</span>
                <span class="badge-total">Total: <?= count($reporte_data) ?></span>
            </div>
            <table class="report-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Cliente</th>
                        <th>DNI</th>
                        <th>Email</th>
                        <th>Teléfono</th>
                        <th>Dirección</th>
                        <th>Servicio</th>
                        <th>Precio</th>
                        <th>Pago</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody id="tablaBody">
                    <?php if (empty($reporte_data)): ?>
                        <tr><td colspan="10" class="empty"><i class="fas fa-inbox"></i> No hay clientes encontrados</td></tr>
                    <?php else: ?>
                        <?php foreach ($reporte_data as$c): ?>
                        <tr>
                            <td><?= $c['id'] ?></td>
                            <td><strong><?= htmlspecialchars($c['nombre']) ?></strong></td>
                            <td><?= htmlspecialchars($c['dni'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($c['email'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($c['telefono'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($c['direccion'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($c['servicio'] ?? '-') ?></td>
                            <td><strong>$<?= number_format($c['precio'] ?? 0, 0, ',', '.') ?></strong></td>
                            <td>
                                <span class="badge <?= ($c['estado_pago'] ?? 'pendiente') == 'pagado' ? 'badge-pagado' : 'badge-pendiente' ?>">
                                    <?= ucfirst($c['estado_pago'] ?? 'pendiente') ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge <?= ($c['estado'] ?? 'Activo') == 'Activo' ? 'badge-activo' : 'badge-inactivo' ?>">
                                    <?= $c['estado'] ?? 'Activo' ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    <?php elseif ($tipo_reporte === 'estadisticas'): ?>
        <div class="stats-container">
            <div class="stats-grid">
                <div class="stat-card" style="border-color: #10b981;">
                    <div class="stat-title">Clientes Activos</div>
                    <div class="stat-number success"><?= $reporte_data['totales']['activos'] ?? 0 ?></div>
                </div>
                <div class="stat-card" style="border-color: #ef4444;">
                    <div class="stat-title">Clientes Inactivos</div>
                    <div class="stat-number danger"><?= $reporte_data['totales']['inactivos'] ?? 0 ?></div>
                </div>
                <div class="stat-card" style="border-color: #10b981;">
                    <div class="stat-title">Pagados</div>
                    <div class="stat-number success"><?= $reporte_data['totales']['pagados'] ?? 0 ?></div>
                </div>
                <div class="stat-card" style="border-color: #f59e0b;">
                    <div class="stat-title">Pendientes</div>
                    <div class="stat-number warning"><?= $reporte_data['totales']['pendientes'] ?? 0 ?></div>
                </div>
            </div>
        </div>

        <div style="padding: 1.5rem 2rem;">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                <div class="resumen-card">
                    <h4 style="margin-bottom: 0.8rem; color: #1b4f6e;"><i class="fas fa-credit-card"></i> Métodos de Pago</h4>
                    <?php if (empty($reporte_data['metodos_pago'])): ?>
                        <div style="color: #94a3b8; text-align:center; padding:10px;">No hay datos en este período</div>
                    <?php else: ?>
                        <?php foreach ($reporte_data['metodos_pago'] as$m): ?>
                        <div class="row">
                            <span class="label"><?= strtoupper(htmlspecialchars($m['metodo'] ?? 'EFECTIVO')) ?></span>
                            <span class="value"><?= $m['cantidad'] ?> pagos - $<?= number_format($m['total'], 0, ',', '.') ?></span>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <div class="resumen-card">
                    <h4 style="margin-bottom: 0.8rem; color: #1b4f6e;"><i class="fas fa-chart-line"></i> Pagos Mensuales (Últimos 12 meses)</h4>
                    <?php if (empty($reporte_data['pagos_mensuales'])): ?>
                        <div style="color: #94a3b8; text-align:center; padding:10px;">No hay datos</div>
                    <?php else: ?>
                        <?php foreach ($reporte_data['pagos_mensuales'] as$m): ?>
                        <div class="row">
                            <span class="label"><?= date('M Y', strtotime($m['mes'] . '-01')) ?></span>
                            <span class="value"><?= $m['cantidad'] ?> pagos - $<?= number_format($m['total'], 0, ',', '.') ?></span>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    <?php elseif ($tipo_reporte === 'servicios'): ?>
        <div class="stats-container">
            <div class="stats-grid">
                <?php
                $total_servicios = count($reporte_data);
                $total_clientes_serv = array_sum(array_column($reporte_data, 'total_clientes'));
                ?>
                <div class="stat-card" style="border-color: #3b82f6;">
                    <div class="stat-title">Total Servicios</div>
                    <div class="stat-number info"><?= $total_servicios ?></div>
                </div>
                <div class="stat-card" style="border-color: #10b981;">
                    <div class="stat-title">Clientes Asociados</div>
                    <div class="stat-number success"><?= $total_clientes_serv ?></div>
                </div>
            </div>
        </div>

        <div class="table-wrapper">
            <div class="section-title">
                <span><i class="fas fa-tags"></i> Listado de Servicios</span>
                <span class="badge-total">Total: <?= $total_servicios ?></span>
            </div>
            <table class="report-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Servicio</th>
                        <th>Precio</th>
                        <th>Facturación</th>
                        <th>Corte</th>
                        <th>Estado Pago</th>
                        <th>Clientes</th>
                        <th>Activos</th>
                    </tr>
                </thead>
                <tbody id="tablaBody">
                    <?php if (empty($reporte_data)): ?>
                        <tr><td colspan="8" class="empty"><i class="fas fa-inbox"></i> No hay servicios registrados</td></tr>
                    <?php else: ?>
                        <?php foreach ($reporte_data as$s): ?>
                        <tr>
                            <td><?= $s['id_servicio'] ?></td>
                            <td><strong><?= htmlspecialchars($s['servicio']) ?></strong></td>
                            <td><strong>$<?= number_format($s['precio'], 0, ',', '.') ?></strong></td>
                            <td><span class="badge badge-fecha">Día <?= $s['dia_facturacion'] ?? 15 ?></span></td>
                            <td><span class="badge" style="background:#fef3c7; color:#92400e;">Día <?= $s['dia_corte'] ?? 15 ?></span></td>
                            <td>
                                <span class="badge <?= ($s['estado_pago'] ?? 'pendiente') == 'pagado' ? 'badge-pagado' : 'badge-pendiente' ?>">
                                    <?= ucfirst($s['estado_pago'] ?? 'pendiente') ?>
                                </span>
                            </td>
                            <td><?= $s['total_clientes'] ?? 0 ?></td>
                            <td><?= $s['clientes_activos'] ?? 0 ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <div class="footer">
        <i class="fas fa-file-invoice-dollar"></i> Módulo Unificado de Reportes y Pagos - Generado el <?= date('d/m/Y H:i:s') ?>
    </div>
</div>

<script>
function aplicarFiltros() {
    const fecha_inicio = document.getElementById('fecha_inicio').value;
    const fecha_fin = document.getElementById('fecha_fin').value;
    const tipo_reporte = document.getElementById('tipo_reporte').value;
    const estado_cliente = document.getElementById('estado_cliente').value;
    
    window.location.href = `reportes_pagos.php?fecha_inicio=${fecha_inicio}&fecha_fin=${fecha_fin}&tipo_reporte=${tipo_reporte}&estado_cliente=${estado_cliente}`;
}

function limpiarFiltros() {
    const hoy = new Date();
    const primerDia = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
    document.getElementById('fecha_inicio').value = primerDia.toISOString().split('T')[0];
    document.getElementById('fecha_fin').value = hoy.toISOString().split('T')[0];
    document.getElementById('tipo_reporte').value = 'pagos';
    document.getElementById('estado_cliente').value = 'todos';
    aplicarFiltros();
}

document.getElementById('tipo_reporte').addEventListener('change', function() {
    const grupoEstado = document.getElementById('grupo_estado');
    grupoEstado.style.display = (this.value === 'clientes') ? 'flex' : 'none';
});

document.addEventListener('DOMContentLoaded', function() {
    const tipo = document.getElementById('tipo_reporte').value;
    if (tipo === 'clientes') {
        document.getElementById('grupo_estado').style.display = 'flex';
    }

    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('#tablaBody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
});
</script>

</body>
</html>