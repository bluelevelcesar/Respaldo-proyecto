<?php
session_start();

// Verificar si está logueado y es administrador de red (id_rol = 4)
if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 4) {
    header('Location: ../login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';
include __DIR__ . '/../controllers/funcion_log.php';
$log = new SistemaLog($conexion);

// =============================================
// OBTENER TIPOS DE ACCIONES ÚNICOS PARA EL FILTRO
// =============================================
$sql_acciones = "SELECT DISTINCT accion FROM log ORDER BY accion ASC";
$result_acciones = mysqli_query($conexion, $sql_acciones);
$acciones_filtro = [];
while ($row = mysqli_fetch_assoc($result_acciones)) {
    $acciones_filtro[] = $row['accion'];
}

// =============================================
// FILTROS Y PAGINACIÓN DE LOGS
// =============================================
$filtro_accion = isset($_GET['filtro_accion']) ? trim($_GET['filtro_accion']) : '';
$filtro_fecha = isset($_GET['filtro_fecha']) ? $_GET['filtro_fecha'] : '';
$filtro_usuario = isset($_GET['filtro_usuario']) ? trim($_GET['filtro_usuario']) : '';

$registros_por_pagina = 10;
$pagina_actual = isset($_GET['pagina_logs']) ? (int)$_GET['pagina_logs'] : 1;
$pagina_actual = max(1, $pagina_actual);
$offset = ($pagina_actual - 1) * $registros_por_pagina;

// =============================================
// CONSTRUIR WHERE PARA FILTROS
// =============================================
$where_clauses = [];
$params = [];
$types = "";

if (!empty($filtro_accion)) {
    $where_clauses[] = "accion LIKE ?";
    $params[] = "%" . $filtro_accion . "%";
    $types .= "s";
}

if (!empty($filtro_fecha)) {
    $where_clauses[] = "DATE(fecha_registro) = ?";
    $params[] = $filtro_fecha;
    $types .= "s";
}

if (!empty($filtro_usuario)) {
    $where_clauses[] = "usuario LIKE ?";
    $params[] = "%" . $filtro_usuario . "%";
    $types .= "s";
}

$where_sql = "";
if (!empty($where_clauses)) {
    $where_sql = "WHERE " . implode(" AND ", $where_clauses);
}

// =============================================
// CONTAR TOTAL DE LOGS CON FILTROS
// =============================================
$sql_count = "SELECT COUNT(*) as total FROM log $where_sql";
if (!empty($params)) {
    $stmt_count = mysqli_prepare($conexion, $sql_count);
    if ($stmt_count) {
        mysqli_stmt_bind_param($stmt_count, $types, ...$params);
        mysqli_stmt_execute($stmt_count);
        $result_count = mysqli_stmt_get_result($stmt_count);
        $total_logs = mysqli_fetch_assoc($result_count)['total'] ?? 0;
        mysqli_stmt_close($stmt_count);
    } else {
        $total_logs = 0;
    }
} else {
    $result_count = mysqli_query($conexion, $sql_count);
    $total_logs = mysqli_fetch_assoc($result_count)['total'] ?? 0;
}

$total_paginas = ceil($total_logs / $registros_por_pagina);

// =============================================
// OBTENER LOGS CON FILTROS Y PAGINACIÓN
// =============================================
$sql_logs = "SELECT 
                usuario as administrador, 
                accion, 
                descripcion as afectado, 
                DATE_FORMAT(fecha_registro, '%d/%m/%Y') as fecha, 
                TIME_FORMAT(fecha_registro, '%H:%i:%s') as hora 
             FROM log 
             $where_sql
             ORDER BY fecha_registro DESC 
             LIMIT $offset, $registros_por_pagina";

if (!empty($params)) {
    $stmt_logs = mysqli_prepare($conexion, $sql_logs);
    if ($stmt_logs) {
        mysqli_stmt_bind_param($stmt_logs, $types, ...$params);
        mysqli_stmt_execute($stmt_logs);
        $result_logs = mysqli_stmt_get_result($stmt_logs);
        $logs = mysqli_fetch_all($result_logs, MYSQLI_ASSOC);
        mysqli_stmt_close($stmt_logs);
    } else {
        $logs = [];
    }
} else {
    $result_logs = mysqli_query($conexion, $sql_logs);
    $logs = mysqli_fetch_all($result_logs, MYSQLI_ASSOC);
}

// =============================================
// TARJETAS: ESTADÍSTICAS SOLICITADAS
// =============================================
$sql_total_usuarios = "SELECT COUNT(*) as total FROM usuario";
$res_t_usuarios = mysqli_query($conexion, $sql_total_usuarios);
$total_usuarios_cards = mysqli_fetch_assoc($res_t_usuarios)['total'] ?? 0;

$sql_total_clientes = "SELECT COUNT(*) as total FROM cliente WHERE estado = 'Activo' AND eliminado = 0";
$res_t_clientes = mysqli_query($conexion, $sql_total_clientes);
$total_clientes_cards = mysqli_fetch_assoc($res_t_clientes)['total'] ?? 0;

$sql_cobros_mes = "SELECT COUNT(*) as total FROM pago WHERE MONTH(fecha_pago) = MONTH(CURRENT_DATE()) AND YEAR(fecha_pago) = YEAR(CURRENT_DATE())";
$res_c_mes = mysqli_query($conexion, $sql_cobros_mes);
$total_cobros_mes = mysqli_fetch_assoc($res_c_mes)['total'] ?? 0;

$sql_tareas_realizadas = "SELECT COUNT(*) as total FROM soporte WHERE estado IN ('resuelto', 'cerrado')";
$res_t_realizadas = mysqli_query($conexion, $sql_tareas_realizadas);
$total_tareas_cards = mysqli_fetch_assoc($res_t_realizadas)['total'] ?? 0;

// =============================================
// DATOS PARA LOS GRÁFICOS
// =============================================
$sql_cobros = "SELECT COUNT(*) as total FROM pago";
$res_cobros = mysqli_query($conexion, $sql_cobros);
$count_cobros = mysqli_fetch_assoc($res_cobros)['total'] ?? 0;

$sql_sesiones = "SELECT COUNT(*) as total FROM log WHERE accion LIKE '%login%' OR accion LIKE '%sesión%' OR accion LIKE '%sesion%' OR accion LIKE '%acceso%'";
$res_sesiones = mysqli_query($conexion, $sql_sesiones);
$count_sesiones = mysqli_fetch_assoc($res_sesiones)['total'] ?? 0;

$sql_tareas = "SELECT COUNT(*) as total FROM soporte WHERE estado IN ('resuelto', 'cerrado')";
$res_tareas = mysqli_query($conexion, $sql_tareas);
$count_tareas = mysqli_fetch_assoc($res_tareas)['total'] ?? 0;

$sql_reclamos = "SELECT COUNT(*) as total FROM soporte WHERE titulo LIKE '%reclamo%' OR descripcion LIKE '%reclamo%'";
$res_reclamos = mysqli_query($conexion, $sql_reclamos);
$count_reclamos = mysqli_fetch_assoc($res_reclamos)['total'] ?? 0;

$sql_usuarios_activos = "SELECT COUNT(*) as total FROM usuario WHERE estado LIKE '%Activo%'";
$res_u_activos = mysqli_query($conexion, $sql_usuarios_activos);
$count_activos = mysqli_fetch_assoc($res_u_activos)['total'] ?? 0;

$sql_usuarios_inactivos = "SELECT COUNT(*) as total FROM usuario WHERE estado LIKE '%Inactivo%'";
$res_u_inactivos = mysqli_query($conexion, $sql_usuarios_inactivos);
$count_inactivos = mysqli_fetch_assoc($res_u_inactivos)['total'] ?? 0;
// =============================================
// DATOS PARA EL GRÁFICO DE TORTA (ESTADÍSTICAS REALES CORREGIDAS)
// =============================================

// 1. Cobros realizados (Contando desde la tabla de pagos)
$sql_cobros = "SELECT COUNT(*) as total FROM pago";
$res_cobros = mysqli_query($conexion, $sql_cobros);
$count_cobros = mysqli_fetch_assoc($res_cobros)['total'] ?? 0;

// 2. Inicio de sesión (Registros en log de accesos o logins)
$sql_sesiones = "SELECT COUNT(*) as total FROM log WHERE accion LIKE '%login%' OR accion LIKE '%sesión%' OR accion LIKE '%sesion%' OR accion LIKE '%acceso%'";
$res_sesiones = mysqli_query($conexion, $sql_sesiones);
$count_sesiones = mysqli_fetch_assoc($res_sesiones)['total'] ?? 0;

// 3. Realización de tareas / Trabajos técnicos finalizados 
// (Buscamos en la tabla soporte los estados 'resuelto' o 'cerrado')
$sql_tareas = "SELECT COUNT(*) as total FROM soporte WHERE estado IN ('resuelto', 'cerrado')";
$res_tareas = mysqli_query($conexion, $sql_tareas);
$count_tareas = mysqli_fetch_assoc($res_tareas)['total'] ?? 0;

// 4. Reclamos realizados 
// (Buscamos en la tabla soporte donde el campo 'titulo' contenga la palabra 'reclamo')
$sql_reclamos = "SELECT COUNT(*) as total FROM soporte WHERE titulo LIKE '%reclamo%' OR descripcion LIKE '%reclamo%'";
$res_reclamos = mysqli_query($conexion, $sql_reclamos);
$count_reclamos = mysqli_fetch_assoc($res_reclamos)['total'] ?? 0;

// =============================================
// ESTADÍSTICAS DE USUARIOS (ACTIVOS / INACTIVOS)
// =============================================
$sql_usuarios_activos = "SELECT COUNT(*) as total FROM usuario WHERE estado LIKE '%Activo%'";
$res_u_activos = mysqli_query($conexion, $sql_usuarios_activos);
$count_activos = mysqli_fetch_assoc($res_u_activos)['total'] ?? 0;

$sql_usuarios_inactivos = "SELECT COUNT(*) as total FROM usuario WHERE estado LIKE '%Inactivo%'";
$res_u_inactivos = mysqli_query($conexion, $sql_usuarios_inactivos);
$count_inactivos = mysqli_fetch_assoc($res_u_inactivos)['total'] ?? 0;

// =============================================
// CONSTRUIR URLS CON FILTROS PARA PAGINACIÓN
// =============================================
$query_params = [];
if (!empty($filtro_accion)) $query_params['filtro_accion'] = $filtro_accion;
if (!empty($filtro_fecha)) $query_params['filtro_fecha'] = $filtro_fecha;
if (!empty($filtro_usuario)) $query_params['filtro_usuario'] = $filtro_usuario;
$query_string = !empty($query_params) ? '&' . http_build_query($query_params) : '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Administrador de Red - Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Chart.js para el Gráfico de Torta -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <link rel="stylesheet" href="../css/responsive_global.css">
    <script src="../js/responsive_sidebar.js" defer></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #f0f4f8; overflow-x: hidden; }
        .app-container { display: flex; min-height: 100vh; }
        
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #0f2b3d 0%, #1b4f6e 100%);
            color: white;
            padding: 2rem 1.5rem;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
        }
        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-track { background: transparent; }
        .sidebar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.3); border-radius: 10px; }
        
        .logo-area {
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(255,255,255,0.15);
        }
        .logo-area h2 { font-size: 1.5rem; font-weight: 700; display: flex; align-items: center; gap: 10px; }
        .logo-area h2 i { color: #60a5fa; }
        .logo-area span { font-size: 0.7rem; opacity: 0.6; display: block; margin-top: 4px; }
        
        .nav-section { margin-bottom: 1.5rem; }
        .nav-section-title {
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            opacity: 0.5;
            margin-bottom: 0.8rem;
            font-weight: 600;
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.7rem 1rem;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.2s;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            margin-bottom: 0.2rem;
            font-size: 0.9rem;
            border: none;
            background: transparent;
            width: 100%;
            text-align: left;
        }
        .nav-item:hover, .nav-item.active { background: rgba(255,255,255,0.15); color: white; }
        .nav-item i { width: 22px; font-size: 1.1rem; text-align: center; color: rgba(255,255,255,0.6); }
        .nav-item:hover i, .nav-item.active i { color: white; }
        
        .main-content { flex: 1; margin-left: 280px; padding: 2rem; min-height: 100vh; }
        
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            background: white;
            padding: 1rem 2rem;
            border-radius: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            flex-wrap: wrap;
            gap: 1rem;
        }
        .page-title { font-size: 1.3rem; font-weight: 700; color: #1e2a41; }
        .page-title i { color: #1b4f6e; margin-right: 10px; }
        
        .user-info { display: flex; align-items: center; gap: 12px; font-size: 0.9rem; color: #1e2a41; }
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
            font-size: 1rem;
        }
        
        /* ============================================= */
        /* ESTADÍSTICAS ORIGINALES */
        /* ============================================= */
        .stats-container { padding: 0.5rem 0 0.5rem 0; }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 1rem;
        }
        
        .stat-card {
            background: white;
            padding: 1rem 1.2rem;
            border-radius: 14px;
            border: 1px solid #e9eef3;
            display: flex;
            align-items: center;
            gap: 1rem;
            transition: all 0.3s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }
        
        .stat-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            flex-shrink: 0;
        }
        
        .stat-info { flex: 1; }
        .stat-number { font-size: 1.5rem; font-weight: 700; line-height: 1.2; }
        .stat-label { font-size: 0.65rem; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600; }
        .stat-trend { font-size: 0.6rem; color: #94a3b8; margin-top: 2px; }
        .stat-trend i { margin-right: 2px; }

        /* ============================================= */
        /* GRÁFICO DE TORTA SECTION */
        /* ============================================= */
        .chart-section {
            background: white;
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            margin-top: 1.5rem;
            margin-bottom: 1.5rem;
        }
        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid #eef2f6;
        }
        .chart-header h3 { display: flex; align-items: center; gap: 10px; color: #1e2a41; font-size: 1rem; font-weight: 700; }
        .chart-header h3 i { color: #1b4f6e; }
        
        /* ============================================= */
        /* LOGS SECTION */
        /* ============================================= */
        .logs-section {
            background: white;
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            margin-top: 1rem;
        }
        
        .logs-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #eef2f6;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        .logs-header h3 { display: flex; align-items: center; gap: 10px; color: #1e2a41; font-size: 1rem; font-weight: 700; }
        .logs-header h3 i { color: #1b4f6e; }
        
        .btn-refresh {
            background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
            color: white;
            border: none;
            padding: 0.5rem 1.2rem;
            border-radius: 40px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.75rem;
            font-weight: 600;
            transition: 0.3s;
        }
        .btn-refresh:hover { opacity: 0.9; transform: scale(0.97); }
        .btn-refresh i { font-size: 0.8rem; }
        
        /* ============================================= */
        /* TABLA DE LOGS */
        /* ============================================= */
        .log-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.8rem;
        }
        .log-table th {
            text-align: left;
            padding: 0.7rem 0.8rem;
            background: #f8fafd;
            font-weight: 600;
            color: #1e2a41;
            font-size: 0.6rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #e2e8f0;
        }
        .log-table td {
            padding: 0.7rem 0.8rem;
            border-bottom: 1px solid #edf2f7;
            color: #1f2b48;
            font-size: 0.8rem;
        }
        .log-table tr:hover td { background: #f8fafc; }
        
        .badge-accion {
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 0.6rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .badge-accion.crear { background: #dbeafe; color: #1e40af; }
        .badge-accion.editar { background: #fef3c7; color: #92400e; }
        .badge-accion.eliminar { background: #fee2e2; color: #991b1b; }
        .badge-accion.pago { background: #d1fae5; color: #065f46; }
        .badge-accion.corte { background: #fce4ec; color: #c62828; }
        .badge-accion.login { background: #e0e7ff; color: #3730a3; }
        .badge-accion.info { background: #e0f2fe; color: #0c4a6e; }
        .badge-accion.warning { background: #fef3c7; color: #92400e; }
        .badge-accion.error { background: #fee2e2; color: #991b1b; }
        .badge-accion.success { background: #d1fae5; color: #065f46; }
        
        .loading, .empty { text-align: center; padding: 2rem; color: #94a3b8; }
        .loading i, .empty i { font-size: 2rem; display: block; margin-bottom: 0.5rem; color: #cbd5e1; }
        
        /* ============================================= */
        /* FILTROS DE LOGS */
        /* ============================================= */
        .filters-log-container {
            background: #f8fafd;
            padding: 1rem 1.2rem;
            border-radius: 12px;
            border: 1px solid #e9eef3;
            margin-bottom: 1.2rem;
        }

        .filters-log-form {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            align-items: flex-end;
        }

        .filters-log-form .filter-group {
            display: flex;
            flex-direction: column;
            gap: 4px;
            flex: 1;
            min-width: 140px;
        }

        .filters-log-form .filter-group label {
            font-size: 0.65rem;
            font-weight: 600;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .filters-log-form .filter-select,
        .filters-log-form .filter-input {
            padding: 0.5rem 0.8rem;
            border: 1.5px solid #dce5ec;
            border-radius: 8px;
            font-size: 0.8rem;
            background: white;
            transition: 0.3s;
            font-family: 'Inter', sans-serif;
            width: 100%;
        }

        .filters-log-form .filter-select:focus,
        .filters-log-form .filter-input:focus {
            outline: none;
            border-color: #1b4f6e;
            box-shadow: 0 0 0 3px rgba(27,79,110,0.1);
        }

        .filter-actions {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-wrap: wrap;
            min-width: 120px;
        }

        .btn-filter {
            padding: 0.5rem 1.2rem;
            background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.75rem;
            transition: 0.3s;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .btn-filter:hover {
            opacity: 0.9;
            transform: scale(0.97);
        }

        .btn-clear-filter {
            padding: 0.5rem 1.2rem;
            background: #f1f5f9;
            color: #1e2a41;
            border: 1.5px solid #dce5ec;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.75rem;
            transition: 0.3s;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .btn-clear-filter:hover {
            background: #e2e8f0;
        }

        .filter-results {
            margin-bottom: 1rem;
            text-align: right;
        }

        .filter-results-count {
            font-size: 0.75rem;
            color: #64748b;
        }

        .filter-results-count strong {
            color: #1e2a41;
        }
        
        /* ============================================= */
        /* PAGINACIÓN DE LOGS */
        /* ============================================= */
        .pagination-wrapper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 1.2rem;
            padding-top: 1rem;
            border-top: 1px solid #eef2f6;
            flex-wrap: wrap;
            gap: 0.8rem;
        }
        
        .pagination-info {
            font-size: 0.75rem;
            color: #64748b;
        }
        
        .pagination-info strong {
            color: #1e2a41;
        }
        
        .pagination {
            display: flex;
            align-items: center;
            gap: 4px;
            flex-wrap: wrap;
        }
        
        .pagination a,
        .pagination span {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 36px;
            height: 36px;
            padding: 0 10px;
            border-radius: 8px;
            font-size: 0.8rem;
            font-weight: 500;
            text-decoration: none;
            transition: 0.2s;
            color: #1e2a41;
            background: white;
            border: 1px solid #e2e8f0;
        }
        
        .pagination a:hover {
            background: #f1f5f9;
            border-color: #1b4f6e;
        }
        
        .pagination .active {
            background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
            color: white;
            border-color: #1b4f6e;
        }
        
        .pagination .disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }
        
        .pagination .prev-next {
            padding: 0 14px;
        }
        
        .pagination .dots {
            border: none;
            background: transparent;
            cursor: default;
        }
        
        .pagination-go-top {
            display: flex;
            align-items: center;
        }
        
        .pagination-go-top a {
            padding: 0.4rem 1rem;
            border-radius: 8px;
            background: #f1f5f9;
            color: #1e2a41;
            text-decoration: none;
            font-size: 0.7rem;
            font-weight: 600;
            transition: 0.2s;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .pagination-go-top a:hover {
            background: #e2e8f0;
        }
        
        .pagination-go-top a i {
            font-size: 0.7rem;
        }
        
        /* ============================================= */
        /* FOOTER */
        /* ============================================= */
        .footer {
            margin-top: 2rem;
            padding-top: 1rem;
            font-size: 0.75rem;
            color: #94a3b8;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        .status-dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            background: #10b981;
            border-radius: 50%;
            margin-right: 6px;
            animation: pulse-dot 2s infinite;
        }
        @keyframes pulse-dot { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
        
        /* ============================================= */
        /* RESPONSIVE */
        /* ============================================= */
        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 1rem; }
            .stats-grid { grid-template-columns: 1fr 1fr; }
            .top-bar { flex-direction: column; align-items: stretch; text-align: center; }
            .user-info { justify-content: center; }
            .footer { flex-direction: column; text-align: center; }
            .log-table th, .log-table td { padding: 0.4rem; font-size: 0.65rem; }
            .logs-header { flex-direction: column; align-items: stretch; text-align: center; }
            .pagination-wrapper { flex-direction: column; align-items: center; }
            .filters-log-form { flex-direction: column; }
            .filters-log-form .filter-group { min-width: 100%; }
            .filter-actions { width: 100%; }
            .btn-filter, .btn-clear-filter { flex: 1; justify-content: center; }
        }
        @media (max-width: 600px) {
            .stats-grid { grid-template-columns: 1fr; }
            .stat-card { padding: 0.7rem 0.8rem; }
            .stat-icon { width: 36px; height: 36px; font-size: 1rem; }
            .stat-number { font-size: 1.2rem; }
        }


        .stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
}
.stat-card {
    background: white;
    padding: 1.2rem;
    border-radius: 14px;
    border: 1px solid #e9eef3;
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}
.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
    flex-shrink: 0;
}
.stat-info { flex: 1; }
.stat-number { font-size: 1.5rem; font-weight: 700; line-height: 1.2; }
.stat-label { font-size: 0.65rem; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600; }

/* Contenedor para poner los gráficos uno al lado del otro */
.charts-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1.5rem;
    margin-top: 1.5rem;
    margin-bottom: 1.5rem;
}
.chart-section {
    background: white;
    border-radius: 20px;
    padding: 1.5rem;
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
}
@media (max-width: 992px) {
    .charts-row { grid-template-columns: 1fr; }
}
    </style>
</head>
<body>
<div class="app-container">
    <!-- ============================================= -->
    <!-- SIDEBAR -->
    <!-- ============================================= -->
    <div class="sidebar">
        <div class="sidebar-mobile-header">
            <span class="sidebar-mobile-title"><i class="fas fa-network-wired"></i> Menú Red</span>
            <button class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Cerrar menú">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="logo-area">
            <h2><i class="fas fa-network-wired"></i> Red Admin</h2>
            <span>Panel de Control</span>
        </div>

        <div class="nav-section">
            <div class="nav-section-title">Principal</div>
            <div class="nav-item active"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></div>
        </div>

        <div class="nav-section">
            <div class="nav-section-title">Red</div>
            <a href="usuarios.php" class="nav-item"><i class="fas fa-user-shield"></i><span>Usuarios</span></a>
            <a href="admin_cliente.php" class="nav-item"><i class="fas fa-users"></i><span>Clientes</span></a>
            <a href="/Chango Vision/pages/servicio.php" class="nav-item"><i class="fas fa-wifi"></i><span>Servicios de Internet</span></a>
            <a href="/Chango Vision/pages/cobrador.php" class="nav-item"><i class="fas fa-hand-holding-usd"></i><span>Cobros</span></a>
            <a href="barrio.php" class="nav-item"><i class="fas fa-chart-line"></i><span>Barrios</span></a>
            <a href="soporte_tecnico.php" class="nav-item"><i class="fas fa-headset"></i><span>Soporte Tecnico</span></a>
        </div>

        <div class="nav-section" style="margin-top: auto;">
            <div class="nav-section-title">Usuario</div>
            <a href="/Chango Vision/pages/cambiar_pass.php" class="nav-item" style="border-top: 1px solid rgba(255,255,255,0.08); padding-top: 15px; margin-top: 5px;">
                <i class="fas fa-key"></i><span>Cambiar Contraseña</span>
            </a>
            <a href="../logout.php" class="nav-item" id="logoutBtn">
                <i class="fas fa-sign-out-alt"></i><span>Cerrar Sesión</span>
            </a>
        </div>
    </div>

    <!-- ============================================= -->
    <!-- MAIN CONTENT -->
    <!-- ============================================= -->
    <div class="main-content">
        <!-- TOP BAR -->
        <div class="top-bar">
            <div style="display:flex; align-items:center; gap:12px;">
                <button class="mobile-toggle-btn" id="mobileMenuBtn" aria-label="Abrir menú de navegación">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title"><i class="fas fa-history"></i> Registro de Actividad</div>
            </div>
            <div class="user-info">
                <span><?= htmlspecialchars($_SESSION['usuario'] ?? 'Administrador Red') ?></span>
                <div class="user-avatar"><?= strtoupper(substr($_SESSION['usuario'] ?? 'R', 0, 1)) ?></div>
            </div>
        </div>

<!-- TARJETAS DE ESTADÍSTICAS -->
        <div class="stats-container">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#dbeafe; color:#3b82f6;">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-number" style="color:#1b4f6e;"><?= $total_usuarios_cards ?></div>
                        <div class="stat-label">Usuarios Totales</div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon" style="background:#d1fae5; color:#10b981;">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-number" style="color:#10b981;"><?= $total_clientes_cards ?></div>
                        <div class="stat-label">Clientes Totales</div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon" style="background:#fef3c7; color:#f59e0b;">
                        <i class="fas fa-hand-holding-usd"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-number" style="color:#f59e0b;"><?= $total_cobros_mes ?></div>
                        <div class="stat-label">Cobros Mensuales</div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon" style="background:#e0e7ff; color:#6366f1;">
                        <i class="fas fa-tasks"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-number" style="color:#6366f1;"><?= $total_tareas_cards ?></div>
                        <div class="stat-label">Tareas Realizadas</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- GRÁFICOS UNO AL LADO DEL OTRO -->
        <div class="charts-row">
            <!-- GRÁFICO 1: LOGS -->
            <div class="chart-section">
                <div class="chart-header">
                    <h3><i class="fas fa-chart-pie"></i> Estadísticas de Logs</h3>
                </div>
                <div style="display: flex; justify-content: center; align-items: center; padding: 1rem 0; flex-wrap: wrap; gap: 1.5rem;">
                    <div style="width: 200px; height: 200px; position: relative;">
                        <canvas id="logsChart"></canvas>
                    </div>
                    <div style="display: flex; flex-direction: column; gap: 8px; font-size: 0.8rem;">
                        <div><span style="display:inline-block; width:10px; height:10px; background:#10b981; border-radius:2px; margin-right:6px;"></span> Cobros: <strong><?= $count_cobros ?></strong></div>
                        <div><span style="display:inline-block; width:10px; height:10px; background:#3b82f6; border-radius:2px; margin-right:6px;"></span> Inicios de sesión: <strong><?= $count_sesiones ?></strong></div>
                        <div><span style="display:inline-block; width:10px; height:10px; background:#f59e0b; border-radius:2px; margin-right:6px;"></span> Tareas: <strong><?= $count_tareas ?></strong></div>
                        <div><span style="display:inline-block; width:10px; height:10px; background:#ef4444; border-radius:2px; margin-right:6px;"></span> Reclamos: <strong><?= $count_reclamos ?></strong></div>
                    </div>
                </div>
            </div>

            <!-- GRÁFICO 2: USUARIOS ACTIVOS E INACTIVOS -->
            <div class="chart-section">
                <div class="chart-header">
                    <h3><i class="fas fa-users"></i> Usuarios Activos / Inactivos</h3>
                </div>
                <div style="display: flex; justify-content: center; align-items: center; padding: 1rem 0; flex-wrap: wrap; gap: 1.5rem;">
                    <div style="width: 200px; height: 200px; position: relative;">
                        <canvas id="usuariosChart"></canvas>
                    </div>
                    <div style="display: flex; flex-direction: column; gap: 8px; font-size: 0.8rem;">
                        <div><span style="display:inline-block; width:10px; height:10px; background:#10b981; border-radius:2px; margin-right:6px;"></span> Activos: <strong><?= $count_activos ?></strong></div>
                        <div><span style="display:inline-block; width:10px; height:10px; background:#ef4444; border-radius:2px; margin-right:6px;"></span> Inactivos: <strong><?= $count_inactivos ?></strong></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ============================================= -->
        <!-- LOGS CON FILTROS Y PAGINACIÓN -->
        <!-- ============================================= -->
        <div class="logs-section">
            <div class="logs-header">
                <h3><i class="fas fa-history"></i> Registros de Actividad</h3>
                <button class="btn-refresh" onclick="location.reload()"><i class="fas fa-sync-alt"></i> Actualizar</button>
            </div>
            
            <!-- ============================================= -->
            <!-- FILTROS DE LOGS -->
            <!-- ============================================= -->
            <div class="filters-log-container">
                <form method="GET" action="" class="filters-log-form" id="filtroForm">
                    <!-- FILTRO POR ACCIÓN -->
                    <div class="filter-group">
                        <label><i class="fas fa-tag"></i> Acción:</label>
                        <select name="filtro_accion" class="filter-select" onchange="this.form.submit()">
                            <option value="">📋 Todas</option>
                            <?php foreach ($acciones_filtro as $accion): ?>
                                <option value="<?= htmlspecialchars($accion) ?>" <?= $filtro_accion == $accion ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($accion) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- FILTRO POR USUARIO -->
                    <div class="filter-group">
                        <label><i class="fas fa-user"></i> Usuario:</label>
                        <input type="text" name="filtro_usuario" class="filter-input" placeholder="Buscar usuario..." value="<?= htmlspecialchars($filtro_usuario) ?>">
                    </div>

                    <!-- FILTRO POR FECHA -->
                    <div class="filter-group">
                        <label><i class="fas fa-calendar"></i> Fecha:</label>
                        <input type="date" name="filtro_fecha" class="filter-input" value="<?= htmlspecialchars($filtro_fecha) ?>">
                    </div>

                    <!-- BOTONES -->
                    <div class="filter-actions">
                        <button type="submit" class="btn-filter">
                            <i class="fas fa-search"></i> Filtrar
                        </button>
                        <a href="admin_red.php" class="btn-clear-filter">
                            <i class="fas fa-undo"></i> Limpiar
                        </a>
                    </div>
                </form>
            </div>

            <!-- CONTADOR DE RESULTADOS FILTRADOS -->
            <div class="filter-results">
                <span class="filter-results-count">
                    <i class="fas fa-list"></i> <strong><?= $total_logs ?></strong> registros encontrados
                    <?php if (!empty($filtro_accion) || !empty($filtro_fecha) || !empty($filtro_usuario)): ?>
                        <span style="font-size:0.65rem; color:#94a3b8; margin-left:8px;">
                            <i class="fas fa-filter"></i> Filtros activos
                        </span>
                    <?php endif; ?>
                </span>
            </div>

            <div id="logsContainer">
                <?php if (empty($logs)): ?>
                    <div class="empty"><i class="fas fa-inbox"></i><p>No hay registros que coincidan con los filtros</p></div>
                <?php else: ?>
                    <table class="log-table">
                        <thead>
                            <tr>
                                <th>Usuario</th>
                                <th>Acción</th>
                                <th>Afectado</th>
                                <th>Fecha</th>
                                <th>Hora</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $logItem): 
                                $clase_accion = 'info';
                                $accion_lower = strtolower($logItem['accion'] ?? '');
                                if (strpos($accion_lower, 'crear') !== false || strpos($accion_lower, 'registrar') !== false) $clase_accion = 'crear';
                                elseif (strpos($accion_lower, 'editar') !== false || strpos($accion_lower, 'actualizar') !== false) $clase_accion = 'editar';
                                elseif (strpos($accion_lower, 'eliminar') !== false) $clase_accion = 'eliminar';
                                elseif (strpos($accion_lower, 'pago') !== false) $clase_accion = 'pago';
                                elseif (strpos($accion_lower, 'cortar') !== false || strpos($accion_lower, 'corte') !== false) $clase_accion = 'corte';
                                elseif (strpos($accion_lower, 'login') !== false || strpos($accion_lower, 'sesión') !== false) $clase_accion = 'login';
                                elseif (strpos($accion_lower, 'error') !== false) $clase_accion = 'error';
                                elseif (strpos($accion_lower, 'success') !== false || strpos($accion_lower, 'éxito') !== false) $clase_accion = 'success';
                                elseif (strpos($accion_lower, 'warning') !== false || strpos($accion_lower, 'advertencia') !== false) $clase_accion = 'warning';
                            ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($logItem['administrador'] ?? 'Anónimo') ?></strong></td>
                                    <td>
                                        <span class="badge-accion <?= $clase_accion ?>">
                                            <i class="fas <?= $clase_accion === 'crear' ? 'fa-plus-circle' : ($clase_accion === 'editar' ? 'fa-edit' : ($clase_accion === 'eliminar' ? 'fa-trash-alt' : ($clase_accion === 'pago' ? 'fa-coins' : ($clase_accion === 'corte' ? 'fa-ban' : ($clase_accion === 'login' ? 'fa-sign-in-alt' : ($clase_accion === 'error' ? 'fa-exclamation-circle' : ($clase_accion === 'success' ? 'fa-check-circle' : ($clase_accion === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle')))))))) ?>"></i>
                                            <?= htmlspecialchars($logItem['accion'] ?? '-') ?>
                                        </span>
                                    </td>
                                    <td><?= htmlspecialchars($logItem['afectado'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($logItem['fecha'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($logItem['hora'] ?? '-') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    
                    <!-- ============================================= -->
                    <!-- PAGINACIÓN CON FILTROS -->
                    <!-- ============================================= -->
                    <?php if ($total_paginas > 1): ?>
                    <div class="pagination-wrapper">
                        <div class="pagination-info">
                            Mostrando <strong><?= ($offset + 1) ?></strong> a <strong><?= min($offset + $registros_por_pagina, $total_logs) ?></strong> 
                            de <strong><?= $total_logs ?></strong> registros
                        </div>

                        <div class="pagination">
                            <!-- ANTERIOR -->
                            <?php if ($pagina_actual > 1): ?>
                                <a href="?pagina_logs=<?= $pagina_actual - 1 ?><?= $query_string ?>" class="prev-next">
                                    <i class="fas fa-chevron-left"></i> Anterior
                                </a>
                            <?php else: ?>
                                <span class="disabled prev-next"><i class="fas fa-chevron-left"></i> Anterior</span>
                            <?php endif; ?>

                            <!-- NÚMEROS DE PÁGINAS -->
                            <?php
                            $rango = 2;
                            $inicio = max(1, $pagina_actual - $rango);
                            $fin = min($total_paginas, $pagina_actual + $rango);

                            if ($inicio > 1) {
                                echo '<a href="?pagina_logs=1' . $query_string . '">1</a>';
                                if ($inicio > 2) echo '<span class="dots">…</span>';
                            }

                            for ($i = $inicio; $i <= $fin; $i++):
                            ?>
                                <?php if ($i == $pagina_actual): ?>
                                    <span class="active"><?= $i ?></span>
                                <?php else: ?>
                                    <a href="?pagina_logs=<?= $i ?><?= $query_string ?>"><?= $i ?></a>
                                <?php endif; ?>
                            <?php endfor; ?>

                            <?php
                            if ($fin < $total_paginas) {
                                if ($fin < $total_paginas - 1) echo '<span class="dots">…</span>';
                                echo '<a href="?pagina_logs=' . $total_paginas . $query_string . '">' . $total_paginas . '</a>';
                            }
                            ?>

                            <!-- SIGUIENTE -->
                            <?php if ($pagina_actual < $total_paginas): ?>
                                <a href="?pagina_logs=<?= $pagina_actual + 1 ?><?= $query_string ?>" class="prev-next">
                                    Siguiente <i class="fas fa-chevron-right"></i>
                                </a>
                            <?php else: ?>
                                <span class="disabled prev-next">Siguiente <i class="fas fa-chevron-right"></i></span>
                            <?php endif; ?>
                        </div>

                        <div class="pagination-go-top">
                            <a href="#" onclick="window.scrollTo({top: 0, behavior: 'smooth'}); return false;">
                                <i class="fas fa-arrow-up"></i> Subir
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- ============================================= -->
        <!-- FOOTER -->
        <!-- ============================================= -->
        <div class="footer">
            <div>&copy; 2026 Panel Administrador de Red - Todos los derechos reservados</div>
            <div><span class="status-dot"></span> Sistema en línea</div>
        </div>
    </div>
</div>

<script>
// =============================================
// INICIALIZAR GRÁFICOS DE TORTA (DOUGHNUT) CON CHART.JS
// =============================================
document.addEventListener("DOMContentLoaded", function() {
    
    // 1. Gráfico de Logs (Cobros, Sesiones, Tareas, Reclamos)
    const ctxLogs = document.getElementById('logsChart')?.getContext('2d');
    if (ctxLogs) {
        const cobros = <?= $count_cobros ?? 0 ?>;
        const sesiones = <?= $count_sesiones ?? 0 ?>;
        const tareas = <?= $count_tareas ?? 0 ?>;
        const reclamos = <?= $count_reclamos ?? 0 ?>;
        
        const totalSumaLogs = cobros + sesiones + tareas + reclamos;

        new Chart(ctxLogs, {
            type: 'doughnut',
            data: {
                labels: ['Cobros realizados', 'Inicio de sesión', 'Realización de tareas', 'Reclamos realizados'],
                datasets: [{
                    data: [cobros, sesiones, tareas, reclamos],
                    backgroundColor: ['#10b981', '#3b82f6', '#f59e0b', '#ef4444'],
                    borderWidth: 0,
                    hoverOffset: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '65%',
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw || 0;
                                const percentage = totalSumaLogs > 0 ? ((value / totalSumaLogs) * 100).toFixed(1) : 0;
                                return ` ${context.label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }

    // 2. Gráfico de Usuarios (Activos e Inactivos)
    const ctxUsuarios = document.getElementById('usuariosChart')?.getContext('2d');
    if (ctxUsuarios) {
        const activos = <?= $count_activos ?? 0 ?>;
        const inactivos = <?= $count_inactivos ?? 0 ?>;
        
        const totalUsuarios = activos + inactivos;

        new Chart(ctxUsuarios, {
            type: 'doughnut',
            data: {
                labels: ['Usuarios Activos', 'Usuarios Inactivos'],
                datasets: [{
                    data: [activos, inactivos],
                    backgroundColor: ['#10b981', '#ef4444'],
                    borderWidth: 0,
                    hoverOffset: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '65%',
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw || 0;
                                const percentage = totalUsuarios > 0 ? ((value / totalUsuarios) * 100).toFixed(1) : 0;
                                return ` ${context.label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }
});

// =============================================
// CONFIRMAR CIERRE DE SESIÓN
// =============================================
document.getElementById('logoutBtn')?.addEventListener('click', function(e) {
    if (!confirm('¿Estás seguro de que deseas cerrar sesión?')) {
        e.preventDefault();
    }
});

// =============================================
// RECARGAR PÁGINA
// =============================================
document.querySelector('.btn-refresh')?.addEventListener('click', function(e) {
    location.reload();
});
</script>
<div class="sidebar-backdrop" id="sidebarBackdrop"></div>
</body>
</html>