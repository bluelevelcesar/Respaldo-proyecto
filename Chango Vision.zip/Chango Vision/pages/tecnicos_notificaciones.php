<?php
// pages/tecnicos_notificaciones.php
session_start();

if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 3) {
    header('Location: login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';

// Función para leer notificaciones del archivo
function leerNotificacionesTecnico() {
    $log_dir = __DIR__ . '/../logs/';
    $archivo = $log_dir . 'notificacion_tecnico_conexion.txt';
    $notificaciones = [];
    
    if (file_exists($archivo)) {
        $contenido = file_get_contents($archivo);
        // Separar por líneas y buscar notificaciones
        $lineas = explode("\n", $contenido);
        $notificacion_actual = [];
        foreach ($lineas as $linea) {
            if (strpos($linea, '========================================') !== false) {
                if (!empty($notificacion_actual)) {
                    $notificaciones[] = $notificacion_actual;
                    $notificacion_actual = [];
                }
                continue;
            }
            if (!empty(trim($linea))) {
                $notificacion_actual[] = $linea;
            }
        }
        if (!empty($notificacion_actual)) {
            $notificaciones[] = $notificacion_actual;
        }
    }
    
    return $notificaciones;
}

$notificaciones = leerNotificacionesTecnico();
$total = count($notificaciones);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificaciones - Técnico | Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #f0f4f8; padding: 2rem; min-height: 100vh; }
        
        .container { max-width: 1000px; margin: 0 auto; }
        
        /* HEADER */
        .header { background: linear-gradient(135deg, #0f2b3d 0%, #1b4f6e 100%); color: white; padding: 2rem; border-radius: 20px; margin-bottom: 2rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; box-shadow: 0 10px 30px rgba(0,0,0,0.15); }
        .header h1 { font-size: 1.5rem; display: flex; align-items: center; gap: 12px; }
        .header h1 i { font-size: 2rem; }
        .header .badge { background: #ef4444; color: white; padding: 4px 14px; border-radius: 30px; font-size: 0.75rem; font-weight: 600; margin-left: 10px; }
        .header .badge.zero { background: #10b981; }
        .btn-volver { background: rgba(255,255,255,0.15); color: white; padding: 0.6rem 1.5rem; border-radius: 40px; text-decoration: none; font-weight: 500; display: inline-flex; align-items: center; gap: 8px; transition: 0.3s; }
        .btn-volver:hover { background: rgba(255,255,255,0.3); transform: scale(0.97); }

        /* NOTIFICACIONES */
        .notificacion {
            background: white;
            border-radius: 20px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            border-left: 6px solid #f59e0b;
            transition: 0.3s;
            animation: slideIn 0.4s ease;
        }
        .notificacion:hover { box-shadow: 0 8px 25px rgba(0,0,0,0.1); transform: translateY(-2px); }
        @keyframes slideIn { from { opacity: 0; transform: translateX(-30px); } to { opacity: 1; transform: translateX(0); } }

        .notificacion .icono { width: 50px; height: 50px; background: #fef3c7; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: #d97706; flex-shrink: 0; }
        .notificacion .contenido { flex: 1; }
        .notificacion .titulo { font-size: 1.1rem; font-weight: 700; color: #0f2b3d; display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .notificacion .titulo .tag { background: #fef3c7; color: #92400e; font-size: 0.6rem; font-weight: 600; padding: 2px 10px; border-radius: 30px; text-transform: uppercase; letter-spacing: 0.5px; }
        .notificacion .detalles { display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem 1.5rem; margin: 0.8rem 0; background: #f8fafc; padding: 1rem; border-radius: 12px; }
        .notificacion .detalles .item { display: flex; align-items: center; gap: 8px; font-size: 0.85rem; color: #1e293b; }
        .notificacion .detalles .item i { color: #1b4f6e; width: 18px; }
        .notificacion .detalles .item .label { font-weight: 600; color: #64748b; }
        .notificacion .fecha { font-size: 0.7rem; color: #94a3b8; margin-top: 0.5rem; display: flex; align-items: center; gap: 6px; }
        .notificacion .acciones { margin-top: 1rem; display: flex; gap: 0.8rem; flex-wrap: wrap; }
        .btn-atender { background: #10b981; color: white; border: none; padding: 0.6rem 1.5rem; border-radius: 40px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: 0.3s; font-size: 0.8rem; }
        .btn-atender:hover { background: #059669; transform: scale(0.97); }
        .btn-ver-mapa { background: #e2e8f0; color: #1e293b; border: none; padding: 0.6rem 1.5rem; border-radius: 40px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: 0.3s; text-decoration: none; font-size: 0.8rem; }
        .btn-ver-mapa:hover { background: #cbd5e1; }

        .empty { text-align: center; padding: 4rem; background: white; border-radius: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .empty i { font-size: 4rem; color: #10b981; display: block; margin-bottom: 1rem; }
        .empty h3 { color: #1e2a41; margin-bottom: 0.5rem; }
        .empty p { color: #94a3b8; }

        .toast { position: fixed; bottom: 20px; right: 20px; background: #10b981; color: white; padding: 1rem 1.5rem; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.2); z-index: 9999; animation: slideIn 0.3s ease; display: flex; align-items: center; gap: 10px; }
        .toast i { font-size: 1.2rem; }

        @media (max-width: 768px) {
            body { padding: 1rem; }
            .notificacion .detalles { grid-template-columns: 1fr; }
            .header { flex-direction: column; text-align: center; }
        }
    </style>
    <link rel="stylesheet" href="../css/responsive_global.css">
</head>
<body>
<div class="container">
    <!-- HEADER -->
    <div class="header">
        <h1>
            <i class="fas fa-bell"></i> Notificaciones
            <span class="badge <?= $total == 0 ? 'zero' : '' ?>"><?= $total ?></span>
        </h1>
        <a href="admin_red.php" class="btn-volver"><i class="fas fa-arrow-left"></i> Volver</a>
    </div>

    <!-- NOTIFICACIONES -->
    <?php if ($total == 0): ?>
        <div class="empty">
            <i class="fas fa-check-circle"></i>
            <h3>¡Todo en orden!</h3>
            <p>No hay notificaciones pendientes para ti.</p>
        </div>
    <?php else: ?>
        <?php foreach ($notificaciones as $notif): ?>
            <?php
            // Extraer datos de la notificación
            $cliente = '';
            $direccion = '';
            $telefono = '';
            $servicio = '';
            $monto = '';
            foreach ($notif as $linea) {
                if (strpos($linea, 'Cliente:') !== false) $cliente = trim(str_replace('Cliente:', '', $linea));
                if (strpos($linea, 'Dirección:') !== false) $direccion = trim(str_replace('Dirección:', '', $linea));
                if (strpos($linea, 'Teléfono:') !== false) $telefono = trim(str_replace('Teléfono:', '', $linea));
                if (strpos($linea, 'Servicio:') !== false) $servicio = trim(str_replace('Servicio:', '', $linea));
                if (strpos($linea, 'Monto pagado:') !== false) $monto = trim(str_replace('Monto pagado:', '', $linea));
            }
            ?>
            <div class="notificacion">
                <div style="display:flex; gap:1rem; align-items:flex-start; flex-wrap:wrap;">
                    <div class="icono"><i class="fas fa-plug"></i></div>
                    <div class="contenido">
                        <div class="titulo">
                            <span>🔌 Nueva conexión pendiente</span>
                            <span class="tag"><i class="fas fa-clock"></i> Pendiente</span>
                        </div>
                        <div class="detalles">
                            <div class="item"><i class="fas fa-user"></i> <span class="label">Cliente:</span> <?= htmlspecialchars($cliente) ?></div>
                            <div class="item"><i class="fas fa-map-marker-alt"></i> <span class="label">Dirección:</span> <?= htmlspecialchars($direccion) ?></div>
                            <div class="item"><i class="fas fa-phone"></i> <span class="label">Teléfono:</span> <?= htmlspecialchars($telefono) ?></div>
                            <div class="item"><i class="fas fa-wifi"></i> <span class="label">Servicio:</span> <?= htmlspecialchars($servicio) ?></div>
                            <div class="item"><i class="fas fa-dollar-sign"></i> <span class="label">Monto pagado:</span> <?= htmlspecialchars($monto) ?></div>
                            <div class="item"><i class="fas fa-calendar-check"></i> <span class="label">Primer pago:</span> ✅ Realizado</div>
                        </div>
                        <div class="fecha"><i class="fas fa-clock"></i> <?= date('d/m/Y H:i') ?></div>
                        <div class="acciones">
                            <button class="btn-atender" onclick="atenderNotificacion(this)">
                                <i class="fas fa-check"></i> Atender conexión
                            </button>
                            <button class="btn-ver-mapa" onclick="verMapa('<?= htmlspecialchars($direccion) ?>')">
                                <i class="fas fa-map-pin"></i> Ver en mapa
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script>
function atenderNotificacion(btn) {
    if (confirm('✅ ¿Ya realizaste la conexión para este cliente?')) {
        const notificacion = btn.closest('.notificacion');
        notificacion.style.opacity = '0.5';
        notificacion.style.transition = '0.5s';
        mostrarToast('✅ Conexión marcada como atendida', 'success');
        setTimeout(() => {
            notificacion.style.display = 'none';
        }, 500);
        // Aquí podrías enviar una petición AJAX para marcar como atendida
    }
}

function verMapa(direccion) {
    if (direccion && direccion !== 'Sin dirección') {
        const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(direccion)}`;
        window.open(url, '_blank');
    } else {
        mostrarToast('❌ No hay dirección disponible', 'error');
    }
}

function mostrarToast(mensaje, tipo) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    if (tipo === 'error') toast.style.background = '#ef4444';
    toast.innerHTML = `<i class="fas ${tipo === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i> ${mensaje}`;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}
</script>
</body>
</html>