<?php
session_start();

if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../login.php');
    exit;
}
// =============================================
// ✅ ROLES PERMITIDOS:
// 1 = Administrador
// 4 = Administrador de Red
// =============================================
$id_rol = $_SESSION['id_rol'] ?? 0;
$roles_permitidos = [1, 4];

if (!in_array($id_rol, $roles_permitidos)) {
    header('Location: ../login.php');
    exit;
}

// =============================================
// ✅ VARIABLES DE ROL PARA USAR EN EL CÓDIGO
// =============================================
$es_administrador = ($id_rol == 1);
$es_admin_red = ($id_rol == 4);

// =============================================
// ✅ DETERMINAR URL DE RETORNO SEGÚN ROL
// =============================================
switch ($id_rol) {
    case 1: // Administrador
        $url_volver = 'admin.php';
        break;
    case 4: // Admin Red
        $url_volver = 'admin_red.php';
        break;
    default:
        $url_volver = 'login.php';
        break;
}

include __DIR__ . '/../config/conexion.php';
include __DIR__ . '/../controllers/funcion_log.php';
include __DIR__ . '/../controllers/funciones_usuario.php'; // ✅ INCLUIR FUNCIONES

$log = new SistemaLog($conexion);

// ===============================
// OBTENER USUARIOS
// ===============================
$sql_usuarios = "SELECT 
                    u.id_usuario,
                    u.nombre,
                    u.apellido,
                    u.dni,
                    u.localidad,
                    u.telefono,
                    u.email,
                    u.usuario,
                    u.id_rol,
                    r.nombre as rol_nombre
                FROM usuario u
                LEFT JOIN rol r ON u.id_rol = r.id_rol
                ORDER BY u.id_usuario DESC";
$result_usuarios = mysqli_query($conexion, $sql_usuarios);
$usuarios = $result_usuarios ? mysqli_fetch_all($result_usuarios, MYSQLI_ASSOC) : [];

// ===============================
// OBTENER ROLES
// ===============================
$sql_roles = "SELECT * FROM rol ORDER BY id_rol";
$result_roles = mysqli_query($conexion, $sql_roles);
$roles = $result_roles ? mysqli_fetch_all($result_roles, MYSQLI_ASSOC) : [];

// ===============================
// MENSAJES DE SESIÓN
// ===============================
$mensaje = $_SESSION['mensaje'] ?? '';
$mensaje_tipo = $_SESSION['mensaje_tipo'] ?? '';
unset($_SESSION['mensaje'], $_SESSION['mensaje_tipo']);

// ===============================
// PROCESAR ACCIONES POST
// ===============================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';

    // =============================================
    // CREAR USUARIO (SIN CONTRASEÑA)
    // =============================================
    if ($accion === 'crear') {
        $nombre = trim($_POST['nombre']);
        $apellido = trim($_POST['apellido']);
        $dni = trim($_POST['dni'] ?? '');
        $localidad = trim($_POST['localidad'] ?? '');
        $telefono = trim($_POST['telefono'] ?? '');
        $email = trim($_POST['email']);
        $usuario = trim($_POST['usuario']);
        $id_rol = intval($_POST['id_rol'] ?? 0);

        // ✅ OBTENER NOMBRE DEL ROL
        $nombre_rol = '';
        foreach ($roles as $r) {
            if ($r['id_rol'] == $id_rol) {
                $nombre_rol = $r['nombre'];
                break;
            }
        }

        // Validaciones
        if (empty($nombre) || empty($apellido) || empty($usuario) || empty($email) || $id_rol <= 0) {
            $_SESSION['mensaje'] = "❌ Complete todos los campos obligatorios";
            $_SESSION['mensaje_tipo'] = "error";
            header("Location: usuarios.php");
            exit;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['mensaje'] = "❌ El email no es válido";
            $_SESSION['mensaje_tipo'] = "error";
            header("Location: usuarios.php");
            exit;
        }

        // Verificar que el usuario no exista
        $check = mysqli_query($conexion, "SELECT id_usuario FROM usuario WHERE usuario = '$usuario'");
        if (mysqli_num_rows($check) > 0) {
            $_SESSION['mensaje'] = "❌ El nombre de usuario ya existe";
            $_SESSION['mensaje_tipo'] = "error";
            header("Location: usuarios.php");
            exit;
        }

        // Verificar que el email no exista
        $check = mysqli_query($conexion, "SELECT id_usuario FROM usuario WHERE email = '$email'");
        if (mysqli_num_rows($check) > 0) {
            $_SESSION['mensaje'] = "❌ El email ya está registrado";
            $_SESSION['mensaje_tipo'] = "error";
            header("Location: usuarios.php");
            exit;
        }

        // ✅ CREAR USUARIO SIN CONTRASEÑA
        $resultado = crearUsuarioSinPassword(
            $conexion,
            $nombre,
            $apellido,
            $email,
            $usuario,
            $id_rol,
            $telefono,
            $localidad,
            $dni
        );

        if ($resultado['success']) {
            // ✅ LOG: CREAR USUARIO
            $log->registrarAccion(
                $_SESSION['id_usuario'],
                $_SESSION['usuario'] ?? 'Admin',
                'Crear Usuario',
                "Se creó el usuario: $usuario (Rol: $nombre_rol)",
                '',
                'success'
            );

            if (isset($resultado['email_enviado']) && $resultado['email_enviado'] === true) {
                $_SESSION['mensaje'] = "✅ Usuario creado. Se envió un correo para crear su contraseña.";
            } else {
                $_SESSION['mensaje'] = "✅ Usuario creado. El correo no pudo ser enviado. Puedes reenviarlo manualmente.";
                $_SESSION['mensaje_tipo'] = "warning";
            }
            $_SESSION['mensaje_tipo'] = "success";
        } else {
            // ✅ LOG: ERROR AL CREAR USUARIO
            $log->registrarAccion(
                $_SESSION['id_usuario'],
                $_SESSION['usuario'] ?? 'Admin',
                'Error al Crear Usuario',
                "Error al crear usuario: $usuario",
                "Error: " . ($resultado['error'] ?? 'Error desconocido'),
                'error'
            );

            $_SESSION['mensaje'] = "❌ Error al crear usuario: " . ($resultado['error'] ?? 'Error desconocido');
            $_SESSION['mensaje_tipo'] = "error";
        }

        header("Location: usuarios.php");
        exit;
    }


// =============================================
    // EDITAR USUARIO (SIN CAMBIO DE CONTRASEÑA)
    // =============================================
    if ($accion === 'editar') {
        $id_usuario = intval($_POST['id_usuario']);
        $nombre = trim($_POST['nombre']);
        $apellido = trim($_POST['apellido']);
        $dni = trim($_POST['dni'] ?? '');
        $localidad = trim($_POST['localidad'] ?? '');
        $telefono = trim($_POST['telefono'] ?? '');
        $email = trim($_POST['email']);
        $usuario = trim($_POST['usuario']);
        $id_rol = intval($_POST['id_rol'] ?? 0);

        // ✅ OBTENER NOMBRE DEL ROL
        $nombre_rol = '';
        foreach ($roles as $r) {
            if ($r['id_rol'] == $id_rol) {
                $nombre_rol = $r['nombre'];
                break;
            }
        }

        if (empty($nombre) || empty($apellido) || empty($usuario) || empty($email) || $id_rol <= 0) {
            $_SESSION['mensaje'] = "❌ Complete todos los campos obligatorios";
            $_SESSION['mensaje_tipo'] = "error";
            header("Location: usuarios.php");
            exit;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['mensaje'] = "❌ El email no es válido";
            $_SESSION['mensaje_tipo'] = "error";
            header("Location: usuarios.php");
            exit;
        }

        // Verificar que el usuario no exista en otro registro
        $check = mysqli_query($conexion, "SELECT id_usuario FROM usuario WHERE usuario = '$usuario' AND id_usuario != $id_usuario");
        if (mysqli_num_rows($check) > 0) {
            $_SESSION['mensaje'] = "❌ El nombre de usuario ya existe";
            $_SESSION['mensaje_tipo'] = "error";
            header("Location: usuarios.php");
            exit;
        }

        // Verificar que el email no exista en otro registro
        $check = mysqli_query($conexion, "SELECT id_usuario FROM usuario WHERE email = '$email' AND id_usuario != $id_usuario");
        if (mysqli_num_rows($check) > 0) {
            $_SESSION['mensaje'] = "❌ El email ya está registrado";
            $_SESSION['mensaje_tipo'] = "error";
            header("Location: usuarios.php");
            exit;
        }

        // ✅ ACTUALIZAR DATOS (SIN CONTRASEÑA)
        $sql = "UPDATE usuario SET 
                    nombre = ?, 
                    apellido = ?, 
                    dni = ?, 
                    localidad = ?, 
                    telefono = ?, 
                    email = ?, 
                    usuario = ?, 
                    id_rol = ? 
                WHERE id_usuario = ?";
        $stmt = mysqli_prepare($conexion, $sql);
        mysqli_stmt_bind_param($stmt, "sssssssii", 
            $nombre, $apellido, $dni, $localidad, $telefono, $email, $usuario, $id_rol, $id_usuario
        );

        if (mysqli_stmt_execute($stmt)) {
            // ✅ LOG: EDITAR USUARIO
            $log->registrarAccion(
                $_SESSION['id_usuario'],
                $_SESSION['usuario'] ?? 'Admin',
                'Editar Usuario',
                "Se editó el usuario: $usuario (Rol: $nombre_rol)",
                '',
                'info'
            );

            $_SESSION['mensaje'] = "✅ Usuario actualizado correctamente";
            $_SESSION['mensaje_tipo'] = "success";
        } else {
            // ✅ LOG: ERROR AL EDITAR USUARIO
            $log->registrarAccion(
                $_SESSION['id_usuario'],
                $_SESSION['usuario'] ?? 'Admin',
                'Error al Editar Usuario',
                "Error al editar usuario: $usuario (ID: $id_usuario)",
                "Error: " . mysqli_error($conexion),
                'error'
            );

            $_SESSION['mensaje'] = "❌ Error al actualizar usuario: " . mysqli_error($conexion);
            $_SESSION['mensaje_tipo'] = "error";
        }
        mysqli_stmt_close($stmt);

        header("Location: usuarios.php");
        exit;
    }

    // ELIMINAR USUARIO
    // =============================================
    if ($accion === 'eliminar') {
        $id_usuario = intval($_POST['id_usuario']);
        $nombre_usuario = $_POST['nombre_usuario'];

        // No permitir eliminar a sí mismo
        if ($id_usuario == $_SESSION['id_usuario']) {
            $_SESSION['mensaje'] = "❌ No puedes eliminar tu propia cuenta";
            $_SESSION['mensaje_tipo'] = "error";
            header("Location: usuarios.php");
            exit;
        }

        $sql = "DELETE FROM usuario WHERE id_usuario = ?";
        $stmt = mysqli_prepare($conexion, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id_usuario);

        if (mysqli_stmt_execute($stmt)) {
            // ✅ LOG: ELIMINAR USUARIO
            $log->registrarAccion(
                $_SESSION['id_usuario'],
                $_SESSION['usuario'] ?? 'Admin',
                'Eliminar Usuario',
                "Se eliminó el usuario: $nombre_usuario",
                '',
                'warning'
            );

            $_SESSION['mensaje'] = "✅ Usuario eliminado correctamente";
            $_SESSION['mensaje_tipo'] = "success";
        } else {
            // ✅ LOG: ERROR AL ELIMINAR USUARIO
            $log->registrarAccion(
                $_SESSION['id_usuario'],
                $_SESSION['usuario'] ?? 'Admin',
                'Error al Eliminar Usuario',
                "Error al eliminar usuario: $nombre_usuario (ID: $id_usuario)",
                "Error: " . mysqli_error($conexion),
                'error'
            );

            $_SESSION['mensaje'] = "❌ Error al eliminar usuario: " . mysqli_error($conexion);
            $_SESSION['mensaje_tipo'] = "error";
        }
        mysqli_stmt_close($stmt);

        header("Location: usuarios.php");
        exit;
    }

      // =============================================
    // REENVIAR CORREO
    // =============================================
    if ($accion === 'reenviar_correo') {
        $id_usuario = intval($_POST['id_usuario']);
        
        // Obtener datos del usuario
        $sql = "SELECT nombre, email, usuario FROM usuario WHERE id_usuario = ?";
        $stmt = mysqli_prepare($conexion, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id_usuario);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $usuario_data = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);
        
        if ($usuario_data) {
            // Generar nuevo token
            $token = bin2hex(random_bytes(32));
            $expiracion = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            $sql_update = "UPDATE usuario SET reset_token = ?, reset_expira = ? WHERE id_usuario = ?";
            $stmt_update = mysqli_prepare($conexion, $sql_update);
            mysqli_stmt_bind_param($stmt_update, "ssi", $token, $expiracion, $id_usuario);
            mysqli_stmt_execute($stmt_update);
            mysqli_stmt_close($stmt_update);
            
            // Enviar correo
            enviarCorreoCreacionCuenta($usuario_data['email'], $usuario_data['nombre'], $token);
            
            // ✅ LOG: REENVIAR CORREO
            $log->registrarAccion(
                $_SESSION['id_usuario'],
                $_SESSION['usuario'] ?? 'Admin',
                'Reenviar Correo',
                "Se reenvió el correo a: {$usuario_data['usuario']}",
                "Email: {$usuario_data['email']}",
                'info'
            );
            
            $_SESSION['mensaje'] = "✅ Correo reenviado a " . $usuario_data['email'];
            $_SESSION['mensaje_tipo'] = "success";
        } else {
            $_SESSION['mensaje'] = "❌ Usuario no encontrado";
            $_SESSION['mensaje_tipo'] = "error";
        }
        
        header("Location: usuarios.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios - Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background: #f0f4f8; padding: 2rem; }
        .container { max-width: 1400px; margin: 0 auto; background: white; border-radius: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); overflow: hidden; }
        
        .header { background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white; padding: 1.5rem 2rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; }
        .header h1 { font-size: 1.5rem; display: flex; align-items: center; gap: 12px; }
        .header-actions { display: flex; gap: 12px; flex-wrap: wrap; }
        .btn-primary { background: white; border: none; padding: 0.6rem 1.3rem; border-radius: 40px; font-weight: 600; color: #1b4f6e; cursor: pointer; transition: 0.2s; display: flex; align-items: center; gap: 8px; }
        .btn-primary:hover { background: #e6f7ff; transform: scale(0.97); }
        .btn-outline-light { background: transparent; border: 1px solid rgba(255,255,255,0.5); padding: 0.6rem 1.3rem; border-radius: 40px; font-weight: 500; color: white; cursor: pointer; display: flex; align-items: center; gap: 8px; text-decoration: none; }
        .btn-outline-light:hover { background: rgba(255,255,255,0.15); }
        .btn-danger { background: #ef4444; color: white; border: none; padding: 0.4rem 0.8rem; border-radius: 8px; cursor: pointer; transition: 0.3s; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 5px; }
        .btn-danger:hover { background: #dc2626; }
        .btn-edit { background: #f59e0b; color: white; border: none; padding: 0.4rem 0.8rem; border-radius: 8px; cursor: pointer; transition: 0.3s; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 5px; }
        .btn-edit:hover { background: #d97706; }
        .btn-success { background: #10b981; color: white; border: none; padding: 0.4rem 0.8rem; border-radius: 8px; cursor: pointer; transition: 0.3s; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 5px; }
        .btn-success:hover { background: #059669; }
        .btn-info { background: #3b82f6; color: white; border: none; padding: 0.4rem 0.8rem; border-radius: 8px; cursor: pointer; transition: 0.3s; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 5px; }
        .btn-info:hover { background: #2563eb; }

        .stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; padding: 1.5rem 2rem 0.5rem 2rem; }
        .stat-card { background: #f9fafc; padding: 1rem; border-radius: 16px; text-align: center; border: 1px solid #e9eef3; }
        .stat-card .number { font-size: 1.6rem; font-weight: 700; color: #1b4f6e; }
        .stat-card .label { font-size: 0.65rem; color: #666; text-transform: uppercase; letter-spacing: 0.5px; }

        .search-container { display: flex; gap: 15px; margin: 0 2rem 1.5rem 2rem; flex-wrap: wrap; align-items: center; }
        .search-box { flex: 1; min-width: 250px; position: relative; }
        .search-box input { width: 100%; padding: 10px 15px 10px 40px; border-radius: 40px; border: 1px solid #ddd; font-size: 0.9rem; outline: none; transition: 0.3s; }
        .search-box input:focus { border-color: #1b4f6e; box-shadow: 0 0 0 3px rgba(27,79,110,0.1); }
        .search-box i { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #999; }

        .table-wrapper { padding: 0 2rem 2rem 2rem; overflow-x: auto; }
        .section-title { font-weight: 700; font-size: 1.1rem; color: #1e2a41; margin-bottom: 1rem; display: flex; align-items: center; gap: 8px; }
        .user-table { width: 100%; border-collapse: collapse; background: white; border-radius: 20px; overflow: hidden; min-width: 1000px; }
        .user-table th { text-align: left; padding: 0.8rem 0.8rem; background: #f8fafd; font-weight: 600; color: #2c3e66; font-size: 0.7rem; text-transform: uppercase; border-bottom: 1px solid #e2e8f0; white-space: nowrap; }
        .user-table td { padding: 0.8rem; border-bottom: 1px solid #edf2f7; color: #1f2b48; font-size: 0.8rem; vertical-align: middle; }
        .user-table tr:hover { background: #f8fafc; }
        .badge { padding: 3px 10px; border-radius: 30px; font-size: 0.65rem; font-weight: 600; display: inline-flex; align-items: center; gap: 4px; }
        .badge-admin { background: #dbeafe; color: #1e40af; }
        .badge-cobrador { background: #fef3c7; color: #92400e; }
        .badge-tecnico { background: #d1fae5; color: #065f46; }
        .badge-adminred { background: #e0e7ff; color: #3730a3; }
        
        /* Estado de contraseña */
        .badge-password { padding: 2px 8px; border-radius: 12px; font-size: 0.6rem; font-weight: 600; }
        .badge-password.set { background: #d1fae5; color: #065f46; }
        .badge-password.pending { background: #fef3c7; color: #92400e; }

        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; visibility: hidden; opacity: 0; transition: 0.2s; }
        .modal-overlay.active { visibility: visible; opacity: 1; }
        .modal-container { background: white; width: 95%; max-width: 600px; border-radius: 20px; overflow: hidden; max-height: 90vh; overflow-y: auto; }
        .modal-header { background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white; padding: 1rem 1.5rem; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 10; }
        .modal-header h3 { font-size: 1.1rem; display: flex; align-items: center; gap: 8px; }
        .close-modal { background: none; border: none; font-size: 1.5rem; cursor: pointer; color: white; transition: 0.3s; }
        .modal-body { padding: 1.5rem; }
        .form-group { margin-bottom: 1rem; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: 700; color: #1b4f6e; margin-bottom: 4px; }
        .form-group label .obligatorio { color: #ef4444; }
        .form-group input, .form-group select { width: 100%; padding: 0.7rem; border: 1.5px solid #dce5ec; border-radius: 10px; font-size: 0.9rem; transition: 0.3s; }
        .form-group input:focus, .form-group select:focus { outline: none; border-color: #1b4f6e; box-shadow: 0 0 0 3px rgba(27,79,110,0.1); }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        .btn-submit { background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white; width: 100%; padding: 0.8rem; border: none; border-radius: 10px; cursor: pointer; font-weight: 600; margin-top: 0.5rem; display: flex; align-items: center; justify-content: center; gap: 8px; transition: 0.3s; }
        .btn-submit:hover { transform: scale(1.01); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }

        .toast-message { position: fixed; top: 20px; right: 20px; padding: 12px 20px; border-radius: 10px; color: white; z-index: 2000; animation: slideIn 0.3s ease; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); max-width: 400px; }
        .toast-success { background: #10b981; }
        .toast-error { background: #ef4444; }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }

        .info-text { font-size: 0.65rem; color: #94a3b8; margin-top: 4px; }

        @media (max-width: 768px) { body { padding: 1rem; } .header { flex-direction: column; text-align: center; } .search-container { flex-direction: column; } .form-row { grid-template-columns: 1fr; } .user-table { min-width: 700px; } }
    
/* ============================================= */
/* FILTRO POR ROL - CON ICONOS */
/* ============================================= */
.search-container {
    display: flex;
    gap: 15px;
    margin: 0 2rem 1.5rem 2rem;
    flex-wrap: wrap;
    align-items: center;
}

.search-box {
    flex: 1;
    min-width: 250px;
    position: relative;
}

.search-box input {
    width: 100%;
    padding: 10px 15px 10px 40px;
    border-radius: 40px;
    border: 1px solid #ddd;
    font-size: 0.9rem;
    outline: none;
    transition: 0.3s;
}

.search-box input:focus {
    border-color: #1b4f6e;
    box-shadow: 0 0 0 3px rgba(27,79,110,0.1);
}

.search-box i {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #999;
    font-size: 0.9rem;
}

.filter-group {
    display: flex;
    align-items: center;
    gap: 8px;
}

.filter-group label {
    font-size: 0.75rem;
    font-weight: 600;
    color: #1b4f6e;
    white-space: nowrap;
    display: flex;
    align-items: center;
    gap: 5px;
}

.filter-group label i {
    color: #1b4f6e;
    font-size: 0.85rem;
}

.filter-select {
    padding: 8px 16px;
    border-radius: 40px;
    border: 1.5px solid #dce5ec;
    font-size: 0.85rem;
    font-weight: 500;
    color: #1e293b;
    background: white;
    cursor: pointer;
    transition: 0.3s;
    appearance: none;
    -webkit-appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%2364748b' d='M6 8L1 3h10z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 12px center;
    padding-right: 35px;
    min-width: 180px;
}

.filter-select:hover {
    border-color: #1b4f6e;
}

.filter-select:focus {
    outline: none;
    border-color: #1b4f6e;
    box-shadow: 0 0 0 3px rgba(27,79,110,0.1);
}

/* Colores por rol en el select */
.filter-select option[value="todos"] { color: #1e293b; }
.filter-select option[value="1"] { color: #2563eb; }      /* Administrador - Azul */
.filter-select option[value="2"] { color: #d97706; }      /* Cobrador - Naranja */
.filter-select option[value="3"] { color: #059669; }      /* Técnico - Verde */
.filter-select option[value="4"] { color: #7c3aed; }      /* Admin Red - Morado */

.filter-select option i {
    margin-right: 6px;
}

/* Contador de resultados */
.filter-results {
    font-size: 0.78rem;
    color: #64748b;
    display: flex;
    align-items: center;
    gap: 6px;
    background: #f8fafc;
    padding: 5px 14px;
    border-radius: 30px;
    border: 1px solid #e9eef3;
}

.filter-results i {
    color: #1b4f6e;
    font-size: 0.85rem;
}

.filter-results strong {
    color: #0f2b3d;
    font-weight: 700;
}

@media (max-width: 768px) {
    .search-container {
        flex-direction: column;
        align-items: stretch;
    }
    .filter-group {
        width: 100%;
        justify-content: space-between;
    }
    .filter-select {
        flex: 1;
        min-width: 100px;
        font-size: 0.8rem;
        padding: 8px 30px 8px 12px;
    }
    .filter-results {
        justify-content: center;
    }
}


    </style>
</head>
<body>

<div class="container">
    <!-- HEADER -->
    <div class="header">
        <h1><i class="fas fa-user-shield"></i> Gestión de Usuarios</h1>
        <div class="header-actions">
            <button class="btn-primary" onclick="abrirModal()">
                <i class="fas fa-user-plus"></i> Nuevo Usuario
            </button>
            <a href="<?= $url_volver ?>" class="btn-outline-light">
                <i class="fas fa-arrow-left"></i> Volver
            </a>
        </div>
    </div>

    <!-- ESTADÍSTICAS -->
    <div class="stats-row">
        <?php
        $total_usuarios = count($usuarios);
        $total_admins = 0;
        $total_cobradores = 0;
        $total_tecnicos = 0;
        $total_adminred = 0;
        foreach ($usuarios as $u) {
            $rol = $u['id_rol'] ?? 0;
            if ($rol == 1) $total_admins++;
            elseif ($rol == 2) $total_cobradores++;
            elseif ($rol == 3) $total_tecnicos++;
            elseif ($rol == 4) $total_adminred++;
        }
        ?>
        <div class="stat-card">
            <div class="number"><?= $total_usuarios ?></div>
            <div class="label">Total Usuarios</div>
        </div>
        <div class="stat-card" style="border-color:#3b82f6;">
            <div class="number"><?= $total_admins ?></div>
            <div class="label">Administradores</div>
        </div>
        <div class="stat-card" style="border-color:#f59e0b;">
            <div class="number"><?= $total_cobradores ?></div>
            <div class="label">Cobradores</div>
        </div>
        <div class="stat-card" style="border-color:#10b981;">
            <div class="number"><?= $total_tecnicos ?></div>
            <div class="label">Técnicos</div>
        </div>
        <div class="stat-card" style="border-color:#8b5cf6;">
            <div class="number"><?= $total_adminred ?></div>
            <div class="label">Admin Red</div>
        </div>
    </div>

<!-- ============================================= -->
<!-- BUSCADOR Y FILTRO -->
<!-- ============================================= -->
<div class="search-container">
    <div class="search-box">
        <i class="fas fa-search"></i>
        <input type="text" id="searchInput" placeholder="Buscar por nombre, usuario o email...">
    </div>

    <div class="filter-group">
        <label for="filterRol">
            <i class="fas fa-user-tag"></i> Rol:
        </label>
        <select id="filterRol" class="filter-select">
            <option value="todos"><i class="fas fa-list"></i> Todos</option>
            <option value="1"><i class="fas fa-user-shield"></i> Administrador</option>
            <option value="2"><i class="fas fa-hand-holding-usd"></i> Cobrador</option>
            <option value="3"><i class="fas fa-tools"></i> Técnico</option>
            <option value="4"><i class="fas fa-network-wired"></i> Admin Red</option>
        </select>
    </div>

    <div class="filter-results">
        <i class="fas fa-users"></i> 
        <strong id="resultsCount"><?= count($usuarios) ?></strong> usuarios
    </div>
</div>

    <!-- TABLA DE USUARIOS -->
    <div class="table-wrapper">
        <div class="section-title">
            <i class="fas fa-users"></i> Listado de Usuarios
        </div>
        <table class="user-table">
            <thead>
                <tr>
                    <th><i class="fas fa-hashtag"></i> ID</th>
                    <th><i class="fas fa-user"></i> Nombre</th>
                    <th><i class="fas fa-user"></i> Usuario</th>
                    <th><i class="fas fa-envelope"></i> Email</th>
                    <th><i class="fas fa-phone"></i> Teléfono</th>
                    <th><i class="fas fa-user-tag"></i> Rol</th>
                    <th><i class="fas fa-lock"></i> Contraseña</th>
                    <th><i class="fas fa-cog"></i> Acciones</th>
                </tr>
            </thead>
            <tbody id="usuariosBody">
                <?php if (empty($usuarios)): ?>
                    <tr><td colspan="8" style="text-align:center; padding:2rem;">No hay usuarios registrados</td></tr>
                <?php else: ?>
                    <?php foreach ($usuarios as $u): 
                        // Verificar si el usuario tiene contraseña o token pendiente
                        $sql_check = "SELECT contrasena, reset_token FROM usuario WHERE id_usuario = " . $u['id_usuario'];
                        $result_check = mysqli_query($conexion, $sql_check);
                        $user_check = mysqli_fetch_assoc($result_check);
                        $tiene_password = !empty($user_check['contrasena']);
                        $tiene_token_pendiente = !empty($user_check['reset_token']);
                    ?>
                    <tr>
                        <td><?= $u['id_usuario'] ?></td>
                        <td><strong><?= htmlspecialchars($u['nombre']) ?> <?= htmlspecialchars($u['apellido']) ?></strong></td>
                        <td><?= htmlspecialchars($u['usuario']) ?></td>
                        <td><?= htmlspecialchars($u['email']) ?></td>
                        <td><?= htmlspecialchars($u['telefono'] ?? '-') ?></td>
                        <td>
                            <?php
                            $rol = $u['id_rol'] ?? 0;
                            $clase = 'badge-admin';
                            $nombre_rol = $u['rol_nombre'] ?? 'Sin rol';
                            if ($rol == 1) { $clase = 'badge-admin'; $nombre_rol = 'Administrador'; }
                            elseif ($rol == 2) { $clase = 'badge-cobrador'; $nombre_rol = 'Cobrador'; }
                            elseif ($rol == 3) { $clase = 'badge-tecnico'; $nombre_rol = 'Técnico'; }
                            elseif ($rol == 4) { $clase = 'badge-adminred'; $nombre_rol = 'Admin Red'; }
                            ?>
                            <span class="badge <?= $clase ?>">
                                <i class="fas fa-user-tag"></i> <?= $nombre_rol ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($tiene_password): ?>
                                <span class="badge-password set"><i class="fas fa-check-circle"></i> Establecida</span>
                            <?php elseif ($tiene_token_pendiente): ?>
                                <span class="badge-password pending"><i class="fas fa-clock"></i> Pendiente</span>
                            <?php else: ?>
                                <span class="badge-password pending"><i class="fas fa-exclamation-circle"></i> Sin crear</span>
                            <?php endif; ?>
                        </td>
                        <td style="white-space:nowrap;">
                            <button class="btn-edit" onclick='editarUsuario(<?= json_encode($u) ?>)'><i class="fas fa-edit"></i></button>
                            <?php if ($u['id_usuario'] != $_SESSION['id_usuario']): ?>
                                <button class="btn-danger" onclick='eliminarUsuario(<?= $u['id_usuario'] ?>, "<?= htmlspecialchars($u['usuario']) ?>")'><i class="fas fa-trash"></i></button>
                            <?php endif; ?>
                            <?php if (!$tiene_password): ?>
                                <button class="btn-info" onclick='reenviarCorreo(<?= $u['id_usuario'] ?>)' title="Reenviar correo para crear contraseña">
                                    <i class="fas fa-envelope"></i>
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ============================================= -->
<!-- MODAL PARA USUARIO -->
<!-- ============================================= -->
<div id="usuarioModal" class="modal-overlay">
    <div class="modal-container">
        <div class="modal-header">
            <h3 id="modalTitle"><i class="fas fa-user-plus"></i> Nuevo Usuario</h3>
            <button class="close-modal" onclick="cerrarModal()">&times;</button>
        </div>
        <div class="modal-body">
            <form id="formUsuario" method="POST">
                <input type="hidden" name="accion" id="formAccion" value="crear">
                <input type="hidden" name="id_usuario" id="usuarioId">

                <div class="info-text" style="margin-bottom: 1rem; background: #dbeafe; padding: 0.8rem; border-radius: 8px; color: #1e40af;">
                    <i class="fas fa-info-circle"></i> Al crear el usuario, se enviará un correo para que el usuario establezca su contraseña.
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Nombre <span class="obligatorio">*</span></label>
                        <input type="text" id="nombreUsuario" name="nombre" placeholder="Nombre" required>
                    </div>
                    <div class="form-group">
                        <label>Apellido <span class="obligatorio">*</span></label>
                        <input type="text" id="apellidoUsuario" name="apellido" placeholder="Apellido" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>DNI</label>
                        <input type="text" id="dniUsuario" name="dni" placeholder="DNI">
                    </div>
                    <div class="form-group">
                        <label>Teléfono</label>
                        <input type="text" id="telefonoUsuario" name="telefono" placeholder="Teléfono">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Email <span class="obligatorio">*</span></label>
                        <input type="email" id="emailUsuario" name="email" placeholder="email@ejemplo.com" required>
                    </div>
                    <div class="form-group">
                        <label>Localidad</label>
                        <input type="text" id="localidadUsuario" name="localidad" placeholder="Localidad">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Usuario <span class="obligatorio">*</span></label>
                        <input type="text" id="usuarioUsuario" name="usuario" placeholder="Nombre de usuario" required>
                    </div>
                    <div class="form-group">
                        <label>Rol <span class="obligatorio">*</span></label>
                        <select id="rolUsuario" name="id_rol" required>
                            <option value="">-- Seleccionar --</option>
                            <?php foreach ($roles as $r): ?>
                                <option value="<?= $r['id_rol'] ?>"><?= htmlspecialchars($r['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- ✅ OCULTAR CAMPOS DE CONTRASEÑA -->
                <input type="hidden" id="contraseñaUsuario" name="contraseña" value="">

                <button type="submit" class="btn-submit"><i class="fas fa-save"></i> Crear Usuario</button>
            </form>
        </div>
    </div>
</div>

<!-- ============================================= -->
<!-- FORMULARIOS OCULTOS -->
<!-- ============================================= -->
<form id="formEliminar" method="POST" style="display:none;">
    <input type="hidden" name="accion" value="eliminar">
    <input type="hidden" name="id_usuario" id="eliminarId">
    <input type="hidden" name="nombre_usuario" id="eliminarNombre">
</form>

<form id="formReenviar" method="POST" style="display:none;">
    <input type="hidden" name="accion" value="reenviar_correo">
    <input type="hidden" name="id_usuario" id="reenviarId">
</form>

<script>
    <?php if ($mensaje): ?>
        mostrarToast('<?= $mensaje ?>', '<?= $mensaje_tipo ?>');
    <?php endif; ?>

    function mostrarToast(mensaje, tipo) {
        const toast = document.createElement('div');
        toast.className = `toast-message toast-${tipo === 'success' ? 'success' : 'error'}`;
        toast.innerHTML = `<i class="fas ${tipo === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i> ${mensaje}`;
        document.body.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(100px)';
            toast.style.transition = 'all 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }, 3500);
    }

    const modal = document.getElementById('usuarioModal');

    function abrirModal() {
        modal.classList.add('active');
        document.getElementById('formAccion').value = 'crear';
        document.getElementById('modalTitle').innerHTML = '<i class="fas fa-user-plus"></i> Nuevo Usuario';
        document.getElementById('usuarioId').value = '';
        document.getElementById('nombreUsuario').value = '';
        document.getElementById('apellidoUsuario').value = '';
        document.getElementById('dniUsuario').value = '';
        document.getElementById('telefonoUsuario').value = '';
        document.getElementById('emailUsuario').value = '';
        document.getElementById('localidadUsuario').value = '';
        document.getElementById('usuarioUsuario').value = '';
        document.getElementById('rolUsuario').value = '';
    }

    function cerrarModal() {
        modal.classList.remove('active');
    }

    function editarUsuario(usuario) {
        modal.classList.add('active');
        document.getElementById('formAccion').value = 'editar';
        document.getElementById('modalTitle').innerHTML = '<i class="fas fa-edit"></i> Editar Usuario';
        document.getElementById('usuarioId').value = usuario.id_usuario;
        document.getElementById('nombreUsuario').value = usuario.nombre || '';
        document.getElementById('apellidoUsuario').value = usuario.apellido || '';
        document.getElementById('dniUsuario').value = usuario.dni || '';
        document.getElementById('telefonoUsuario').value = usuario.telefono || '';
        document.getElementById('emailUsuario').value = usuario.email || '';
        document.getElementById('localidadUsuario').value = usuario.localidad || '';
        document.getElementById('usuarioUsuario').value = usuario.usuario || '';
        document.getElementById('rolUsuario').value = usuario.id_rol || '';
    }

    function eliminarUsuario(id, nombre) {
        if (confirm(`¿Eliminar el usuario "${nombre}"?`)) {
            document.getElementById('eliminarId').value = id;
            document.getElementById('eliminarNombre').value = nombre;
            document.getElementById('formEliminar').submit();
        }
    }

    function reenviarCorreo(id) {
        if (confirm('¿Reenviar correo para que el usuario cree su contraseña?')) {
            document.getElementById('reenviarId').value = id;
            document.getElementById('formReenviar').submit();
        }
    }


// =============================================
// FILTRO COMBINADO (BÚSQUEDA EN TODOS LOS CAMPOS + ROL)
// =============================================
const searchInput = document.getElementById('searchInput');
const filterRol = document.getElementById('filterRol');
const resultsCount = document.getElementById('resultsCount');

function filtrarTabla() {
    const searchTerm = searchInput.value.toLowerCase().trim();
    const rolSeleccionado = filterRol.value;
    const rows = document.querySelectorAll('#usuariosBody tr');
    let visibleCount = 0;

    rows.forEach(row => {
        // Saltar fila de "No hay usuarios"
        if (row.cells.length < 8) return;

        // =============================================
        // ✅ RECORRER TODAS LAS CELDAS DE LA FILA
        // =============================================
        let coincideBusqueda = false;
        
        // Si el término de búsqueda está vacío, todos coinciden
        if (searchTerm === '') {
            coincideBusqueda = true;
        } else {
            // Buscar en todas las celdas de la fila
            for (let i = 0; i < row.cells.length; i++) {
                const cellText = row.cells[i]?.textContent?.toLowerCase() || '';
                if (cellText.includes(searchTerm)) {
                    coincideBusqueda = true;
                    break;
                }
            }
        }

        // =============================================
        // ✅ OBTENER ROL DE LA FILA
        // =============================================
        const rolCell = row.cells[5]; // Columna de Rol
        const rolBadge = rolCell?.querySelector('.badge');
        let rolTexto = '';
        if (rolBadge) {
            const texto = rolBadge.textContent.trim();
            if (texto.includes('Administrador')) rolTexto = '1';
            else if (texto.includes('Cobrador')) rolTexto = '2';
            else if (texto.includes('Técnico')) rolTexto = '3';
            else if (texto.includes('Admin Red')) rolTexto = '4';
        }

        // Coincidencia de rol
        const matchRol = rolSeleccionado === 'todos' || rolTexto === rolSeleccionado;

        // Mostrar u ocultar
        if (coincideBusqueda && matchRol) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });

    // Actualizar contador
    if (resultsCount) {
        resultsCount.textContent = visibleCount;
    }
}

// Event listeners
if (searchInput) searchInput.addEventListener('input', filtrarTabla);
if (filterRol) filterRol.addEventListener('change', filtrarTabla);

// Inicializar
document.addEventListener('DOMContentLoaded', function() {
    filtrarTabla();
});



    // CERRAR MODAL CON ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') cerrarModal();
    });

    // CERRAR MODAL AL HACER CLIC FUERA
    modal.addEventListener('click', function(e) {
        if (e.target === this) cerrarModal();
    });

    
</script>

</body>
</html>