<?php
session_start();

// Verificar si está logueado
if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../login.php');
    exit;
}

// Roles permitidos: 1=Admin_red, 2=Cobrador, 4=Admin
$rol_permitido = in_array($_SESSION['id_rol'], [1, 2, 4]);
if (!$rol_permitido) {
    header('Location: ../login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';
include __DIR__ . '/../controllers/funcion_log.php';

$log = new SistemaLog($conexion);
$id_rol = $_SESSION['id_rol'];
$id_usuario = $_SESSION['id_usuario'];

// =============================================
// DETERMINAR SI ES COBRADOR (rol 2)
// =============================================
$es_cobrador = ($id_rol == 2);
$id_cobrador_actual = $es_cobrador ? $id_usuario : null;

// =============================================
// ESTADÍSTICAS GENERALES
// =============================================

// 1. TOTAL DE CLIENTES
$sql_total_clientes = "SELECT COUNT(*) as total FROM cliente WHERE eliminado = 0";
$result_total = mysqli_query($conexion, $sql_total_clientes);
$total_clientes = mysqli_fetch_assoc($result_total)['total'] ?? 0;

// 2. CLIENTES POR ESTADO DE PAGO
$sql_estados_pago = "SELECT estado_pago, COUNT(*) as total FROM cliente WHERE eliminado = 0 GROUP BY estado_pago";
$result_estados = mysqli_query($conexion, $sql_estados_pago);
$stats_pago = ['pagado' => 0, 'pendiente' => 0, 'suspendido' => 0];
while ($row = mysqli_fetch_assoc($result_estados)) {
    $estado = strtolower($row['estado_pago']);
    if (isset($stats_pago[$estado])) {
        $stats_pago[$estado] = $row['total'];
    }
}

// 3. TOTAL DE COBRADORES (usuarios con rol 2)
$sql_total_cobradores = "SELECT COUNT(*) as total FROM usuario WHERE id_rol = 2";
$result_cobradores = mysqli_query($conexion, $sql_total_cobradores);
$total_cobradores = mysqli_fetch_assoc($result_cobradores)['total'] ?? 0;

// 4. TOTAL DE PRODUCTOS
$sql_total_productos = "SELECT COUNT(*) as total FROM productos";
$result_productos = mysqli_query($conexion, $sql_total_productos);
$total_productos = mysqli_fetch_assoc($result_productos)['total'] ?? 0;

// 5. COBROS DEL MES (usando mes y anio de la tabla pago)
$sql_cobros_mes = "
    SELECT 
        COUNT(*) as total_cobros,
        SUM(monto) as total_recaudado
    FROM pago 
    WHERE mes = MONTH(CURRENT_DATE())
        AND anio = YEAR(CURRENT_DATE())
        AND estado = 'Pagado'
";
$result_cobros = mysqli_query($conexion, $sql_cobros_mes);
$cobros_mes = mysqli_fetch_assoc($result_cobros);

// 6. CLIENTES POR BARRIO (usando la tabla barrio)
$sql_barrios = "
    SELECT 
        b.nombre as barrio, 
        COUNT(c.id) as cantidad 
    FROM cliente c
    INNER JOIN barrio b ON c.id_barrio = b.id_barrio
    WHERE c.eliminado = 0
    GROUP BY c.id_barrio
    ORDER BY cantidad DESC 
    LIMIT 10
";
$result_barrios = mysqli_query($conexion, $sql_barrios);
$clientes_por_barrio = [];
while ($row = mysqli_fetch_assoc($result_barrios)) {
    $clientes_por_barrio[] = $row;
}

// 7. ÚLTIMOS COBROS REGISTRADOS (sin id_cobrador)
$sql_ultimos_cobros = "
    SELECT 
        p.id_pago,
        p.monto,
        p.fecha_pago,
        p.metodo_pago,
        p.mes,
        p.anio,
        p.estado as estado_pago,
        c.nombre as cliente_nombre,
        c.apellido as cliente_apellido,
        c.telefono
    FROM pago p
    LEFT JOIN cliente c ON p.id_cliente = c.id
    ORDER BY p.fecha_pago DESC
    LIMIT 10
";
$result_ultimos = mysqli_query($conexion, $sql_ultimos_cobros);
$ultimos_cobros = [];
while ($row = mysqli_fetch_assoc($result_ultimos)) {
    $ultimos_cobros[] = $row;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Control - Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Inter', sans-serif; 
            background: #f0f4f8; 
            overflow-x: hidden;
        }

        .app-container { display: flex; min-height: 100vh; }

        /* ============================================= */
        /* SIDEBAR */
        /* ============================================= */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #0f2b3d 0%, #1b4f6e 100%);
            color: white;
            padding: 2rem 1.5rem;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
        }

        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-track { background: transparent; }
        .sidebar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.3); border-radius: 10px; }

        .logo-area {
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(255,255,255,0.15);
        }

        .logo-area h2 {
            font-size: 1.5rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .logo-area h2 i { color: #60a5fa; }
        .logo-area span { font-size: 0.7rem; opacity: 0.6; display: block; margin-top: 4px; }

        .nav-section { margin-bottom: 1.5rem; }
        .nav-section-title {
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            opacity: 0.5;
            margin-bottom: 0.8rem;
            font-weight: 600;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.7rem 1rem;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.2s;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            margin-bottom: 0.2rem;
            font-size: 0.9rem;
            border: none;
            background: transparent;
            width: 100%;
            text-align: left;
        }

        .nav-item:hover { background: rgba(255,255,255,0.1); color: white; }
        .nav-item.active { background: rgba(255,255,255,0.15); color: white; }
        .nav-item i { width: 22px; font-size: 1.1rem; text-align: center; color: rgba(255,255,255,0.6); }
        .nav-item:hover i, .nav-item.active i { color: white; }

        .nav-divider { border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 0.5rem 0 1rem 0; }

        /* ============================================= */
        /* MAIN CONTENT */
        /* ============================================= */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            background: white;
            padding: 1rem 2rem;
            border-radius: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            flex-wrap: wrap;
            gap: 1rem;
        }

        .page-title { font-size: 1.3rem; font-weight: 700; color: #1e2a41; }
        .page-title i { color: #1b4f6e; margin-right: 10px; }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.9rem;
            color: #1e2a41;
        }
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
            font-size: 1rem;
        }

        .rol-badge {
            padding: 0.15rem 0.6rem;
            border-radius: 12px;
            font-size: 0.6rem;
            font-weight: 600;
        }
        .rol-admin_red { background: #dbeafe; color: #3b82f6; }
        .rol-admin { background: #e0f2fe; color: #0ea5e9; }
        .rol-cobrador { background: #d1fae5; color: #10b981; }

        /* ============================================= */
        /* ESTADÍSTICAS */
        /* ============================================= */
        .stats-container { padding: 0.5rem 0 0.5rem 0; }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }

        .stat-card {
            background: white;
            padding: 1.2rem 1.5rem;
            border-radius: 14px;
            border: 1px solid #e9eef3;
            transition: all 0.3s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        .stat-card .stat-label {
            font-size: 0.7rem;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
            margin-bottom: 0.3rem;
        }

        .stat-card .stat-number {
            font-size: 1.8rem;
            font-weight: 700;
            color: #0f2b3d;
        }

        .stat-card .stat-icon {
            float: right;
            font-size: 2rem;
            opacity: 0.2;
        }

        /* ============================================= */
        /* GRÁFICOS Y TABLAS */
        /* ============================================= */
        .row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-top: 1.5rem;
        }

        .card {
            background: white;
            border-radius: 16px;
            border: 1px solid #e9eef3;
            padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }

        .card h4 {
            font-size: 0.85rem;
            font-weight: 700;
            color: #0f2b3d;
            margin-bottom: 1rem;
        }
        .card h4 i { color: #1b4f6e; margin-right: 6px; }

        .card-body { padding: 0.5rem 0; }
        .card-body canvas { max-width: 100%; max-height: 220px; }

        /* ============================================= */
        /* TABLA DE ÚLTIMOS COBROS */
        /* ============================================= */
        .table-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
        thead { background: #f8fafd; }
        th {
            padding: 0.7rem 0.8rem;
            text-align: left;
            font-weight: 600;
            color: #1e2a41;
            border-bottom: 2px solid #e9eef3;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        td {
            padding: 0.6rem 0.8rem;
            border-bottom: 1px solid #f1f5f9;
            color: #1e2a41;
        }
        tr:hover { background: #f8fafd; }

        .badge {
            padding: 0.2rem 0.7rem;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 600;
            display: inline-block;
        }
        .badge-success { background: #d1fae5; color: #10b981; }
        .badge-warning { background: #fef3c7; color: #f59e0b; }
        .badge-danger { background: #fee2e2; color: #ef4444; }

        .text-muted { color: #94a3b8; }
        .text-center { text-align: center; }

        /* ============================================= */
        /* BARRIOS */
        /* ============================================= */
        .barrios-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.5rem;
        }
        .barrio-item {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0.8rem;
            background: #f8fafd;
            border-radius: 8px;
            font-size: 0.8rem;
        }
        .barrio-item .barrio-nombre { color: #0f2b3d; }
        .barrio-item .barrio-cantidad { font-weight: 600; color: #1b4f6e; }

        /* ============================================= */
        /* FOOTER */
        /* ============================================= */
        .footer {
            margin-top: 2rem;
            padding-top: 1rem;
            text-align: center;
            font-size: 0.75rem;
            color: #94a3b8;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .status-dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            background: #10b981;
            border-radius: 50%;
            margin-right: 6px;
            animation: pulse-dot 2s infinite;
        }

        @keyframes pulse-dot { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }

        /* ============================================= */
        /* RESPONSIVE */
        /* ============================================= */
        @media (max-width: 992px) {
            .row { grid-template-columns: 1fr; }
        }

        @media (max-width: 768px) {
            .sidebar { display: none; }
            .main-content { margin-left: 0; padding: 1rem; }
            .stats-grid { grid-template-columns: 1fr 1fr; }
            .top-bar { flex-direction: column; align-items: stretch; text-align: center; }
            .user-info { justify-content: center; }
            .footer { flex-direction: column; text-align: center; }
            .barrios-grid { grid-template-columns: 1fr; }
        }

        @media (max-width: 600px) {
            .stats-grid { grid-template-columns: 1fr; }
            .stat-card .stat-number { font-size: 1.4rem; }
        }
    </style>
</head>
<body>

<div class="app-container">
    <!-- ============================================= -->
    <!-- SIDEBAR -->
    <!-- ============================================= -->
    <div class="sidebar">
        <div class="logo-area">
            <h2><i class="fas fa-tv"></i> Chango Vision</h2>
            <span>Panel de Control</span>
        </div>

        

        <!-- Módulo Cobros -->
        <div class="nav-section">
            <div class="nav-section-title">Cobros</div>
            <a href="admin_cliente.php" class="nav-item">
                <i class="fas fa-hand-holding-usd"></i>
                <span>Registrar Cobro</span>
            </a>
            
            
            
        </div>

       

        <!-- Reportes -->
        <div class="nav-section">
            <div class="nav-section-title">Reportes</div>
            <a href="soporte_tecnico.php" class="nav-item">
                <i class="fas fa-file-alt"></i>
                <span>Tarea Tecnica</span>
            </a>
        </div>

        <hr class="nav-divider">

        <!-- Seguridad -->
        <div class="nav-section">
            <div class="nav-section-title">Seguridad</div>
            <a href="cambiar_datos.php" class="nav-item">
                <i class="fas fa-user-cog"></i>
                <span>Cambiar Datos</span>
            </a>
            <a href="../logout.php" class="nav-item" onclick="return confirm('¿Cerrar sesión?')">
                <i class="fas fa-sign-out-alt"></i>
                <span>Cerrar Sesión</span>
            </a>
        </div>
    </div>

    <!-- ============================================= -->
    <!-- MAIN CONTENT -->
    <!-- ============================================= -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="page-title">
                <i class="fas fa-chart-pie"></i> Panel de Control
            </div>
            <div class="user-info">
                <i class="fas fa-user-shield" style="color:#1b4f6e;"></i>
                <span><?= htmlspecialchars($_SESSION['usuario'] ?? 'Usuario') ?></span>
                <?php
                $rol_nombre = '';
                if ($id_rol == 1) $rol_nombre = 'Admin_red';
                elseif ($id_rol == 2) $rol_nombre = 'Cobrador';
                elseif ($id_rol == 4) $rol_nombre = 'Admin';
                ?>
                <span class="rol-badge rol-<?= strtolower($rol_nombre) ?>"><?= $rol_nombre ?></span>
                <div class="user-avatar">
                    <?= strtoupper(substr($_SESSION['usuario'] ?? 'A', 0, 1)) ?>
                </div>
            </div>
        </div>

        <!-- ============================================= -->
        <!-- ESTADÍSTICAS -->
        <!-- ============================================= -->
        <div class="stats-container">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                    <div class="stat-label">Total Clientes</div>
                    <div class="stat-number"><?= number_format($total_clientes) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-check-circle" style="color:#10b981;"></i></div>
                    <div class="stat-label">Pagaron</div>
                    <div class="stat-number" style="color:#10b981;"><?= number_format($stats_pago['pagado']) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-clock" style="color:#f59e0b;"></i></div>
                    <div class="stat-label">Pendientes</div>
                    <div class="stat-number" style="color:#f59e0b;"><?= number_format($stats_pago['pendiente']) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-pause-circle" style="color:#ef4444;"></i></div>
                    <div class="stat-label">Suspendidos</div>
                    <div class="stat-number" style="color:#ef4444;"><?= number_format($stats_pago['suspendido']) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-user-tie" style="color:#3b82f6;"></i></div>
                    <div class="stat-label">Cobradores</div>
                    <div class="stat-number" style="color:#3b82f6;"><?= number_format($total_cobradores) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-coins" style="color:#10b981;"></i></div>
                    <div class="stat-label">Cobros del Mes</div>
                    <div class="stat-number" style="color:#10b981;">
                        $<?= number_format($cobros_mes['total_recaudado'] ?? 0, 0, ',', '.') ?>
                    </div>
                    <div style="font-size:0.7rem; color:#94a3b8;">
                        <?= $cobros_mes['total_cobros'] ?? 0 ?> transacciones
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-box" style="color:#8b5cf6;"></i></div>
                    <div class="stat-label">Productos</div>
                    <div class="stat-number" style="color:#8b5cf6;"><?= number_format($total_productos) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-percent" style="color:#0ea5e9;"></i></div>
                    <div class="stat-label">Eficiencia</div>
                    <div class="stat-number" style="color:#0ea5e9;">
                        <?= $total_clientes > 0 ? round(($stats_pago['pagado'] / $total_clientes) * 100) : 0 ?>%
                    </div>
                    <div style="font-size:0.7rem; color:#94a3b8;">Clientes al día</div>
                </div>
            </div>
        </div>

        <!-- ============================================= -->
        <!-- GRÁFICOS Y TABLAS -->
        <!-- ============================================= -->
        <div class="row">
            <!-- Gráfico de Pagos -->
            <div class="card">
                <h4><i class="fas fa-chart-pie"></i> Distribución de Pagos</h4>
                <div class="card-body">
                    <canvas id="pagosChart"></canvas>
                </div>
                <div style="display:flex; justify-content:center; gap:1.5rem; margin-top:0.5rem; font-size:0.75rem;">
                    <span><span style="display:inline-block; width:12px; height:12px; background:#10b981; border-radius:4px;"></span> Pagaron (<?= $stats_pago['pagado'] ?>)</span>
                    <span><span style="display:inline-block; width:12px; height:12px; background:#f59e0b; border-radius:4px;"></span> Pendientes (<?= $stats_pago['pendiente'] ?>)</span>
                    <span><span style="display:inline-block; width:12px; height:12px; background:#ef4444; border-radius:4px;"></span> Suspendidos (<?= $stats_pago['suspendido'] ?>)</span>
                </div>
            </div>

            <!-- Clientes por Barrio -->
            <div class="card">
                <h4><i class="fas fa-map-marker-alt"></i> Clientes por Barrio</h4>
                <div class="card-body">
                    <?php if (!empty($clientes_por_barrio)): ?>
                        <div class="barrios-grid">
                            <?php foreach ($clientes_por_barrio as $barrio): ?>
                                <div class="barrio-item">
                                    <span class="barrio-nombre">📍 <?= htmlspecialchars($barrio['barrio']) ?></span>
                                    <span class="barrio-cantidad"><?= $barrio['cantidad'] ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted text-center">No hay clientes registrados</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- ============================================= -->
        <!-- ÚLTIMOS COBROS -->
        <!-- ============================================= -->
        <div class="card" style="margin-top:1.5rem;">
            <h4><i class="fas fa-history"></i> Últimos Cobros Registrados</h4>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Cliente</th>
                            <th>Monto</th>
                            <th>Método</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($ultimos_cobros)): ?>
                            <?php foreach ($ultimos_cobros as $cobro): ?>
                            <tr>
                                <td><?= date('d/m/Y H:i', strtotime($cobro['fecha_pago'])) ?></td>
                                <td><?= htmlspecialchars($cobro['cliente_nombre'] . ' ' . $cobro['cliente_apellido']) ?></td>
                                <td><strong>$<?= number_format($cobro['monto'], 0, ',', '.') ?></strong></td>
                                <td><span class="badge badge-success"><?= htmlspecialchars($cobro['metodo_pago'] ?? 'Efectivo') ?></span></td>
                                <td>
                                    <span class="badge <?= $cobro['estado_pago'] == 'Pagado' ? 'badge-success' : 'badge-warning' ?>">
                                        <?= $cobro['estado_pago'] ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-muted text-center">No hay cobros registrados</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ============================================= -->
        <!-- FOOTER -->
        <!-- ============================================= -->
        <div class="footer">
            <div>© 2026 Chango Vision - Todos los derechos reservados</div>
            <div class="footer-status">
                <span><span class="status-dot"></span> Sistema Activo</span>
                <span><i class="fas fa-user-shield"></i> <?= $rol_nombre ?></span>
                <span id="updateTime"><i class="fas fa-clock"></i> Actualizando...</span>
            </div>
        </div>
    </div>
</div>

<!-- ============================================= -->
<!-- SCRIPTS -->
<!-- ============================================= -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Actualizar hora
    function actualizarHora() {
        const ahora = new Date();
        const fecha = ahora.toLocaleDateString('es-AR');
        const hora = ahora.toLocaleTimeString('es-AR');
        document.getElementById('updateTime').innerHTML = `<i class="fas fa-clock"></i> ${fecha} ${hora}`;
    }
    actualizarHora();
    setInterval(actualizarHora, 30000);

    // Gráfico de Pagos
    const ctx = document.getElementById('pagosChart').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Pagaron', 'Pendientes', 'Suspendidos'],
            datasets: [{
                data: [
                    <?= $stats_pago['pagado'] ?>,
                    <?= $stats_pago['pendiente'] ?>,
                    <?= $stats_pago['suspendido'] ?>
                ],
                backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { display: false }
            },
            cutout: '70%'
        }
    });
});
</script>

</body>
</html>