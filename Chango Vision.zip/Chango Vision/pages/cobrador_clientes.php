<?php
session_start();

// Verificar si está logueado
if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../login.php');
    exit;
}

// Roles permitidos: 1=Admin_red, 2=Cobrador, 4=Admin
$rol_permitido = in_array($_SESSION['id_rol'], [1, 2, 4]);
if (!$rol_permitido) {
    header('Location: ../login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';
include __DIR__ . '/../controllers/funcion_log.php';

$log = new SistemaLog($conexion);
$id_rol = $_SESSION['id_rol'];
$id_usuario = $_SESSION['id_usuario'];

// =============================================
// DETERMINAR SI ES COBRADOR (rol 2)
// =============================================
$es_cobrador = ($id_rol == 2);
$id_cobrador_actual = $es_cobrador ? $id_usuario : null;

// =============================================
// ESTADÍSTICAS GENERALES
// =============================================

// 1. TOTAL DE CLIENTES
$sql_total_clientes = "SELECT COUNT(*) as total FROM cliente WHERE eliminado = 0";
$result_total = mysqli_query($conexion, $sql_total_clientes);
$total_clientes = mysqli_fetch_assoc($result_total)['total'] ?? 0;

// 2. CLIENTES POR ESTADO DE PAGO
$sql_estados_pago = "SELECT estado_pago, COUNT(*) as total FROM cliente WHERE eliminado = 0 GROUP BY estado_pago";
$result_estados = mysqli_query($conexion, $sql_estados_pago);
$stats_pago = ['pagado' => 0, 'pendiente' => 0, 'suspendido' => 0];
while ($row = mysqli_fetch_assoc($result_estados)) {
    $estado = strtolower($row['estado_pago']);
    if (isset($stats_pago[$estado])) {
        $stats_pago[$estado] = $row['total'];
    }
}

// 3. TOTAL DE COBRADORES (usuarios con rol 2)
$sql_total_cobradores = "SELECT COUNT(*) as total FROM usuario WHERE id_rol = 2";
$result_cobradores = mysqli_query($conexion, $sql_total_cobradores);
$total_cobradores = mysqli_fetch_assoc($result_cobradores)['total'] ?? 0;

// 4. TOTAL DE PRODUCTOS
$sql_total_productos = "SELECT COUNT(*) as total FROM productos";
$result_productos = mysqli_query($conexion, $sql_total_productos);
$total_productos = mysqli_fetch_assoc($result_productos)['total'] ?? 0;

// 5. COBROS DEL MES (usando mes y anio de la tabla pago)
$sql_cobros_mes = "
    SELECT 
        COUNT(*) as total_cobros,
        SUM(monto) as total_recaudado
    FROM pago 
    WHERE mes = MONTH(CURRENT_DATE())
        AND anio = YEAR(CURRENT_DATE())
        AND estado = 'Pagado'
";
$result_cobros = mysqli_query($conexion, $sql_cobros_mes);
$cobros_mes = mysqli_fetch_assoc($result_cobros);

// =============================================
// 6. CLIENTES POR BARRIO Y SUS CLIENTES (Exclusivo lista Cobrador)
// =============================================

if ($es_cobrador) {
    // A) Si el usuario es Cobrador: se cuentan únicamente los clientes pendientes de su 2do pago en adelante
    $sql_barrios = "
        SELECT 
            b.id_barrio,
            b.nombre as barrio, 
            COUNT(c.id) as cantidad 
        FROM barrio b
        INNER JOIN cliente c ON c.id_barrio = b.id_barrio 
            AND c.eliminado = 0
            AND c.estado = 'Activo'
            AND c.estado_pago != 'suspendido'
            AND (
                SELECT COUNT(*) 
                FROM pago p 
                WHERE p.id_cliente = c.id 
                  AND p.estado = 'Pagado'
            ) = 1
            AND c.fecha_ultimo_pago IS NOT NULL
        GROUP BY b.id_barrio, b.nombre
        HAVING cantidad > 0
        ORDER BY cantidad DESC
    ";
} else {
    // B) Si es Admin / Admin Red: muestra todos los clientes activos del barrio
    $sql_barrios = "
        SELECT 
            b.id_barrio,
            b.nombre as barrio, 
            COUNT(c.id) as cantidad 
        FROM barrio b
        LEFT JOIN cliente c ON c.id_barrio = b.id_barrio AND c.eliminado = 0
        GROUP BY b.id_barrio, b.nombre
        HAVING cantidad > 0
        ORDER BY cantidad DESC
    ";
}

$result_barrios = mysqli_query($conexion, $sql_barrios);
$clientes_por_barrio = [];

while ($row = mysqli_fetch_assoc($result_barrios)) {
    $id_b = $row['id_barrio'];
    
    if ($es_cobrador) {
        // Trae únicamente los clientes pendientes del cobrador para ese barrio (hasta 4)
        $sql_c_barrio = "
            SELECT id, nombre, apellido, estado_pago 
            FROM cliente 
            WHERE id_barrio = $id_b 
              AND eliminado = 0 
              AND estado = 'Activo'
              AND estado_pago != 'suspendido'
              AND (
                  SELECT COUNT(*) 
                  FROM pago p 
                  WHERE p.id_cliente = cliente.id 
                    AND p.estado = 'Pagado'
              ) = 1
              AND fecha_ultimo_pago IS NOT NULL
            LIMIT 4";
    } else {
        // Trae los clientes generales para Administradores
        $sql_c_barrio = "SELECT id, nombre, apellido, estado_pago FROM cliente WHERE id_barrio = $id_b AND eliminado = 0 LIMIT 4";
    }

    $res_c_barrio = mysqli_query($conexion, $sql_c_barrio);
    $lista_clientes = [];
    while ($cb = mysqli_fetch_assoc($res_c_barrio)) {
        $lista_clientes[] = $cb;
    }
    
    $row['clientes'] = $lista_clientes;
    $clientes_por_barrio[] = $row;
}

// 7. COBROS REGISTRADOS DEL DÍA DE HOY (DATE(fecha_pago) = CURDATE())
$sql_ultimos_cobros = "
    SELECT 
        p.id_pago,
        p.monto,
        p.fecha_pago,
        p.metodo_pago,
        p.mes,
        p.anio,
        p.estado as estado_pago,
        c.nombre as cliente_nombre,
        c.apellido as cliente_apellido,
        c.telefono,
        c.dni
    FROM pago p
    LEFT JOIN cliente c ON p.id_cliente = c.id
    WHERE DATE(p.fecha_pago) = CURDATE()
    ORDER BY p.fecha_pago DESC
";
$result_ultimos = mysqli_query($conexion, $sql_ultimos_cobros);
$ultimos_cobros = [];
$total_monto_hoy = 0;

while ($row = mysqli_fetch_assoc($result_ultimos)) {
    $ultimos_cobros[] = $row;
    if (strtolower($row['estado_pago']) === 'pagado') {
        $total_monto_hoy += floatval($row['monto']);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../css/responsive_global.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Librerías para generación de PDF profesional -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <script src="../js/responsive_sidebar.js" defer></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Inter', sans-serif; 
            background: #f0f4f8; 
            overflow-x: hidden;
        }

        .app-container { display: flex; min-height: 100vh; }

        /* ============================================= */
        /* SIDEBAR */
        /* ============================================= */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #0f2b3d 0%, #1b4f6e 100%);
            color: white;
            padding: 2rem 1.5rem;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
        }

        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-track { background: transparent; }
        .sidebar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.3); border-radius: 10px; }

        .logo-area {
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(255,255,255,0.15);
        }

        .logo-area h2 {
            font-size: 1.5rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .logo-area h2 i { color: #60a5fa; }
        .logo-area span { font-size: 0.7rem; opacity: 0.6; display: block; margin-top: 4px; }

        .nav-section { margin-bottom: 1.5rem; }
        .nav-section-title {
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            opacity: 0.5;
            margin-bottom: 0.8rem;
            font-weight: 600;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.7rem 1rem;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.2s;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            margin-bottom: 0.2rem;
            font-size: 0.9rem;
            border: none;
            background: transparent;
            width: 100%;
            text-align: left;
        }

        .nav-item:hover { background: rgba(255,255,255,0.1); color: white; }
        .nav-item.active { background: rgba(255,255,255,0.15); color: white; }
        .nav-item i { width: 22px; font-size: 1.1rem; text-align: center; color: rgba(255,255,255,0.6); }
        .nav-item:hover i, .nav-item.active i { color: white; }

        .nav-divider { border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 0.5rem 0 1rem 0; }

        /* ============================================= */
        /* MAIN CONTENT */
        /* ============================================= */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            background: white;
            padding: 1rem 2rem;
            border-radius: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            flex-wrap: wrap;
            gap: 1rem;
        }

        .page-title { font-size: 1.3rem; font-weight: 700; color: #1e2a41; }
        .page-title i { color: #1b4f6e; margin-right: 10px; }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.9rem;
            color: #1e2a41;
        }
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
            font-size: 1rem;
        }

        .rol-badge {
            padding: 0.15rem 0.6rem;
            border-radius: 12px;
            font-size: 0.6rem;
            font-weight: 600;
        }
        .rol-admin_red { background: #dbeafe; color: #3b82f6; }
        .rol-admin { background: #e0f2fe; color: #0ea5e9; }
        .rol-cobrador { background: #d1fae5; color: #10b981; }

        /* ============================================= */
        /* ESTADÍSTICAS */
        /* ============================================= */
        .stats-container { padding: 0.5rem 0 0.5rem 0; }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }

        .stat-card {
            background: white;
            padding: 1.2rem 1.5rem;
            border-radius: 14px;
            border: 1px solid #e9eef3;
            transition: all 0.3s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        .stat-card .stat-label {
            font-size: 0.7rem;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
            margin-bottom: 0.3rem;
        }

        .stat-card .stat-number {
            font-size: 1.8rem;
            font-weight: 700;
            color: #0f2b3d;
        }

        .stat-card .stat-icon {
            float: right;
            font-size: 2rem;
            opacity: 0.2;
        }

        /* ============================================= */
        /* GRÁFICOS Y TABLAS */
        /* ============================================= */
        .row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-top: 1.5rem;
        }

        .card {
            background: white;
            border-radius: 16px;
            border: 1px solid #e9eef3;
            padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }

        .card h4 {
            font-size: 0.85rem;
            font-weight: 700;
            color: #0f2b3d;
            margin-bottom: 1rem;
        }
        .card h4 i { color: #1b4f6e; margin-right: 6px; }

        .card-body { padding: 0.5rem 0; }
        .card-body canvas { max-width: 100%; max-height: 220px; }

        /* ============================================= */
        /* TABLA DE ÚLTIMOS COBROS */
        /* ============================================= */
        .table-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
        thead { background: #f8fafd; }
        th {
            padding: 0.7rem 0.8rem;
            text-align: left;
            font-weight: 600;
            color: #1e2a41;
            border-bottom: 2px solid #e9eef3;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        td {
            padding: 0.6rem 0.8rem;
            border-bottom: 1px solid #f1f5f9;
            color: #1e2a41;
        }
        tr:hover { background: #f8fafd; }

        .badge {
            padding: 0.2rem 0.7rem;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 600;
            display: inline-block;
        }
        .badge-success { background: #d1fae5; color: #10b981; }
        .badge-warning { background: #fef3c7; color: #f59e0b; }
        .badge-danger { background: #fee2e2; color: #ef4444; }

        .text-muted { color: #94a3b8; }
        .text-center { text-align: center; }

        /* ============================================= */
        /* BARRIOS */
        /* ============================================= */
        .barrios-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.5rem;
        }
        .barrio-item {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0.8rem;
            background: #f8fafd;
            border-radius: 8px;
            font-size: 0.8rem;
        }
        .barrio-item .barrio-nombre { color: #0f2b3d; }
        .barrio-item .barrio-cantidad { font-weight: 600; color: #1b4f6e; }

        /* ============================================= */
        /* FOOTER */
        /* ============================================= */
        .footer {
            margin-top: 2rem;
            padding-top: 1rem;
            text-align: center;
            font-size: 0.75rem;
            color: #94a3b8;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .status-dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            background: #10b981;
            border-radius: 50%;
            margin-right: 6px;
            animation: pulse-dot 2s infinite;
        }

        @keyframes pulse-dot { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }

        /* ============================================= */
        /* RESPONSIVE */
        /* ============================================= */
        @media (max-width: 992px) {
            .row { grid-template-columns: 1fr; }
        }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 1rem; }
            .stats-grid { grid-template-columns: 1fr 1fr; }
            .top-bar { flex-direction: column; align-items: stretch; text-align: center; }
            .user-info { justify-content: center; }
            .footer { flex-direction: column; text-align: center; }
            .barrios-grid { grid-template-columns: 1fr; }
        }

        @media (max-width: 600px) {
            .stats-grid { grid-template-columns: 1fr; }
            .stat-card .stat-number { font-size: 1.4rem; }
        }
    </style>
</head>
<body>

<div class="app-container">
    <!-- ============================================= -->
    <!-- SIDEBAR -->
    <!-- ============================================= -->
    <div class="sidebar">
        <div class="sidebar-mobile-header">
            <span class="sidebar-mobile-title"><i class="fas fa-tv"></i> Menú</span>
            <button class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Cerrar menú">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="logo-area">
            <h2><i class="fas fa-tv"></i> Chango Vision</h2>
            <span>Panel de Control</span>
        </div>

        

        <!-- Módulo Cobros -->
        <div class="nav-section">
            <div class="nav-section-title">Cobros</div>
            <a href="admin_cliente.php" class="nav-item">
                <i class="fas fa-hand-holding-usd"></i>
                <span>Registrar Cobro</span>
            </a>
            
            
            
        </div>

       

        <!-- Reportes -->
        <div class="nav-section">
            <div class="nav-section-title">Reportes</div>
            <a href="soporte_tecnico.php" class="nav-item">
                <i class="fas fa-file-alt"></i>
                <span>Registrar Reclamo</span>
            </a>
        </div>

        <hr class="nav-divider">

        <!-- Seguridad -->
        <div class="nav-section">
            <div class="nav-section-title">Seguridad</div>
            <a href="cambiar_datos.php" class="nav-item">
                <i class="fas fa-user-cog"></i>
                <span>Cambiar Datos</span>
            </a>
            <a href="../logout.php" class="nav-item" onclick="return confirm('¿Cerrar sesión?')">
                <i class="fas fa-sign-out-alt"></i>
                <span>Cerrar Sesión</span>
            </a>
        </div>
    </div>

    <!-- ============================================= -->
    <!-- MAIN CONTENT -->
    <!-- ============================================= -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div style="display: flex; align-items: center; gap: 12px;">
                <button class="mobile-toggle-btn" id="mobileMenuBtn" aria-label="Abrir menú de navegación">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <i class="fas fa-calendar-day"></i>
                    <span id="fechaActual"><?= date('d/m/Y') ?></span>
                </div>
            </div>
            <div class="user-info">
                <i class="fas fa-user-shield" style="color:#1b4f6e;"></i>
                <span><?= htmlspecialchars($_SESSION['usuario'] ?? 'Usuario') ?></span>
                <?php
                $rol_nombre = '';
                if ($id_rol == 1) $rol_nombre = 'Admin_red';
                elseif ($id_rol == 2) $rol_nombre = 'Cobrador';
                elseif ($id_rol == 4) $rol_nombre = 'Admin';
                ?>
                <span class="rol-badge rol-<?= strtolower($rol_nombre) ?>"><?= $rol_nombre ?></span>
                <div class="user-avatar">
                    <?= strtoupper(substr($_SESSION['usuario'] ?? 'A', 0, 1)) ?>
                </div>
            </div>
        </div>

        <!-- ============================================= -->
        <!-- ESTADÍSTICAS GENERALES -->
        <!-- ============================================= -->
        <div class="stats-container">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                    <div class="stat-label">Total Clientes</div>
                    <div class="stat-number"><?= number_format($total_clientes) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-check-circle" style="color:#10b981;"></i></div>
                    <div class="stat-label">Pagaron</div>
                    <div class="stat-number" style="color:#10b981;"><?= number_format($stats_pago['pagado']) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-clock" style="color:#f59e0b;"></i></div>
                    <div class="stat-label">Pendientes</div>
                    <div class="stat-number" style="color:#f59e0b;"><?= number_format($stats_pago['pendiente']) ?></div>
                </div>

                <!-- TARJETA DEL TOTAL DE PLATA RECAUDADA EN EL MES -->
                <div class="stat-card" style="background: linear-gradient(135deg, #059669 0%, #10b981 100%); color: white;">
                    <div class="stat-icon"><i class="fas fa-wallet" style="color:white; opacity:0.3;"></i></div>
                    <div class="stat-label" style="color:rgba(255,255,255,0.85);">Total Recaudado Mes</div>
                    <div class="stat-number" style="color:white; font-size:1.9rem;">
                        $<?= number_format($cobros_mes['total_recaudado'] ?? 0, 0, ',', '.') ?>
                    </div>
                    <div style="font-size:0.75rem; color:rgba(255,255,255,0.8); margin-top:2px;">
                        <?= number_format($cobros_mes['total_cobros'] ?? 0) ?> cobranzas realizadas
                    </div>
                </div>
            </div>
        </div>

        <!-- Gráfico de Pagos -->
<div class="card">
    <h4><i class="fas fa-chart-pie"></i> Distribución de Pagos</h4>
    <div class="card-body" style="position: relative; width: 100%; max-width: 280px; margin: 0 auto;">
        <canvas id="pagosChart"></canvas>
        
        <!-- TEXTO CENTRADO EN EL MEDIO DEL GRÁFICO -->
        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; pointer-events: none;">
            <span style="font-size: 0.65rem; color: #64748b; font-weight: 600; text-transform: uppercase; display: block;">Recaudado</span>
            <span style="font-size: 1.2rem; font-weight: 800; color: #0f2b3d; display: block; line-height: 1.1;">
                $<?= number_format($cobros_mes['total_recaudado'] ?? 0, 0, ',', '.') ?>
            </span>
            <span style="font-size: 0.7rem; color: #1b4f6e; font-weight: 700; margin-top: 2px; display: block;">
                <?= number_format($total_clientes) ?> Clientes
            </span>
        </div>
    </div>

    <div style="display:flex; justify-content:center; gap:1.5rem; margin-top:1rem; font-size:0.75rem;">
        <span>
            <span style="display:inline-block; width:12px; height:12px; background:#10b981; border-radius:4px;"></span> 
            Pagaron (<?= $stats_pago['pagado'] ?>)
        </span>
        <span>
            <span style="display:inline-block; width:12px; height:12px; background:#f59e0b; border-radius:4px;"></span> 
            Pendientes (<?= $stats_pago['pendiente'] ?>)
        </span>
    </div>
</div>

            <!-- Clientes por Barrio -->
<div class="card">
    <!-- Encabezado con título, botón + al lado, y filtro a la derecha -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; flex-wrap: wrap; gap: 0.5rem;">
        <div style="display: flex; align-items: center; gap: 10px;">
            <h4 style="margin: 0;"><i class="fas fa-map-marker-alt"></i> Clientes por Barrio</h4>
            <!-- Botón + redirige a la lista completa de clientes -->
            <!-- Encabezado de la tarjeta con enlace condicional -->
<a href="<?= $es_cobrador ? 'admin_cliente.php' : 'admin_cliente.php' ?>" id="btnVerMasBarrio" title="Ver listado completo" 
   style="background: #1b4f6e; color: white; width: 24px; height: 24px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; text-decoration: none; font-size: 0.75rem; transition: background 0.2s;">
    <i class="fas fa-plus"></i>
</a>
        </div>

        <!-- Selector para filtrar barrios dinámicamente -->
        <select id="selectBarrioFiltro" onchange="filtrarBarrio(this.value)" style="padding: 4px 8px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 0.8rem; background: white; color: #1e2a41; cursor: pointer;">
            <option value="todos">Todos los Barrios</option>
            <?php foreach ($clientes_por_barrio as $b): ?>
                <option value="<?= $b['id_barrio'] ?>"><?= htmlspecialchars($b['barrio']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- Cuerpo con los barrios y sus primeros 3 o 4 clientes -->
    <div class="card-body">
        <?php if (!empty($clientes_por_barrio)): ?>
            <div id="contenedorBarrios" style="display: flex; flex-direction: column; gap: 0.8rem;">
                <?php foreach ($clientes_por_barrio as $b): ?>
                    <div class="barrio-card-item" data-barrio-id="<?= $b['id_barrio'] ?>" style="background: #f8fafd; border: 1px solid #e2e8f0; border-radius: 10px; padding: 0.75rem;">
                        <!-- Nombre del Barrio y Cantidad Total -->
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.4rem; border-bottom: 1px solid #edf2f7; padding-bottom: 4px;">
                            <span style="font-weight: 700; color: #0f2b3d; font-size: 0.85rem; display: flex; align-items: center; gap: 6px;">
                                <i class="fas fa-map-pin" style="color: #1b4f6e; font-size: 0.8rem;"></i>
                                <?= htmlspecialchars($b['barrio']) ?>
                            </span>
                            <span style="color: #64748b; font-weight: 600; font-size: 0.75rem; background: #e2e8f0; padding: 2px 8px; border-radius: 12px;">
                                <?= $b['cantidad'] ?> clientes
                            </span>
                        </div>
                        
                        <!-- Lista simple de nombres de clientes (Sin estado de pago) -->
                        <div style="display: flex; flex-direction: column; gap: 4px;">
                            <?php foreach ($b['clientes'] as $cli): ?>
                                <div style="display: flex; align-items: center; gap: 6px; font-size: 0.78rem; color: #334155; padding: 2px 0;">
                                    <i class="fas fa-user" style="color: #94a3b8; font-size: 0.7rem;"></i>
                                    <span><?= htmlspecialchars($cli['nombre'] . ' ' . $cli['apellido']) ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-muted text-center" style="padding: 1rem 0;">No hay clientes registrados</p>
        <?php endif; ?>
    </div>
</div>

       <!-- ============================================= -->
<!-- COBROS DEL DÍA Y EXPORTAR A PDF -->
<!-- ============================================= -->
<div class="card" style="margin-top:1.5rem;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; flex-wrap: wrap; gap: 0.5rem;">
        <h4 style="margin:0;"><i class="fas fa-history"></i> Cobros Registrados Hoy (<?= date('d/m/Y') ?>)</h4>
        
        <!-- Botón Exportar PDF -->
        <button onclick="exportarCobrosHoyPDF()" style="background: linear-gradient(135deg, #dc2626, #ef4444); color: white; border: none; padding: 6px 14px; border-radius: 8px; cursor: pointer; font-size: 0.8rem; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 2px 6px rgba(220,38,38,0.25); transition: 0.2s;">
            <i class="fas fa-file-pdf"></i> Exportar PDF
        </button>
    </div>

    <div class="table-wrapper">
        <table id="tablaCobrosHoy">
            <thead>
                <tr>
                    <th>Hora</th>
                    <th>Cliente</th>
                    <th>DNI</th>
                    <th>Monto</th>
                    <th>Método</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($ultimos_cobros)): ?>
                    <?php foreach ($ultimos_cobros as $cobro): ?>
                    <tr>
                        <td><?= date('H:i', strtotime($cobro['fecha_pago'])) ?> hs</td>
                        <td><?= htmlspecialchars($cobro['cliente_nombre'] . ' ' . $cobro['cliente_apellido']) ?></td>
                        <td><?= htmlspecialchars($cobro['dni'] ?? '-') ?></td>
                        <td><strong>$<?= number_format($cobro['monto'], 0, ',', '.') ?></strong></td>
                        <td><span class="badge badge-success"><?= htmlspecialchars($cobro['metodo_pago'] ?? 'Efectivo') ?></span></td>
                        <td>
                            <span class="badge <?= strtolower($cobro['estado_pago']) == 'pagado' ? 'badge-success' : 'badge-warning' ?>">
                                <?= $cobro['estado_pago'] ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-muted text-center" style="padding: 1.5rem 0;">No se han registrado cobros en el día de hoy</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
        <!-- ============================================= -->
        <!-- FOOTER -->
        <!-- ============================================= -->
        <div class="footer">
            <div>© 2026 Chango Vision - Todos los derechos reservados</div>
            <div class="footer-status">
                <span><span class="status-dot"></span> Sistema Activo</span>
                <span><i class="fas fa-user-shield"></i> <?= $rol_nombre ?></span>
                <span id="updateTime"><i class="fas fa-clock"></i> Actualizando...</span>
            </div>
        </div>
    </div>
</div>

<!-- ============================================= -->
<!-- SCRIPTS -->
<!-- ============================================= -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Actualizar hora
    function actualizarHora() {
        const ahora = new Date();
        const fecha = ahora.toLocaleDateString('es-AR');
        const hora = ahora.toLocaleTimeString('es-AR');
        document.getElementById('updateTime').innerHTML = `<i class="fas fa-clock"></i> ${fecha} ${hora}`;
    }
    actualizarHora();
    setInterval(actualizarHora, 30000);

    // Gráfico de Pagos
    const ctx = document.getElementById('pagosChart').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Pagaron', 'Pendientes', 'Suspendidos'],
            datasets: [{
                data: [
                    <?= $stats_pago['pagado'] ?>,
                    <?= $stats_pago['pendiente'] ?>,
                    <?= $stats_pago['suspendido'] ?>
                ],
                backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { display: false }
            },
            cutout: '70%'
        }
    });
});

function filtrarBarrio(idBarrio) {
    const items = document.querySelectorAll('.barrio-card-item');
    const btnMas = document.getElementById('btnVerMasBarrio');
    const urlBase = <?= json_encode($es_cobrador ? 'cobrador_clientes.php' : 'admin_cliente.php') ?>;

    if (idBarrio === 'todos') {
        btnMas.href = urlBase;
    } else {
        btnMas.href = `${urlBase}?barrio=${idBarrio}`;
    }

    items.forEach(item => {
        if (idBarrio === 'todos' || item.getAttribute('data-barrio-id') === idBarrio) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

// Variable global para guardar la instancia del gráfico
let pagosChartInstance = null;

document.addEventListener('DOMContentLoaded', function() {
    const canvas = document.getElementById('pagosChart');
    if (!canvas) return;

    // 1. Destruir gráfico existente si el canvas ya está en uso
    if (pagosChartInstance) {
        pagosChartInstance.destroy();
    }
    const chartExistente = Chart.getChart(canvas);
    if (chartExistente) {
        chartExistente.destroy();
    }

    const ctx = canvas.getContext('2d');
    
    // Obtener los valores de PHP
    const pagado = <?= (int)($stats_pago['pagado'] ?? 0) ?>;
    const pendiente = <?= (int)($stats_pago['pendiente'] ?? 0) ?>;
    const suspendido = <?= (int)($stats_pago['suspendido'] ?? 0) ?>;
    
    // Total de personas consideradas en el gráfico
    const totalEnGrafico = pagado + pendiente + suspendido;

    // 2. Crear y guardar la nueva instancia del gráfico
    pagosChartInstance = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Pagaron', 'Pendientes', 'Suspendidos'],
            datasets: [{
                data: [pagado, pendiente, suspendido],
                backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
                borderWidth: 0,
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            cutout: '72%',
            plugins: {
                legend: { 
                    display: false 
                },
                tooltip: {
                    callbacks: {
                        // Personalización para mostrar Porcentaje + Personas
                        label: function(context) {
                            const cantidad = context.raw || 0;
                            let porcentaje = 0;
                            
                            if (totalEnGrafico > 0) {
                                porcentaje = ((cantidad / totalEnGrafico) * 100).toFixed(1);
                                if (porcentaje.endsWith('.0')) {
                                    porcentaje = Math.round(porcentaje);
                                }
                            }
                            
                            return ` ${context.label}: ${porcentaje}% (${cantidad} personas)`;
                        }
                    }
                }
            }
        }
    });
});

function exportarCobrosHoyPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    const fechaHoy = new Date().toLocaleDateString('es-AR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
    
    const horaImpresion = new Date().toLocaleTimeString('es-AR', {
        hour: '2-digit',
        minute: '2-digit'
    });

    // 1. Encabezado Membretado / Estilizado
    doc.setFillColor(15, 43, 61); // Color de la marca (#0f2b3d)
    doc.rect(0, 0, 210, 28, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('CHANGO VISION', 14, 15);

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text('Reporte Diario de Cobranzas', 14, 22);

    // Fecha y hora a la derecha
    doc.setFontSize(9);
    doc.text(`Fecha: ${fechaHoy}`, 196, 15, { align: 'right' });
    doc.text(`Emitido: ${horaImpresion} hs`, 196, 22, { align: 'right' });

    // 2. Extraer datos de la tabla HTML
    const filasTabla = document.querySelectorAll('#tablaCobrosHoy tbody tr');
    const data = [];
    let totalMonto = 0;
    let cantidadCobros = 0;

    filasTabla.forEach(row => {
        const celdas = row.querySelectorAll('td');
        if (celdas.length >= 6 && !row.querySelector('.text-muted')) {
            const hora = celdas[0].innerText.trim();
            const cliente = celdas[1].innerText.trim();
            const dni = celdas[2].innerText.trim();
            const montoTexto = celdas[3].innerText.trim();
            const metodo = celdas[4].innerText.trim();
            const estado = celdas[5].innerText.trim();

            data.push([hora, cliente, dni, montoTexto, metodo, estado]);

            if (estado.toLowerCase() === 'pagado') {
                const montoLimpio = parseFloat(montoTexto.replace(/[^0-9]/g, '')) || 0;
                totalMonto += montoLimpio;
                cantidadCobros++;
            }
        }
    });

    // 3. Generar la tabla en el PDF usando AutoTable
    if (data.length > 0) {
        doc.autoTable({
            startY: 35,
            head: [['Hora', 'Cliente', 'DNI', 'Monto', 'Método', 'Estado']],
            body: data,
            theme: 'striped',
            headStyles: {
                fillColor: [27, 79, 110], // #1b4f6e
                textColor: [255, 255, 255],
                fontStyle: 'bold',
                fontSize: 9
            },
            bodyStyles: {
                fontSize: 8.5,
                textColor: [30, 42, 65]
            },
            alternateRowStyles: {
                fillColor: [248, 250, 253]
            },
            columnStyles: {
                0: { cellWidth: 20 },
                1: { cellWidth: 65 },
                2: { cellWidth: 30 },
                3: { cellWidth: 30, fontStyle: 'bold' },
                4: { cellWidth: 25 },
                5: { cellWidth: 20 }
            }
        });

        // 4. Resumen Total al final del reporte
        const finalY = doc.lastAutoTable.finalY + 10;

        doc.setFillColor(240, 253, 244); // Fondo verde suave
        doc.setDrawColor(187, 247, 208);
        doc.roundedRect(14, finalY, 182, 18, 3, 3, 'FD');

        doc.setFontSize(10);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(15, 43, 61);
        doc.text(`Total Cobranzas: ${cantidadCobros}`, 20, finalY + 11);

        doc.setFontSize(12);
        doc.setTextColor(16, 185, 129); // Verde éxito
        doc.text(`Total Recaudado Hoy: $${totalMonto.toLocaleString('es-AR')}`, 190, finalY + 11, { align: 'right' });

    } else {
        doc.setFontSize(10);
        doc.setTextColor(100, 116, 139);
        doc.text('No se registraron cobros en la fecha actual.', 14, 45);
    }

    // 5. Pie de página
    const totalPaginas = doc.internal.getNumberOfPages();
    for (let i = 1; i <= totalPaginas; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(148, 163, 184);
        doc.text(`Sistema Chango Visión - Página ${i} de ${totalPaginas}`, 105, 290, { align: 'center' });
    }

    // Descargar directamente el PDF
    doc.save(`Reporte_Cobros_${fechaHoy.replace(/\//g, '-')}.pdf`);
}

</script>

<div class="sidebar-backdrop" id="sidebarBackdrop"></div>
</body>
</html>