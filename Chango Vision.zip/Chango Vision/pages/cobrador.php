<?php
// =============================================
// ACTIVAR ERRORES PARA VER EL PROBLEMA
// =============================================
ini_set('display_errors', 1);
error_reporting(E_ALL);

// =============================================
// SESIÓN
// =============================================
session_start();

// =============================================
// ✅ ROLES PERMITIDOS:
// 1 = Administrador
// 2 = Cobrador
// 4 = Administrador de Red
// =============================================
$id_rol = $_SESSION['id_rol'] ?? 0;
$roles_permitidos = [1, 2, 4];

if (!in_array($id_rol, $roles_permitidos)) {
    header('Location: ../login.php');
    exit;
}

// =============================================
// ✅ VARIABLES DE ROL PARA USAR EN EL CÓDIGO
// =============================================
$es_administrador = ($id_rol == 1);
$es_cobrador = ($id_rol == 2);
$es_admin_red = ($id_rol == 4);

// =============================================
// CONEXIÓN
// =============================================
include __DIR__ . '/../config/conexion.php';

// ✅ VERIFICAR CONEXIÓN
if (!$conexion) {
    die('Error de conexión a BD');
}

// =============================================
// FUNCIÓN PARA ESCAPAR HTML
// =============================================
function escapeHtml($text) {
    if (!$text) return '';
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}

// =============================================
// FUNCIÓN PARA CALCULAR ESTADO DE PAGO
// =============================================
function calcularEstadoPago($fecha_ultimo_pago, $estado_manual = null) {
    if ($estado_manual === 'pagado') {
        return ['estado' => 'pagado', 'dias_mora' => 0];
    }
    
    if (empty($fecha_ultimo_pago)) {
        return ['estado' => 'pendiente', 'dias_mora' => 0];
    }
    
    try {
        $hoy = new DateTime();
        $fecha = new DateTime($fecha_ultimo_pago);
        $diferencia = $hoy->diff($fecha);
        $dias = $diferencia->days;
        
        if ($dias > 30 && $estado_manual !== 'pagado') {
            return ['estado' => 'mora', 'dias_mora' => $dias - 30];
        }
        
        return ['estado' => 'pagado', 'dias_mora' => 0];
    } catch (Exception $e) {
        return ['estado' => 'pendiente', 'dias_mora' => 0];
    }
}

// =============================================
// OBTENER CLIENTES PARA COBRADOR
// =============================================
$hoy = (int)date('d');
$mes_actual = (int)date('m');
$anio_actual = (int)date('Y');

$sql = "SELECT 
            c.id,
            c.nombre,
            c.apellido,
          
            c.estado_pago,
            c.fecha_ultimo_pago,
            ts.nombre as servicio_nombre,
            ts.precio_base as precio,
            ts.dia_corte,
            ts.dia_facturacion,
            (SELECT COUNT(*) FROM pago WHERE id_cliente = c.id) as total_pagos
        FROM cliente c
        LEFT JOIN tipo_servicio ts ON c.id_tipo = ts.id_tipo
        WHERE c.estado = 'Activo'
        ORDER BY c.nombre ASC";

$result = mysqli_query($conexion, $sql);

if (!$result) {
    die('Error en la consulta: ' . mysqli_error($conexion));
}

$clientes = [];
while ($row = mysqli_fetch_assoc($result)) {
    // ✅ 1. SOLO CLIENTES QUE YA PAGARON AL MENOS UNA VEZ
    if ($row['total_pagos'] == 0) {
        continue; // Saltar primer pago
    }
    
    // ✅ 2. VERIFICAR SI YA PAGÓ ESTE MES
    $sql_verificar = "SELECT COUNT(*) as pagado FROM pago 
                      WHERE id_cliente = {$row['id']} 
                      AND mes = $mes_actual 
                      AND anio = $anio_actual";
    $result_verificar = mysqli_query($conexion, $sql_verificar);
    $ya_pago_este_mes = false;
    if ($result_verificar) {
        $row_verificar = mysqli_fetch_assoc($result_verificar);
        if ($row_verificar['pagado'] > 0) {
            $ya_pago_este_mes = true;
        }
    }
    
    // ✅ 3. SI YA PAGÓ ESTE MES, NO APARECE
    if ($ya_pago_este_mes) {
        continue; // Saltar clientes que ya pagaron este mes
    }
    
    // ✅ 4. VERIFICAR SI EL DÍA DE FACTURACIÓN ES HOY O YA PASÓ
    $dia_corte = $row['dia_corte'] ?? 15;
    
    // Si el día de corte es mayor al día actual, NO se muestra (aún no es fecha de cobro)
    if ($dia_corte > $hoy) {
        continue; // Saltar clientes que aún no llega su fecha de cobro
    }
    
    // ✅ EL CLIENTE CUMPLE TODAS LAS CONDICIONES → SE MUESTRA
    $estado_info = calcularEstadoPago($row['fecha_ultimo_pago'], $row['estado_pago']);
    
    $clientes[] = [
        'id' => $row['id'],
        'nombre' => $row['nombre'] . ' ' . $row['apellido'],
        'direccion' => $row['direccion'] ?? 'Sin dirección',
        'servicio_nombre' => $row['servicio_nombre'] ?? 'Sin servicio',
        'precio' => $row['precio'] ?? 0,
        'dia_corte' => $dia_corte,
        'dia_facturacion' => $row['dia_facturacion'] ?? 15,
        'estado' => $estado_info['estado'],
        'dias_mora' => $estado_info['dias_mora'],
        'total_pagos' => $row['total_pagos'],
        'ya_pago_este_mes' => $ya_pago_este_mes
    ];
}

// ✅ ESTADÍSTICAS
$total_clientes = count($clientes);
$pendientes = 0;
$pagados = 0;
$vencen_hoy = 0;

foreach ($clientes as $c) {
    if ($c['estado'] === 'pendiente' || $c['estado'] === 'mora') {
        $pendientes++;
    } else {
        $pagados++;
    }
    
    if ($c['dia_corte'] == $hoy && ($c['estado'] === 'pendiente' || $c['estado'] === 'mora')) {
        $vencen_hoy++;
    }
}

// ✅ TOTAL POR COBRAR
$total_general = 0;
foreach ($clientes as $c) {
    if ($c['estado'] === 'pendiente' || $c['estado'] === 'mora') {
        $total_general += $c['precio'];
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cobrador - Panel de Cobranza | Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background: #f0f2f5; padding: 2rem; color: #1a1a2e; }
        .container { max-width: 1200px; margin: 0 auto; background: white; border-radius: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); overflow: hidden; }
        
        .header { background: linear-gradient(135deg, #0f2b3d 0%, #1b4f6e 100%); color: white; padding: 1.5rem 2rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; }
        .header h1 { font-size: 1.5rem; font-weight: 700; display: flex; align-items: center; gap: 12px; }
        .user-info { display: flex; align-items: center; gap: 15px; background: rgba(255,255,255,0.15); padding: 0.5rem 1rem; border-radius: 40px; }
        .user-avatar { width: 35px; height: 35px; background: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #1b4f6e; font-weight: bold; }
        .btn-volver { background: rgba(255,255,255,0.2); color: white; border: none; padding: 0.5rem 1.2rem; border-radius: 40px; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; font-size: 0.85rem; }
        .btn-volver:hover { background: rgba(255,255,255,0.3); }
        
        .stats-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 1rem;
            padding: 1.5rem 2rem 0 2rem;
        }
        .stat-card {
            background: #f8fafc;
            padding: 1rem 1.2rem;
            border-radius: 16px;
            border-left: 4px solid #1b4f6e;
        }
        .stat-card .label { font-size: 0.65rem; text-transform: uppercase; color: #64748b; font-weight: 600; letter-spacing: 0.5px; }
        .stat-card .value { font-size: 1.6rem; font-weight: 700; color: #0f2b3d; }
        .stat-card .value.success { color: #10b981; }
        .stat-card .value.warning { color: #f59e0b; }
        .stat-card .value.danger { color: #ef4444; }
        
        .buscador-section { background: #f8fafc; padding: 1rem 2rem; border-bottom: 1px solid #e2e8f0; display: flex; gap: 1rem; flex-wrap: wrap; align-items: center; }
        .buscador-box { flex: 1; min-width: 250px; position: relative; }
        .buscador-box label { font-weight: 600; color: #0a2b4e; font-size: 0.75rem; text-transform: uppercase; display: block; margin-bottom: 5px; }
        .buscador-box input { width: 100%; padding: 10px 14px; border: 1.5px solid #cbd5e1; border-radius: 12px; font-size: 0.9rem; background: white; padding-left: 38px; }
        .buscador-box input:focus { outline: none; border-color: #1b4f6e; box-shadow: 0 0 0 3px rgba(27,79,110,0.2); }
        .buscador-icon { position: absolute; left: 12px; bottom: 10px; color: #64748b; }
        .btn-limpiar { background: #e2e8f0; color: #1e293b; border: none; padding: 8px 18px; border-radius: 40px; font-weight: 600; cursor: pointer; margin-top: 22px; font-size: 0.8rem; }
        .btn-limpiar:hover { background: #cbd5e1; }
        
        .resumen-total { background: #f8fafc; margin: 1rem 2rem 0 2rem; padding: 0.8rem 1.5rem; border-radius: 16px; display: flex; justify-content: space-between; align-items: center; border-left: 4px solid #10b981; flex-wrap: wrap; }
        .total-monto { font-size: 1.5rem; font-weight: 700; color: #10b981; background: white; padding: 5px 15px; border-radius: 40px; }
        .resultados-info { color: #475569; font-size: 0.8rem; }
        
        .table-wrapper { overflow-x: auto; padding: 0 1.5rem 1.5rem 1.5rem; }
        .pagos-table { width: 100%; border-collapse: collapse; }
        .pagos-table th { background: #0f2b3d; color: white; padding: 12px 10px; text-align: left; font-weight: 600; font-size: 0.75rem; text-transform: uppercase; }
        .pagos-table td { padding: 12px 10px; border-bottom: 1px solid #e2e8f0; color: #1e293b; font-size: 0.85rem; }
        .pagos-table tr:hover { background: #f8fafc; }
        
        .badge { display: inline-block; padding: 3px 10px; border-radius: 30px; font-size: 0.7rem; font-weight: 600; }
        .badge-pendiente { background: #dbeafe; color: #1e40af; }
        .badge-pagado { background: #d1fae5; color: #065f46; }
        .badge-mora { background: #fee2e2; color: #991b1b; }
        .badge-corte { background: #fef3c7; color: #92400e; }
        .badge-ultimo-dia { background: #fee2e2; color: #991b1b; animation: pulse-badge 1.5s ease-in-out infinite; }
        .badge-tolerancia { background: #fef3c7; color: #92400e; border: 2px solid #f59e0b; }
        
        @keyframes pulse-badge {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        .footer { background: #f1f5f9; padding: 0.8rem 2rem; text-align: center; color: #64748b; font-size: 0.7rem; border-top: 1px solid #e2e8f0; }
        .loading { text-align: center; padding: 40px; color: #94a3b8; }
        
        @keyframes slideIn { from { transform: translateX(100px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        .toast { 
            position: fixed; bottom: 20px; right: 20px; 
            padding: 12px 20px; border-radius: 10px; z-index: 9999; 
            animation: slideIn 0.3s ease; font-size: 0.85rem; 
            display: flex; align-items: center; gap: 8px; 
            color: white; box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            max-width: 400px;
        }
        .toast.success { background: #10b981; }
        .toast.error { background: #ef4444; }
        .toast.warning { background: #f59e0b; }
        
        .btn-pagar {
            padding: 6px 16px;
            border: none;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.75rem;
            transition: all 0.2s;
            cursor: pointer;
            background: #10b981;
            color: white;
        }
        .btn-pagar:hover { background: #059669; transform: scale(1.05); }
        .btn-pagar i { margin-right: 5px; }
        .btn-pagar.pagado { background: #d1fae5; color: #065f46; cursor: default; }
        .btn-pagar.vencido { background: #e2e8f0; color: #94a3b8; cursor: not-allowed; }
        
        @media (max-width: 768px) { 
            body { padding: 1rem; } 
            .buscador-section { flex-direction: column; align-items: stretch; } 
            .btn-limpiar { margin-top: 0; }
            .stats-row { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>
<div class="container">
    <!-- HEADER -->
    <div class="header">
        <h1><i class="fas fa-hand-holding-usd"></i> Panel de Cobrador</h1>
        <div style="display:flex; gap:15px; align-items:center; flex-wrap:wrap;">
            <div class="user-info">
                <i class="fas fa-user-circle"></i>
                <span><?= htmlspecialchars($_SESSION['usuario'] ?? 'Cobrador') ?></span>
                <div class="user-avatar">C</div>
            </div>
            <?php 
            $url_volver = match($_SESSION['id_rol'] ?? 0) {
                1 => 'admin.php',
                2 => 'cobrador_clientes.php',
                3 => 'tecnico.php',
                4 => 'admin_red.php',
                default => 'login.php'
            };
            ?>
            <a href="<?= $url_volver ?>" class="btn-volver">
                <i class="fas fa-arrow-left"></i> Volver
            </a>
        </div>
    </div>

    <!-- ESTADÍSTICAS RÁPIDAS -->
    <div class="stats-row" id="statsRow">
        <div class="stat-card">
            <div class="label">Total Clientes</div>
            <div class="value" id="totalClientes"><?= $total_clientes ?></div>
        </div>
        <div class="stat-card" style="border-color: #f59e0b;">
            <div class="label">Para Cobrar</div>
            <div class="value warning" id="totalPendientes"><?= $pendientes ?></div>
        </div>
        <div class="stat-card" style="border-color: #10b981;">
            <div class="label">Cobrados</div>
            <div class="value success" id="totalCobradosHoy"><?= $pagados ?></div>
        </div>
        <div class="stat-card" style="border-color: #ef4444;">
            <div class="label">Vencen Hoy</div>
            <div class="value danger" id="totalVencenHoy"><?= $vencen_hoy ?></div>
        </div>
    </div>

    <!-- BUSCADOR -->
    <div class="buscador-section">
        <div class="buscador-box">
            <label><i class="fas fa-search"></i> BUSCAR</label>
            <input type="text" id="buscadorInput" placeholder="Nombre o dirección...">
            <span class="buscador-icon"><i class="fas fa-search"></i></span>
        </div>
        <button id="btnLimpiarBusqueda" class="btn-limpiar"><i class="fas fa-times"></i> Limpiar</button>
        <div class="resultados-info" id="resultadosInfo"></div>
    </div>

    <!-- TOTAL POR COBRAR -->
    <?php 
    $total_general = 0;
    foreach ($clientes as $c) {
        if ($c['estado'] === 'pendiente' || $c['estado'] === 'mora') {
            $total_general += $c['precio'];
        }
    }
    ?>
    <div class="resumen-total">
        <span><i class="fas fa-chart-line"></i> TOTAL POR COBRAR</span>
        <span class="total-monto" id="totalGeneral">$<?= number_format($total_general, 0, ',', '.') ?></span>
    </div>

   <div class="table-wrapper">
    <table class="pagos-table">
        <thead>
            <tr>
                <th><i class="fas fa-user"></i> Cliente</th>
                <th><i class="fas fa-tv"></i> Servicio</th>
                <th><i class="fas fa-map-marker-alt"></i> Dirección</th>
                <th><i class="fas fa-calendar-alt"></i> Facturación</th>
                <th><i class="fas fa-credit-card"></i> Estado</th>
                <th><i class="fas fa-dollar-sign"></i> Monto</th>
                <th><i class="fas fa-cog"></i> Acción</th>
            </tr>
        </thead>
        <tbody id="tablaBody">
            <?php if (empty($clientes)): ?>
                <tr><td colspan="7" style="text-align:center; padding:40px;">
                    <i class="fas fa-check-circle" style="font-size:2rem; display:block; color:#10b981; margin-bottom:10px;"></i>
                    ✅ No hay clientes para cobrar hoy
                </td></tr>
            <?php else: ?>
                <?php foreach ($clientes as $c): 
                    $hoy = (int)date('d');
                    $esHoy = ($c['dia_corte'] == $hoy);
                    
                    // Calcular días de mora (si está en mora)
                    $dias_mora = $c['dias_mora'] ?? 0;
                    
                    // Determinar estado visual
                    $estadoTexto = '';
                    $estadoClass = '';
                    $estadoIcono = '';
                    
                    if ($c['estado'] === 'pagado') {
                        $estadoTexto = 'Pagado';
                        $estadoClass = 'badge-pagado';
                        $estadoIcono = 'fa-check-circle';
                    } elseif ($c['estado'] === 'mora') {
                        $estadoTexto = 'En Mora';
                        $estadoClass = 'badge-mora';
                        $estadoIcono = 'fa-exclamation-triangle';
                    } else {
                        $estadoTexto = 'Pendiente';
                        $estadoClass = 'badge-pendiente';
                        $estadoIcono = 'fa-clock';
                    }
                    
                    // Clase para el día de facturación
                    $badgeFacturacionClass = 'badge-corte';
                    $badgeFacturacionTexto = 'Día ' . $c['dia_corte'];
                    if ($esHoy) {
                        $badgeFacturacionClass = 'badge-ultimo-dia';
                        $badgeFacturacionTexto = '¡HOY!';
                    }
                ?>
                <tr>
                    <td><strong><i class="fas fa-user" style="color:#1b4f6e;"></i> <?= escapeHtml($c['nombre']) ?></strong></td>
                    <td>
                        <span class="badge badge-pendiente"><i class="fas fa-wifi"></i> <?= escapeHtml($c['servicio_nombre']) ?></span>
                    </td>
                    <td><i class="fas fa-map-pin" style="color:#64748b;"></i> <?= escapeHtml($c['direccion']) ?></td>
                    <td>
                        <span class="badge <?= $badgeFacturacionClass ?>">
                            <i class="fas fa-calendar-day"></i> <strong><?= $badgeFacturacionTexto ?></strong>
                        </span>
                        <br><small style="font-size:0.6rem; color:#64748b;">Facturación: Día <?= $c['dia_facturacion'] ?></small>
                        <?php if ($c['estado'] === 'mora' && $dias_mora > 0): ?>
                            <br><small style="color:#dc2626; font-weight:600; font-size:0.6rem;">
                                <i class="fas fa-exclamation-triangle"></i> <?= $dias_mora ?> día(s) de mora
                            </small>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge <?= $estadoClass ?>">
                            <i class="fas <?= $estadoIcono ?>"></i> <?= $estadoTexto ?>
                            <?php if ($c['estado'] === 'mora' && $dias_mora > 0): ?>
                                <span style="background:#991b1b; color:white; padding:1px 6px; border-radius:10px; font-size:0.55rem; margin-left:3px;">
                                    <?= $dias_mora ?>d
                                </span>
                            <?php endif; ?>
                        </span>
                        <?php if ($esHoy): ?>
                            <br><small style="color:#991b1b; font-weight:600; font-size:0.6rem;">
                                <i class="fas fa-exclamation-triangle"></i> Vence hoy
                            </small>
                        <?php endif; ?>
                    </td>
                    <td style="font-weight:700; color:#1b4f6e;">
                        <i class="fas fa-dollar-sign"></i> <?= number_format($c['precio'], 0, ',', '.') ?>
                    </td>
                    <td>
                        <?php if ($c['estado'] === 'pagado'): ?>
                            <button class="btn-pagar pagado" disabled>
                                <i class="fas fa-check-circle"></i> Pagado
                            </button>
                        <?php else: ?>
                            <button onclick="registrarPago(<?= $c['id'] ?>, <?= $c['dia_corte'] ?>, <?= $c['precio'] ?>, '<?= escapeHtml($c['nombre']) ?>', '<?= escapeHtml($c['servicio_nombre']) ?>')" 
                                    class="btn-pagar">
                                <i class="fas fa-credit-card"></i> Pagar
                            </button>
                            <?php if ($esHoy): ?>
                                <br><small style="color:#991b1b; font-weight:600; font-size:0.6rem;">
                                    <i class="fas fa-exclamation-triangle"></i> ¡Último día!
                                </small>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
// =============================================
// VARIABLES
// =============================================
let clientesData = <?= json_encode($clientes) ?>;
let filtroTexto = "";

// =============================================
// TOAST NOTIFICACIONES
// =============================================
function mostrarToast(mensaje, tipo) {
    const toast = document.createElement('div');
    toast.className = `toast ${tipo}`;
    const iconos = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle'
    };
    toast.innerHTML = `<i class="fas ${iconos[tipo] || 'fa-info-circle'}"></i> ${mensaje}`;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// =============================================
// REGISTRAR PAGO
// =============================================
async function registrarPago(id, diaCorte, monto, nombre, servicio) {
    const hoy = new Date();
    const mesActual = hoy.getMonth();
    const anioActual = hoy.getFullYear();
    const fechaTolerancia = new Date(anioActual, mesActual, diaCorte + 1);
    
    // Verificar si está dentro del día de corte + 1 (tolerancia)
    if (hoy > fechaTolerancia) {
        mostrarToast('❌ Este servicio ya venció. No se puede pagar.', 'error');
        return;
    }
    
    if (!confirm(`¿Confirmar pago de $${monto.toLocaleString()} para ${nombre} - ${servicio}?`)) {
        return;
    }
    
    try {
        const response = await fetch('../controllers/actualizar_estado_cobrador.php', {
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                id: id, 
                estado: 'pagado'
            })
        });
        
        const text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch(e) {
            console.error('Respuesta no es JSON:', text);
            mostrarToast('Error: El servidor no devolvió una respuesta válida', 'error');
            return;
        }
        
        if (data.success) {
            let mensaje = `✅ Pago registrado: ${nombre} - ${servicio} ($${monto.toLocaleString()})`;
            if (data.primer_pago) {
                mensaje += ' 🔔 Se notificó al técnico para la conexión.';
            }
            mostrarToast(mensaje, 'success');
            // Recargar la página para actualizar los datos
            setTimeout(() => location.reload(), 1500);
        } else {
            mostrarToast(data.error || 'Error al registrar pago', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        mostrarToast('Error de conexión', 'error');
    }
}

// =============================================
// FILTRAR Y RENDERIZAR
// =============================================
function getClientesFiltrados() {
    if (!filtroTexto.trim()) return clientesData;
    const termino = filtroTexto.trim().toLowerCase();
    return clientesData.filter(c => 
        c.nombre?.toLowerCase().includes(termino) || 
        c.direccion?.toLowerCase().includes(termino)
    );
}

function renderizarTabla() {
    const filtrados = getClientesFiltrados();
    const tablaBody = document.getElementById('tablaBody');
    const hoy = new Date().getDate();
    
    const info = document.getElementById('resultadosInfo');
    if (clientesData.length === 0) {
        info.innerHTML = '<i class="fas fa-check-circle" style="color:#10b981;"></i> No hay clientes para cobrar';
    } else {
        info.innerHTML = `<i class="fas fa-users"></i> ${filtrados.length} de ${clientesData.length} clientes para cobrar`;
    }
    
    if (clientesData.length === 0) { 
        tablaBody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:40px;">
            <i class="fas fa-check-circle" style="font-size:2rem; display:block; color:#10b981; margin-bottom:10px;"></i>
            ¡Todos los clientes están al día!
        </td></tr>`; 
        return; 
    }
    
    if (filtrados.length === 0) { 
        tablaBody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding:40px;"><i class="fas fa-search" style="font-size:2rem; display:block; color:#cbd5e1; margin-bottom:10px;"></i>No se encontraron resultados</td></tr>'; 
        return; 
    }

    let html = '';
    filtrados.forEach(c => {
        const enTolerancia = (hoy > c.dia_corte && hoy <= c.dia_corte + 1);
        const esHoy = (c.dia_corte === hoy);
        
        let badgeCorteClass = 'badge-corte';
        let badgeCorteIcono = 'fa-calendar-times';
        let badgeCorteTexto = `Día ${c.dia_corte}`;
        
        if (esHoy && (c.estado === 'pendiente' || c.estado === 'mora')) {
            badgeCorteClass = 'badge-ultimo-dia';
            badgeCorteIcono = 'fa-exclamation-circle';
            badgeCorteTexto = '¡HOY!';
        } else if (enTolerancia && (c.estado === 'pendiente' || c.estado === 'mora')) {
            badgeCorteClass = 'badge-tolerancia';
            badgeCorteIcono = 'fa-clock';
            badgeCorteTexto = 'Último día';
        }
        
        let estadoTexto = '';
        let estadoClass = '';
        let estadoIcono = '';
        
        if (c.estado === 'pagado') {
            estadoTexto = 'Pagado';
            estadoClass = 'badge-pagado';
            estadoIcono = 'fa-check-circle';
        } else if (c.estado === 'mora') {
            estadoTexto = 'En Mora';
            estadoClass = 'badge-mora';
            estadoIcono = 'fa-exclamation-triangle';
        } else {
            estadoTexto = 'Pendiente';
            estadoClass = 'badge-pendiente';
            estadoIcono = 'fa-clock';
        }
        
        let btnClass = (c.estado === 'pagado') ? 'pagado' : '';
        let btnText = (c.estado === 'pagado') ? 'Pagado' : 'Pagar';
        let btnIcon = (c.estado === 'pagado') ? 'fa-check-circle' : 'fa-credit-card';
        let btnDisabled = (c.estado === 'pagado') ? 'disabled' : '';
        
        html += `<tr>
            <td><strong><i class="fas fa-user" style="color:#1b4f6e;"></i> ${escapeHtml(c.nombre)}</strong></td>
            <td>
                <span class="badge badge-pendiente"><i class="fas fa-wifi"></i> ${escapeHtml(c.servicio_nombre)}</span>
            </td>
            <td><i class="fas fa-map-pin" style="color:#64748b;"></i> ${escapeHtml(c.direccion)}</td>
            <td>
                <span class="badge ${badgeCorteClass}">
                    <i class="fas ${badgeCorteIcono}"></i> <strong>${badgeCorteTexto}</strong>
                </span>
                <br><small style="font-size:0.6rem; color:#64748b;"><i class="fas fa-calendar-day"></i> Facturación: Día ${c.dia_facturacion}</small>
                ${enTolerancia && c.estado !== 'pagado' ? '<br><small style="color:#f59e0b; font-weight:600; font-size:0.6rem;"><i class="fas fa-exclamation-triangle"></i> Tolerancia (corte + 1)</small>' : ''}
            </td>
            <td>
                <span class="badge ${estadoClass}">
                    <i class="fas ${estadoIcono}"></i> ${estadoTexto}
                    ${c.estado === 'mora' && c.dias_mora > 0 ? `<span style="background:#991b1b; color:white; padding:1px 6px; border-radius:10px; font-size:0.55rem; margin-left:3px;">${c.dias_mora}d</span>` : ''}
                </span>
            </td>
            <td style="font-weight:700; color:#1b4f6e;"><i class="fas fa-dollar-sign"></i> ${(c.precio || 0).toLocaleString()}</td>
            <td>
                ${c.estado === 'pagado' 
                    ? `<button class="btn-pagar pagado" disabled><i class="fas fa-check-circle"></i> Pagado</button>`
                    : `<button onclick="registrarPago(${c.id}, ${c.dia_corte}, ${c.precio || 0}, '${escapeHtml(c.nombre)}', '${escapeHtml(c.servicio_nombre)}')" class="btn-pagar"><i class="fas fa-credit-card"></i> Pagar</button>`
                }
                ${esHoy && c.estado !== 'pagado' ? '<br><small style="color:#991b1b; font-weight:600; font-size:0.6rem;"><i class="fas fa-exclamation-triangle"></i> Vence hoy</small>' : ''}
            </td>
        </tr>`;
    });
    tablaBody.innerHTML = html;
}

// =============================================
// ESCAPE HTML
// =============================================
function escapeHtml(text) { 
    if (!text) return ''; 
    const div = document.createElement('div'); 
    div.textContent = text; 
    return div.innerHTML; 
}

// =============================================
// EVENT LISTENERS
// =============================================
document.getElementById('buscadorInput').addEventListener('input', (e) => { 
    filtroTexto = e.target.value; 
    renderizarTabla(); 
});

document.getElementById('btnLimpiarBusqueda').addEventListener('click', () => { 
    document.getElementById('buscadorInput').value = ''; 
    filtroTexto = ''; 
    renderizarTabla(); 
});

// =============================================
// INICIALIZAR
// =============================================
renderizarTabla();
</script>
</body>
</html>