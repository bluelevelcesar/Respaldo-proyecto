<?php
require_once __DIR__ . '/../config/conexion.php';
session_start();

$token = $_GET['token'] ?? '';

if (empty($token)) {
    header('Location: ../login.php');
    exit;
}

// =============================================
// DETERMINAR EL PROPÓSITO DEL TOKEN
// =============================================
// Verificar si el token existe y obtener información del usuario
$sql = "SELECT id_usuario, usuario, nombre, contrasena 
        FROM usuario 
        WHERE reset_token = ? 
        AND reset_expira > NOW()";

$stmt = $conexion->prepare($sql);

if (!$stmt) {
    die("Error SQL: " . $conexion->error);
}

$stmt->bind_param("s", $token);
$stmt->execute();

$resultado = $stmt->get_result();
$usuario = $resultado->fetch_assoc();

if (!$usuario) {
    die("❌ Enlace inválido o expirado. Solicita un nuevo enlace.");
}

// =============================================
// ✅ DETERMINAR SI ES "CREAR" O "RESTABLECER"
// =============================================
// Si el usuario NO tiene contraseña (NULL o vacío) → Es CREAR
// Si el usuario YA tiene contraseña → Es RESTABLECER
$es_creacion = empty($usuario['contrasena']);
$titulo = $es_creacion ? "Crear tu Contraseña" : "Restablecer Contraseña";
$subtitulo = $es_creacion 
    ? "Hola <strong>{$usuario['usuario']}</strong>, crea tu contraseña para acceder al sistema." 
    : "Hola <strong>{$usuario['usuario']}</strong>, ingresa tu nueva contraseña.";
$boton_texto = $es_creacion ? "Crear Contraseña" : "Actualizar Contraseña";
$icono = $es_creacion ? "fa-user-plus" : "fa-key";

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $confirmar = $_POST['confirmar_password'] ?? '';

    if (strlen($password) < 4) {
        $error = "La contraseña debe tener al menos 4 caracteres";
    } elseif ($password !== $confirmar) {
        $error = "Las contraseñas no coinciden";
    } else {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $sql = "UPDATE usuario 
                SET contrasena = ?, 
                    reset_token = NULL, 
                    reset_expira = NULL 
                WHERE id_usuario = ?";

        $stmt = $conexion->prepare($sql);

        if (!$stmt) {
            die("Error SQL: " . $conexion->error);
        }

        $stmt->bind_param("si", $password_hash, $usuario['id_usuario']);
        $stmt->execute();
        $success = true;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $titulo ?> - Chango Vision</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0f2b3d 0%, #1b4f6e 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .reset-container {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .reset-container h2 {
            color: #1b4f6e;
            margin-bottom: 0.5rem;
            text-align: center;
        }

        .reset-container .icon-title {
            text-align: center;
            font-size: 2.5rem;
            color: #1b4f6e;
            margin-bottom: 0.5rem;
        }

        .reset-container p {
            text-align: center;
            margin-bottom: 1rem;
            color: #333;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }

        .form-group input {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 0.9rem;
            transition: 0.2s;
        }

        .form-group input:focus {
            outline: none;
            border-color: #1b4f6e;
            box-shadow: 0 0 0 3px rgba(27,79,110,0.1);
        }

        .btn-reset {
            background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
            color: white;
            width: 100%;
            padding: 0.8rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            transition: 0.2s;
            margin-top: 0.5rem;
        }

        .btn-reset:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }

        .message {
            margin-top: 1rem;
            margin-bottom: 1rem;
            padding: 0.8rem;
            border-radius: 8px;
            text-align: center;
            font-size: 0.85rem;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .btn-login {
            display: block;
            text-align: center;
            margin-top: 1rem;
            color: #1b4f6e;
            text-decoration: none;
            font-weight: 600;
        }

        .btn-login:hover {
            text-decoration: underline;
        }

        .badge-tipo {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            margin-bottom: 1rem;
            text-align: center;
            width: 100%;
        }

        .badge-crear {
            background: #dbeafe;
            color: #1e40af;
        }

        .badge-restablecer {
            background: #fef3c7;
            color: #92400e;
        }
    </style>
</head>

<body>
    <div class="reset-container">
        <div class="icon-title">
            <i class="fas <?= $icono ?>"></i>
        </div>

        <h2><?= $titulo ?></h2>

        <?php if ($es_creacion): ?>
            <div class="badge-tipo badge-crear">
                <i class="fas fa-user-plus"></i> Creación de cuenta
            </div>
        <?php else: ?>
            <div class="badge-tipo badge-restablecer">
                <i class="fas fa-undo-alt"></i> Restablecimiento de contraseña
            </div>
        <?php endif; ?>

        <?php if ($success === true): ?>
            <div class="message success">
                ✅ Contraseña <?= $es_creacion ? 'creada' : 'actualizada' ?> correctamente.<br>
                Redirigiendo al login...
            </div>

            <script>
                setTimeout(function() {
                    window.location.href = '../login.php';
                }, 3000);
            </script>

        <?php else: ?>

            <p><?= $subtitulo ?></p>

            <?php if (!empty($error)): ?>
                <div class="message error">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label>Nueva contraseña</label>
                    <input 
                        type="password" 
                        name="password" 
                        required 
                        minlength="4"
                        placeholder="Mínimo 4 caracteres"
                    >
                </div>

                <div class="form-group">
                    <label>Confirmar contraseña</label>
                    <input 
                        type="password" 
                        name="confirmar_password" 
                        required
                        placeholder="Repite tu contraseña"
                    >
                </div>

                <button type="submit" class="btn-reset">
                    <i class="fas fa-save"></i> <?= $boton_texto ?>
                </button>
            </form>

            <a href="../login.php" class="btn-login">
                <i class="fas fa-arrow-left"></i> Volver al inicio de sesión
            </a>

        <?php endif; ?>
    </div>
</body>
</html>