<?php
// =============================================
// soporte_tecnico.php - MÓDULO DE SOPORTE TÉCNICO
// =============================================
session_start();
// Verificar que el usuario esté logueado
if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../login.php');
    exit;
}
// =============================================
// ✅ ROLES PERMITIDOS:
// 1 = Administrador (Clientes)
// 2 = Cobrador
// 3 = Técnico
// 4 = Administrador de Red
// =============================================
$id_rol = $_SESSION['id_rol'] ?? 0;
$roles_permitidos = [1, 2, 3, 4];
if (!in_array($id_rol, $roles_permitidos)) {
    header('Location: ../login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';
include __DIR__ . '/../controllers/funcion_log.php';
$log = new SistemaLog($conexion);

$id_usuario = $_SESSION['id_usuario'];
$nombre_usuario = $_SESSION['usuario'] ?? 'Usuario';

// =============================================
// ✅ DETERMINAR ROLES ESPECÍFICOS
// =============================================
$es_tecnico = ($id_rol == 3);
$es_admin_red = ($id_rol == 4);
$es_admin = ($id_rol == 1); // Admin de clientes
$es_cobrador = ($id_rol == 2);

// Solo Técnico (3) y Admin de Red (4) pueden cambiar el estado de la tarea
$puede_cambiar_estado = ($es_tecnico || $es_admin_red);
// Solo Admin de Clientes (1) y Admin de Red (4) pueden editar/eliminar de manera general
$es_admin_general = ($es_admin || $es_admin_red);

// =============================================
// ✅ DETERMINAR URL DE RETORNO SEGÚN ROL
// =============================================
$url_volver = match($id_rol) {
    1 => 'admin.php',
    2 => 'cobrador_clientes.php',
    3 => 'tecnico.php',
    4 => 'admin_red.php',
    default => 'login.php'
};

// =============================================
// PROCESAR ACCIONES POST
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';

// =============================================
// CREAR SOLICITUD (COBRADORES Y ADMINS)
// =============================================
// =============================================
// CREAR SOLICITUD (COBRADORES Y ADMINS)
// =============================================
if ($accion === 'crear_solicitud') {
    if ($es_tecnico) {
        $_SESSION['mensaje'] = "Acceso denegado: Los técnicos no pueden crear nuevas tareas.";
        $_SESSION['mensaje_tipo'] = "error";
        header("Location: soporte_tecnico.php");
        exit;
    }

    $cliente_id = intval($_POST['cliente_id'] ?? 0);
    $descripcion_ingresada = trim($_POST['descripcion'] ?? '');
    $prioridad = $_POST['prioridad'] ?? 'media';
    
    // Capturar GPS si se envió desde el formulario
    $ubicacion_url = trim($_POST['ubicacion_url'] ?? '');
    if (empty($ubicacion_url)) {
        $ubicacion_url = null;
    }

    if (empty($descripcion_ingresada) || $cliente_id <= 0) {
        $_SESSION['mensaje'] = "Complete todos los campos obligatorios";
        $_SESSION['mensaje_tipo'] = "error";
        header("Location: soporte_tecnico.php");
        exit;
    }

    $descripcion = $descripcion_ingresada;
    $titulo = "Reclamo"; 

    // ✅ Agregamos creador_id a la consulta SQL
    $sql = "INSERT INTO soporte (cliente_id, tecnico_id, creador_id, titulo, descripcion, prioridad, estado, ubicacion_url)
            VALUES (?, NULL, ?, ?, ?, ?, 'pendiente', ?)";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "iissss", $cliente_id, $id_usuario, $titulo, $descripcion, $prioridad, $ubicacion_url);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['mensaje'] = "Reclamo guardado correctamente.";
        $_SESSION['mensaje_tipo'] = "success";
    } else {
        $_SESSION['mensaje'] = "Error al guardar el reclamo: " . mysqli_error($conexion);
        $_SESSION['mensaje_tipo'] = "error";
    }
    mysqli_stmt_close($stmt);
    header("Location: soporte_tecnico.php");
    exit;
}

    // =============================================
    // EDITAR SOLICITUD (SOLO ADMINS)
    // =============================================
    if ($accion === 'editar_solicitud' && ($es_admin_general || $es_cobrador)) {
        $id_soporte = intval($_POST['id_soporte']);
        $cliente_id = intval($_POST['cliente_id'] ?? 0);
        $descripcion = trim($_POST['descripcion'] ?? '');
        $prioridad = $_POST['prioridad'] ?? 'media';

        if (empty($descripcion) || $cliente_id <= 0) {
            $_SESSION['mensaje'] = "Complete todos los campos obligatorios";
            $_SESSION['mensaje_tipo'] = "error";
            header("Location: soporte_tecnico.php");
            exit;
        }

        $sql_update = "UPDATE soporte SET cliente_id = ?, descripcion = ?, prioridad = ? WHERE id_soporte = ?";
        $stmt = mysqli_prepare($conexion, $sql_update);
        mysqli_stmt_bind_param($stmt, "issi", $cliente_id, $descripcion, $prioridad, $id_soporte);

        if (mysqli_stmt_execute($stmt)) {
            $log->registrarAccion(
                $_SESSION['id_usuario'],
                $_SESSION['usuario'] ?? 'Administrador',
                'Editar Solicitud',
                "Solicitud ID: $id_soporte",
                "Cliente: $cliente_id, Prioridad: $prioridad",
                'info'
            );
            $_SESSION['mensaje'] = "Solicitud editada correctamente";
            $_SESSION['mensaje_tipo'] = "success";
        } else {
            $_SESSION['mensaje'] = "Error al editar solicitud: " . mysqli_error($conexion);
            $_SESSION['mensaje_tipo'] = "error";
        }
        mysqli_stmt_close($stmt);
        header("Location: soporte_tecnico.php");
        exit;
    }

    // =============================================
    // CAMBIAR ESTADO (SOLO TÉCNICOS Y ADMIN RED)
    // =============================================
    if ($accion === 'cambiar_estado') {
        if (!$puede_cambiar_estado) {
            $_SESSION['mensaje'] = "Acceso denegado: No tienes permisos para cambiar el estado.";
            $_SESSION['mensaje_tipo'] = "error";
            header("Location: soporte_tecnico.php");
            exit;
        }

        $id_soporte = intval($_POST['id_soporte']);
        $nuevo_estado = $_POST['nuevo_estado'] ?? '';
        $comentario = trim($_POST['comentario'] ?? '');

        // ✅ Estados válidos: solo resuelto y cerrado (se quitó en_progreso)
        $estados_validos = ['resuelto', 'cerrado'];
        if (!in_array($nuevo_estado, $estados_validos)) {
            $_SESSION['mensaje'] = "Estado inválido";
            $_SESSION['mensaje_tipo'] = "error";
            header("Location: soporte_tecnico.php");
            exit;
        }

        $sql_update = "UPDATE soporte SET estado = ?, comentario = ?, tecnico_id = ? WHERE id_soporte = ?";
        $stmt = mysqli_prepare($conexion, $sql_update);
        mysqli_stmt_bind_param($stmt, "ssii", $nuevo_estado, $comentario, $id_usuario, $id_soporte);

        if (mysqli_stmt_execute($stmt)) {
            if ($nuevo_estado === 'resuelto') {
                $sql_fecha = "UPDATE soporte SET fecha_resolucion = CURDATE() WHERE id_soporte = ?";
                $stmt_fecha = mysqli_prepare($conexion, $sql_fecha);
                mysqli_stmt_bind_param($stmt_fecha, "i", $id_soporte);
                mysqli_stmt_execute($stmt_fecha);
                mysqli_stmt_close($stmt_fecha);
            }

            $log->registrarAccion(
                $_SESSION['id_usuario'],
                $_SESSION['usuario'] ?? 'Usuario',
                'Cambiar Estado Solicitud',
                "Solicitud ID: $id_soporte → $nuevo_estado",
                $comentario ? "Comentario: $comentario" : '',
                'info'
            );
            $_SESSION['mensaje'] = "Estado actualizado correctamente";
            $_SESSION['mensaje_tipo'] = "success";
        } else {
            $_SESSION['mensaje'] = "Error al actualizar estado: " . mysqli_error($conexion);
            $_SESSION['mensaje_tipo'] = "error";
        }
        mysqli_stmt_close($stmt);
        header("Location: soporte_tecnico.php");
        exit;
    }

    // =============================================
    // ELIMINAR SOLICITUD (SOLO ADMINS)
    // =============================================
   if ($accion === 'eliminar_solicitud' && ($es_admin_general || $es_cobrador)) {
        $id_soporte = intval($_POST['id_soporte']);

        $sql_delete = "DELETE FROM soporte WHERE id_soporte = ?";
        $stmt = mysqli_prepare($conexion, $sql_delete);
        mysqli_stmt_bind_param($stmt, "i", $id_soporte);

        if (mysqli_stmt_execute($stmt)) {
            $log->registrarAccion(
                $_SESSION['id_usuario'],
                $_SESSION['usuario'] ?? 'Administrador',
                'Eliminar Solicitud',
                "Solicitud ID: $id_soporte",
                'Solicitud eliminada del sistema',
                'warning'
            );
            $_SESSION['mensaje'] = "Solicitud eliminada correctamente";
            $_SESSION['mensaje_tipo'] = "success";
        } else {
            $_SESSION['mensaje'] = "Error al eliminar solicitud: " . mysqli_error($conexion);
            $_SESSION['mensaje_tipo'] = "error";
        }
        mysqli_stmt_close($stmt);
        header("Location: soporte_tecnico.php");
        exit;
    }
}

$mensaje = $_SESSION['mensaje'] ?? '';
$mensaje_tipo = $_SESSION['mensaje_tipo'] ?? '';
unset($_SESSION['mensaje'], $_SESSION['mensaje_tipo']);

// =============================================
// ESTADÍSTICAS (SOLO LAS 4 SOLICITADAS)
// =============================================
// 1. Pendientes (todas)
$sql_pendientes = "SELECT COUNT(*) as total FROM soporte WHERE estado IN ('pendiente', 'cerrado')";
$result_pendientes = mysqli_query($conexion, $sql_pendientes);
$total_pendientes = mysqli_fetch_assoc($result_pendientes)['total'] ?? 0;

// 2. Domicilio Cerrado (solo los del día actual)
$sql_cerrados_hoy = "SELECT COUNT(*) as total FROM soporte WHERE estado = 'cerrado' AND DATE(fecha_creacion) = CURDATE()";
$result_cerrados_hoy = mysqli_query($conexion, $sql_cerrados_hoy);
$total_cerrados_hoy = mysqli_fetch_assoc($result_cerrados_hoy)['total'] ?? 0;

// 3. Resueltos (solo los del día actual)
$sql_resueltos_hoy = "SELECT COUNT(*) as total FROM soporte WHERE estado = 'resuelto' AND DATE(fecha_resolucion) = CURDATE()";
$result_resueltos_hoy = mysqli_query($conexion, $sql_resueltos_hoy);
$total_resueltos_hoy = mysqli_fetch_assoc($result_resueltos_hoy)['total'] ?? 0;

// 4. Prioridad Alta (todas, activas)
$sql_prioridad_alta = "SELECT COUNT(*) as total FROM soporte WHERE prioridad = 'alta' AND estado != 'resuelto' AND estado != 'cerrado'";
$result_prioridad_alta = mysqli_query($conexion, $sql_prioridad_alta);
$total_prioridad_alta = mysqli_fetch_assoc($result_prioridad_alta)['total'] ?? 0;

// =============================================
// CAPTURAR FILTROS DESDE GET
// =============================================
$filtro_estado = $_GET['estado'] ?? 'todos';
$filtro_prioridad = $_GET['prioridad'] ?? 'todas';
$filtro_barrio = $_GET['barrio'] ?? 'todos';

$where_clauses = [];
$params = [];
$types = "";

// =============================================
// RESTRICCIÓN PARA COBRADORES:
// El cobrador ve las tareas que él creó O las que tienen GPS asignado
// =============================================
if ($es_cobrador) {
    $where_clauses[] = "(s.creador_id = " . intval($id_usuario) . " OR (s.ubicacion_url IS NOT NULL AND s.ubicacion_url != ''))";
}
// Para el Técnico ($es_tecnico) y Admins ($es_admin), NO se aplica la restricción anterior,
// por lo tanto, ellos podrán ver tanto las tareas del cobrador como las del admin.

if ($filtro_estado !== 'todos') {
    $where_clauses[] = "s.estado = ?";
    $params[] = $filtro_estado;
    $types .= "s";
} else {
    $where_clauses[] = "s.estado != 'resuelto'";
}

if ($filtro_prioridad !== 'todas') {
    $where_clauses[] = "s.prioridad = ?";
    $params[] = $filtro_prioridad;
    $types .= "s";
}

if ($filtro_barrio !== 'todos') {
    $where_clauses[] = "b.nombre = ?";
    $params[] = $filtro_barrio;
    $types .= "s";
}

$where_sql = count($where_clauses) > 0 ? "WHERE " . implode(" AND ", $where_clauses) : "";

// =============================================
// CONFIGURACIÓN DE PAGINACIÓN CON FILTROS
// =============================================
$por_pagina = 5;
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;
$inicio = ($pagina_actual - 1) * $por_pagina;

// Obtener el total de registros filtrados
$sql_total = "SELECT COUNT(*) as total 
              FROM soporte s
              LEFT JOIN cliente c ON s.cliente_id = c.id
              LEFT JOIN barrio b ON c.id_barrio = b.id_barrio 
              $where_sql";
$stmt_total = mysqli_prepare($conexion, $sql_total);
if (!empty($params)) {
    mysqli_stmt_bind_param($stmt_total, $types, ...$params);
}
mysqli_stmt_execute($stmt_total);
$result_total = mysqli_stmt_get_result($stmt_total);
$fila_total = mysqli_fetch_assoc($result_total);
$total_registros = $fila_total['total'] ?? 0;
$total_paginas = ceil($total_registros / $por_pagina);
mysqli_stmt_close($stmt_total);

// =============================================
// OBTENER SOLICITUDES FILTRADAS CON LIMIT Y OFFSET
// =============================================
$sql_solicitudes = "SELECT s.*,
        c.nombre as cliente_nombre,
        c.apellido as cliente_apellido,
        c.telefono as cliente_telefono,
        b.nombre as cliente_barrio
    FROM soporte s
    LEFT JOIN cliente c ON s.cliente_id = c.id
    LEFT JOIN barrio b ON c.id_barrio = b.id_barrio
    $where_sql
    ORDER BY
        CASE s.prioridad
            WHEN 'alta' THEN 1
            WHEN 'media' THEN 2
            WHEN 'baja' THEN 3
        END,
        s.fecha_creacion DESC
    LIMIT ? OFFSET ?";

$stmt_solicitudes = mysqli_prepare($conexion, $sql_solicitudes);
$all_params = $params;
$all_params[] = $por_pagina;
$all_params[] = $inicio;
$all_types = $types . "ii";

if (!empty($all_types)) {
    mysqli_stmt_bind_param($stmt_solicitudes, $all_types, ...$all_params);
}
mysqli_stmt_execute($stmt_solicitudes);
$result_solicitudes = mysqli_stmt_get_result($stmt_solicitudes);
$solicitudes = mysqli_fetch_all($result_solicitudes, MYSQLI_ASSOC);
mysqli_stmt_close($stmt_solicitudes);

// Obtener listado completo de barrios para el select de la tabla
$sql_barrios_totales = "SELECT DISTINCT b.nombre FROM barrio b INNER JOIN cliente c ON c.id_barrio = b.id_barrio WHERE b.nombre IS NOT NULL ORDER BY b.nombre";
$result_barrios_totales = mysqli_query($conexion, $sql_barrios_totales);
$barrios_unicos = [];
while ($row_b = mysqli_fetch_assoc($result_barrios_totales)) {
    $barrios_unicos[] = $row_b['nombre'];
}

$sql_clientes = "SELECT c.id, c.nombre, c.apellido, c.telefono, b.nombre as barrio
    FROM cliente c
    LEFT JOIN barrio b ON c.id_barrio = b.id_barrio
    WHERE c.estado = 'Activo'
    ORDER BY c.nombre";
$result_clientes = mysqli_query($conexion, $sql_clientes);
$clientes = mysqli_fetch_all($result_clientes, MYSQLI_ASSOC);

// Función auxiliar para mantener los parámetros en los links de paginación
function generarUrlPagina($num_pagina) {
    $params_url = $_GET;
    $params_url['pagina'] = $num_pagina;
    return '?' . http_build_query($params_url);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Soporte Técnico - Chango Vision</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Inter', sans-serif; background: #f0f4f8; padding: 2rem; }
.container {
    max-width: 1200px;
    margin: 0 auto;
    background: white;
    border-radius: 24px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    overflow: hidden;
}
.header {
    background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
    color: white;
    padding: 1.5rem 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 1rem;
}
.header h1 { font-size: 1.3rem; display: flex; align-items: center; gap: 10px; }
.btn-volver {
    background: rgba(255,255,255,0.2);
    border: 1px solid rgba(255,255,255,0.3);
    padding: 0.5rem 1.2rem;
    border-radius: 40px;
    font-weight: 500;
    color: white;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 0.85rem;
}
.btn-volver:hover { background: rgba(255,255,255,0.3); }
.btn-crear {
    background: white;
    border: none;
    padding: 0.5rem 1.2rem;
    border-radius: 40px;
    font-weight: 600;
    color: #1b4f6e;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: 0.3s;
    font-size: 0.85rem;
}
.btn-crear:hover { background: #e6f7ff; transform: scale(0.97); }
.stats-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 1rem;
    padding: 1.5rem 2rem 0.5rem 2rem;
}
.stat-card {
    background: #f8fafc;
    padding: 1rem 1.2rem;
    border-radius: 12px;
    text-align: center;
    border: 1px solid #e9eef3;
}
.stat-card .number {
    font-size: 1.5rem;
    font-weight: 700;
    color: #0f2b3d;
}
.stat-card .number.success { color: #10b981; }
.stat-card .number.warning { color: #f59e0b; }
.stat-card .number.danger { color: #ef4444; }
.stat-card .number.info { color: #3b82f6; }
.stat-card .label {
    font-size: 0.65rem;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
    margin-top: 2px;
}
.table-wrapper { padding: 1rem 2rem 2rem 2rem; overflow-x: auto; }
.section-title {
    font-weight: 700;
    font-size: 1rem;
    color: #1e2a41;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 0.5rem;
}
.filter-group { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
.filter-select {
    padding: 5px 12px;
    border-radius: 20px;
    border: 1.5px solid #dce5ec;
    font-size: 0.75rem;
    background: white;
    cursor: pointer;
}
.filter-select:focus { outline: none; border-color: #1b4f6e; }
.solicitudes-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.8rem;
}
.solicitudes-table th {
    text-align: left;
    padding: 0.6rem 0.6rem;
    background: #f8fafd;
    font-weight: 600;
    color: #1e2a41;
    font-size: 0.6rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e2e8f0;
}
.solicitudes-table td {
    padding: 0.6rem;
    border-bottom: 1px solid #edf2f7;
    color: #1f2b48;
    vertical-align: middle;
}
.solicitudes-table tr:hover td { background: #f8fafc; }
.badge-barrio {
    font-size: 0.7rem;
    color: #1b4f6e;
    background: #e8f4fd;
    padding: 3px 10px;
    border-radius: 12px;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}
.badge-estado {
    padding: 2px 10px;
    border-radius: 20px;
    font-size: 0.6rem;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}
.badge-estado.pendiente { background: #fef3c7; color: #92400e; }
.badge-estado.progreso { background: #dbeafe; color: #1e40af; }
.badge-estado.resuelto { background: #d1fae5; color: #065f46; }
.badge-estado.cerrado { background: #e2e8f0; color: #475569; }
.badge-prioridad {
    padding: 1px 8px;
    border-radius: 10px;
    font-size: 0.55rem;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}
.badge-prioridad.alta { background: #fee2e2; color: #991b1b; }
.badge-prioridad.media { background: #fef3c7; color: #92400e; }
.badge-prioridad.baja { background: #e0e7ff; color: #3730a3; }
.empty-state { text-align: center; padding: 2rem; color: #94a3b8; }
.empty-state i { font-size: 2rem; display: block; margin-bottom: 0.5rem; color: #cbd5e1; }
.btn-accion {
    padding: 4px 8px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 0.65rem;
    font-weight: 600;
    transition: 0.3s;
    margin: 2px;
}
.btn-accion.estado { background: #1b4f6e; color: white; }
.btn-accion.estado:hover { background: #0f2b3d; }
.btn-accion.editar { background: #f59e0b; color: white; }
.btn-accion.editar:hover { background: #d97706; }
.btn-accion.eliminar { background: #ef4444; color: white; }
.btn-accion.eliminar:hover { background: #dc2626; }

/* ESTILOS DE PAGINACIÓN */
.pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 6px;
    margin-top: 1.5rem;
}
.pagination a, .pagination span {
    padding: 6px 12px;
    border-radius: 8px;
    font-size: 0.75rem;
    font-weight: 600;
    text-decoration: none;
    border: 1px solid #dce5ec;
    color: #1b4f6e;
    background: white;
    transition: 0.2s;
}
.pagination a:hover {
    background: #1b4f6e;
    color: white;
    border-color: #1b4f6e;
}
.pagination .active {
    background: #1b4f6e;
    color: white;
    border-color: #1b4f6e;
}
.pagination .disabled {
    color: #94a3b8;
    background: #f8fafc;
    border-color: #e9eef3;
    cursor: not-allowed;
}

.modal-overlay {
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(0,0,0,0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
    visibility: hidden;
    opacity: 0;
    transition: 0.2s;
}
.modal-overlay.active { visibility: visible; opacity: 1; }
.modal-container {
    background: white;
    width: 95%;
    max-width: 550px;
    border-radius: 20px;
    overflow: hidden;
    max-height: 90vh;
    overflow-y: auto;
}
.modal-header {
    background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
    color: white;
    padding: 1rem 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.modal-header h3 { font-size: 1rem; display: flex; align-items: center; gap: 8px; }
.close-modal { background: none; border: none; font-size: 1.5rem; cursor: pointer; color: white; transition: 0.3s; }
.close-modal:hover { transform: scale(1.1); }
.modal-body { padding: 1.5rem; }
.form-group { margin-bottom: 1rem; }
.form-group label { display: block; font-size: 0.7rem; font-weight: 700; color: #1b4f6e; margin-bottom: 4px; }
.form-group label .obligatorio { color: #ef4444; }
.form-group input, .form-group select, .form-group textarea {
    width: 100%;
    padding: 0.6rem;
    border: 1.5px solid #dce5ec;
    border-radius: 10px;
    font-size: 0.85rem;
    font-family: 'Inter', sans-serif;
}
.form-group input:focus, .form-group select:focus, .form-group textarea:focus {
    outline: none;
    border-color: #1b4f6e;
    box-shadow: 0 0 0 3px rgba(27,79,110,0.1);
}
.form-group textarea { resize: vertical; min-height: 80px; }
.btn-submit {
    background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
    color: white;
    width: 100%;
    padding: 0.7rem;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    font-weight: 600;
    transition: 0.3s;
    font-size: 0.9rem;
}
.toast-message {
    position: fixed;
    top: 20px; right: 20px;
    padding: 10px 18px;
    border-radius: 10px;
    color: white;
    z-index: 2000;
    display: flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}
.toast-success { background: #10b981; }
.toast-error { background: #ef4444; }
.cliente-search-wrapper { position: relative; }
.cliente-dropdown {
    position: absolute;
    top: 100%; left: 0; right: 0;
    background: white;
    border: 1.5px solid #dce5ec;
    border-top: none;
    border-radius: 0 0 10px 10px;
    max-height: 200px;
    overflow-y: auto;
    z-index: 10;
    display: none;
}
.cliente-dropdown.show { display: block; }
.cliente-dropdown-item { padding: 0.6rem 0.8rem; cursor: pointer; border-bottom: 1px solid #f0f4f8; }
.cliente-dropdown-item:hover { background: #f0f7ff; }
.cliente-dropdown-item .nombre { font-weight: 600; color: #0f2b3d; font-size: 0.85rem; }
.cliente-dropdown-item .telefono { font-size: 0.7rem; color: #94a3b8; }
.cliente-selected {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 0.6rem;
    background: #f0fdf4;
    border: 1.5px solid #bbf7d0;
    border-radius: 10px;
    margin-top: 4px;
}
.cliente-selected .info { flex: 1; }
.cliente-selected .info .nombre { font-weight: 600; color: #065f46; }
.cliente-selected .btn-remove { background: none; border: none; color: #ef4444; cursor: pointer; font-size: 1.2rem; }
.btn-ver-detalle {
    padding: 4px 10px; border: none; border-radius: 6px; cursor: pointer; font-size: 0.65rem; font-weight: 600; background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white;
}

.barrio-search-wrapper { position: relative; }
.barrio-dropdown {
    position: absolute;
    top: 100%; left: 0; right: 0;
    background: white;
    border: 1.5px solid #dce5ec;
    border-radius: 0 0 10px 10px;
    max-height: 180px;
    overflow-y: auto;
    z-index: 100;
    display: none;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}
.barrio-dropdown.show { display: block; }
.barrio-dropdown-item {
    padding: 0.5rem 0.8rem;
    cursor: pointer;
    font-size: 0.75rem;
    border-bottom: 1px solid #f0f4f8;
    color: #1b4f6e;
}
.barrio-dropdown-item:hover { background: #f0f7ff; }
.barrio-dropdown-item.selected { background: #e8f4fd; font-weight: 600; }

</style>
</head>
<body>
<div class="container">
    <div class="header">
            <?php if ($id_rol == 2): ?>

        <h1><i class="fas fa-headset"></i> Reclamos</h1>
    <?php endif; ?>

     <?php if ($id_rol == 1 || $id_rol == 4): ?>

        <h1><i class="fas fa-headset"></i> Soporte Técnico</h1>
    <?php endif; ?>

        <div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap;">
            <?php if (!$es_tecnico): ?>
            <button class="btn-crear" onclick="abrirModal('modalCrear')">
                <i class="fas fa-plus"></i> Nuevo Reclamo
            </button>
            <?php endif; ?>
            <a href="<?= $url_volver ?>" class="btn-volver">
                <i class="fas fa-arrow-left"></i> Volver
            </a>
        </div>
    </div>

    <?php if ($mensaje): ?>
    <div class="toast-message toast-<?= $mensaje_tipo === 'success' ? 'success' : 'error' ?>">
        <i class="fas <?= $mensaje_tipo === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle' ?>"></i>
        <?= $mensaje ?>
    </div>
    <script>setTimeout(() => { document.querySelector('.toast-message')?.remove(); }, 4000);</script>
    <?php endif; ?>

    <!-- ESTADÍSTICAS (OCULTAS PARA COBRADOR) -->
<?php if (!$es_cobrador): ?>
<div class="stats-row">
    <div class="stat-card">
        <div class="number warning"><?= $total_pendientes ?></div>
        <div class="label"><i class="fas fa-clock" style="color:#f59e0b;"></i> Pendientes</div>
    </div>
    <div class="stat-card">
        <div class="number info"><?= $total_cerrados_hoy ?></div>
        <div class="label"><i class="fas fa-lock" style="color:#3b82f6;"></i> Domicilio Cerrado (Hoy)</div>
    </div>
    <div class="stat-card">
        <div class="number success"><?= $total_resueltos_hoy ?></div>
        <div class="label"><i class="fas fa-check-circle" style="color:#10b981;"></i> Resueltos (Hoy)</div>
    </div>
    <div class="stat-card">
        <div class="number danger"><?= $total_prioridad_alta ?></div>
        <div class="label"><i class="fas fa-triangle-exclamation" style="color:#ef4444;"></i> Prioridad Alta</div>
    </div>
</div>
<?php endif; ?>

    <div class="table-wrapper">
        <div class="section-title">
            <span><i class="fas fa-list"></i> Tareas de Soporte (Total encontrados: <?= $total_registros ?>)</span>
            <div class="filter-group">
               <select id="filterEstado" class="filter-select" onchange="filtrarTabla()">
    <option value="todos" <?= $filtro_estado === 'todos' ? 'selected' : '' ?>>Todos (activos)</option>
    <option value="pendiente" <?= $filtro_estado === 'pendiente' ? 'selected' : '' ?>>Pendientes</option>
    <option value="cerrado" <?= $filtro_estado === 'cerrado' ? 'selected' : '' ?>>Domicilio Cerrado</option>
    <option value="resuelto" <?= $filtro_estado === 'resuelto' ? 'selected' : '' ?>>Resueltos</option>
</select>
                <select id="filterPrioridad" class="filter-select" onchange="filtrarTabla()">
                    <option value="todas" <?= $filtro_prioridad === 'todas' ? 'selected' : '' ?>>Todas las prioridades</option>
                    <option value="alta" <?= $filtro_prioridad === 'alta' ? 'selected' : '' ?>>Alta</option>
                    <option value="media" <?= $filtro_prioridad === 'media' ? 'selected' : '' ?>>Media</option>
                    <option value="baja" <?= $filtro_prioridad === 'baja' ? 'selected' : '' ?>>Baja</option>
                </select>
            </div>
        </div>

        <?php if (empty($solicitudes)): ?>
            <div class="empty-state">
                <i class="fas fa-check-circle" style="color:#10b981;"></i>
                <p>No hay solicitudes registradas con los filtros seleccionados</p>
            </div>
        <?php else: ?>
        <table class="solicitudes-table" id="solicitudesTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Cliente</th>
                    <th style="position:relative;">
    BARRIO
    <div class="barrio-search-wrapper" style="margin-top:4px;">
        <input type="text" id="filterBarrioInput" class="filter-select" 
               style="width:100%; padding:5px 10px;" 
               placeholder="Escribir barrio..." 
               autocomplete="off"
               value="<?= htmlspecialchars($filtro_barrio !== 'todos' ? $filtro_barrio : '') ?>">
        <div class="barrio-dropdown" id="barrioDropdown"></div>
    </div>
</th>
                    <th>Descripción</th>
                    <th>Prioridad</th>
                    <th>Estado</th>
                    <th>Fecha</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($solicitudes as $s):
                $estado_clases = ['pendiente' => 'pendiente', 'en_progreso' => 'progreso', 'resuelto' => 'resuelto', 'cerrado' => 'cerrado'];
                $prioridad_clases = ['alta' => 'alta', 'media' => 'media', 'baja' => 'baja'];
                $estados = ['pendiente' => 'Pendiente', 'en_progreso' => 'Visita a Domicilio', 'resuelto' => 'Resuelto', 'cerrado' => 'Domicilio Cerrado'];
                $prioridad_iconos = [
                    'alta'  => '<i class="fas fa-circle-exclamation"></i>',
                    'media' => '<i class="fas fa-circle"></i>',
                    'baja'  => '<i class="fas fa-circle-check"></i>'
                ];
                $barrio_actual = $s['cliente_barrio'] ?? 'Sin barrio';
            ?>
                <tr>
                    <td>#<?= $s['id_soporte'] ?></td>
                    <td>
                        <strong><?= htmlspecialchars($s['cliente_nombre'] ?? 'Cliente') ?> <?= htmlspecialchars($s['cliente_apellido'] ?? '') ?></strong>
                        <br>
                        <small style="font-size:0.65rem; color:#94a3b8;"><i class="fas fa-phone"></i> <?= htmlspecialchars($s['cliente_telefono'] ?? '-') ?></small>
                    </td>
                    <td><span class="badge-barrio"><i class="fas fa-map-pin"></i> <?= htmlspecialchars($barrio_actual) ?></span></td>
                    <td><?= htmlspecialchars(substr($s['descripcion'] ?? '', 0, 60)) ?></td>
                    <td>
                        <span class="badge-prioridad <?= $prioridad_clases[$s['prioridad']] ?? 'baja' ?>">
                            <?= $prioridad_iconos[$s['prioridad']] ?? '' ?> <?= ucfirst($s['prioridad'] ?? 'Baja') ?>
                        </span>
                    </td>
                    <td>
                        <span class="badge-estado <?= $estado_clases[$s['estado']] ?? 'pendiente' ?>">
                            <?= $estados[$s['estado']] ?? 'Pendiente' ?>
                        </span>
                    </td>
                    <td><?= date('d/m/Y', strtotime($s['fecha_creacion'])) ?></td>
                    <td style="white-space:nowrap;">
                        <button class="btn-ver-detalle" onclick="verDetalle(<?= $s['id_soporte'] ?>)" title="Ver detalles">
                            <i class="fas fa-eye"></i>
                        </button>
                        
                        <?php if ($puede_cambiar_estado): ?>
                        <button class="btn-accion estado" onclick="abrirModalEstado(<?= $s['id_soporte'] ?>, '<?= $s['estado'] ?>')" title="Cambiar Estado">
                            <i class="fas fa-sync-alt"></i> Estado
                        </button>
                        <?php endif; ?>

                        <?php 
$puede_editar_eliminar_tarea = $es_admin_general || $es_cobrador;
?>

<!-- Reemplazar el bloque if ($es_admin_general) por este: -->
<?php if ($puede_editar_eliminar_tarea): ?>
    <button class="btn-accion editar" onclick="abrirModalEditar(<?= $s['id_soporte'] ?>, <?= $s['cliente_id'] ?>, '<?= addslashes($s['descripcion']) ?>', '<?= $s['prioridad'] ?>')" title="Editar">
        <i class="fas fa-pen"></i>
    </button>
    <button class="btn-accion eliminar" onclick="eliminarSolicitud(<?= $s['id_soporte'] ?>)" title="Eliminar">
        <i class="fas fa-trash"></i>
    </button>
<?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <!-- CONTROLES DE PAGINACIÓN -->
        <?php if ($total_paginas > 1): ?>
        <div class="pagination">
            <?php if ($pagina_actual > 1): ?>
                <a href="<?= generarUrlPagina(1) ?>"><i class="fas fa-angle-double-left"></i></a>
                <a href="<?= generarUrlPagina($pagina_actual - 1) ?>"><i class="fas fa-angle-left"></i> Anterior</a>
            <?php else: ?>
                <span class="disabled"><i class="fas fa-angle-double-left"></i></span>
                <span class="disabled"><i class="fas fa-angle-left"></i> Anterior</span>
            <?php endif; ?>

            <?php 
            $inicio_range = max(1, $pagina_actual - 2);$fin_range = min($total_paginas,$pagina_actual + 2);
            for ($i = $inicio_range; $i <= $fin_range; $i++): 
            ?>
                <?php if ($i ==$pagina_actual): ?>
                    <span class="active"><?= $i ?></span>
                <?php else: ?>
                    <a href="<?= generarUrlPagina($i) ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>

            <?php if ($pagina_actual <$total_paginas): ?>
                <a href="<?= generarUrlPagina($pagina_actual + 1) ?>">Siguiente <i class="fas fa-angle-right"></i></a>
                <a href="<?= generarUrlPagina($total_paginas) ?>"><i class="fas fa-angle-double-right"></i></a>
            <?php else: ?>
                <span class="disabled">Siguiente <i class="fas fa-angle-right"></i></span>
                <span class="disabled"><i class="fas fa-angle-double-right"></i></span>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php endif; ?>
    </div>
</div>

<!-- MODAL CREAR TAREA / RECLAMO -->
<?php if (!$es_tecnico): ?>
<div id="modalCrear" class="modal-overlay">
    <div class="modal-container">
        <div class="modal-header">
            <h3>
                <i class="fas fa-plus"></i> 
                <?php 
                    // Evaluar según el rol de la sesión
                    if (isset($_SESSION['id_rol']) && $_SESSION['id_rol'] == 2) {
                        echo "Nuevo Reclamo";
                    } else {
                        echo "Nueva Tarea";
                    }
                ?>
            </h3>
            <button class="close-modal" onclick="cerrarModal('modalCrear')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST" action="">
                <input type="hidden" name="accion" value="crear_solicitud">
                <input type="hidden" name="cliente_id" id="clienteIdCrear" value="">
                <div class="form-group">
                    <label>Buscar Cliente <span class="obligatorio">*</span></label>
                    <div class="cliente-search-wrapper">
                        <input type="text" id="clienteSearchCrear" placeholder="Escribe para buscar un cliente..." autocomplete="off">
                        <div class="cliente-dropdown" id="clienteDropdownCrear"></div>
                    </div>
                    <div id="clienteSelectedCrear" style="display:none;" class="cliente-selected">
                        <div class="info"><span class="nombre" id="clienteNombreCrear"></span></div>
                        <button type="button" class="btn-remove" onclick="clearCliente('Crear')">&times;</button>
                    </div>
                </div>

                <!-- CAMPO EXCLUSIVO PARA COBRADORES -->
<?php if ($es_cobrador): ?>
<div class="form-group">
    <label><i class="fas fa-map-marker-alt" style="color:#1b4f6e;"></i> Ubicación (Google Maps)</label>
    <div style="display: flex; gap: 8px;">
        <input type="url" name="ubicacion_url" id="ubicacionUrlInput" placeholder="https://www.google.com/maps?q=..." style="flex: 1;">
        <button type="button" id="btnObtenerUbicacion" onclick="obtenerUbicacionCobrador()" class="btn-accion" style="background:#1b4f6e; color:white; padding:0 12px; border-radius:10px; font-size:0.75rem; display:inline-flex; align-items:center; gap:6px; white-space:nowrap; cursor:pointer;">
            <i class="fas fa-crosshairs"></i> Obtener GPS
        </button>
    </div>
    <small id="statusUbicacion" style="display:block; font-size:0.65rem; margin-top:4px; color:#64748b;"></small>
</div>
<?php endif; ?>

                <div class="form-group">
                    <label>Descripción <span class="obligatorio">*</span></label>
                    <textarea name="descripcion" required></textarea>
                </div>
                <div class="form-group">
                    <label>Prioridad <span class="obligatorio">*</span></label>
                    <select name="prioridad" required>
                        <option value="baja">Baja</option>
                        <option value="media" selected>Media</option>
                        <option value="alta">Alta</option>
                    </select>
                </div>
                <button type="submit" class="btn-submit"><i class="fas fa-save"></i> Crear Tarea</button>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- MODAL EDITAR TAREA -->
<!-- MODAL EDITAR TAREA -->
<?php if ($es_admin_general || $es_cobrador): ?>
<div id="modalEditar" class="modal-overlay">
    <div class="modal-container">
        <div class="modal-header">
            <h3><i class="fas fa-pen"></i> Editar Tarea</h3>
            <button class="close-modal" onclick="cerrarModal('modalEditar')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST" action="">
                <input type="hidden" name="accion" value="editar_solicitud">
                <input type="hidden" name="id_soporte" id="idSoporteEditar">
                <input type="hidden" name="cliente_id" id="clienteIdEditar" value="">
                <div class="form-group">
                    <label>Buscar Cliente <span class="obligatorio">*</span></label>
                    <div class="cliente-search-wrapper">
                        <input type="text" id="clienteSearchEditar" placeholder="Escribe para buscar..." autocomplete="off">
                        <div class="cliente-dropdown" id="clienteDropdownEditar"></div>
                    </div>
                    <div id="clienteSelectedEditar" style="display:none;" class="cliente-selected">
                        <div class="info"><span class="nombre" id="clienteNombreEditar"></span></div>
                        <button type="button" class="btn-remove" onclick="clearCliente('Editar')">&times;</button>
                    </div>
                </div>
                <div class="form-group">
                    <label>Descripción <span class="obligatorio">*</span></label>
                    <textarea name="descripcion" id="descripcionEditar" required></textarea>
                </div>
                <div class="form-group">
                    <label>Prioridad <span class="obligatorio">*</span></label>
                    <select name="prioridad" id="prioridadEditar" required>
                        <option value="baja">Baja</option>
                        <option value="media">Media</option>
                        <option value="alta">Alta</option>
                    </select>
                </div>
                <button type="submit" class="btn-submit"><i class="fas fa-save"></i> Guardar Cambios</button>
            </form>
        </div>
    </div>
</div>
<form id="formEliminar" method="POST" style="display:none;">
    <input type="hidden" name="accion" value="eliminar_solicitud">
    <input type="hidden" name="id_soporte" id="idSoporteEliminar">
</form>
<?php endif; ?>

<!-- MODAL CAMBIAR ESTADO (SOLO RESUELTO Y CERRADO) -->
<div id="modalEstado" class="modal-overlay">
    <div class="modal-container">
        <div class="modal-header">
            <h3><i class="fas fa-sync-alt"></i> Cambiar Estado</h3>
            <button class="close-modal" onclick="cerrarModal('modalEstado')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST" action="">
                <input type="hidden" name="accion" value="cambiar_estado">
                <input type="hidden" name="id_soporte" id="idSoporteEstado">
                <div class="form-group">
                    <label>Nuevo Estado <span class="obligatorio">*</span></label>
                    <select name="nuevo_estado" id="nuevoEstado" required>
                        <option value="resuelto">Resuelto</option>
                        <option value="cerrado">Domicilio Cerrado</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Comentario / Avance</label>
                    <textarea name="comentario" placeholder="Agrega un comentario sobre el avance..."></textarea>
                </div>
                <button type="submit" class="btn-submit"><i class="fas fa-save"></i> Actualizar Estado</button>
            </form>
        </div>
    </div>
</div>

<!-- MODAL VER DETALLES (DISEÑO MEJORADO) -->
<div id="modalDetalle" class="modal-overlay">
    <div class="modal-container" style="max-width: 700px;">
        <div class="modal-header" style="background: linear-gradient(135deg, #0f2b3d, #1b4f6e);">
            <h3><i class="fas fa-clipboard-list"></i> Detalles de la Tarea</h3>
            <button class="close-modal" onclick="cerrarModal('modalDetalle')">&times;</button>
        </div>
        <div class="modal-body" id="detalleContenido">
            <div style="text-align:center; padding:2rem; color:#94a3b8;">
                <i class="fas fa-spinner fa-spin" style="font-size:2rem;"></i>
                <p>Cargando detalles...</p>
            </div>
        </div>
    </div>
</div>

<script>
const clientes = <?= json_encode($clientes) ?>;

function initClienteSearch(suffix) {
    const searchInput = document.getElementById('clienteSearch' + suffix);
    const dropdown = document.getElementById('clienteDropdown' + suffix);
    if (!searchInput) return;

    searchInput.addEventListener('focus', () => filterClientes(suffix));
    searchInput.addEventListener('input', () => filterClientes(suffix));

    document.addEventListener('click', function(e) {
        if (!searchInput.closest('.cliente-search-wrapper').contains(e.target)) {
            dropdown.classList.remove('show');
        }
    });

    window.filterClientes = function(suf) {
        const input = document.getElementById('clienteSearch' + suf);
        const drop = document.getElementById('clienteDropdown' + suf);
        const term = input.value.toLowerCase().trim();
        let filtered = term ? clientes.filter(c => c.nombre.toLowerCase().includes(term) || c.apellido.toLowerCase().includes(term)) : clientes;
        
        drop.innerHTML = filtered.length === 0 ? '<div class="cliente-dropdown-item">No encontrado</div>' : 
            filtered.slice(0, 10).map(c => `
                <div class="cliente-dropdown-item" onclick="selectCliente('${suf}', ${c.id}, '${c.nombre} ${c.apellido}')">
                    <div class="nombre">${c.nombre} ${c.apellido}</div>
                </div>
            `).join('');
        drop.classList.add('show');
    };

    window.selectCliente = function(suf, id, nombre) {
        document.getElementById('clienteId' + suf).value = id;
        document.getElementById('clienteNombre' + suf).textContent = nombre;
        document.getElementById('clienteSelected' + suf).style.display = 'flex';
        document.getElementById('clienteDropdown' + suf).classList.remove('show');
    };

    window.clearCliente = function(suf) {
        document.getElementById('clienteId' + suf).value = '';
        document.getElementById('clienteSelected' + suf).style.display = 'none';
    };
}

<?php if (!$es_tecnico): ?> initClienteSearch('Crear'); <?php endif; ?>
<?php if ($es_admin_general || $es_cobrador): ?> initClienteSearch('Editar'); <?php endif; ?>
function abrirModal(id) { document.getElementById(id).classList.add('active'); }
function cerrarModal(id) { document.getElementById(id).classList.remove('active'); }
function abrirModalEstado(id, estadoActual) {
    document.getElementById('modalEstado').classList.add('active');
    document.getElementById('idSoporteEstado').value = id;
    // Si el estado actual es 'en_progreso' o 'pendiente', preseleccionar 'resuelto'
    document.getElementById('nuevoEstado').value = (estadoActual === 'pendiente' || estadoActual === 'en_progreso') ? 'resuelto' : estadoActual;
}

<?php if ($es_admin_general || $es_cobrador): ?>
function abrirModalEditar(id, clienteId, descripcion, prioridad) {
    document.getElementById('modalEditar').classList.add('active');
    document.getElementById('idSoporteEditar').value = id;
    document.getElementById('descripcionEditar').value = descripcion;
    document.getElementById('prioridadEditar').value = prioridad;
    const cliente = clientes.find(c => c.id === clienteId);
    if (cliente) {
        document.getElementById('clienteIdEditar').value = clienteId;
        document.getElementById('clienteNombreEditar').textContent = cliente.nombre + ' ' + cliente.apellido;
        document.getElementById('clienteSelectedEditar').style.display = 'flex';
    }
}
function eliminarSolicitud(id) {
    if (confirm('¿Estás seguro de eliminar esta solicitud?')) {
        document.getElementById('idSoporteEliminar').value = id;
        document.getElementById('formEliminar').submit();
    }
}
<?php endif; ?>

function verDetalle(id) {
    document.getElementById('modalDetalle').classList.add('active');
    document.getElementById('detalleContenido').innerHTML = `
        <div style="text-align:center; padding:2rem; color:#94a3b8;">
            <i class="fas fa-spinner fa-spin" style="font-size:2rem;"></i>
            <p>Cargando detalles...</p>
        </div>
    `;

    fetch(`../controllers/get_soporte_detalle.php?id=${id}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                const d = data.data;
                const estadoClases = { 'pendiente': 'pendiente', 'en_progreso': 'progreso', 'resuelto': 'resuelto', 'cerrado': 'cerrado' };
                const estados = { 'pendiente': 'Pendiente', 'en_progreso': 'Visita a Domicilio', 'resuelto': 'Resuelto', 'cerrado': 'Domicilio Cerrado' };
                const prioridadColores = { 'alta': '#dc2626', 'media': '#f59e0b', 'baja': '#22c55e' };
                const prioridadIconos = { 'alta': 'fa-circle-exclamation', 'media': 'fa-circle', 'baja': 'fa-circle-check' };

                document.getElementById('detalleContenido').innerHTML = `
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:1.2rem; margin-bottom:1.5rem;">
                        
                        <!-- 1. CÓDIGO DE CLIENTE Y FECHA DE CREACIÓN -->
                        <div class="detalle-item">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-id-card" style="color:#1b4f6e;"></i> Código de Cliente
                            </label>
                            <p style="font-weight:700; color:#0f2b3d; font-size:1rem;">${d.codigo_cliente || 'N/A'}</p>
                        </div>

                        <div class="detalle-item">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-calendar" style="color:#1b4f6e;"></i> Fecha de Creación
                            </label>
                            <p style="font-weight:600; color:#0f2b3d; font-size:0.95rem;">${d.fecha_creacion || '-'}</p>
                        </div>

                        <!-- 2. DATOS DEL CLIENTE, BARRIO, PRIORIDAD, ESTADO, UBICACIÓN -->
                        <div class="detalle-item" style="grid-column: span 2;">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-user" style="color:#1b4f6e;"></i> Nombre del Cliente
                            </label>
                            <p style="font-weight:700; color:#0f2b3d; font-size:1rem;">${d.cliente_nombre || 'No asignado'} ${d.cliente_apellido || ''}</p>
                            <span style="font-size:0.75rem; color:#94a3b8;">
                                <i class="fas fa-phone"></i> ${d.cliente_telefono || 'Sin teléfono'}
                            </span>
                        </div>

                        <div class="detalle-item">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-map-pin" style="color:#1b4f6e;"></i> Barrio
                            </label>
                            <span style="font-size:0.8rem; color:#1b4f6e; background:#e8f4fd; padding:3px 10px; border-radius:12px; font-weight:600; display:inline-block;">
                                ${d.cliente_barrio || 'Sin barrio'}
                            </span>
                        </div>

                        <div class="detalle-item">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-flag" style="color:#1b4f6e;"></i> Prioridad
                            </label>
                            <span style="display:inline-flex; align-items:center; gap:6px; padding:4px 12px; border-radius:20px; background:${prioridadColores[d.prioridad] || '#94a3b8'}20; color:${prioridadColores[d.prioridad] || '#94a3b8'}; font-weight:600; font-size:0.8rem;">
                                <i class="fas ${prioridadIconos[d.prioridad] || 'fa-circle'}"></i>
                                ${d.prioridad ? d.prioridad.charAt(0).toUpperCase() + d.prioridad.slice(1) : 'Media'}
                            </span>
                        </div>

                        <div class="detalle-item">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-circle" style="color:#1b4f6e;"></i> Estado
                            </label>
                            <span class="badge-estado ${estadoClases[d.estado] || 'pendiente'}" style="display:inline-flex; align-items:center; gap:6px;">
                                <i class="fas ${d.estado === 'resuelto' ? 'fa-check-circle' : (d.estado === 'en_progreso' ? 'fa-spinner fa-spin' : (d.estado === 'cerrado' ? 'fa-lock' : 'fa-clock'))}"></i>
                                ${estados[d.estado] || 'Pendiente'}
                            </span>
                        </div>

                        <div class="detalle-item">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-map-marked-alt" style="color:#1b4f6e;"></i> Ubicación
                            </label>
                            ${d.ubicacion_url ? `
                                <a href="${d.ubicacion_url}" target="_blank" style="display:inline-flex; align-items:center; gap:8px; color:#1b4f6e; text-decoration:none; font-weight:600; font-size:0.85rem; background:#e8f4fd; padding:6px 12px; border-radius:10px; border:1px solid #b2d8f8;">
                                    <i class="fas fa-external-link-alt" style="color:#10b981;"></i> Ver en Maps
                                </a>
                            ` : '<span style="font-size:0.8rem; color:#94a3b8;">Sin ubicación asignada</span>'}
                        </div>

                    </div>

                    <!-- 3. DESCRIPCIÓN AL FINAL -->
                    <div style="border-top: 1.5px solid #e9eef3; padding-top: 1.2rem;">
                        <div class="detalle-item">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:6px;">
                                <i class="fas fa-align-left" style="color:#1b4f6e;"></i> Descripción
                            </label>
                            <p style="color:#1f2b48; font-size:0.9rem; line-height:1.6; background:#f8fafd; padding:1rem; border-radius:10px; border:1px solid #e9eef3;">
                                ${d.descripcion || 'Sin descripción'}
                            </p>
                        </div>

                        ${d.comentario ? `
                        <div class="detalle-item" style="margin-top:1rem;">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-comment" style="color:#1b4f6e;"></i> Comentario Técnico
                            </label>
                            <p style="color:#1f2b48; font-size:0.85rem; background:#fef3c7; padding:0.8rem 1rem; border-radius:10px; border:1px solid #fde68a;">
                                ${d.comentario}
                            </p>
                        </div>
                        ` : ''}
                    </div>
                `;
            } else {
                document.getElementById('detalleContenido').innerHTML = `
                    <div style="text-align:center; padding:2rem; color:#ef4444;">
                        <i class="fas fa-exclamation-triangle" style="font-size:2rem;"></i>
                        <p>${data.message || 'Error al cargar los detalles'}</p>
                    </div>
                `;
            }
        })
        .catch(error => {
            document.getElementById('detalleContenido').innerHTML = `
                <div style="text-align:center; padding:2rem; color:#ef4444;">
                    <i class="fas fa-circle-exclamation" style="font-size:2rem;"></i>
                    <p>Error al cargar los detalles</p>
                </div>
            `;
            console.error('Error:', error);
        });
}

// =============================================
// BUSCADOR DE BARRIOS CON AUTOCOMPLETADO
// =============================================
const barriosDisponibles = <?= json_encode($barrios_unicos) ?>;

(function initBarrioSearch() {
    const input = document.getElementById('filterBarrioInput');
    const dropdown = document.getElementById('barrioDropdown');
    if (!input || !dropdown) return;

    function renderDropdown(term) {
        const t = term.toLowerCase().trim();
        const filtrados = t 
            ? barriosDisponibles.filter(b => b.toLowerCase().includes(t))
            : barriosDisponibles;

        if (filtrados.length === 0) {
            dropdown.innerHTML = '<div class="barrio-dropdown-item" style="color:#94a3b8;">Sin resultados</div>';
        } else {
            dropdown.innerHTML = filtrados.map(b => 
                `<div class="barrio-dropdown-item" data-barrio="${b}">
                    <i class="fas fa-map-pin" style="color:#1b4f6e; margin-right:6px;"></i>${b}
                </div>`
            ).join('');
        }
        dropdown.classList.add('show');
    }

    input.addEventListener('focus', () => renderDropdown(input.value));
    input.addEventListener('input', () => renderDropdown(input.value));

    // Seleccionar barrio al hacer clic
    dropdown.addEventListener('click', (e) => {
        const item = e.target.closest('.barrio-dropdown-item');
        if (!item || !item.dataset.barrio) return;
        input.value = item.dataset.barrio;
        dropdown.classList.remove('show');
        filtrarTabla(); // Aplica el filtro automáticamente
    });

    // Cerrar al hacer clic fuera
    document.addEventListener('click', (e) => {
        if (!input.closest('.barrio-search-wrapper').contains(e.target)) {
            dropdown.classList.remove('show');
        }
    });

    // Enter aplica el filtro con lo que esté escrito
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            dropdown.classList.remove('show');
            filtrarTabla();
        }
    });
})();

// =============================================
// FILTRADO GLOBAL DESDE EL SERVIDOR (RECARGA URL)
// =============================================
function filtrarTabla() {
    const estado = document.getElementById('filterEstado').value;
    const prioridad = document.getElementById('filterPrioridad').value;
    const barrioInput = document.getElementById('filterBarrioInput');
    const barrioTexto = barrioInput ? barrioInput.value.trim() : '';

    // Si el texto coincide exactamente con un barrio, se usa; si no, se ignora
    const barrioValido = barriosDisponibles.find(b => b.toLowerCase() === barrioTexto.toLowerCase());
    const barrio = barrioValido || 'todos';

    const url = new URL(window.location.href);
    url.searchParams.set('estado', estado);
    url.searchParams.set('prioridad', prioridad);
    url.searchParams.set('barrio', barrio);
    url.searchParams.set('pagina', '1');
    window.location.href = url.toString();
}

let watchGpsId = null;

function obtenerUbicacionCobrador() {
    const inputUrl = document.getElementById('ubicacionUrlInput');
    const statusText = document.getElementById('statusUbicacion');
    const btn = document.getElementById('btnObtenerUbicacion');

    if (!navigator.geolocation) {
        statusText.style.color = '#ef4444';
        statusText.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Tu navegador no soporta geolocalización.';
        return;
    }

    // Cancelar cualquier rastreo activo previo
    if (watchGpsId !== null) {
        navigator.geolocation.clearWatch(watchGpsId);
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Ajustando GPS...';
    statusText.style.color = '#1b4f6e';
    statusText.innerHTML = '<i class="fas fa-satellite"></i> Conectando con satélites GPS (buscando precisión alta)...';

    const opcionesGps = {
        enableHighAccuracy: true, // Obliga a activar el chip GPS físico
        timeout: 20000,           // Espera hasta 20 segundos
        maximumAge: 0             // Prohíbe totalmente datos en caché de IP/red
    };

    let mejorLectura = null;
    let tiempoLimiteTimeout = null;

    // Usamos watchPosition para refinar la señal progresivamente hasta que sea precisa
    watchGpsId = navigator.geolocation.watchPosition(
        (pos) => {
            const lat = pos.coords.latitude;
            const lng = pos.coords.longitude;
            const precision = pos.coords.accuracy;

            // Guardar la mejor lectura obtenida hasta el momento
            if (!mejorLectura || precision < mejorLectura.precision) {
                mejorLectura = { lat, lng, precision };
            }

            statusText.style.color = '#1b4f6e';
            statusText.innerHTML = `<i class="fas fa-satellite-dish fa-spin"></i> Mejorando precisión... Margen actual: ${Math.round(precision)}m`;

            // Si la lectura es precisa (menor o igual a 50 metros), detenemos la búsqueda inmediatamente
            if (precision <= 50) {
                finalizarGps(mejorLectura.lat, mejorLectura.lng, mejorLectura.precision);
            }
        },
        (err) => {
            if (watchGpsId !== null) navigator.geolocation.clearWatch(watchGpsId);
            if (tiempoLimiteTimeout) clearTimeout(tiempoLimiteTimeout);

            btn.disabled = false;
            btn.style.background = '#1b4f6e';
            btn.innerHTML = '<i class="fas fa-crosshairs"></i> Reintentar GPS';

            const msgs = { 
                1: 'Permiso denegado. Habilita el permiso de ubicación.', 
                2: 'Señal GPS no disponible. Activa la ubicación de alta precisión en tu celular.', 
                3: 'Tiempo agotado sin señal GPS precisa.' 
            };
            
            statusText.style.color = '#ef4444';
            statusText.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + (msgs[err.code] || 'Error al obtener GPS.');
        },
        opcionesGps
    );

    // Límite de 12 segundos: Si no llega a <= 50m, usa la mejor lectura que haya conseguido
    tiempoLimiteTimeout = setTimeout(() => {
        if (mejorLectura) {
            finalizarGps(mejorLectura.lat, mejorLectura.lng, mejorLectura.precision);
        } else {
            if (watchGpsId !== null) navigator.geolocation.clearWatch(watchGpsId);
            btn.disabled = false;
            btn.style.background = '#1b4f6e';
            btn.innerHTML = '<i class="fas fa-crosshairs"></i> Reintentar GPS';
            statusText.style.color = '#ef4444';
            statusText.innerHTML = '<i class="fas fa-exclamation-circle"></i> No se pudo fijar la señal GPS. Intenta nuevamente encendiendo la ubicación del teléfono.';
        }
    }, 12000);

    function finalizarGps(lat, lng, precision) {
        if (watchGpsId !== null) {
            navigator.geolocation.clearWatch(watchGpsId);
            watchGpsId = null;
        }
        if (tiempoLimiteTimeout) {
            clearTimeout(tiempoLimiteTimeout);
        }

        const googleMapsUrl = `https://www.google.com/maps?q=${lat},${lng}`;
        inputUrl.value = googleMapsUrl;

        btn.disabled = false;
        btn.style.background = '#10b981';
        btn.innerHTML = '<i class="fas fa-check"></i> Ubicación Lista';

        if (precision > 100) {
            statusText.style.color = '#f59e0b';
            statusText.innerHTML = `<i class="fas fa-exclamation-triangle"></i> Ubicación de red (Margen: ${Math.round(precision)}m). Asegúrate de tener activa la 'Ubicación de alta precisión' en el celular.`;
        } else {
            statusText.style.color = '#10b981';
            statusText.innerHTML = `<i class="fas fa-check-circle"></i> GPS preciso (${lat.toFixed(5)}, ${lng.toFixed(5)}) · Margen: ~${Math.round(precision)}m`;
        }
    }
}


// Si viene desde otra pantalla con ?action=crear, se abre el modal automáticamente
const urlParams = new URLSearchParams(window.location.search);
if (urlParams.get('action') === 'crear') {
    abrirModal('modalCrear');
}
</script>
</body>
</html>