<?php
// pages/confirmar_cambio_pass.php
session_start();
error_reporting(0);
ini_set('display_errors', 0);

include __DIR__ . '/../config/conexion.php';

$token = $_GET['token'] ?? '';

if (empty($token)) {
    die("Token no válido");
}

// Verificar token
$sql = "SELECT id_usuario, nueva_password_temp, reset_expira FROM usuario WHERE reset_token = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("s", $token);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    die("Token inválido o ya fue utilizado");
}

$usuario = $resultado->fetch_assoc();
$expiracion = strtotime($usuario['reset_expira']);

if (time() > $expiracion) {
    die("El enlace ha expirado. Solicita un nuevo cambio de contraseña");
}

// Verificar que existe una contraseña temporal
$nueva_password = $usuario['nueva_password_temp'] ?? '';

if (empty($nueva_password)) {
    die("No hay una contraseña pendiente de confirmación");
}

$id_usuario = $usuario['id_usuario'];

// Hashear la nueva contraseña
$hash_password = password_hash($nueva_password, PASSWORD_DEFAULT);

// Actualizar la contraseña y limpiar tokens
$sql_update = "UPDATE usuario SET contrasena = ?, reset_token = NULL, reset_expira = NULL, nueva_password_temp = NULL WHERE id_usuario = ?";
$stmt_update = $conexion->prepare($sql_update);
$stmt_update->bind_param("si", $hash_password, $id_usuario);

if (!$stmt_update->execute()) {
    die("Error al actualizar la contraseña: " . $stmt_update->error);
}

// También actualizar la sesión si el usuario está logueado
if (isset($_SESSION['id_usuario']) && $_SESSION['id_usuario'] == $id_usuario) {
    $_SESSION['password_changed'] = true;
}

$stmt->close();
$stmt_update->close();
$conexion->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contraseña actualizada - Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }
        body {
            background: linear-gradient(135deg, #0f2b3d 0%, #1b4f6e 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .card {
            background: white;
            border-radius: 32px;
            padding: 2rem;
            max-width: 450px;
            width: 100%;
            text-align: center;
            animation: fadeIn 0.5s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .icon-success {
            width: 80px;
            height: 80px;
            background: #dcfce7;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
        }
        .icon-success i {
            font-size: 40px;
            color: #16a34a;
        }
        .btn {
            display: inline-block;
            margin-top: 1.5rem;
            padding: 12px 24px;
            background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
            color: white;
            text-decoration: none;
            border-radius: 40px;
            transition: 0.3s;
            font-weight: 600;
        }
        .btn:hover {
            transform: translateY(-2px);
            opacity: 0.9;
        }
        h2 {
            margin-bottom: 1rem;
            color: #0f2b3d;
        }
        p {
            color: #666;
            margin-bottom: 0.5rem;
        }
        .info-text {
            font-size: 0.85rem;
            color: #888;
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="icon-success">
            <i class="fas fa-check-circle"></i>
        </div>
        <h2>¡Contraseña actualizada!</h2>
        <p>Tu contraseña ha sido cambiada exitosamente.</p>
        <p>Ahora puedes iniciar sesión con tu nueva contraseña.</p>
        <a href="../login.php" class="btn">Iniciar sesión</a>
        <p class="info-text">
            <i class="fas fa-shield-alt"></i> Tu cuenta está más segura ahora
        </p>
    </div>
</body>
</html>