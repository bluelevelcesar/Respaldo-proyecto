<?php
// =============================================
// soporte_historial.php - HISTORIAL DE TRABAJOS REALIZADOS
// =============================================
session_start();

// Verificar si está logueado
if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';
include __DIR__ . '/../controllers/funcion_log.php';

$log = new SistemaLog($conexion);

$id_tecnico =$_SESSION['id_usuario'];
$nombre_tecnico =$_SESSION['usuario'] ?? 'Técnico';
$id_rol =$_SESSION['id_rol'] ?? 0;
$es_tecnico = ($id_rol == 3);

// Determinar botón de volver según el rol del usuario
$url_volver = match($id_rol) {
    1 => 'admin.php',
    2 => 'cobrador_clientes.php',
    3 => 'tecnico.php',
    4 => 'admin_red.php',
    default => 'login.php'
};

// =============================================
// CAPTURAR FILTROS Y BÚSQUEDA
// =============================================
$buscar = trim($_GET['buscar'] ?? '');
$filtro_estado =$_GET['estado'] ?? 'todos';
$filtro_prioridad =$_GET['prioridad'] ?? 'todas';

$where_clauses = [];
$params = [];$types = "";

// Si es técnico, solo ve los trabajos asignados/finalizados por él
if ($es_tecnico) {$where_clauses[] = "s.tecnico_id = ?";
    $params[] =$id_tecnico;
    $types .= "i";
}

// En el historial por defecto se muestran los finalizados (resuelto o cerrado)
if ($filtro_estado !== 'todos') {$where_clauses[] = "s.estado = ?";
    $params[] =$filtro_estado;
    $types .= "s";
} else {
    $where_clauses[] = "s.estado IN ('resuelto', 'cerrado')";
}

if ($filtro_prioridad !== 'todas') {$where_clauses[] = "s.prioridad = ?";
    $params[] =$filtro_prioridad;
    $types .= "s";
}

if (!empty($buscar)) {$where_clauses[] = "(c.nombre LIKE ? OR c.apellido LIKE ? OR s.descripcion LIKE ? OR b.nombre LIKE ?)";
    $term_buscar = "%{$buscar}%";
    $params[] =$term_buscar;
    $params[] =$term_buscar;
    $params[] =$term_buscar;
    $params[] =$term_buscar;
    $types .= "ssss";
}

$where_sql = count($where_clauses) > 0 ? "WHERE " . implode(" AND ", $where_clauses) : "";

// =============================================
// CONFIGURACIÓN DE PAGINACIÓN
// =============================================
$por_pagina = 8;
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;
$inicio = ($pagina_actual - 1) *$por_pagina;

// Contar registros totales filtrados
$sql_total = "SELECT COUNT(*) as total 
              FROM soporte s
              LEFT JOIN cliente c ON s.cliente_id = c.id
              LEFT JOIN barrio b ON c.id_barrio = b.id_barrio
              $where_sql";

$stmt_total = mysqli_prepare($conexion,$sql_total);
if (!empty($params)) {
    mysqli_stmt_bind_param($stmt_total, $types, ...$params);
}
mysqli_stmt_execute($stmt_total);
$total_registros = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_total))['total'] ?? 0;
$total_paginas = ceil($total_registros / $por_pagina);
mysqli_stmt_close($stmt_total);

// =============================================
// CONSULTA DE TRABAJOS CON LIMIT Y OFFSET
// =============================================
$sql_historial = "SELECT s.*, 
                         c.nombre as cliente_nombre, 
                         c.apellido as cliente_apellido, 
                         c.telefono as cliente_telefono,
                         b.nombre as cliente_barrio
                  FROM soporte s
                  LEFT JOIN cliente c ON s.cliente_id = c.id
                  LEFT JOIN barrio b ON c.id_barrio = b.id_barrio
                  $where_sql
                  ORDER BY s.fecha_resolucion DESC, s.id_soporte DESC
                  LIMIT ? OFFSET ?";

$stmt_historial = mysqli_prepare($conexion,$sql_historial);
$all_params =$params;
$all_params[] =$por_pagina;
$all_params[] =$inicio;
$all_types =$types . "ii";

if (!empty($all_types)) {
    mysqli_stmt_bind_param($stmt_historial, $all_types, ...$all_params);
}
mysqli_stmt_execute($stmt_historial);
$historial = mysqli_fetch_all(mysqli_stmt_get_result($stmt_historial), MYSQLI_ASSOC);
mysqli_stmt_close($stmt_historial);

function generarUrlPagina($num_pagina) {
    $params_url =$_GET;
    $params_url['pagina'] =$num_pagina;
    return '?' . http_build_query($params_url);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Trabajos - Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #f0f4f8; padding: 2rem; }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
            color: white;
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .header h1 { font-size: 1.3rem; display: flex; align-items: center; gap: 10px; }

        .btn-volver {
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            padding: 0.5rem 1.2rem;
            border-radius: 40px;
            font-weight: 500;
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            transition: 0.3s;
            font-size: 0.85rem;
        }
        .btn-volver:hover { background: rgba(255,255,255,0.3); }

        .table-wrapper { padding: 1.5rem 2rem 2rem 2rem; overflow-x: auto; }

        /* TABLA Y FILTROS */
        .filter-container { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            gap: 1rem; 
            flex-wrap: wrap; 
            margin-bottom: 1.5rem; 
        }
        .search-box { 
            display: flex; 
            align-items: center; 
            background: #f8fafc; 
            border: 1.5px solid #dce5ec; 
            border-radius: 30px; 
            padding: 0.4rem 1rem; 
            width: 320px; 
        }
        .search-box input { 
            border: none; 
            background: transparent; 
            outline: none; 
            width: 100%; 
            font-size: 0.85rem; 
            padding-left: 8px; 
            font-family: 'Inter', sans-serif;
        }
        .filter-select { 
            padding: 6px 14px; 
            border-radius: 20px; 
            border: 1.5px solid #dce5ec; 
            font-size: 0.75rem; 
            background: white; 
            outline: none; 
            cursor: pointer; 
        }
        .filter-select:focus { border-color: #1b4f6e; }

        .historial-table { width: 100%; border-collapse: collapse; font-size: 0.8rem; }
        .historial-table th { 
            text-align: left; 
            padding: 0.6rem; 
            background: #f8fafd; 
            font-weight: 600; 
            color: #1e2a41; 
            font-size: 0.6rem; 
            text-transform: uppercase; 
            letter-spacing: 0.5px; 
            border-bottom: 2px solid #e2e8f0; 
        }
        .historial-table td { 
            padding: 0.6rem; 
            border-bottom: 1px solid #edf2f7; 
            color: #1f2b48; 
            vertical-align: middle; 
        }
        .historial-table tr:hover td { background: #f8fafc; }

        /* BADGES */
        .badge-barrio {
            font-size: 0.7rem;
            color: #1b4f6e;
            background: #e8f4fd;
            padding: 3px 10px;
            border-radius: 12px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .badge-estado { 
            padding: 2px 10px; 
            border-radius: 20px; 
            font-size: 0.6rem; 
            font-weight: 600; 
            display: inline-flex; 
            align-items: center; 
            gap: 4px; 
        }
        .badge-estado.resuelto { background: #d1fae5; color: #065f46; }
        .badge-estado.cerrado { background: #e2e8f0; color: #475569; }

        .badge-prioridad { 
            padding: 1px 8px; 
            border-radius: 10px; 
            font-size: 0.55rem; 
            font-weight: 600; 
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .badge-prioridad.alta { background: #fee2e2; color: #991b1b; }
        .badge-prioridad.media { background: #fef3c7; color: #92400e; }
        .badge-prioridad.baja { background: #e0e7ff; color: #3730a3; }

        .btn-ver-detalle { 
            padding: 4px 10px; 
            border: none; 
            border-radius: 6px; 
            cursor: pointer; 
            font-size: 0.65rem; 
            font-weight: 600; 
            background: linear-gradient(135deg, #0f2b3d, #1b4f6e); 
            color: white; 
            transition: 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .btn-ver-detalle:hover { opacity: 0.9; transform: scale(0.97); }

        .empty-state { text-align: center; padding: 2.5rem; color: #94a3b8; }
        .empty-state i { font-size: 2rem; display: block; margin-bottom: 0.5rem; color: #cbd5e1; }

        /* PAGINACIÓN */
        .pagination { 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            gap: 6px; 
            margin-top: 1.5rem; 
        }
        .pagination a, .pagination span { 
            padding: 6px 12px; 
            border-radius: 8px; 
            font-size: 0.75rem; 
            font-weight: 600; 
            text-decoration: none; 
            border: 1px solid #dce5ec; 
            color: #1b4f6e; 
            background: white; 
            transition: 0.2s; 
        }
        .pagination a:hover, .pagination .active { 
            background: #1b4f6e; 
            color: white; 
            border-color: #1b4f6e; 
        }
        .pagination .disabled { 
            color: #94a3b8; 
            background: #f8fafc; 
            border-color: #e9eef3; 
            cursor: not-allowed; 
        }

        /* MODAL */
        .modal-overlay { 
            position: fixed; 
            top: 0; left: 0; 
            width: 100%; height: 100%; 
            background: rgba(0,0,0,0.5); 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            z-index: 1000; 
            visibility: hidden; 
            opacity: 0; 
            transition: 0.2s; 
        }
        .modal-overlay.active { visibility: visible; opacity: 1; }
        .modal-container { 
            background: white; 
            width: 95%; 
            max-width: 700px; 
            border-radius: 20px; 
            overflow: hidden; 
            max-height: 90vh; 
            overflow-y: auto; 
        }
        .modal-header { 
            background: linear-gradient(135deg, #0f2b3d, #1b4f6e); 
            color: white; 
            padding: 1rem 1.5rem; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }
        .modal-header h3 { font-size: 1rem; display: flex; align-items: center; gap: 8px; }
        .close-modal { background: none; border: none; font-size: 1.5rem; cursor: pointer; color: white; transition: 0.3s; }
        .close-modal:hover { transform: scale(1.1); }
        .modal-body { padding: 1.5rem; }

        @media (max-width: 768px) {
            body { padding: 1rem; }
            .filter-container { flex-direction: column; align-items: stretch; }
            .search-box { width: 100%; }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1><i class="fas fa-history"></i> Historial de Trabajos Realizados</h1>
        <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
            <span style="font-size:0.85rem; color:rgba(255,255,255,0.8);">
                Técnico: <strong style="color:white;"><?= htmlspecialchars($nombre_tecnico) ?></strong>
            </span>
            <a href="<?= $url_volver ?>" class="btn-volver">
                <i class="fas fa-arrow-left"></i> Volver
            </a>
        </div>
    </div>

    <div class="table-wrapper">
        <!-- FILTROS -->
        <form method="GET" action="" class="filter-container">
            <div class="search-box">
                <i class="fas fa-search" style="color:#94a3b8;"></i>
                <input type="text" name="buscar" placeholder="Buscar por cliente, barrio o descripción..." value="<?= htmlspecialchars($buscar) ?>">
            </div>
            <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
                <select name="estado" class="filter-select" onchange="this.form.submit()">
                    <option value="todos" <?= $filtro_estado === 'todos' ? 'selected' : '' ?>>Todos (Finalizados)</option>
                    <option value="resuelto" <?= $filtro_estado === 'resuelto' ? 'selected' : '' ?>>Resueltos</option>
                    <option value="cerrado" <?= $filtro_estado === 'cerrado' ? 'selected' : '' ?>>Domicilio Cerrado</option>
                </select>

                <select name="prioridad" class="filter-select" onchange="this.form.submit()">
                    <option value="todas" <?= $filtro_prioridad === 'todas' ? 'selected' : '' ?>>Todas las prioridades</option>
                    <option value="alta" <?= $filtro_prioridad === 'alta' ? 'selected' : '' ?>>Alta</option>
                    <option value="media" <?= $filtro_prioridad === 'media' ? 'selected' : '' ?>>Media</option>
                    <option value="baja" <?= $filtro_prioridad === 'baja' ? 'selected' : '' ?>>Baja</option>
                </select>

                <?php if (!empty($buscar) || $filtro_estado !== 'todos' || $filtro_prioridad !== 'todas'): ?>
                    <a href="soporte_historial.php" class="filter-select" style="text-decoration:none; background:#ef4444; color:white; border:none; display:inline-flex; align-items:center; gap:4px;">
                        <i class="fas fa-times"></i> Limpiar
                    </a>
                <?php endif; ?>
            </div>
        </form>

        <!-- TABLA DE HISTORIAL -->
        <?php if (empty($historial)): ?>
            <div class="empty-state">
                <i class="fas fa-check-circle" style="color:#10b981;"></i>
                <p>No se encontraron trabajos completados en el historial.</p>
            </div>
        <?php else: ?>
            <div style="overflow-x:auto;">
                <table class="historial-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Cliente</th>
                            <th>Barrio</th>
                            <th>Descripción</th>
                            <th>Prioridad</th>
                            <th>Estado</th>
                            <th>Fecha Resolución</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($historial as$h): 
                            $prioridad_clases = ['alta' => 'alta', 'media' => 'media', 'baja' => 'baja'];$prioridad_iconos = [
                                'alta'  => '<i class="fas fa-circle-exclamation"></i>',
                                'media' => '<i class="fas fa-circle"></i>',
                                'baja'  => '<i class="fas fa-circle-check"></i>'
                            ];
                        ?>
                        <tr>
                            <td>#<?= $h['id_soporte'] ?></td>
                            <td>
                                <strong><?= htmlspecialchars($h['cliente_nombre'] ?? 'Cliente') ?> <?= htmlspecialchars($h['cliente_apellido'] ?? '') ?></strong>
                                <br><small style="font-size:0.65rem; color:#94a3b8;"><i class="fas fa-phone"></i> <?= htmlspecialchars($h['cliente_telefono'] ?? '-') ?></small>
                            </td>
                            <td>
                                <span class="badge-barrio">
                                    <i class="fas fa-map-pin"></i> <?= htmlspecialchars($h['cliente_barrio'] ?? 'Sin barrio') ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars(substr($h['descripcion'] ?? '', 0, 50)) ?>...</td>
                            <td>
                                <span class="badge-prioridad <?= $prioridad_clases[$h['prioridad']] ?? 'baja' ?>">
                                    <?= $prioridad_iconos[$h['prioridad']] ?? '' ?> <?= ucfirst($h['prioridad'] ?? 'Baja') ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge-estado <?= $h['estado'] === 'resuelto' ? 'resuelto' : 'cerrado' ?>">
                                    <i class="fas <?= $h['estado'] === 'resuelto' ? 'fa-check-circle' : 'fa-lock' ?>"></i>
                                    <?= $h['estado'] === 'resuelto' ? 'Resuelto' : 'Domicilio Cerrado' ?>
                                </span>
                            </td>
                            <td><?= $h['fecha_resolucion'] ? date('d/m/Y', strtotime($h['fecha_resolucion'])) : date('d/m/Y', strtotime($h['fecha_creacion'])) ?></td>
                            <td>
                                <button class="btn-ver-detalle" onclick="verDetalle(<?= $h['id_soporte'] ?>)">
                                    <i class="fas fa-eye"></i> Detalle
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- CONTROLES DE PAGINACIÓN -->
            <?php if ($total_paginas > 1): ?>
            <div class="pagination">
                <?php if ($pagina_actual > 1): ?>
                    <a href="<?= generarUrlPagina(1) ?>"><i class="fas fa-angle-double-left"></i></a>
                    <a href="<?= generarUrlPagina($pagina_actual - 1) ?>"><i class="fas fa-angle-left"></i> Anterior</a>
                <?php else: ?>
                    <span class="disabled"><i class="fas fa-angle-double-left"></i></span>
                    <span class="disabled"><i class="fas fa-angle-left"></i> Anterior</span>
                <?php endif; ?>

                <?php for ($i = max(1,$pagina_actual - 2); $i <= min($total_paginas, $pagina_actual + 2);$i++): ?>
                    <?php if ($i ==$pagina_actual): ?>
                        <span class="active"><?= $i ?></span>
                    <?php else: ?>
                        <a href="<?= generarUrlPagina($i) ?>"><?= $i ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <?php if ($pagina_actual <$total_paginas): ?>
                    <a href="<?= generarUrlPagina($pagina_actual + 1) ?>">Siguiente <i class="fas fa-angle-right"></i></a>
                    <a href="<?= generarUrlPagina($total_paginas) ?>"><i class="fas fa-angle-double-right"></i></a>
                <?php else: ?>
                    <span class="disabled">Siguiente <i class="fas fa-angle-right"></i></span>
                    <span class="disabled"><i class="fas fa-angle-double-right"></i></span>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<!-- MODAL VER DETALLES DE TRABAJO -->
<div id="modalDetalle" class="modal-overlay">
    <div class="modal-container">
        <div class="modal-header">
            <h3><i class="fas fa-clipboard-list"></i> Detalle del Trabajo Realizado</h3>
            <button class="close-modal" onclick="cerrarModal('modalDetalle')">&times;</button>
        </div>
        <div class="modal-body" id="detalleContenido">
            <div style="text-align:center; padding:2rem; color:#94a3b8;">
                <i class="fas fa-spinner fa-spin" style="font-size:2rem;"></i>
                <p>Cargando detalles...</p>
            </div>
        </div>
    </div>
</div>

<script>
function cerrarModal(id) {
    document.getElementById(id).classList.remove('active');
}

function verDetalle(id) {
    document.getElementById('modalDetalle').classList.add('active');
    document.getElementById('detalleContenido').innerHTML = `
        <div style="text-align:center; padding:2rem; color:#94a3b8;">
            <i class="fas fa-spinner fa-spin" style="font-size:2rem;"></i>
            <p>Cargando detalles...</p>
        </div>
    `;

    fetch(`../controllers/get_soporte_detalle.php?id=${id}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                const d = data.data;
                const estadoClases = { 'pendiente': 'pendiente', 'en_progreso': 'progreso', 'resuelto': 'resuelto', 'cerrado': 'cerrado' };
                const estados = { 'pendiente': 'Pendiente', 'en_progreso': 'Visita a Domicilio', 'resuelto': 'Resuelto', 'cerrado': 'Domicilio Cerrado' };
                const prioridadColores = { 'alta': '#dc2626', 'media': '#f59e0b', 'baja': '#22c55e' };
                const prioridadIconos = { 'alta': 'fa-circle-exclamation', 'media': 'fa-circle', 'baja': 'fa-circle-check' };

                document.getElementById('detalleContenido').innerHTML = `
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:1.2rem; margin-bottom:1.5rem;">
                        
                        <!-- 1. CÓDIGO DE CLIENTE Y FECHA DE CREACIÓN -->
                        <div class="detalle-item">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-id-card" style="color:#1b4f6e;"></i> Código de Cliente
                            </label>
                            <p style="font-weight:700; color:#0f2b3d; font-size:1rem;">${d.codigo_cliente || 'N/A'}</p>
                        </div>

                        <div class="detalle-item">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-calendar" style="color:#1b4f6e;"></i> Fecha de Creación
                            </label>
                            <p style="font-weight:600; color:#0f2b3d; font-size:0.95rem;">${d.fecha_creacion || '-'}</p>
                        </div>

                        <!-- 2. DATOS DEL CLIENTE, BARRIO, PRIORIDAD, ESTADO, UBICACIÓN -->
                        <div class="detalle-item" style="grid-column: span 2;">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-user" style="color:#1b4f6e;"></i> Nombre del Cliente
                            </label>
                            <p style="font-weight:700; color:#0f2b3d; font-size:1rem;">${d.cliente_nombre || 'No asignado'} ${d.cliente_apellido || ''}</p>
                            <span style="font-size:0.75rem; color:#94a3b8;">
                                <i class="fas fa-phone"></i> ${d.cliente_telefono || 'Sin teléfono'}
                            </span>
                        </div>

                        <div class="detalle-item">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-map-pin" style="color:#1b4f6e;"></i> Barrio
                            </label>
                            <span style="font-size:0.8rem; color:#1b4f6e; background:#e8f4fd; padding:3px 10px; border-radius:12px; font-weight:600; display:inline-block;">
                                ${d.cliente_barrio || 'Sin barrio'}
                            </span>
                        </div>

                        <div class="detalle-item">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-flag" style="color:#1b4f6e;"></i> Prioridad
                            </label>
                            <span style="display:inline-flex; align-items:center; gap:6px; padding:4px 12px; border-radius:20px; background:${prioridadColores[d.prioridad] || '#94a3b8'}20; color:${prioridadColores[d.prioridad] || '#94a3b8'}; font-weight:600; font-size:0.8rem;">
                                <i class="fas ${prioridadIconos[d.prioridad] || 'fa-circle'}"></i>
                                ${d.prioridad ? d.prioridad.charAt(0).toUpperCase() + d.prioridad.slice(1) : 'Media'}
                            </span>
                        </div>

                        <div class="detalle-item">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-circle" style="color:#1b4f6e;"></i> Estado
                            </label>
                            <span class="badge-estado ${estadoClases[d.estado] || 'pendiente'}" style="display:inline-flex; align-items:center; gap:6px;">
                                <i class="fas ${d.estado === 'resuelto' ? 'fa-check-circle' : (d.estado === 'en_progreso' ? 'fa-spinner fa-spin' : (d.estado === 'cerrado' ? 'fa-lock' : 'fa-clock'))}"></i>
                                ${estados[d.estado] || 'Pendiente'}
                            </span>
                        </div>

                        <div class="detalle-item">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-map-marked-alt" style="color:#1b4f6e;"></i> Ubicación
                            </label>
                            ${d.ubicacion_url ? `
                                <a href="${d.ubicacion_url}" target="_blank" style="display:inline-flex; align-items:center; gap:8px; color:#1b4f6e; text-decoration:none; font-weight:600; font-size:0.85rem; background:#e8f4fd; padding:6px 12px; border-radius:10px; border:1px solid #b2d8f8;">
                                    <i class="fas fa-external-link-alt" style="color:#10b981;"></i> Ver en Maps
                                </a>
                            ` : '<span style="font-size:0.8rem; color:#94a3b8;">Sin ubicación asignada</span>'}
                        </div>

                    </div>

                    <!-- 3. DESCRIPCIÓN AL FINAL -->
                    <div style="border-top: 1.5px solid #e9eef3; padding-top: 1.2rem;">
                        <div class="detalle-item">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:6px;">
                                <i class="fas fa-align-left" style="color:#1b4f6e;"></i> Descripción
                            </label>
                            <p style="color:#1f2b48; font-size:0.9rem; line-height:1.6; background:#f8fafd; padding:1rem; border-radius:10px; border:1px solid #e9eef3;">
                                ${d.descripcion || 'Sin descripción'}
                            </p>
                        </div>

                        ${d.comentario ? `
                        <div class="detalle-item" style="margin-top:1rem;">
                            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                                <i class="fas fa-comment" style="color:#1b4f6e;"></i> Comentario Técnico
                            </label>
                            <p style="color:#1f2b48; font-size:0.85rem; background:#fef3c7; padding:0.8rem 1rem; border-radius:10px; border:1px solid #fde68a;">
                                ${d.comentario}
                            </p>
                        </div>
                        ` : ''}
                    </div>
                `;
            } else {
                document.getElementById('detalleContenido').innerHTML = `
                    <div style="text-align:center; padding:2rem; color:#ef4444;">
                        <i class="fas fa-exclamation-triangle" style="font-size:2rem;"></i>
                        <p>${data.message || 'Error al cargar los detalles'}</p>
                    </div>
                `;
            }
        })
        .catch(error => {
            document.getElementById('detalleContenido').innerHTML = `
                <div style="text-align:center; padding:2rem; color:#ef4444;">
                    <i class="fas fa-circle-exclamation" style="font-size:2rem;"></i>
                    <p>Error al cargar los detalles</p>
                </div>
            `;
            console.error('Error:', error);
        });
}
</script>

</body>
</html>