<?php
session_start();

// Verificar si está logueado y es administrador de red (id_rol = 4)
if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 4) {
    header('Location: ../login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';
include __DIR__ . '/../controllers/funcion_log.php';

$log = new SistemaLog($conexion);

// =============================================
// PROCESAR ACCIONES POST (CRUD BARRIOS)
// =============================================
$mensaje = '';
$mensaje_tipo = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';
    
    // CREAR BARRIO
    if ($accion === 'crear_barrio') {
        $nombre = trim($_POST['nombre']);
        
        $stmt = $conexion->prepare("INSERT INTO barrio (nombre) VALUES (?)");
        $stmt->bind_param("s", $nombre);
        
        if ($stmt->execute()) {
            $mensaje = "Barrio creado correctamente";
            $mensaje_tipo = "success";
        } else {
            $mensaje = "Error al crear barrio: " . $conexion->error;
            $mensaje_tipo = "error";
        }
        $stmt->close();
    }
    
    // EDITAR BARRIO
    if ($accion === 'editar_barrio') {
        $id_barrio = intval($_POST['id_barrio']);
        $nombre = trim($_POST['nombre']);
        
        $stmt = $conexion->prepare("UPDATE barrio SET nombre = ? WHERE id_barrio = ?");
        $stmt->bind_param("si", $nombre, $id_barrio);
        
        if ($stmt->execute()) {
            $mensaje = "Barrio actualizado correctamente";
            $mensaje_tipo = "success";
        } else {
            $mensaje = "Error al actualizar barrio: " . $conexion->error;
            $mensaje_tipo = "error";
        }
        $stmt->close();
    }
    
    // ELIMINAR BARRIO
    if ($accion === 'eliminar_barrio') {
        $id_barrio = intval($_POST['id_barrio']);
        $nombre = $_POST['nombre'];
        
        // Verificar si hay clientes usando este barrio
        $check = $conexion->prepare("SELECT COUNT(*) as total FROM cliente WHERE id_barrio = ?");
        $check->bind_param("i", $id_barrio);
        $check->execute();
        $result = $check->get_result();
        $clientes_asignados = $result->fetch_assoc()['total'];
        $check->close();
        
        if ($clientes_asignados > 0) {
            $mensaje = "No se puede eliminar el barrio porque tiene $clientes_asignados cliente(s) asignado(s)";
            $mensaje_tipo = "error";
        } else {
            $stmt = $conexion->prepare("DELETE FROM barrio WHERE id_barrio = ?");
            $stmt->bind_param("i", $id_barrio);
            
            if ($stmt->execute()) {
                $mensaje = "Barrio eliminado correctamente";
                $mensaje_tipo = "success";
            } else {
                $mensaje = "Error al eliminar barrio: " . $conexion->error;
                $mensaje_tipo = "error";
            }
            $stmt->close();
        }
    }
}

// Obtener lista de barrios
$sql_barrios = "SELECT * FROM barrio ORDER BY id_barrio DESC";
$result_barrios = $conexion->query($sql_barrios);
$barrios = $result_barrios ? $result_barrios->fetch_all(MYSQLI_ASSOC) : [];

// Obtener estadísticas
$sql_stats = "SELECT 
    (SELECT COUNT(*) FROM barrio) as total_barrios,
    (SELECT COUNT(*) FROM cliente) as total_clientes";
$result_stats = $conexion->query($sql_stats);
$stats = $result_stats ? $result_stats->fetch_assoc() : [
    'total_barrios' => 0, 
    'total_clientes' => 0
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Barrios - Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #f0f4f8; min-height: 100vh; }
        .container { max-width: 1400px; margin: 0 auto; padding: 2rem; }
        
        .header { background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white; padding: 1.5rem 2rem; border-radius: 20px; margin-bottom: 2rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; }
        .header h1 { font-size: 1.5rem; display: flex; align-items: center; gap: 12px; }
        .btn-volver { background: #6c757d; color: white; padding: 0.7rem 1.5rem; border-radius: 40px; text-decoration: none; font-weight: 600; transition: 0.3s; display: inline-flex; align-items: center; gap: 8px; }
        .btn-volver:hover { background: #5a6268; transform: translateY(-2px); }
        
        .btn-primary { background: linear-gradient(135deg, #1b4f6e, #0f2b3d); color: white; border: none; padding: 0.7rem 1.5rem; border-radius: 10px; cursor: pointer; font-weight: 600; transition: 0.3s; display: inline-flex; align-items: center; gap: 8px; }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
        .btn-danger { background: #ef4444; color: white; border: none; padding: 0.4rem 0.8rem; border-radius: 8px; cursor: pointer; transition: 0.3s; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 5px; }
        .btn-danger:hover { background: #dc2626; }
        .btn-edit { background: #f59e0b; color: white; border: none; padding: 0.4rem 0.8rem; border-radius: 8px; cursor: pointer; margin-right: 5px; transition: 0.3s; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 5px; }
        .btn-edit:hover { background: #d97706; }
        
        .card { background: white; border-radius: 20px; padding: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; padding-bottom: 0.75rem; border-bottom: 2px solid #eef2f6; flex-wrap: wrap; gap: 0.5rem; }
        .card-header h2 { font-size: 1.2rem; color: #1e2a41; display: flex; align-items: center; gap: 8px; }
        
        .form-group { margin-bottom: 1rem; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: 700; color: #1b4f6e; margin-bottom: 0.3rem; }
        .form-group label i { margin-right: 5px; }
        .form-group input, .form-group select { width: 100%; padding: 0.7rem; border: 1.5px solid #dce5ec; border-radius: 12px; font-family: 'Inter', sans-serif; font-size: 0.9rem; transition: 0.3s; }
        .form-group input:focus, .form-group select:focus { outline: none; border-color: #1b4f6e; box-shadow: 0 0 0 3px rgba(27,79,110,0.1); }
        
        .table-wrapper { overflow-x: auto; }
        .table { width: 100%; border-collapse: collapse; }
        .table th { text-align: left; padding: 1rem 0.8rem; background: #f8fafc; font-weight: 600; color: #1e2a41; border-bottom: 2px solid #e2e8f0; font-size: 0.8rem; }
        .table td { padding: 0.8rem; border-bottom: 1px solid #edf2f7; color: #1f2b48; font-size: 0.85rem; }
        .table tr:hover td { background: #f8fafc; }
        
        .badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 0.7rem; font-weight: 600; }
        .badge-barrio { background: #e0e7ff; color: #3730a3; }
        
        .stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
        .stat-card { background: white; padding: 1rem; border-radius: 16px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.05); transition: 0.3s; }
        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .stat-card .number { font-size: 1.8rem; font-weight: 700; color: #1b4f6e; }
        .stat-card .label { font-size: 0.7rem; color: #666; text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-card .icon { font-size: 1.5rem; color: #1b4f6e; margin-bottom: 0.5rem; }
        
        .modal-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5);
            display: flex; align-items: center; justify-content: center; z-index: 1000; visibility: hidden; opacity: 0; transition: 0.2s;
        }
        .modal-overlay.active { visibility: visible; opacity: 1; }
        .modal-container { background: white; width: 90%; max-width: 450px; border-radius: 20px; overflow: hidden; animation: modalFadeIn 0.3s ease; }
        @keyframes modalFadeIn { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        .modal-header { background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white; padding: 1rem 1.5rem; display: flex; justify-content: space-between; align-items: center; }
        .modal-header h3 { font-size: 1.1rem; display: flex; align-items: center; gap: 8px; }
        .modal-body { padding: 1.5rem; }
        .close-modal { background: none; border: none; font-size: 1.5rem; cursor: pointer; color: white; transition: 0.3s; }
        .close-modal:hover { transform: scale(1.1); }
        
        .toast {
            position: fixed; bottom: 20px; right: 20px; background: #10b981; color: white;
            padding: 12px 20px; border-radius: 10px; z-index: 9999; animation: slideIn 0.3s ease;
            display: flex; align-items: center; gap: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .toast.error { background: #ef4444; }
        @keyframes slideIn { from { transform: translateX(100px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        
        .two-columns { display: grid; grid-template-columns: 1fr 1.5fr; gap: 1.5rem; }
        .info-text { font-size: 0.7rem; color: #64748b; margin-top: 0.3rem; display: flex; align-items: center; gap: 5px; }
        
        @media (max-width: 768px) { 
            .two-columns { grid-template-columns: 1fr; } 
            .container { padding: 1rem; }
            .stats-row { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1><i class="fas fa-map-marker-alt"></i> Gestión de Barrios</h1>
        <div style="display: flex; gap: 1rem;">
            <a href="admin_red.php" class="btn-volver"><i class="fas fa-arrow-left"></i> Volver al Panel</a>
        </div>
    </div>

    <!-- ESTADÍSTICAS RÁPIDAS -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="icon"><i class="fas fa-building"></i></div>
            <div class="number"><?= $stats['total_barrios'] ?></div>
            <div class="label">Total Barrios</div>
        </div>
        <div class="stat-card">
            <div class="icon"><i class="fas fa-users"></i></div>
            <div class="number"><?= $stats['total_clientes'] ?></div>
            <div class="label">Clientes Registrados</div>
        </div>
    </div>

    <div class="two-columns">
        <!-- FORMULARIO PARA CREAR BARRIO -->
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-plus-circle"></i> Nuevo Barrio</h2>
            </div>
            <form id="formBarrio" method="POST">
                <input type="hidden" name="accion" value="crear_barrio">
                <div class="form-group">
                    <label><i class="fas fa-location-dot"></i> Nombre del Barrio</label>
                    <input type="text" name="nombre" id="nombreBarrio" placeholder="Ej: Centro, Alto Verde, San Martín" required>
                </div>
                <button type="submit" class="btn-primary" style="width:100%"><i class="fas fa-save"></i> Guardar Barrio</button>
            </form>
        </div>

        <!-- TABLA DE BARRIOS -->
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-list"></i> Lista de Barrios</h2>
                <button class="btn-primary" onclick="location.reload()"><i class="fas fa-sync-alt"></i> Actualizar</button>
            </div>
            <div class="table-wrapper">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($barrios)): ?>
                            <tr><td colspan="3" style="text-align:center; padding: 2rem;">No hay barrios registrados <i class="fas fa-sad-tear"></i></td></tr>
                        <?php else: ?>
                            <?php foreach ($barrios as $barrio): ?>
                            <tr>
                                <td><?= $barrio['id_barrio'] ?></td>
                                <td><strong><?= htmlspecialchars($barrio['nombre']) ?></strong></td>
                                <td>
                                    <button class="btn-edit" onclick='editarBarrio(<?= json_encode($barrio) ?>)'><i class="fas fa-edit"></i> Editar</button>
                                    <button class="btn-danger" onclick="eliminarBarrio(<?= $barrio['id_barrio'] ?>, '<?= htmlspecialchars($barrio['nombre']) ?>')"><i class="fas fa-trash"></i> Eliminar</button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- MODAL PARA EDITAR BARRIO -->
<div id="modalEditar" class="modal-overlay">
    <div class="modal-container">
        <div class="modal-header">
            <h3><i class="fas fa-edit"></i> Editar Barrio</h3>
            <button class="close-modal" onclick="cerrarModal()">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <input type="hidden" name="accion" value="editar_barrio">
                <input type="hidden" name="id_barrio" id="editId">
                <div class="form-group">
                    <label><i class="fas fa-location-dot"></i> Nombre del Barrio</label>
                    <input type="text" name="nombre" id="editNombre" required>
                </div>
                <button type="submit" class="btn-primary" style="width:100%"><i class="fas fa-save"></i> Actualizar Barrio</button>
            </form>
        </div>
    </div>
</div>

<!-- FORMULARIOS OCULTOS PARA ELIMINAR -->
<form id="formEliminar" method="POST" style="display:none;">
    <input type="hidden" name="accion" value="eliminar_barrio">
    <input type="hidden" name="id_barrio" id="eliminarId">
    <input type="hidden" name="nombre" id="eliminarNombre">
</form>

<script>
    // Mostrar mensajes de éxito/error
    <?php if ($mensaje): ?>
        mostrarToast('<?= $mensaje ?>', '<?= $mensaje_tipo ?>');
    <?php endif; ?>

    function mostrarToast(mensaje, tipo) {
        const toast = document.createElement('div');
        toast.className = 'toast';
        if (tipo === 'error') toast.classList.add('error');
        toast.innerHTML = `<i class="fas ${tipo === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i> ${mensaje}`;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    }

    function editarBarrio(barrio) {
        document.getElementById('editId').value = barrio.id_barrio;
        document.getElementById('editNombre').value = barrio.nombre;
        document.getElementById('modalEditar').classList.add('active');
    }

    function eliminarBarrio(id, nombre) {
        if (confirm(`¿Eliminar el barrio "${nombre}"?\n\nNota: No se puede eliminar si tiene clientes asignados.`)) {
            document.getElementById('eliminarId').value = id;
            document.getElementById('eliminarNombre').value = nombre;
            document.getElementById('formEliminar').submit();
        }
    }

    function cerrarModal() {
        document.getElementById('modalEditar').classList.remove('active');
    }

    // Cerrar modal al hacer clic fuera
    document.getElementById('modalEditar').addEventListener('click', function(e) {
        if (e.target === this) cerrarModal();
    });
</script>
</body>
</html>