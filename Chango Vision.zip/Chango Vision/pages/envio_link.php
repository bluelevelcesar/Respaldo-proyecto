<?php
// olvide_password.php - Formulario para recuperar contraseña
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña - Chango Visión</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0f2b3d 0%, #1b4f6e 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h2 {
            color: #1b4f6e;
            margin-bottom: 1rem;
            text-align: center;
        }

        .subtitle {
            text-align: center;
            margin-bottom: 1.5rem;
            color: #666;
            font-size: 0.9rem;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }

        input {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 0.9rem;
            transition: 0.2s;
        }

        input:focus {
            outline: none;
            border-color: #1b4f6e;
            box-shadow: 0 0 0 3px rgba(27,79,110,0.1);
        }

        .btn-enviar {
            background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
            color: white;
            width: 100%;
            padding: 0.8rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            transition: 0.2s;
            margin-top: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-enviar:hover:not(:disabled) {
            opacity: 0.9;
            transform: translateY(-2px);
        }

        .btn-enviar:disabled {
            background: #95a5a6;
            cursor: not-allowed;
            opacity: 0.7;
        }

        .btn-volver {
            background: #6c757d;
            color: white;
            width: 100%;
            padding: 0.8rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            transition: 0.2s;
            margin-top: 0.5rem;
            text-align: center;
            display: inline-block;
            text-decoration: none;
        }

        .btn-volver:hover {
            background: #5a6268;
            transform: translateY(-2px);
        }

        .message {
            margin-top: 1rem;
            padding: 0.8rem;
            border-radius: 8px;
            text-align: center;
            font-size: 0.85rem;
            animation: fadeIn 0.5s ease;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .spinner {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid white;
            border-top-color: transparent;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }

        .loading-text {
            display: inline-block;
            animation: pulse 1s ease-in-out infinite;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2><i class="fas fa-key"></i> Recuperar Contraseña</h2>
        <div class="subtitle">
            Te enviaremos un enlace para restablecer tu contraseña
        </div>

        <div id="messageContainer"></div>

        <form id="formRecuperar">
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Correo electrónico</label>
                <input type="email" id="email" name="email" placeholder="tucorreo@ejemplo.com" required>
            </div>
            <button type="submit" class="btn-enviar" id="submitBtn">
                <i class="fas fa-paper-plane"></i> Enviar enlace de recuperación
            </button>
            <a href="../login.php" class="btn-volver">
                <i class="fas fa-arrow-left"></i> Volver al login
            </a>
        </form>
    </div>

    <script>
        const form = document.getElementById('formRecuperar');
        const messageContainer = document.getElementById('messageContainer');
        const submitBtn = document.getElementById('submitBtn');
        const emailInput = document.getElementById('email');

        function mostrarMensaje(texto, tipo) {
            messageContainer.innerHTML = `<div class="message ${tipo}">${texto}</div>`;
            
            if (tipo === 'success') {
                setTimeout(() => {
                    if (messageContainer.innerHTML.includes(texto)) {
                        messageContainer.innerHTML = '';
                    }
                }, 5000);
            }
        }

        function mostrarLoading(mostrar) {
            if (mostrar) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<span class="spinner"></span> <span class="loading-text">Enviando...</span>';
                messageContainer.innerHTML = '';
            } else {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Enviar enlace de recuperación';
            }
        }

        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            const email = emailInput.value.trim();

            if (!email) {
                mostrarMensaje('❌ Ingresa un correo electrónico', 'error');
                emailInput.focus();
                return;
            }

            mostrarLoading(true);

            try {
                // ✅ RUTA DEL PRIMER CÓDIGO (original)
                const response = await fetch('../controllers/enviar_recuperacion.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'email=' + encodeURIComponent(email)
                });

                const result = (await response.text()).trim();

                console.log('Respuesta del servidor:', result);

                if (result === 'enviado') {
                    mostrarMensaje(
                        '✅ ¡Correo enviado! Revisa tu bandeja de entrada. (Si no lo ves, revisa spam)',
                        'success'
                    );
                    form.reset();
                } else if (result === 'no_encontrado') {
                    mostrarMensaje(
                        '❌ No existe una cuenta con ese correo electrónico',
                        'error'
                    );
                } else {
                    mostrarMensaje(
                        '❌ Error: ' + result,
                        'error'
                    );
                }
            } catch (error) {
                console.error('Error:', error);
                mostrarMensaje(
                    '❌ Error de conexión con el servidor. Intenta nuevamente.',
                    'error'
                );
            } finally {
                mostrarLoading(false);
            }
        });
    </script>
</body>
</html>