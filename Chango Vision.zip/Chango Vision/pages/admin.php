<?php
session_start();

// Verificar si está logueado y es admin
if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 1) {
    header('Location: ../login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';
include __DIR__ . '/../controllers/funcion_log.php';

$log = new SistemaLog($conexion);

// Configurar zona horaria local y obtener la fecha de hoy formateada en español
date_default_timezone_set('America/Argentina/La_Rioja');
$dias_semana = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
$meses_anio = ['', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
// Obtener la fecha de hoy en formato numérico (Día/Mes/Año)
$fecha_hoy_formateada = date('d/m/Y');
// =============================================
// ESTADÍSTICAS PRINCIPALES
// =============================================

// 1. TOTAL DE CLIENTES
$sql_total_clientes = "SELECT COUNT(*) as total FROM cliente";
$result_total = mysqli_query($conexion, $sql_total_clientes);
$total_clientes_general = mysqli_fetch_assoc($result_total)['total'] ?? 0;

// 2. CLIENTES POR ESTADO DE PAGO
$sql_estados_pago = "SELECT estado_pago, COUNT(*) as total FROM cliente GROUP BY estado_pago";
$result_estados = mysqli_query($conexion, $sql_estados_pago);
$stats_pago = ['pagado' => 0, 'pendiente' => 0, 'suspendido' => 0];
while ($row = mysqli_fetch_assoc($result_estados)) {
    $estado = strtolower($row['estado_pago']);
    if (isset($stats_pago[$estado])) {
        $stats_pago[$estado] = $row['total'];
    }
}

// 3. CLIENTES POR ESTADO (Activo/Inactivo)
$sql_estado_cliente = "SELECT `estado`, COUNT(*) as total FROM cliente GROUP BY `estado`";
$result_estado_cliente = mysqli_query($conexion, $sql_estado_cliente);
$stats_estado = ['Activo' => 0, 'Inactivo' => 0];
while ($row = mysqli_fetch_assoc($result_estado_cliente)) {
    $stats_estado[$row['estado']] = $row['total'];
}

// 4. PORCENTAJE DE CLIENTES AL DÍA
$porcentaje_al_dia = 0;
if ($total_clientes_general > 0) {
    $porcentaje_al_dia = round(($stats_pago['pagado'] / $total_clientes_general) * 100);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Admin - Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../js/admin_cliente.js"></script>
   <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Inter', sans-serif; background: #f0f4f8; overflow-x: hidden; }

    .app-container { display: flex; min-height: 100vh; }

    /* ============================================= */
    /* SIDEBAR */
    /* ============================================= */
    .sidebar {
        width: 280px;
        background: linear-gradient(180deg, #0f2b3d 0%, #1b4f6e 100%);
        color: white;
        padding: 2rem 1.5rem;
        display: flex;
        flex-direction: column;
        position: fixed;
        height: 100vh;
        overflow-y: auto;
        z-index: 100;
    }

    .sidebar::-webkit-scrollbar { width: 4px; }
    .sidebar::-webkit-scrollbar-track { background: transparent; }
    .sidebar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.3); border-radius: 10px; }

    .logo-area {
        margin-bottom: 2rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid rgba(255,255,255,0.15);
    }

    .logo-area h2 {
        font-size: 1.5rem;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .logo-area h2 i { color: #60a5fa; }
    .logo-area span { font-size: 0.7rem; opacity: 0.6; display: block; margin-top: 4px; }

    .nav-section { margin-bottom: 1.5rem; }
    .nav-section-title {
        font-size: 0.65rem;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        opacity: 0.5;
        margin-bottom: 0.8rem;
        font-weight: 600;
    }

    .nav-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 0.7rem 1rem;
        border-radius: 12px;
        cursor: pointer;
        transition: all 0.2s;
        color: rgba(255,255,255,0.8);
        text-decoration: none;
        margin-bottom: 0.2rem;
        font-size: 0.9rem;
        border: none;
        background: transparent;
        width: 100%;
        text-align: left;
    }

    .nav-item:hover { background: rgba(255,255,255,0.1); color: white; }
    .nav-item.active { background: rgba(255,255,255,0.15); color: white; }
    .nav-item i { width: 22px; font-size: 1.1rem; text-align: center; color: rgba(255,255,255,0.6); }
    .nav-item:hover i, .nav-item.active i { color: white; }

    .nav-item .badge {
        background: #ef4444;
        color: white;
        padding: 1px 8px;
        border-radius: 20px;
        font-size: 0.6rem;
        font-weight: 700;
        margin-left: auto;
    }

    .nav-divider { border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 0.5rem 0 1rem 0; }

    /* ============================================= */
    /* MAIN CONTENT */
    /* ============================================= */
    .main-content {
        flex: 1;
        margin-left: 280px;
        padding: 2rem;
        min-height: 100vh;
    }

    .top-bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
        background: white;
        padding: 1rem 2rem;
        border-radius: 20px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
        flex-wrap: wrap;
        gap: 1rem;
    }

    .page-title { font-size: 1.3rem; font-weight: 700; color: #1e2a41; }
    .page-title i { color: #1b4f6e; margin-right: 10px; }

    .user-info {
        display: flex;
        align-items: center;
        gap: 12px;
        font-size: 0.9rem;
        color: #1e2a41;
    }
    .user-avatar {
        width: 40px;
        height: 40px;
        background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        color: white;
        font-size: 1rem;
    }

    /* ============================================= */
    /* ESTADÍSTICAS CON ICONOS */
    /* ============================================= */
    .stats-container {
        padding: 0.5rem 0 0.5rem 0;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 1rem;
    }

    .stat-card {
        background: white;
        padding: 1rem 1.2rem;
        border-radius: 14px;
        border: 1px solid #e9eef3;
        display: flex;
        align-items: center;
        gap: 1rem;
        transition: all 0.3s ease;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }

    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }

    .stat-icon {
        width: 44px;
        height: 44px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        flex-shrink: 0;
    }

    .stat-info {
        flex: 1;
    }

    .stat-number {
        font-size: 1.5rem;
        font-weight: 700;
        line-height: 1.2;
    }

    .stat-label {
        font-size: 0.65rem;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 600;
    }

    .stat-trend {
        font-size: 0.6rem;
        color: #94a3b8;
        margin-top: 2px;
    }

    .stat-trend i {
        margin-right: 2px;
    }

    /* ============================================= */
    /* GRÁFICOS */
    /* ============================================= */
    .charts-container {
        padding: 0.5rem 0 1rem 0;
    }

    .charts-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1.5rem;
    }

    .chart-card {
        background: white;
        border-radius: 16px;
        border: 1px solid #e9eef3;
        padding: 1.2rem;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        transition: all 0.3s ease;
    }

    .chart-card:hover {
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }

    .chart-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
    }

    .chart-header h4 {
        font-size: 0.85rem;
        font-weight: 700;
        color: #0f2b3d;
        margin: 0;
    }

    .chart-header h4 i {
        color: #1b4f6e;
        margin-right: 6px;
    }

    .chart-body {
        display: flex;
        justify-content: center;
        padding: 0.5rem 0;
    }

    .chart-body canvas {
        max-width: 100%;
        max-height: 250px;
    }

    .chart-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 0.8rem;
        padding-top: 0.8rem;
        border-top: 1px solid #f1f5f9;
        flex-wrap: wrap;
        gap: 0.5rem;
    }

    .legend-item {
        font-size: 0.65rem;
        color: #64748b;
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .legend-color {
        display: inline-block;
        width: 12px;
        height: 12px;
        border-radius: 4px;
    }

    .total-ganancias {
        font-size: 0.8rem;
        font-weight: 700;
        color: #1b4f6e;
    }

    /* ============================================= */
    /* CLIENTES POR BARRIO */
    /* ============================================= */
    .barrios-container {
        padding: 0 0 1.5rem 0;
    }

    .barrios-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.8rem;
    }

    .barrios-header h4 {
        font-size: 0.85rem;
        font-weight: 700;
        color: #0f2b3d;
        margin: 0;
    }

    .barrios-header h4 i {
        color: #1b4f6e;
        margin-right: 6px;
    }

    .barrios-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 0.8rem;
    }

    .barrio-card {
        background: #f8fafd;
        padding: 0.7rem 1rem;
        border-radius: 10px;
        border: 1px solid #e9eef3;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: all 0.3s ease;
    }

    .barrio-card:hover {
        background: #f1f5f9;
        transform: translateX(3px);
    }

    .barrio-nombre {
        font-weight: 500;
        color: #0f2b3d;
        font-size: 0.8rem;
    }

    .barrio-cantidad {
        font-weight: 700;
        color: #1b4f6e;
        font-size: 0.85rem;
    }

    .total-label {
        font-weight: 400;
        color: #94a3b8;
        font-size: 0.6rem;
    }

    /* ============================================= */
    /* FOOTER */
    /* ============================================= */
    .footer {
        margin-top: 2rem;
        padding-top: 1rem;
        text-align: center;
        font-size: 0.75rem;
        color: #94a3b8;
        border-top: 1px solid #e2e8f0;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 0.5rem;
    }

    .status-dot {
        display: inline-block;
        width: 8px;
        height: 8px;
        background: #10b981;
        border-radius: 50%;
        margin-right: 6px;
        animation: pulse-dot 2s infinite;
    }

    @keyframes pulse-dot { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }

    .update-time { font-size: 0.7rem; color: #94a3b8; }

    /* ============================================= */
    /* RESPONSIVE */
    /* ============================================= */
    @media (max-width: 992px) {
        .charts-grid {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 768px) {
        .sidebar { display: none; }
        .main-content { margin-left: 0; padding: 1rem; }
        .stats-grid { grid-template-columns: 1fr 1fr; }
        .charts-grid { grid-template-columns: 1fr; }
        .barrios-grid { grid-template-columns: 1fr 1fr; }
        .top-bar { flex-direction: column; align-items: stretch; text-align: center; }
        .user-info { justify-content: center; }
        .footer { flex-direction: column; text-align: center; }
    }

    @media (max-width: 600px) {
        .stats-grid { grid-template-columns: 1fr; }
        .barrios-grid { grid-template-columns: 1fr; }
        .stat-card { padding: 0.7rem 0.8rem; }
        .stat-icon { width: 36px; height: 36px; font-size: 1rem; }
        .stat-number { font-size: 1.2rem; }
    }
</style>
</head>
<body>

<div class="app-container">
    <!-- ============================================= -->
    <!-- SIDEBAR -->
    <!-- ============================================= -->
    <div class="sidebar">
        <div class="logo-area">
            <h2><i class="fas fa-tv"></i> Chango Vision</h2>
            <span>Panel de Administración</span>
        </div>

        

        <div class="nav-section">
            <div class="nav-section-title">Gestión</div>
            <a href="admin_cliente.php" class="nav-item">
                <i class="fas fa-users"></i>
                <span>Clientes</span>
            </a>
            <a href="soporte_tecnico.php" class="nav-item">
                <i class="fas fa-headset"></i>
                <span>Servicios Técnicos</span>
            </a>
            
             <a href="servicio.php" class="nav-item">
                <i class="fas fa-headset"></i>
                <span>Servicios</span>
            </a>

             <a href="reportes_pagos.php" class="nav-item">
                <i class="fas fa-file-alt"></i>
                <span>Reportes y Pagos</span>
            </a>
            
        </div>

        <div class="nav-section">
            <div class="nav-section-title">Seguridad</div>
            <a href="cambiar_datos.php" class="nav-item">
                <i class="fas fa-user-cog"></i>
                <span>Cambiar Datos</span>
            </a>
            <a href="../logout.php" class="nav-item" onclick="return confirm('¿Cerrar sesión?')">
                <i class="fas fa-sign-out-alt"></i>
                <span>Cerrar Sesión</span>
            </a>
        </div>
    </div>

    <!-- ============================================= -->
    <!-- MAIN CONTENT -->
    <!-- ============================================= -->
    <div class="main-content">
        <div class="top-bar">
            <div class="page-title">
                <i class="fas fa-calendar-alt"></i> <?= htmlspecialchars($fecha_hoy_formateada) ?>
            </div>
            <div class="user-info">
                <i class="fas fa-user-shield" style="color:#1b4f6e;"></i>
                <span><?= htmlspecialchars($_SESSION['usuario'] ?? 'Administrador') ?></span>
                <div class="user-avatar">
                    <?= strtoupper(substr($_SESSION['usuario'] ?? 'A', 0, 1)) ?>
                </div>
            </div>
        </div>

 <!-- ============================================= -->
<!-- TARJETAS DE ESTADÍSTICAS -->
<!-- ============================================= -->
<div class="stats-container">
    <div class="stats-grid">
        <!-- TOTAL CLIENTES -->
        <div class="stat-card">
            <div class="stat-icon" style="background:#dbeafe; color:#3b82f6;">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number" style="color:#1b4f6e;" id="totalClientes">0</div>
                <div class="stat-label">Total Clientes Activos</div>
            </div>
        </div>
        
        <!-- PAGARON EN EL MES -->
        <div class="stat-card">
            <div class="stat-icon" style="background:#d1fae5; color:#10b981;">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number" style="color:#10b981;" id="pagaronCount">0</div>
                <div class="stat-label">Pagaron (Mes Actual)</div>
            </div>
        </div>
        
        <!-- PENDIENTES DEL MES -->
        <div class="stat-card">
            <div class="stat-icon" style="background:#fef3c7; color:#f59e0b;">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number" style="color:#f59e0b;" id="pendientesCount">0</div>
                <div class="stat-label">Pendientes (Mes Actual)</div>
            </div>
        </div>
        
        <!-- CORTADOS / SUSPENDIDOS -->
        <div class="stat-card">
            <div class="stat-icon" style="background:#fee2e2; color:#ef4444;">
                <i class="fas fa-pause-circle"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number" style="color:#ef4444;" id="cortadosCount">0</div>
                <div class="stat-label">Servicios Cortados</div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================= -->
<!-- GRÁFICOS -->
<!-- ============================================= -->
<!-- GRÁFICO DE DISTRIBUCIÓN DE PAGOS POR PORCENTAJE -->
<div class="chart-card">
    <div class="chart-header">
        <h4><i class="fas fa-chart-pie"></i> Distribución de Estado de Pagos</h4>
        <span id="updateTime" style="font-size:0.65rem; color:#94a3b8;">
            <i class="fas fa-clock"></i> Cargando...
        </span>
    </div>
    
    <div class="chart-body" style="position: relative; width: 100%; max-width: 260px; margin: 0 auto;">
        <canvas id="pagosChart"></canvas>
        
        <!-- TEXTO CENTRADO EN EL MEDIO DEL DOUGHNUT -->
        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; pointer-events: none;">
            <span style="font-size: 0.65rem; color: #64748b; font-weight: 600; text-transform: uppercase; display: block;">Total Muestra</span>
            <span style="font-size: 1.3rem; font-weight: 800; color: #0f2b3d; display: block; line-height: 1.1;" id="textoTotalClientesGrafico">
                0
            </span>
            <span style="font-size: 0.65rem; color: #1b4f6e; font-weight: 700; margin-top: 2px; display: block;">
                Clientes
            </span>
        </div>
    </div>

    <!-- LEYENDA CON CANTIDAD Y PORCENTAJE CALCUADO -->
    <div style="display:flex; justify-content:center; gap:1rem; margin-top:1rem; font-size:0.75rem; flex-wrap:wrap;">
        <span>
            <span style="display:inline-block; width:10px; height:10px; background:#10b981; border-radius:3px;"></span> 
            Pagaron: <strong id="lblPagaron">0 (0%)</strong>
        </span>
        <span>
            <span style="display:inline-block; width:10px; height:10px; background:#f59e0b; border-radius:3px;"></span> 
            Pendientes: <strong id="lblPendientes">0 (0%)</strong>
        </span>
        <span>
            <span style="display:inline-block; width:10px; height:10px; background:#ef4444; border-radius:3px;"></span> 
            Cortados: <strong id="lblCortados">0 (0%)</strong>
        </span>
    </div>
</div>

<div class="chart-card">
    <div class="chart-header" style="flex-direction: column; align-items: flex-start; gap: 4px;">
        <h3 style="font-size: 1.2rem; font-weight: 700; color: #1e293b; margin: 0;">Histórico de Recaudación por Servicios</h3>
        <div style="display: flex; justify-content: space-between; width: 100%; align-items: center; margin-top: 4px;">
            <div>
                <span id="precioPromedioActual" style="font-size: 1.4rem; font-weight: 800; color: #0f172a;">$0,00</span>
                <span style="font-size: 0.75rem; color: #64748b; display: block;">Recaudación del mes</span>
            </div>
            <span style="font-size: 0.8rem; font-weight: 600; color: #64748b;">Año: 2026</span>
        </div>
    </div>
    
    <div class="chart-body" style="position: relative; height: 280px; margin-top: 10px;">
        <canvas id="variacionPreciosChart"></canvas>
    </div>
</div>


<!-- CLIENTES POR BARRIO CON FILTRO Y PREVISUALIZACIÓN -->
<div class="chart-card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; flex-wrap: wrap; gap: 0.5rem;">
        <div style="display: flex; align-items: center; gap: 10px;">
            <h4 style="margin: 0;"><i class="fas fa-map-marker-alt"></i> Clientes por Barrio</h4>
            <!-- Botón + dinámico -->
            <a href="admin_cliente.php" id="btnVerMasBarrio" title="Ver listado completo en clientes" 
               style="background: #1b4f6e; color: white; width: 24px; height: 24px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; text-decoration: none; font-size: 0.75rem;">
                <i class="fas fa-plus"></i>
            </a>
        </div>

        <!-- Selector de Filtro -->
        <select id="selectBarrioFiltro" onchange="filtrarBarrio(this.value)" style="padding: 4px 8px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 0.8rem; background: white; color: #1e2a41; cursor: pointer;">
            <option value="todos">Todos los Barrios</option>
        </select>
    </div>

    <!-- Contenedor dinámico -->
    <div class="card-body" style="max-height: 320px; overflow-y: auto;">
        <div id="contenedorBarrios" style="display: flex; flex-direction: column; gap: 0.8rem;">
            <div style="text-align:center; padding:1rem; color:#94a3b8;">
                <i class="fas fa-spinner fa-spin"></i> Cargando barrios...
            </div>
        </div>
    </div>
</div>

        <!-- ============================================= -->
        <!-- FOOTER -->
        <!-- ============================================= -->
        <div class="footer">
            <div>© 2026 Chango Vision - Todos los derechos reservados</div>
            <div class="footer-status">
                <span><span class="status-dot"></span> Sistema Activo</span>
                <span><i class="fas fa-user-shield"></i> Administrador</span>
                <span class="update-time" id="updateTime">
                    <i class="fas fa-clock"></i> Actualizando...
                </span>
            </div>
        </div>
    </div>
</div>

<script>
let pagosChart = null;
let variacionChart = null;

async function cargarEstadisticas() {
    try {
        const response = await fetch('../controllers/get_estadisticas.php');
        const data = await response.json();
        
        if (!data.success) {
            console.error('Error:', data.error);
            return;
        }
        
        // 1. Actualizar tarjetas principales
        document.getElementById('totalClientes').textContent = data.total_clientes || 0;
        document.getElementById('pagaronCount').textContent = data.pagaron || 0;
        document.getElementById('pendientesCount').textContent = data.pendientes || 0;
        document.getElementById('cortadosCount').textContent = data.cortados || 0;
        
        // 2. Mostrar la recaudación del mes actual
        if (document.getElementById('precioPromedioActual')) {
            document.getElementById('precioPromedioActual').textContent = '$' + Number(data.total_ganancias || 0).toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }
        
        // 3. Hora de actualización
        if (document.getElementById('updateTime')) {
            document.getElementById('updateTime').innerHTML = '<i class="fas fa-clock"></i> ' + (data.fecha_actualizacion || '');
        }
        
        // --- 4. CÁLCULO DE PORCENTAJES Y RENDERIZADO DEL GRÁFICO (DOUGHNUT) ---
        const pagado = Number(data.pagaron || 0);
        const pendiente = Number(data.pendientes || 0);
        const cortado = Number(data.cortados || 0);
        const totalMuestra = pagado + pendiente + cortado;

        // Cálculo de porcentajes exactos
        const pctPagado = totalMuestra > 0 ? Math.round((pagado / totalMuestra) * 100) : 0;
        const pctPendiente = totalMuestra > 0 ? Math.round((pendiente / totalMuestra) * 100) : 0;
        const pctCortado = totalMuestra > 0 ? Math.round((cortado / totalMuestra) * 100) : 0;

        // Actualizar el valor central del gráfico con el total de clientes
        if (document.getElementById('textoTotalClientesGrafico')) {
            document.getElementById('textoTotalClientesGrafico').textContent = totalMuestra;
        }

        // Actualizar leyenda inferior con cantidades y porcentajes
        if (document.getElementById('lblPagaron')) {
            document.getElementById('lblPagaron').textContent = `${pagado} (${pctPagado}%)`;
        }
        if (document.getElementById('lblPendientes')) {
            document.getElementById('lblPendientes').textContent = `${pendiente} (${pctPendiente}%)`;
        }
        if (document.getElementById('lblCortados')) {
            document.getElementById('lblCortados').textContent = `${cortado} (${pctCortado}%)`;
        }

        const ctxPagos = document.getElementById('pagosChart').getContext('2d');
        if (pagosChart) {
            pagosChart.data.datasets[0].data = [pagado, pendiente, cortado];
            pagosChart.update();
        } else {
            pagosChart = new Chart(ctxPagos, {
                type: 'doughnut',
                data: {
                    labels: ['Pagaron', 'Pendientes', 'Cortados'],
                    datasets: [{
                        data: [pagado, pendiente, cortado],
                        backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
                        borderWidth: 0,
                        hoverOffset: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    cutout: '72%',
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const valor = context.raw || 0;
                                    const porcentaje = totalMuestra > 0 ? ((valor / totalMuestra) * 100).toFixed(1) : 0;
                                    return ` ${context.label}: ${porcentaje}% (${valor} clientes)`;
                                }
                            }
                        }
                    }
                }
            });
        }

       // --- 5. GRÁFICO DE PRECIOS: SÓLO BARRAS (SIN LÍNEA DE TENDENCIA) ---
        const ctxVariacion = document.getElementById('variacionPreciosChart').getContext('2d');

        function prepararDatasetsVariacion(datasetsOriginales) {
            const paleta = [
                { fondo: 'rgba(59, 130, 246, 0.78)', borde: '#2563eb' },
                { fondo: 'rgba(16, 185, 129, 0.78)', borde: '#059669' },
                { fondo: 'rgba(245, 158, 11, 0.80)', borde: '#d97706' },
                { fondo: 'rgba(139, 92, 246, 0.76)', borde: '#7c3aed' },
                { fondo: 'rgba(236, 72, 153, 0.76)', borde: '#db2777' },
                { fondo: 'rgba(20, 184, 166, 0.78)', borde: '#0f766e' }
            ];
            return (datasetsOriginales || []).map((ds, i) => ({
                ...ds,
                type: 'bar',
                backgroundColor: paleta[i % paleta.length].fondo,
                borderColor: paleta[i % paleta.length].borde,
                borderWidth: 1,
                borderRadius: 0,
                borderSkipped: false,
                maxBarThickness: 38,
                categoryPercentage: 0.78,
                barPercentage: 0.88
            }));
        }

        const datasetsVariacion = prepararDatasetsVariacion(data.datasets_servicios || []);
        if (variacionChart) {
            variacionChart.data.labels = data.meses || [];
            variacionChart.data.datasets = datasetsVariacion;
            variacionChart.update();
        } else {
            variacionChart = new Chart(ctxVariacion, {
                type: 'bar',
                data: {
                    labels: data.meses || ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
                    datasets: datasetsVariacion
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: { mode: 'index', intersect: false },
                    layout: { padding: { top: 8, right: 10, bottom: 2, left: 2 } },
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top',
                            align: 'start',
                            labels: {
                                usePointStyle: true,
                                pointStyle: 'circle',
                                boxWidth: 8,
                                boxHeight: 8,
                                padding: 16,
                                color: '#475569',
                                font: { family: 'Inter', size: 11, weight: '600' }
                            }
                        },
                        tooltip: {
                            backgroundColor: '#1e293b',
                            titleColor: '#ffffff',
                            bodyColor: '#f8fafc',
                            padding: 12,
                            cornerRadius: 10,
                            callbacks: {
                                label: function(context) {
                                    if (context.raw === null || context.raw === undefined) return context.dataset.label + ': sin datos';
                                    return context.dataset.label + ': $' + Number(context.raw).toLocaleString('es-AR', { maximumFractionDigits: 0 });
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            stacked: false,
                            grid: { display: false },
                            border: { display: false },
                            ticks: { font: { family: 'Inter', size: 11 }, color: '#64748b' }
                        },
                        y: {
                            beginAtZero: true,
                            border: { display: false, dash: [4, 4] },
                            grid: { color: 'rgba(148, 163, 184, 0.20)', drawTicks: false },
                            ticks: {
                                padding: 10,
                                font: { family: 'Inter', size: 11 },
                                color: '#64748b',
                                callback: function(value) { return '$' + Number(value).toLocaleString('es-AR'); }
                            }
                        }
                    }
                }
            });
        }

        // 6. Cargar barrios usando el nombre correcto de la función
        renderBarriosAdmin(data.clientes_por_barrio);

    } catch (error) {
        console.error('Error al cargar estadísticas:', error);
    }
}

// Renderizar la lista de barrios mostrando los primeros 6 clientes ordenados por barrio
function renderBarriosAdmin(barrios) {
    const container = document.getElementById('contenedorBarrios');
    const select = document.getElementById('selectBarrioFiltro');
    if (!container || !select) return;

    if (!barrios || barrios.length === 0) {
        container.innerHTML = `<p style="text-align:center; color:#94a3b8; padding:1rem;">No hay clientes registrados en barrios.</p>`;
        return;
    }

    select.innerHTML = '<option value="todos">Todos los Barrios</option>';
    let html = '';

    barrios.forEach(b => {
        select.innerHTML += `<option value="${b.id_barrio}">${b.barrio || 'Sin Barrio'}</option>`;

        html += `
            <div class="barrio-card-item" data-barrio-id="${b.id_barrio}" style="background: #f8fafd; border: 1px solid #e2e8f0; border-radius: 10px; padding: 0.85rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.6rem; border-bottom: 1px solid #edf2f7; padding-bottom: 6px;">
                    <span style="font-weight: 700; color: #0f2b3d; font-size: 0.9rem; display: flex; align-items: center; gap: 6px;">
                        <i class="fas fa-map-pin" style="color: #1b4f6e;"></i>
                        ${b.barrio || 'Sin Barrio'}
                    </span>
                    <span style="color: #64748b; font-weight: 600; font-size: 0.75rem; background: #e2e8f0; padding: 2px 8px; border-radius: 12px;">
                        ${b.cantidad} clientes
                    </span>
                </div>
                <div style="display: flex; flex-direction: column; gap: 4px;">
        `;

        // Previsualización de los primeros 6 clientes
        if (b.clientes && b.clientes.length > 0) {
            const primerosSeis = b.clientes.slice(0, 4);
            primerosSeis.forEach(cli => {
                html += `
                    <div style="display: flex; align-items: center; gap: 6px; font-size: 0.8rem; color: #334155; padding: 3px 0;">
                        <i class="fas fa-user" style="color: #94a3b8; font-size: 0.7rem;"></i>
                        <span>${cli.nombre} ${cli.apellido}</span>
                    </div>
                `;
            });
            if (b.clientes.length > 4) {
                html += `<span style="font-size: 0.72rem; color: #64748b; font-style: italic; margin-top: 2px;">Y ${b.clientes.length - 6} clientes más...</span>`;
            }
        } else {
            html += `<span style="font-size:0.75rem; color:#94a3b8;">Sin previsualización de clientes</span>`;
        }

        html += `
                </div>
            </div>
        `;
    });

    container.innerHTML = html;
}

// Filtrar tarjeta de barrio en pantalla y actualizar el enlace del botón más (+) 
function filtrarBarrio(idBarrio) {
    const items = document.querySelectorAll('.barrio-card-item');
    const btnMas = document.getElementById('btnVerMasBarrio');
    const urlBase = 'admin_cliente.php';

    // Si selecciona un barrio en particular, agrega el parámetro ?barrio=ID al botón +
    if (idBarrio === 'todos') {
        btnMas.href = urlBase;
    } else {
        btnMas.href = `${urlBase}?barrio=${idBarrio}`;
    }

    items.forEach(item => {
        if (idBarrio === 'todos' || item.getAttribute('data-barrio-id') === idBarrio) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    cargarEstadisticas();
    setInterval(cargarEstadisticas, 30000);
});
</script>

</body>
</html>