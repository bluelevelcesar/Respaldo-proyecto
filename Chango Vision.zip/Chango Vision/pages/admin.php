<?php
session_start();

// Verificar si está logueado y es admin
if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 1) {
    header('Location: ../login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';
include __DIR__ . '/../controllers/funcion_log.php';

$log = new SistemaLog($conexion);
// =============================================
// ESTADÍSTICAS PRINCIPALES
// =============================================

// 1. TOTAL DE CLIENTES
$sql_total_clientes = "SELECT COUNT(*) as total FROM cliente";
$result_total = mysqli_query($conexion, $sql_total_clientes);
$total_clientes_general = mysqli_fetch_assoc($result_total)['total'] ?? 0;

// 2. CLIENTES POR ESTADO DE PAGO
$sql_estados_pago = "SELECT estado_pago, COUNT(*) as total FROM cliente GROUP BY estado_pago";
$result_estados = mysqli_query($conexion, $sql_estados_pago);
$stats_pago = ['pagado' => 0, 'pendiente' => 0, 'suspendido' => 0];
while ($row = mysqli_fetch_assoc($result_estados)) {
    $estado = strtolower($row['estado_pago']);
    if (isset($stats_pago[$estado])) {
        $stats_pago[$estado] = $row['total'];
    }
}

// 3. CLIENTES POR ESTADO (Activo/Inactivo)
$sql_estado_cliente = "SELECT `estado`, COUNT(*) as total FROM cliente GROUP BY `estado`";
$result_estado_cliente = mysqli_query($conexion, $sql_estado_cliente);
$stats_estado = ['Activo' => 0, 'Inactivo' => 0];
while ($row = mysqli_fetch_assoc($result_estado_cliente)) {
    $stats_estado[$row['estado']] = $row['total'];
}

// 4. PORCENTAJE DE CLIENTES AL DÍA
$porcentaje_al_dia = 0;
if ($total_clientes_general > 0) {
    $porcentaje_al_dia = round(($stats_pago['pagado'] / $total_clientes_general) * 100);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Admin - Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../js/admin_cliente.js"></script>
   <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Inter', sans-serif; background: #f0f4f8; overflow-x: hidden; }

    .app-container { display: flex; min-height: 100vh; }

    /* ============================================= */
    /* SIDEBAR */
    /* ============================================= */
    .sidebar {
        width: 280px;
        background: linear-gradient(180deg, #0f2b3d 0%, #1b4f6e 100%);
        color: white;
        padding: 2rem 1.5rem;
        display: flex;
        flex-direction: column;
        position: fixed;
        height: 100vh;
        overflow-y: auto;
        z-index: 100;
    }

    .sidebar::-webkit-scrollbar { width: 4px; }
    .sidebar::-webkit-scrollbar-track { background: transparent; }
    .sidebar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.3); border-radius: 10px; }

    .logo-area {
        margin-bottom: 2rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid rgba(255,255,255,0.15);
    }

    .logo-area h2 {
        font-size: 1.5rem;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .logo-area h2 i { color: #60a5fa; }
    .logo-area span { font-size: 0.7rem; opacity: 0.6; display: block; margin-top: 4px; }

    .nav-section { margin-bottom: 1.5rem; }
    .nav-section-title {
        font-size: 0.65rem;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        opacity: 0.5;
        margin-bottom: 0.8rem;
        font-weight: 600;
    }

    .nav-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 0.7rem 1rem;
        border-radius: 12px;
        cursor: pointer;
        transition: all 0.2s;
        color: rgba(255,255,255,0.8);
        text-decoration: none;
        margin-bottom: 0.2rem;
        font-size: 0.9rem;
        border: none;
        background: transparent;
        width: 100%;
        text-align: left;
    }

    .nav-item:hover { background: rgba(255,255,255,0.1); color: white; }
    .nav-item.active { background: rgba(255,255,255,0.15); color: white; }
    .nav-item i { width: 22px; font-size: 1.1rem; text-align: center; color: rgba(255,255,255,0.6); }
    .nav-item:hover i, .nav-item.active i { color: white; }

    .nav-item .badge {
        background: #ef4444;
        color: white;
        padding: 1px 8px;
        border-radius: 20px;
        font-size: 0.6rem;
        font-weight: 700;
        margin-left: auto;
    }

    .nav-divider { border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 0.5rem 0 1rem 0; }

    /* ============================================= */
    /* MAIN CONTENT */
    /* ============================================= */
    .main-content {
        flex: 1;
        margin-left: 280px;
        padding: 2rem;
        min-height: 100vh;
    }

    .top-bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
        background: white;
        padding: 1rem 2rem;
        border-radius: 20px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
        flex-wrap: wrap;
        gap: 1rem;
    }

    .page-title { font-size: 1.3rem; font-weight: 700; color: #1e2a41; }
    .page-title i { color: #1b4f6e; margin-right: 10px; }

    .user-info {
        display: flex;
        align-items: center;
        gap: 12px;
        font-size: 0.9rem;
        color: #1e2a41;
    }
    .user-avatar {
        width: 40px;
        height: 40px;
        background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        color: white;
        font-size: 1rem;
    }

    /* ============================================= */
    /* ESTADÍSTICAS CON ICONOS */
    /* ============================================= */
    .stats-container {
        padding: 0.5rem 0 0.5rem 0;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 1rem;
    }

    .stat-card {
        background: white;
        padding: 1rem 1.2rem;
        border-radius: 14px;
        border: 1px solid #e9eef3;
        display: flex;
        align-items: center;
        gap: 1rem;
        transition: all 0.3s ease;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }

    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }

    .stat-icon {
        width: 44px;
        height: 44px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        flex-shrink: 0;
    }

    .stat-info {
        flex: 1;
    }

    .stat-number {
        font-size: 1.5rem;
        font-weight: 700;
        line-height: 1.2;
    }

    .stat-label {
        font-size: 0.65rem;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 600;
    }

    .stat-trend {
        font-size: 0.6rem;
        color: #94a3b8;
        margin-top: 2px;
    }

    .stat-trend i {
        margin-right: 2px;
    }

    /* ============================================= */
    /* GRÁFICOS */
    /* ============================================= */
    .charts-container {
        padding: 0.5rem 0 1rem 0;
    }

    .charts-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1.5rem;
    }

    .chart-card {
        background: white;
        border-radius: 16px;
        border: 1px solid #e9eef3;
        padding: 1.2rem;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        transition: all 0.3s ease;
    }

    .chart-card:hover {
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }

    .chart-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
    }

    .chart-header h4 {
        font-size: 0.85rem;
        font-weight: 700;
        color: #0f2b3d;
        margin: 0;
    }

    .chart-header h4 i {
        color: #1b4f6e;
        margin-right: 6px;
    }

    .chart-body {
        display: flex;
        justify-content: center;
        padding: 0.5rem 0;
    }

    .chart-body canvas {
        max-width: 100%;
        max-height: 250px;
    }

    .chart-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 0.8rem;
        padding-top: 0.8rem;
        border-top: 1px solid #f1f5f9;
        flex-wrap: wrap;
        gap: 0.5rem;
    }

    .legend-item {
        font-size: 0.65rem;
        color: #64748b;
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .legend-color {
        display: inline-block;
        width: 12px;
        height: 12px;
        border-radius: 4px;
    }

    .total-ganancias {
        font-size: 0.8rem;
        font-weight: 700;
        color: #1b4f6e;
    }

    /* ============================================= */
    /* CLIENTES POR BARRIO */
    /* ============================================= */
    .barrios-container {
        padding: 0 0 1.5rem 0;
    }

    .barrios-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.8rem;
    }

    .barrios-header h4 {
        font-size: 0.85rem;
        font-weight: 700;
        color: #0f2b3d;
        margin: 0;
    }

    .barrios-header h4 i {
        color: #1b4f6e;
        margin-right: 6px;
    }

    .barrios-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 0.8rem;
    }

    .barrio-card {
        background: #f8fafd;
        padding: 0.7rem 1rem;
        border-radius: 10px;
        border: 1px solid #e9eef3;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: all 0.3s ease;
    }

    .barrio-card:hover {
        background: #f1f5f9;
        transform: translateX(3px);
    }

    .barrio-nombre {
        font-weight: 500;
        color: #0f2b3d;
        font-size: 0.8rem;
    }

    .barrio-cantidad {
        font-weight: 700;
        color: #1b4f6e;
        font-size: 0.85rem;
    }

    .total-label {
        font-weight: 400;
        color: #94a3b8;
        font-size: 0.6rem;
    }

    /* ============================================= */
    /* FOOTER */
    /* ============================================= */
    .footer {
        margin-top: 2rem;
        padding-top: 1rem;
        text-align: center;
        font-size: 0.75rem;
        color: #94a3b8;
        border-top: 1px solid #e2e8f0;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 0.5rem;
    }

    .status-dot {
        display: inline-block;
        width: 8px;
        height: 8px;
        background: #10b981;
        border-radius: 50%;
        margin-right: 6px;
        animation: pulse-dot 2s infinite;
    }

    @keyframes pulse-dot { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }

    .update-time { font-size: 0.7rem; color: #94a3b8; }

    /* ============================================= */
    /* RESPONSIVE */
    /* ============================================= */
    @media (max-width: 992px) {
        .charts-grid {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 768px) {
        .sidebar { display: none; }
        .main-content { margin-left: 0; padding: 1rem; }
        .stats-grid { grid-template-columns: 1fr 1fr; }
        .charts-grid { grid-template-columns: 1fr; }
        .barrios-grid { grid-template-columns: 1fr 1fr; }
        .top-bar { flex-direction: column; align-items: stretch; text-align: center; }
        .user-info { justify-content: center; }
        .footer { flex-direction: column; text-align: center; }
    }

    @media (max-width: 600px) {
        .stats-grid { grid-template-columns: 1fr; }
        .barrios-grid { grid-template-columns: 1fr; }
        .stat-card { padding: 0.7rem 0.8rem; }
        .stat-icon { width: 36px; height: 36px; font-size: 1rem; }
        .stat-number { font-size: 1.2rem; }
    }
</style>
</head>
<body>

<div class="app-container">
    <!-- ============================================= -->
    <!-- SIDEBAR -->
    <!-- ============================================= -->
    <div class="sidebar">
        <div class="logo-area">
            <h2><i class="fas fa-tv"></i> Chango Vision</h2>
            <span>Panel de Administración</span>
        </div>

        

        <div class="nav-section">
            <div class="nav-section-title">Gestión</div>
            <a href="admin_cliente.php" class="nav-item">
                <i class="fas fa-users"></i>
                <span>Clientes</span>
            </a>
            <a href="soporte_tecnico.php" class="nav-item">
                <i class="fas fa-headset"></i>
                <span>Servicios Técnicos</span>
            </a>
            

             <a href="reportes_pagos.php" class="nav-item">
                <i class="fas fa-file-alt"></i>
                <span>Reportes y Pagos</span>
            </a>
            
        </div>

        <div class="nav-section">
            <div class="nav-section-title">Seguridad</div>
            <a href="cambiar_datos.php" class="nav-item">
                <i class="fas fa-user-cog"></i>
                <span>Cambiar Datos</span>
            </a>
            <a href="../logout.php" class="nav-item" onclick="return confirm('¿Cerrar sesión?')">
                <i class="fas fa-sign-out-alt"></i>
                <span>Cerrar Sesión</span>
            </a>
        </div>
    </div>

    <!-- ============================================= -->
    <!-- MAIN CONTENT -->
    <!-- ============================================= -->
    <div class="main-content">
        <div class="top-bar">
            <div class="page-title">
                <i class="fas fa-chart-pie"></i> Panel Principal
            </div>
            <div class="user-info">
                <i class="fas fa-user-shield" style="color:#1b4f6e;"></i>
                <span><?= htmlspecialchars($_SESSION['usuario'] ?? 'Administrador') ?></span>
                <div class="user-avatar">
                    <?= strtoupper(substr($_SESSION['usuario'] ?? 'A', 0, 1)) ?>
                </div>
            </div>
        </div>

     <!-- ============================================= -->
<!-- TARJETAS DE ESTADÍSTICAS -->
<!-- ============================================= -->
<div class="stats-container">
    <div class="stats-grid">
        <!-- TOTAL CLIENTES -->
        <div class="stat-card">
            <div class="stat-icon" style="background:#dbeafe; color:#3b82f6;">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number" style="color:#1b4f6e;" id="totalClientes">0</div>
                <div class="stat-label">Total Clientes</div>
            </div>
        </div>
        
        <!-- PAGARON -->
        <div class="stat-card">
            <div class="stat-icon" style="background:#d1fae5; color:#10b981;">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number" style="color:#10b981;" id="pagaronCount">0</div>
                <div class="stat-label">Pagaron</div>
            </div>
        </div>
        
        <!-- PENDIENTES -->
        <div class="stat-card">
            <div class="stat-icon" style="background:#fef3c7; color:#f59e0b;">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number" style="color:#f59e0b;" id="pendientesCount">0</div>
                <div class="stat-label">Pendientes</div>
            </div>
        </div>
        
        <!-- CORTADOS -->
        <div class="stat-card">
            <div class="stat-icon" style="background:#fee2e2; color:#ef4444;">
                <i class="fas fa-pause-circle"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number" style="color:#ef4444;" id="cortadosCount">0</div>
                <div class="stat-label">Cortados</div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================= -->
<!-- GRÁFICOS -->
<!-- ============================================= -->
<div class="charts-container">
    <div class="charts-grid">
        <!-- GRÁFICO DE PAGOS -->
        <div class="chart-card">
            <div class="chart-header">
                <h4><i class="fas fa-chart-pie"></i> Distribución de Pagos</h4>
                <span id="updateTime" style="font-size:0.65rem; color:#94a3b8;">
                    <i class="fas fa-clock"></i> Cargando...
                </span>
            </div>
            <div class="chart-body">
                <canvas id="pagosChart" width="300" height="250"></canvas>
            </div>
            <div class="chart-footer">
                <span class="legend-item"><span class="legend-color" style="background:#10b981;"></span> Pagaron</span>
                <span class="legend-item"><span class="legend-color" style="background:#f59e0b;"></span> Pendientes</span>
                <span class="legend-item"><span class="legend-color" style="background:#ef4444;"></span> Cortados</span>
            </div>
        </div>

        <!-- GRÁFICO DE GANANCIAS -->
        <div class="chart-card">
            <div class="chart-header">
                <h4><i class="fas fa-chart-bar"></i> Recaudación Mensual</h4>
                <span id="gananciasMes" style="font-size:0.65rem; color:#10b981; font-weight:600;">
                    Este mes: $0
                </span>
            </div>
            <div class="chart-body">
                <canvas id="gananciasChart" width="300" height="250"></canvas>
            </div>
            <div class="chart-footer">
                <span class="legend-item"><span class="legend-color" style="background:#1b4f6e;"></span> Recaudación ($)</span>
                <span class="total-ganancias" id="totalGanancias">Total: $0</span>
            </div>
        </div>
    </div>
</div>

<!-- ============================================= -->
<!-- CLIENTES POR BARRIO -->
<!-- ============================================= -->
<div class="barrios-container">
    <div class="barrios-header">
        <h4><i class="fas fa-map-marker-alt"></i> Clientes por Barrio</h4>
    </div>
    <div class="barrios-grid" id="barriosContainer">
        <div style="text-align:center; padding:1rem; color:#94a3b8; grid-column: 1 / -1;">
            <i class="fas fa-spinner fa-spin"></i> Cargando barrios...
        </div>
    </div>
</div>

        <!-- ============================================= -->
        <!-- FOOTER -->
        <!-- ============================================= -->
        <div class="footer">
            <div>© 2026 Chango Vision - Todos los derechos reservados</div>
            <div class="footer-status">
                <span><span class="status-dot"></span> Sistema Activo</span>
                <span><i class="fas fa-user-shield"></i> Administrador</span>
                <span class="update-time" id="updateTime">
                    <i class="fas fa-clock"></i> Actualizando...
                </span>
            </div>
        </div>
    </div>
</div>

<!-- ============================================= -->
<!-- SCRIPTS -->
<!-- ============================================= -->
<script>
let pagosChart = null;
let gananciasChart = null;

// =============================================
// CARGAR ESTADÍSTICAS
// =============================================
async function cargarEstadisticas() {
    try {
        const response = await fetch('../controllers/get_estadisticas.php');
        const data = await response.json();
        
        if (!data.success) {
            console.error('Error:', data.error);
            return;
        }
        
        // Actualizar tarjetas
        document.getElementById('totalClientes').textContent = data.total_clientes || 0;
        document.getElementById('pagaronCount').textContent = data.pagaron || 0;
        document.getElementById('pendientesCount').textContent = data.pendientes || 0;
        document.getElementById('cortadosCount').textContent = data.cortados || 0;
        document.getElementById('totalGanancias').textContent = '$' + (data.total_ganancias || 0).toLocaleString();
        
        // Calcular ganancias del mes actual
        const gananciasMes = data.ganancias_mensuales ? data.ganancias_mensuales[data.ganancias_mensuales.length - 1] || 0 : 0;
        document.getElementById('gananciasMes').textContent = 'Este mes: $' + gananciasMes.toLocaleString();
        
        // Actualizar hora
        document.getElementById('updateTime').innerHTML = '<i class="fas fa-clock"></i> ' + (data.fecha_actualizacion || 'Actualizando...');
        
        // Actualizar gráfico de pagos
        const ctxPagos = document.getElementById('pagosChart').getContext('2d');
        if (pagosChart) {
            pagosChart.data.datasets[0].data = [data.pagaron || 0, data.pendientes || 0, data.cortados || 0];
            pagosChart.update();
        } else {
            pagosChart = new Chart(ctxPagos, {
                type: 'pie',
                data: {
                    labels: ['Pagaron', 'Pendientes', 'Cortados'],
                    datasets: [{
                        data: [data.pagaron || 0, data.pendientes || 0, data.cortados || 0],
                        backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: { position: 'bottom', labels: { font: { size: 11 } } }
                    }
                }
            });
        }
        
        // Actualizar gráfico de ganancias
        const ctxGanancias = document.getElementById('gananciasChart').getContext('2d');
        if (gananciasChart) {
            gananciasChart.data.datasets[0].data = data.ganancias_mensuales || [0, 0, 0, 0, 0, 0];
            gananciasChart.update();
        } else {
            gananciasChart = new Chart(ctxGanancias, {
                type: 'bar',
                data: {
                    labels: data.meses || ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun'],
                    datasets: [{
                        label: 'Recaudación ($)',
                        data: data.ganancias_mensuales || [0, 0, 0, 0, 0, 0],
                        backgroundColor: '#1b4f6e',
                        borderRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: { position: 'top' }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return '$' + value.toLocaleString();
                                }
                            }
                        }
                    }
                }
            });
        }
        
        // Actualizar barrios
        const barriosContainer = document.getElementById('barriosContainer');
        if (data.clientes_por_barrio && data.clientes_por_barrio.length > 0) {
            let html = '';
            data.clientes_por_barrio.forEach(barrio => {
                const nombre = barrio.barrio || 'Sin barrio';
                const cantidad = barrio.cantidad || 0;
                html += `
                    <div class="barrio-card">
                        <span class="barrio-nombre">📍 ${nombre}</span>
                        <span class="barrio-cantidad">${cantidad} <span class="total-label">clientes</span></span>
                    </div>
                `;
            });
            barriosContainer.innerHTML = html;
        } else {
            barriosContainer.innerHTML = `
                <div style="text-align:center; padding:1rem; color:#94a3b8; grid-column: 1 / -1;">
                    <i class="fas fa-info-circle"></i> No hay clientes registrados
                </div>
            `;
        }
        
    } catch (error) {
        console.error('Error al cargar estadísticas:', error);
    }
}

// =============================================
// ACTUALIZAR HORA
// =============================================
function actualizarHora() {
    const ahora = new Date();
    const fecha = ahora.toLocaleDateString('es-AR');
    const hora = ahora.toLocaleTimeString('es-AR');
    document.getElementById('updateTime').innerHTML = `<i class="fas fa-clock"></i> ${fecha} ${hora}`;
}

// =============================================
// INICIALIZAR
// =============================================
document.addEventListener('DOMContentLoaded', function() {
    cargarEstadisticas();
    actualizarHora();
    
    // Actualizar cada 30 segundos
    setInterval(cargarEstadisticas, 30000);
    setInterval(actualizarHora, 30000);
});
</script>

</body>
</html>