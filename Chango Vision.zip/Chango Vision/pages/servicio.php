<?php
session_start();

// Verificar que el usuario esté logueado
if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../login.php');
    exit;
}

// ✅ PERMITIR ACCESO A ADMINISTRADOR DE RED (4) Y ADMINISTRADOR (1)
$id_rol = $_SESSION['id_rol'] ?? 0;
if ($id_rol != 4 && $id_rol != 1) {
    header('Location: ../login.php');
    exit;
}
include __DIR__ . '/../config/conexion.php';

$mensaje = '';
$mensaje_tipo = '';

// PROCESAR ACCIONES
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';

    // CREAR TIPO
    if ($accion === 'crear_tipo') {
        $nombre = trim($_POST['nombre']);
        $descripcion = trim($_POST['descripcion']);
        $precio_base = floatval($_POST['precio_base']);
        $dia_facturacion = intval($_POST['dia_facturacion']);
        $dia_corte = intval($_POST['dia_corte']);

        $stmt = $conexion->prepare("INSERT INTO tipo_servicio (nombre, descripcion, precio_base, dia_facturacion, dia_corte, estado) VALUES (?, ?, ?, ?, ?, 'Activo')");
        $stmt->bind_param("ssdii", $nombre, $descripcion, $precio_base, $dia_facturacion, $dia_corte);
        
        if ($stmt->execute()) {
            $_SESSION['mensaje'] = "✅ Tipo de servicio creado correctamente";
            $_SESSION['mensaje_tipo'] = "success";
        } else {
            $_SESSION['mensaje'] = "❌ Error: " . $conexion->error;
            $_SESSION['mensaje_tipo'] = "error";
        }
        header("Location: servicio.php");
        exit;
    }

    // EDITAR TIPO
    if ($accion === 'editar_tipo') {
        $id_tipo = intval($_POST['id_tipo']);
        $nombre = trim($_POST['nombre']);
        $descripcion = trim($_POST['descripcion']);
        $precio_base = floatval($_POST['precio_base']);
        $dia_facturacion = intval($_POST['dia_facturacion']);
        $dia_corte = intval($_POST['dia_corte']);
        $estado = $_POST['estado'];

        $stmt = $conexion->prepare("UPDATE tipo_servicio SET nombre=?, descripcion=?, precio_base=?, dia_facturacion=?, dia_corte=?, estado=? WHERE id_tipo=?");
        $stmt->bind_param("ssdiisi", $nombre, $descripcion, $precio_base, $dia_facturacion, $dia_corte, $estado, $id_tipo);
        
        if ($stmt->execute()) {
            $_SESSION['mensaje'] = "✅ Tipo actualizado correctamente";
            $_SESSION['mensaje_tipo'] = "success";
        } else {
            $_SESSION['mensaje'] = "❌ Error: " . $conexion->error;
            $_SESSION['mensaje_tipo'] = "error";
        }
        header("Location: servicio.php");
        exit;
    }

    // ELIMINAR TIPO
    if ($accion === 'eliminar_tipo') {
        $id_tipo = intval($_POST['id_tipo']);
        
        $check = $conexion->query("SELECT COUNT(*) as total FROM servicio WHERE id_tipo = $id_tipo");
        $row = $check->fetch_assoc();
        if ($row['total'] > 0) {
            $_SESSION['mensaje'] = "❌ No se puede eliminar. Tiene {$row['total']} servicio(s) asignado(s).";
            $_SESSION['mensaje_tipo'] = "error";
        } else {
            $stmt = $conexion->prepare("DELETE FROM tipo_servicio WHERE id_tipo = ?");
            $stmt->bind_param("i", $id_tipo);
            if ($stmt->execute()) {
                $_SESSION['mensaje'] = "✅ Tipo eliminado correctamente";
                $_SESSION['mensaje_tipo'] = "success";
            } else {
                $_SESSION['mensaje'] = "❌ Error: " . $conexion->error;
                $_SESSION['mensaje_tipo'] = "error";
            }
        }
        header("Location: servicio.php");
        exit;
    }
}

// Obtener tipos
$tipos = $conexion->query("SELECT * FROM tipo_servicio ORDER BY id_tipo DESC")->fetch_all(MYSQLI_ASSOC);
$mensaje = $_SESSION['mensaje'] ?? '';
$mensaje_tipo = $_SESSION['mensaje_tipo'] ?? '';
unset($_SESSION['mensaje'], $_SESSION['mensaje_tipo']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tipos de Servicio - Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background: #f0f4f8; padding: 2rem; }
        .container { max-width: 1200px; margin: 0 auto; background: white; border-radius: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); overflow: hidden; }
        .header { background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white; padding: 1.5rem 2rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; }
        .header h1 { font-size: 1.5rem; display: flex; align-items: center; gap: 12px; }
        .btn-volver { background: #6c757d; color: white; padding: 0.7rem 1.5rem; border-radius: 40px; text-decoration: none; font-weight: 600; transition: 0.3s; }
        .btn-volver:hover { background: #5a6268; }
        .btn-primary { background: linear-gradient(135deg, #1b4f6e, #0f2b3d); color: white; border: none; padding: 0.7rem 1.5rem; border-radius: 10px; cursor: pointer; font-weight: 600; transition: 0.3s; }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
        .btn-edit { background: #f59e0b; color: white; border: none; padding: 0.3rem 0.7rem; border-radius: 6px; cursor: pointer; }
        .btn-edit:hover { background: #d97706; }
        .btn-delete { background: #ef4444; color: white; border: none; padding: 0.3rem 0.7rem; border-radius: 6px; cursor: pointer; }
        .btn-delete:hover { background: #dc2626; }
        .card { background: white; border-radius: 20px; padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; padding-bottom: 0.75rem; border-bottom: 2px solid #eef2f6; flex-wrap: wrap; gap: 0.5rem; }
        .card-header h2 { font-size: 1.2rem; color: #1e2a41; display: flex; align-items: center; gap: 8px; }
        .form-group { margin-bottom: 1rem; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: 700; color: #1b4f6e; margin-bottom: 0.3rem; }
        .form-group label .obligatorio { color: #ef4444; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 0.7rem; border: 1.5px solid #dce5ec; border-radius: 12px; font-size: 0.9rem; transition: 0.3s; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: #1b4f6e; box-shadow: 0 0 0 3px rgba(27,79,110,0.1); }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        .info-text { font-size: 0.65rem; color: #64748b; margin-top: 3px; }
        .table-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #0f2b3d; color: white; padding: 10px; text-align: left; font-size: 0.75rem; text-transform: uppercase; }
        td { padding: 10px; border-bottom: 1px solid #e2e8f0; font-size: 0.85rem; }
        tr:hover { background: #f8fafc; }
        .badge { display: inline-block; padding: 2px 10px; border-radius: 30px; font-size: 0.7rem; font-weight: 600; }
        .badge-activo { background: #d1fae5; color: #065f46; }
        .badge-inactivo { background: #fee2e2; color: #991b1b; }
        .toast { position: fixed; bottom: 20px; right: 20px; padding: 12px 20px; border-radius: 10px; color: white; font-weight: 600; z-index: 9999; animation: slideIn 0.3s ease; }
        .toast.success { background: #10b981; }
        .toast.error { background: #ef4444; }
        @keyframes slideIn { from { transform: translateX(100px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; visibility: hidden; opacity: 0; transition: 0.2s; }
        .modal-overlay.active { visibility: visible; opacity: 1; }
        .modal-container { background: white; width: 90%; max-width: 500px; border-radius: 20px; overflow: hidden; }
        .modal-header { background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white; padding: 1rem 1.5rem; display: flex; justify-content: space-between; align-items: center; }
        .modal-header h3 { font-size: 1.1rem; display: flex; align-items: center; gap: 8px; }
        .modal-body { padding: 1.5rem; }
        .close-modal { background: none; border: none; font-size: 1.5rem; cursor: pointer; color: white; }
        @media (max-width: 768px) { body { padding: 1rem; } .form-row { grid-template-columns: 1fr; } }
    </style>
    <link rel="stylesheet" href="../css/responsive_global.css">
</head>
<body>
<div class="container">
    <?php
// =============================================
// ✅ DETERMINAR URL DE RETORNO SEGÚN EL ROL
// =============================================
$url_volver = ($id_rol == 1) ? 'admin.php' : 'admin_red.php';
?>

<div class="header">
    <h1><i class="fas fa-tags"></i> Tipos de Servicio</h1>
    <a href="<?= $url_volver ?>" class="btn-volver"><i class="fas fa-arrow-left"></i> Volver</a>
</div>

    <?php if ($mensaje): ?>
        <div style="padding: 1rem 2rem 0 2rem;">
            <div class="toast <?= $mensaje_tipo ?>" style="position:static; animation:none; margin:0;">
                <?= $mensaje ?>
            </div>
        </div>
    <?php endif; ?>

    <div style="padding: 1.5rem;">
        <!-- FORMULARIO CREAR -->
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-plus-circle"></i> Nuevo Tipo de Servicio</h2>
                <small style="color:#64748b;">Define los servicios que ofreces</small>
            </div>
            <form method="POST">
                <input type="hidden" name="accion" value="crear_tipo">
                <div class="form-group">
                    <label>Nombre <span class="obligatorio">*</span></label>
                    <input type="text" name="nombre" placeholder="Ej: Internet Premium" required>
                </div>
                <div class="form-group">
                    <label>Descripción</label>
                    <textarea name="descripcion" placeholder="Descripción..." rows="2"></textarea>
                </div>
                <div class="form-group">
                    <label>Precio Base <span class="obligatorio">*</span></label>
                    <input type="number" name="precio_base" placeholder="30000" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Día de Facturación <span class="obligatorio">*</span></label>
                        <select name="dia_facturacion" required>
                            <?php for ($i = 1; $i <= 31; $i++): ?>
                                <option value="<?= $i ?>" <?= $i == 15 ? 'selected' : '' ?>>Día <?= $i ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Día de Corte <span class="obligatorio">*</span></label>
                        <select name="dia_corte" required>
                            <?php for ($i = 1; $i <= 31; $i++): ?>
                                <option value="<?= $i ?>" <?= $i == 20 ? 'selected' : '' ?>>Día <?= $i ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn-primary" style="width:100%"><i class="fas fa-save"></i> Guardar</button>
            </form>
        </div>

        <!-- TABLA -->
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-list"></i> Tipos de Servicio</h2>
                <button class="btn-primary" onclick="location.reload()"><i class="fas fa-sync-alt"></i> Actualizar</button>
            </div>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr><th>ID</th><th>Nombre</th><th>Descripción</th><th>Precio</th><th>Fact.</th><th>Corte</th><th>Estado</th><th>Acciones</th></tr>
                    </thead>
                    <tbody>
                        <?php if (empty($tipos)): ?>
                            <tr><td colspan="8" style="text-align:center; padding:2rem;">No hay tipos registrados</td></tr>
                        <?php else: ?>
                            <?php foreach ($tipos as $t): ?>
                            <tr>
                                <td><?= $t['id_tipo'] ?></td>
                                <td><strong><?= htmlspecialchars($t['nombre']) ?></strong></td>
                                <td><?= htmlspecialchars($t['descripcion'] ?? '-') ?></td>
                                <td>$<?= number_format($t['precio_base'], 0, ',', '.') ?></td>
                                <td>Día <?= $t['dia_facturacion'] ?></td>
                                <td>Día <?= $t['dia_corte'] ?></td>
                                <td><span class="badge <?= $t['estado'] == 'Activo' ? 'badge-activo' : 'badge-inactivo' ?>"><?= $t['estado'] ?></span></td>
                                <td>
                                    <button class="btn-edit" onclick='editarTipo(<?= json_encode($t) ?>)'><i class="fas fa-edit"></i></button>
                                    <button class="btn-delete" onclick='eliminarTipo(<?= $t['id_tipo'] ?>)'><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- MODAL EDITAR -->
<div id="modalEditar" class="modal-overlay">
    <div class="modal-container">
        <div class="modal-header">
            <h3><i class="fas fa-edit"></i> Editar Tipo</h3>
            <button class="close-modal" onclick="cerrarModal()">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <input type="hidden" name="accion" value="editar_tipo">
                <input type="hidden" name="id_tipo" id="editId">
                <div class="form-group">
                    <label>Nombre</label>
                    <input type="text" name="nombre" id="editNombre" required>
                </div>
                <div class="form-group">
                    <label>Descripción</label>
                    <textarea name="descripcion" id="editDescripcion" rows="2"></textarea>
                </div>
                <div class="form-group">
                    <label>Precio</label>
                    <input type="number" name="precio_base" id="editPrecio" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Facturación</label>
                        <select name="dia_facturacion" id="editFacturacion">
                            <?php for ($i = 1; $i <= 31; $i++): ?>
                                <option value="<?= $i ?>">Día <?= $i ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Corte</label>
                        <select name="dia_corte" id="editCorte">
                            <?php for ($i = 1; $i <= 31; $i++): ?>
                                <option value="<?= $i ?>">Día <?= $i ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Estado</label>
                    <select name="estado" id="editEstado">
                        <option value="Activo">Activo</option>
                        <option value="Inactivo">Inactivo</option>
                    </select>
                </div>
                <button type="submit" class="btn-primary" style="width:100%"><i class="fas fa-save"></i> Actualizar</button>
            </form>
        </div>
    </div>
</div>

<form id="formEliminar" method="POST" style="display:none;">
    <input type="hidden" name="accion" value="eliminar_tipo">
    <input type="hidden" name="id_tipo" id="eliminarId">
</form>

<script>
    <?php if ($mensaje): ?>
        mostrarToast('<?= $mensaje ?>', '<?= $mensaje_tipo ?>');
    <?php endif; ?>

    function mostrarToast(mensaje, tipo) {
        const toast = document.createElement('div');
        toast.className = `toast ${tipo}`;
        toast.innerHTML = `<i class="fas ${tipo === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i> ${mensaje}`;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    }

    function editarTipo(tipo) {
        document.getElementById('editId').value = tipo.id_tipo;
        document.getElementById('editNombre').value = tipo.nombre;
        document.getElementById('editDescripcion').value = tipo.descripcion || '';
        document.getElementById('editPrecio').value = tipo.precio_base;
        document.getElementById('editFacturacion').value = tipo.dia_facturacion || 15;
        document.getElementById('editCorte').value = tipo.dia_corte || 20;
        document.getElementById('editEstado').value = tipo.estado || 'Activo';
        document.getElementById('modalEditar').classList.add('active');
    }

    function eliminarTipo(id) {
        if (confirm('¿Eliminar este tipo de servicio?')) {
            document.getElementById('eliminarId').value = id;
            document.getElementById('formEliminar').submit();
        }
    }

    function cerrarModal() {
        document.getElementById('modalEditar').classList.remove('active');
    }

    document.getElementById('modalEditar').addEventListener('click', function(e) {
        if (e.target === this) cerrarModal();
    });
</script>
</body>
</html>