<?php
// pages/clientes_a_cortar.php
session_start();

if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 3) {
    header('Location: login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';
include __DIR__ . '/../controllers/verificar_vencimientos.php';
include __DIR__ . '/../controllers/verificar_notificaciones.php';

verificarYProcesarVencimientos($conexion);

$clientes_pendientes = obtenerListaClientesPendientes($conexion);
$total = count($clientes_pendientes);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes a Cortar - Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #f0f4f8; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; }
        .header { background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white; padding: 20px; border-radius: 15px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
        .header h1 { font-size: 1.3rem; display: flex; align-items: center; gap: 10px; }
        .badge { background: #ef4444; color: white; padding: 2px 10px; border-radius: 30px; font-size: 0.7rem; }
        .btn-volver { background: #6c757d; color: white; padding: 8px 20px; border-radius: 30px; text-decoration: none; font-size: 0.8rem; display: inline-flex; align-items: center; gap: 6px; }
        .btn-volver:hover { background: #5a6268; }
        .cliente { background: white; padding: 15px; margin: 10px 0; border-left: 4px solid #ef4444; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .cliente .nombre { font-weight: 600; font-size: 1.1rem; }
        .cliente .dir { font-size: 0.85rem; color: #64748b; margin-top: 4px; }
        .cliente .tel { font-size: 0.85rem; color: #64748b; }
        .cliente .servicio { font-size: 0.75rem; color: #64748b; margin-top: 4px; }
        .empty { text-align: center; padding: 40px; color: #94a3b8; }
        .empty i { font-size: 2rem; display: block; margin-bottom: 10px; }
        .footer { text-align: center; margin-top: 20px; font-size: 0.7rem; color: #94a3b8; }
        .actions { margin-top: 10px; display: flex; gap: 8px; flex-wrap: wrap; }
        .btn-cortar { background: #ef4444; color: white; border: none; padding: 6px 14px; border-radius: 20px; font-size: 0.7rem; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; }
        .btn-cortar:hover { background: #dc2626; }
        .btn-contactar { background: #0a4b7a; color: white; border: none; padding: 6px 14px; border-radius: 20px; font-size: 0.7rem; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; }
        .btn-contactar:hover { background: #0a2b4e; }
        .btn-pdf { background: #d97706; color: white; border: none; padding: 6px 14px; border-radius: 20px; font-size: 0.7rem; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; }
        .btn-pdf:hover { background: #b45309; }
        @media (max-width: 768px) { .header { flex-direction: column; text-align: center; } }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1><i class="fas fa-cut"></i> Clientes a Cortar <span class="badge"><?= $total ?></span></h1>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <a href="tecnicos_notificaciones.php" class="btn-volver"><i class="fas fa-arrow-left"></i> Volver</a>
        </div>
    </div>

    <?php if ($total == 0): ?>
        <div class="empty">
            <i class="fas fa-check-circle" style="color: #10b981;"></i>
            No hay clientes pendientes de corte
        </div>
    <?php else: ?>
        <?php foreach ($clientes_pendientes as $c): ?>
            <div class="cliente">
                <div class="nombre"><i class="fas fa-user"></i> <?= htmlspecialchars($c['nombre']) ?></div>
                <div class="dir"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($c['direccion']) ?></div>
                <div class="tel"><i class="fas fa-phone"></i> <?= htmlspecialchars($c['telefono'] ?? 'Sin teléfono') ?></div>
                <div class="servicio"><i class="fas fa-wifi"></i> <?= htmlspecialchars($c['servicio']) ?></div>
                <div class="actions">
                    <button class="btn-cortar" onclick="cortarCliente(<?= $c['id'] ?>, '<?= htmlspecialchars($c['nombre']) ?>')">
                        <i class="fas fa-power-off"></i> Cortar servicio
                    </button>
                    <button class="btn-contactar" onclick="contactarCliente(<?= $c['id'] ?>, '<?= htmlspecialchars($c['nombre']) ?>', '<?= htmlspecialchars($c['telefono'] ?? '') ?>')">
                        <i class="fas fa-phone"></i> Contactar
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <div class="footer">
        <i class="fas fa-info-circle"></i> Los clientes aparecen aquí cuando no pagan dentro del período de cobro
    </div>
</div>

<script>
    function cortarCliente(id, nombre) {
        if (confirm(`¿Cortar el servicio de "${nombre}"?\n\nEl cliente perderá conexión a Internet.`)) {
            window.location.href = `../controllers/cortar_cliente.php?id=${id}`;
        }
    }

    function contactarCliente(id, nombre, telefono) {
        if (telefono) {
            alert(`📞 Contactar a ${nombre}\nTeléfono: ${telefono}\n\n(Simulación de llamada)`);
        } else {
            alert(`📞 ${nombre} no tiene teléfono registrado`);
        }
    }
</script>
</body>
</html>