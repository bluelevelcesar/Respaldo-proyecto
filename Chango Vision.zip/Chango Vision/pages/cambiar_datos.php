<?php
session_start();

// Verificar que el usuario esté logueado
if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';

// Obtener datos del usuario actual
$id_usuario = $_SESSION['id_usuario'];
$sql = "SELECT id_usuario, nombre, apellido, email, usuario, telefono, localidad, dni FROM usuario WHERE id_usuario = ?";
$stmt = mysqli_prepare($conexion, $sql);
mysqli_stmt_bind_param($stmt, "i", $id_usuario);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$usuario = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$usuario) {
    header('Location: ../logout.php');
    exit;
}

$mensaje = '';
$tipo_mensaje = '';

// =============================================
// DETERMINAR PÁGINA DE RETORNO SEGÚN ROL
// =============================================
function getVolverUrl($rol) {
    return match($rol) {
        1 => 'admin.php',
        2 => 'cobrador_clientes.php',
        3 => 'tecnico.php',
        4 => 'admin_red.php',
        default => 'admin.php'
    };
}

// =============================================
// PROCESAR FORMULARIO
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $localidad = trim($_POST['localidad'] ?? '');
    $dni = trim($_POST['dni'] ?? '');
    $usuario_nombre = trim($_POST['usuario'] ?? '');
    
    $errores = [];
    
    // ✅ VALIDAR CAMPOS OBLIGATORIOS
    if (empty($nombre)) $errores[] = 'El nombre es obligatorio';
    if (empty($email)) $errores[] = 'El email es obligatorio';
    if (empty($usuario_nombre)) $errores[] = 'El usuario es obligatorio';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errores[] = 'Email no válido';
    
    // ✅ VERIFICAR EMAIL ÚNICO
    if (empty($errores)) {
        $sql_email = "SELECT id_usuario FROM usuario WHERE email = ? AND id_usuario != ?";
        $stmt_email = mysqli_prepare($conexion, $sql_email);
        mysqli_stmt_bind_param($stmt_email, "si", $email, $id_usuario);
        mysqli_stmt_execute($stmt_email);
        $result_email = mysqli_stmt_get_result($stmt_email);
        if (mysqli_num_rows($result_email) > 0) {
            $errores[] = 'El email ya está registrado por otro usuario';
        }
        mysqli_stmt_close($stmt_email);
    }
    
    // ✅ VERIFICAR USUARIO ÚNICO
    if (empty($errores)) {
        $sql_usuario = "SELECT id_usuario FROM usuario WHERE usuario = ? AND id_usuario != ?";
        $stmt_usuario = mysqli_prepare($conexion, $sql_usuario);
        mysqli_stmt_bind_param($stmt_usuario, "si", $usuario_nombre, $id_usuario);
        mysqli_stmt_execute($stmt_usuario);
        $result_usuario = mysqli_stmt_get_result($stmt_usuario);
        if (mysqli_num_rows($result_usuario) > 0) {
            $errores[] = 'El nombre de usuario ya está registrado por otro usuario';
        }
        mysqli_stmt_close($stmt_usuario);
    }
    
    // ✅ ACTUALIZAR DATOS
    if (empty($errores)) {
        $sql_update = "UPDATE usuario SET 
                            nombre = ?,
                            apellido = ?,
                            email = ?,
                            telefono = ?,
                            localidad = ?,
                            dni = ?,
                            usuario = ?
                        WHERE id_usuario = ?";
        $stmt_update = mysqli_prepare($conexion, $sql_update);
        mysqli_stmt_bind_param($stmt_update, "sssssssi", 
            $nombre, $apellido, $email, $telefono, $localidad, $dni, $usuario_nombre, $id_usuario
        );
        
        if (mysqli_stmt_execute($stmt_update)) {
            $mensaje = '✅ Datos actualizados correctamente';
            $tipo_mensaje = 'success';
            
            // Actualizar sesión
            $_SESSION['usuario'] = $usuario_nombre;
            
            // Recargar datos
            $usuario['nombre'] = $nombre;
            $usuario['apellido'] = $apellido;
            $usuario['email'] = $email;
            $usuario['telefono'] = $telefono;
            $usuario['localidad'] = $localidad;
            $usuario['dni'] = $dni;
            $usuario['usuario'] = $usuario_nombre;
        } else {
            $mensaje = '❌ Error al actualizar datos: ' . mysqli_error($conexion);
            $tipo_mensaje = 'error';
        }
        mysqli_stmt_close($stmt_update);
    } else {
        $mensaje = implode('<br>', $errores);
        $tipo_mensaje = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cambiar Datos - Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #f0f4f8; padding: 2rem; }
        
        .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); overflow: hidden; }
        
        .header { background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white; padding: 1.5rem 2rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; }
        .header h1 { font-size: 1.3rem; display: flex; align-items: center; gap: 10px; }
        .btn-volver { background: rgba(255,255,255,0.2); color: white; border: none; padding: 0.5rem 1.2rem; border-radius: 40px; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; font-size: 0.85rem; transition: 0.3s; }
        .btn-volver:hover { background: rgba(255,255,255,0.3); }
        
        .btn-cambiar-pass {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 0.5rem 1.2rem;
            border-radius: 40px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 0.85rem;
            transition: 0.3s;
        }
        .btn-cambiar-pass:hover { background: rgba(255,255,255,0.3); }
        
        .body-content { padding: 2rem; }
        
        .mensaje { padding: 1rem; border-radius: 12px; margin-bottom: 1.5rem; font-size: 0.9rem; }
        .mensaje.success { background: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
        .mensaje.error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        
        .form-group { margin-bottom: 1.2rem; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: 700; color: #1b4f6e; margin-bottom: 4px; }
        .form-group label .obligatorio { color: #ef4444; }
        .form-group input { width: 100%; padding: 0.7rem; border: 1.5px solid #dce5ec; border-radius: 10px; font-size: 0.9rem; transition: 0.3s; }
        .form-group input:focus { outline: none; border-color: #1b4f6e; box-shadow: 0 0 0 3px rgba(27,79,110,0.1); }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        
        .separador { border: none; border-top: 2px solid #e9eef3; margin: 1.5rem 0; }
        
        .info-text { font-size: 0.65rem; color: #94a3b8; margin-top: 4px; }
        
        .btn-submit { background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white; width: 100%; padding: 0.8rem; border: none; border-radius: 10px; cursor: pointer; font-weight: 600; font-size: 1rem; transition: 0.3s; margin-top: 0.5rem; }
        .btn-submit:hover { transform: scale(1.01); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
        
        .accion-extra {
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 2px solid #e9eef3;
            text-align: center;
        }
        .accion-extra p { color: #64748b; font-size: 0.85rem; margin-bottom: 0.8rem; }
        .btn-cambiar-pass-link {
            background: linear-gradient(135deg, #065f46, #10b981);
            color: white;
            border: none;
            padding: 0.7rem 2rem;
            border-radius: 40px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9rem;
            font-weight: 600;
            transition: 0.3s;
        }
        .btn-cambiar-pass-link:hover {
            transform: scale(1.02);
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.4);
        }
        
        @media (max-width: 768px) {
            body { padding: 1rem; }
            .form-row { grid-template-columns: 1fr; }
            .header { flex-direction: column; text-align: center; }
        }
    </style>
    <link rel="stylesheet" href="../css/responsive_global.css">
</head>
<body>
<div class="container">
    <div class="header">
        <h1><i class="fas fa-user-edit"></i> Cambiar Datos</h1>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <a href="cambiar_pass.php" class="btn-cambiar-pass">
                <i class="fas fa-key"></i> Cambiar Contraseña
            </a>
            <a href="<?= getVolverUrl($_SESSION['id_rol'] ?? 1) ?>" class="btn-volver">
                <i class="fas fa-arrow-left"></i> Volver
            </a>
        </div>
    </div>
    
    <div class="body-content">
        <?php if (!empty($mensaje)): ?>
            <div class="mensaje <?= $tipo_mensaje ?>">
                <?= $mensaje ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <!-- ============================================= -->
            <!-- DATOS PERSONALES -->
            <!-- ============================================= -->
            <div class="form-row">
                <div class="form-group">
                    <label>Nombre <span class="obligatorio">*</span></label>
                    <input type="text" name="nombre" value="<?= htmlspecialchars($usuario['nombre'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label>Apellido</label>
                    <input type="text" name="apellido" value="<?= htmlspecialchars($usuario['apellido'] ?? '') ?>">
                </div>
            </div>

            <div class="form-group">
                <label>Email <span class="obligatorio">*</span></label>
                <input type="email" name="email" value="<?= htmlspecialchars($usuario['email'] ?? '') ?>" required>
            </div>

            <div class="form-group">
                <label>Usuario <span class="obligatorio">*</span></label>
                <input type="text" name="usuario" value="<?= htmlspecialchars($usuario['usuario'] ?? '') ?>" required>
                <div class="info-text"><i class="fas fa-info-circle"></i> Nombre de usuario para iniciar sesión</div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Teléfono</label>
                    <input type="text" name="telefono" value="<?= htmlspecialchars($usuario['telefono'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Localidad</label>
                    <input type="text" name="localidad" value="<?= htmlspecialchars($usuario['localidad'] ?? '') ?>">
                </div>
            </div>

            <div class="form-group">
                <label>DNI</label>
                <input type="text" name="dni" value="<?= htmlspecialchars($usuario['dni'] ?? '') ?>">
            </div>

            <button type="submit" class="btn-submit">
                <i class="fas fa-save"></i> Guardar Cambios
            </button>
        </form>

        <!-- ============================================= -->
        <!-- BOTÓN PARA IR A CAMBIAR CONTRASEÑA -->
        <!-- ============================================= -->
        <div class="accion-extra">
            <p><i class="fas fa-info-circle" style="color:#1b4f6e;"></i> ¿Necesitas cambiar tu contraseña?</p>
            <a href="cambiar_pass.php" class="btn-cambiar-pass-link">
                <i class="fas fa-key"></i> Ir a Cambiar Contraseña
            </a>
        </div>
    </div>
</div>
</body>
</html>