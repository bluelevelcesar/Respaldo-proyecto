<?php
session_start();

// Verificar que el usuario esté logueado
if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../login.php');
    exit;
}

// ✅ SOLO TÉCNICOS (id_rol = 3) PUEDEN ACCEDER
if ($_SESSION['id_rol'] != 3) {
    header('Location: ../login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';
include __DIR__ . '/../controllers/verificar_vencimientos.php';

// Verificar vencimientos automáticamente al cargar la página
verificarYProcesarVencimientos($conexion);

// =============================================
// LEER NOTIFICACIONES DEL ARCHIVO
// =============================================
function leerNotificacionesConexion() {
    $log_dir = __DIR__ . '/../logs/';
    $archivo = $log_dir . 'notificacion_tecnico_conexion.txt';
    $notificaciones = [];
    
    if (file_exists($archivo)) {
        $contenido = file_get_contents($archivo);
        // Separar por notificaciones (cada una comienza con [fecha])
        $bloques = explode("[", $contenido);
        foreach ($bloques as $bloque) {
            if (trim($bloque) == '') continue;
            $partes = explode("]", $bloque, 2);
            if (count($partes) >= 2) {
                $fecha = trim($partes[0]);
                $mensaje = trim($partes[1]);
                
                // Extraer datos del mensaje
                $cliente = '';
                $direccion = '';
                $telefono = '';
                $servicio = '';
                $monto = '';
                
                $lineas = explode("\n", $mensaje);
                foreach ($lineas as $linea) {
                    if (strpos($linea, 'Cliente:') !== false) {
                        $cliente = trim(str_replace('Cliente:', '', $linea));
                    } elseif (strpos($linea, 'Dirección:') !== false) {
                        $direccion = trim(str_replace('Dirección:', '', $linea));
                    } elseif (strpos($linea, 'Teléfono:') !== false) {
                        $telefono = trim(str_replace('Teléfono:', '', $linea));
                    } elseif (strpos($linea, 'Servicio:') !== false) {
                        $servicio = trim(str_replace('Servicio:', '', $linea));
                    } elseif (strpos($linea, 'Monto pagado:') !== false) {
                        $monto = trim(str_replace('Monto pagado:', '', $linea));
                    }
                }
                
                $notificaciones[] = [
                    'fecha' => $fecha,
                    'cliente' => $cliente,
                    'direccion' => $direccion,
                    'telefono' => $telefono,
                    'servicio' => $servicio,
                    'monto' => $monto,
                    'mensaje_completo' => $mensaje
                ];
            }
        }
    }
    
    return array_reverse($notificaciones); // Mostrar las más recientes primero
}

$notificaciones_conexion = leerNotificacionesConexion();
$total_notificaciones = count($notificaciones_conexion);

// Obtener datos de la base de datos

// 1. CLIENTES PENDIENTES DE CORTE
$sql_clientes_pendientes = "SELECT c.id, c.nombre,  c.telefono, s.nombre as servicio
                            FROM cliente c
                            LEFT JOIN servicio s ON c.id_servicio = s.id_servicio
                            WHERE c.estado = 'Activo' 
                            AND s.estado_pago = 'vencido'";
$result_clientes_pendientes = mysqli_query($conexion, $sql_clientes_pendientes);
$clientes_pendientes = $result_clientes_pendientes ? mysqli_fetch_all($result_clientes_pendientes, MYSQLI_ASSOC) : [];
$total_pendientes = count($clientes_pendientes);

// 2. TODOS LOS CLIENTES ACTIVOS
$sql_clientes = "SELECT id, nombre, telefono, email FROM cliente WHERE estado = 'Activo' ORDER BY nombre";
$result_clientes = mysqli_query($conexion, $sql_clientes);
$clientes = $result_clientes ? mysqli_fetch_all($result_clientes, MYSQLI_ASSOC) : [];

// 3. TRABAJOS ASIGNADOS
$sql_trabajos = "SELECT 
                    c.id as cliente_id,
                    c.nombre as cliente_nombre,
                   
                    c.telefono,
                    s.nombre as servicio_nombre,
                    s.estado_pago,
                    c.fecha_ultimo_pago
                 FROM cliente c
                 LEFT JOIN servicio s ON c.id_servicio = s.id_servicio
                 WHERE c.estado = 'Activo'
                 ORDER BY c.id DESC";
$result_trabajos = mysqli_query($conexion, $sql_trabajos);
$trabajos = $result_trabajos ? mysqli_fetch_all($result_trabajos, MYSQLI_ASSOC) : [];

// Obtener mensajes de sesión
$mensaje = $_SESSION['mensaje'] ?? '';
$mensaje_tipo = $_SESSION['mensaje_tipo'] ?? '';
unset($_SESSION['mensaje'], $_SESSION['mensaje_tipo']);

// Contar pendientes para el badge
$total_pendientes_trabajos = 0;
foreach ($trabajos as $t) {
    if (($t['estado_pago'] ?? 'pendiente') != 'pagado') {
        $total_pendientes_trabajos++;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Técnico - Chango Vision</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background: #f0f2f5; padding: 2rem; color: #1a1a2e; }
        .container { max-width: 1400px; margin: 0 auto; background: white; border-radius: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); overflow: hidden; border: 1px solid #e0e4e8; }

        .header {
            background: linear-gradient(135deg, #0a2b4e 0%, #0a4b7a 100%);
            color: white;
            padding: 1.5rem 2rem;
            border-bottom: 4px solid #00a3ff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .header h1 { font-size: 1.8rem; font-weight: 600; display: flex; align-items: center; gap: 12px; }
        .header h1 i { font-size: 2rem; }
        .header p { color: #cbd5e1; margin-top: 4px; font-size: 0.85rem; }
        .header-badges { display: flex; gap: 10px; flex-wrap: wrap; }
        .badge-notif { background: #ef4444; color: white; padding: 6px 14px; border-radius: 30px; font-size: 0.75rem; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; }
        .badge-corte { background: #f59e0b; color: white; padding: 6px 14px; border-radius: 30px; font-size: 0.75rem; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; }
        .badge-ok { background: #10b981; color: white; padding: 6px 14px; border-radius: 30px; font-size: 0.75rem; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; }

        .btn-volver {
            background: rgba(255,255,255,0.15);
            color: white;
            border: 1px solid rgba(255,255,255,0.3);
            padding: 8px 18px;
            border-radius: 30px;
            text-decoration: none;
            font-size: 0.85rem;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.3s;
        }
        .btn-volver:hover { background: rgba(255,255,255,0.25); }

        .tabs {
            display: flex;
            background: #f8fafc;
            border-bottom: 2px solid #e2e8f0;
            padding: 0 1rem;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        .tab-btn {
            padding: 1rem 1.8rem;
            font-size: 1rem;
            font-weight: 600;
            background: transparent;
            border: none;
            cursor: pointer;
            color: #475569;
            transition: all 0.2s;
            border-radius: 12px 12px 0 0;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .tab-btn:hover { background: #e2e8f0; color: #0a2b4e; }
        .tab-btn.active { background: white; color: #0a4b7a; border-bottom: 3px solid #0a4b7a; }
        .tab-btn .tab-badge { background: #ef4444; color: white; padding: 1px 8px; border-radius: 30px; font-size: 0.6rem; }

        .tab-content { display: none; padding: 2rem; animation: fadeIn 0.3s ease; }
        .tab-content.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

        .card { background: white; border-radius: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 1.5rem; }
        .card-header { background: #f8fafc; padding: 1rem 1.5rem; border-bottom: 2px solid #e2e8f0; font-weight: 700; color: #0a2b4e; font-size: 1.1rem; display: flex; align-items: center; gap: 8px; justify-content: space-between; flex-wrap: wrap; }
        .card-body { padding: 1.5rem; }

        .notificacion-item {
            background: #fefce8;
            border: 2px solid #f59e0b;
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            transition: 0.3s;
            animation: slideIn 0.4s ease;
        }
        .notificacion-item:hover { box-shadow: 0 8px 25px rgba(0,0,0,0.1); transform: translateY(-2px); }
        @keyframes slideIn { from { opacity: 0; transform: translateX(-30px); } to { opacity: 1; transform: translateX(0); } }

        .notificacion-item .icono { width: 50px; height: 50px; background: #fef3c7; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: #d97706; flex-shrink: 0; }
        .notificacion-item .contenido { flex: 1; }
        .notificacion-item .titulo { font-size: 1.1rem; font-weight: 700; color: #0f2b3d; display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .notificacion-item .titulo .tag { background: #fef3c7; color: #92400e; font-size: 0.6rem; font-weight: 600; padding: 2px 10px; border-radius: 30px; text-transform: uppercase; letter-spacing: 0.5px; }
        .notificacion-item .detalles { display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem 1.5rem; margin: 0.8rem 0; background: #f8fafc; padding: 1rem; border-radius: 12px; }
        .notificacion-item .detalles .item { display: flex; align-items: center; gap: 8px; font-size: 0.85rem; color: #1e293b; }
        .notificacion-item .detalles .item i { color: #1b4f6e; width: 18px; }
        .notificacion-item .detalles .item .label { font-weight: 600; color: #64748b; }
        .notificacion-item .fecha { font-size: 0.7rem; color: #94a3b8; margin-top: 0.5rem; display: flex; align-items: center; gap: 6px; }
        .notificacion-item .acciones { margin-top: 1rem; display: flex; gap: 0.8rem; flex-wrap: wrap; }
        .btn-atender { background: #10b981; color: white; border: none; padding: 0.6rem 1.5rem; border-radius: 40px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: 0.3s; font-size: 0.8rem; }
        .btn-atender:hover { background: #059669; transform: scale(0.97); }
        .btn-ver-mapa { background: #e2e8f0; color: #1e293b; border: none; padding: 0.6rem 1.5rem; border-radius: 40px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: 0.3s; text-decoration: none; font-size: 0.8rem; }
        .btn-ver-mapa:hover { background: #cbd5e1; }

        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.2rem; margin-bottom: 1.5rem; }
        .input-group { display: flex; flex-direction: column; gap: 6px; }
        .input-group label { font-weight: 600; color: #0a2b4e; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.5px; display: flex; align-items: center; gap: 6px; }
        .input-group input, .input-group select, .input-group textarea { padding: 10px 14px; border: 1.5px solid #cbd5e1; border-radius: 12px; font-size: 0.95rem; transition: all 0.2s; background: white; }
        .input-group input:focus, .input-group select:focus, .input-group textarea:focus { outline: none; border-color: #0a4b7a; box-shadow: 0 0 0 3px rgba(10,75,122,0.2); }

        .btn { 
            background: #0a2b4e; 
            color: white; 
            border: none; 
            padding: 10px 24px; 
            border-radius: 40px; 
            font-weight: bold; 
            cursor: pointer; 
            transition: all 0.2s; 
            font-size: 0.9rem; 
            display: inline-flex; 
            align-items: center; 
            gap: 8px; 
        }
        .btn-primary { background: #0a4b7a; }
        .btn-primary:hover { background: #0a2b4e; transform: translateY(-1px); }
        .btn-success { background: #059669; }
        .btn-success:hover { background: #047857; }
        .btn-warning { background: #d97706; }
        .btn-warning:hover { background: #b45309; }
        .btn-danger { background: #dc2626; }
        .btn-danger:hover { background: #b91c1c; }
        .btn-sm { padding: 6px 14px; font-size: 0.75rem; }

        .table-wrapper { overflow-x: auto; }
        .data-table { width: 100%; border-collapse: collapse; background: white; border-radius: 16px; overflow: hidden; }
        .data-table th { background: #0a2b4e; color: white; padding: 12px; text-align: left; font-size: 0.85rem; font-weight: 600; }
        .data-table td { padding: 12px; border-bottom: 1px solid #e2e8f0; color: #1e293b; }
        .data-table tr:hover { background: #f1f5f9; }

        .badge { display: inline-block; padding: 4px 12px; border-radius: 30px; font-size: 0.75rem; font-weight: bold; display: inline-flex; align-items: center; gap: 4px; }
        .badge-pendiente { background: #fef3c7; color: #92400e; }
        .badge-completado { background: #d1fae5; color: #065f46; }
        .badge-cortar { background: #fee2e2; color: #991b1b; }

        .contactar-btn { background: #0a4b7a; color: white; border: none; padding: 6px 12px; border-radius: 20px; cursor: pointer; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 5px; }
        .contactar-btn:hover { background: #0a2b4e; }

        .filtros { display: flex; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap; }
        .filtros input, .filtros select { padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 12px; }

        .cliente-item { padding: 12px; border-left: 3px solid #ef4444; background: #fef2f2; border-radius: 8px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
        .cliente-item .info { flex: 1; }
        .cliente-item .nombre { font-weight: 600; display: flex; align-items: center; gap: 8px; }
        .cliente-item .dir { font-size: 0.85rem; color: #64748b; display: flex; align-items: center; gap: 6px; }
        .cliente-item .tel { font-size: 0.85rem; color: #64748b; display: flex; align-items: center; gap: 6px; }
        .cliente-item .acciones { display: flex; gap: 8px; flex-wrap: wrap; }

        .empty { text-align: center; padding: 40px; color: #94a3b8; }
        .empty i { font-size: 2rem; display: block; margin-bottom: 10px; }

        .footer { background: #f1f5f9; padding: 1rem 2rem; text-align: center; color: #334155; font-size: 0.8rem; border-top: 1px solid #e2e8f0; }

        .toast-message { position: fixed; top: 20px; right: 20px; padding: 12px 20px; border-radius: 8px; color: white; z-index: 2000; animation: slideIn 0.3s ease; display: flex; align-items: center; gap: 8px; }
        .toast-success { background: #4CAF50; }
        .toast-error { background: #f44336; }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }

        @media (max-width: 768px) {
            body { padding: 1rem; }
            .tab-btn { padding: 0.75rem 1rem; font-size: 0.8rem; }
            .tab-content { padding: 1rem; }
            .data-table th, .data-table td { font-size: 0.7rem; padding: 8px; }
            .header { flex-direction: column; text-align: center; }
            .cliente-item { flex-direction: column; align-items: stretch; }
            .notificacion-item .detalles { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="container">
    <?php if ($mensaje): ?>
        <div class="toast-message toast-<?= $mensaje_tipo === 'success' ? 'success' : 'error' ?>">
            <i class="fas <?= $mensaje_tipo === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle' ?>"></i>
            <?= htmlspecialchars($mensaje) ?>
        </div>
        <script>setTimeout(() => { document.querySelector('.toast-message')?.remove(); }, 3000);</script>
    <?php endif; ?>

    <div class="header">
        <div>
            <h1><i class="fas fa-tools"></i> Técnico | Chango Vision</h1>
            <p><i class="fas fa-user-circle"></i> <?= htmlspecialchars($_SESSION['usuario'] ?? 'Técnico') ?> | Gestión de cortes y clientes</p>
        </div>
        <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
            <div class="header-badges">
                <?php if ($total_notificaciones > 0): ?>
                    <span class="badge-notif"><i class="fas fa-bell"></i> <?= $total_notificaciones ?> nueva(s)</span>
                <?php endif; ?>
                <?php if ($total_pendientes > 0): ?>
                    <span class="badge-corte"><i class="fas fa-cut"></i> <?= $total_pendientes ?> cliente(s) para cortar</span>
                <?php else: ?>
                    <span class="badge-ok"><i class="fas fa-check-circle"></i> Sin cortes pendientes</span>
                <?php endif; ?>
            </div>
            <a href="../logout.php" class="btn-volver" onclick="return confirm('¿Cerrar sesión?')">
                <i class="fas fa-sign-out-alt"></i> Salir
            </a>
        </div>
    </div>

    <!-- Pestañas -->
    <div class="tabs">
        <button class="tab-btn <?= $total_notificaciones > 0 ? '' : 'active' ?>" data-tab="notificaciones">
            <i class="fas fa-bell"></i> Notificaciones
            <?php if ($total_notificaciones > 0): ?>
                <span class="tab-badge"><?= $total_notificaciones ?></span>
            <?php endif; ?>
        </button>
        <button class="tab-btn" data-tab="trabajos">
            <i class="fas fa-tasks"></i> Trabajos asignados
            <?php if ($total_pendientes_trabajos > 0): ?>
                <span class="tab-badge"><?= $total_pendientes_trabajos ?></span>
            <?php endif; ?>
        </button>
        <button class="tab-btn" data-tab="cortes">
            <i class="fas fa-cut"></i> Cortes pendientes 
            <?php if ($total_pendientes > 0): ?>
                <span class="tab-badge"><?= $total_pendientes ?></span>
            <?php endif; ?>
        </button>
        <button class="tab-btn" data-tab="contactar">
            <i class="fas fa-phone"></i> Contactar
        </button>
    </div>

    <!-- ============================================ -->
    <!-- PESTAÑA: NOTIFICACIONES DE NUEVAS CONEXIONES -->
    <!-- ============================================ -->
    <div id="notificaciones" class="tab-content <?= $total_notificaciones > 0 ? 'active' : '' ?>">
        <div class="card">
            <div class="card-header">
                <span><i class="fas fa-bell"></i> Notificaciones de nuevas conexiones</span>
                <span class="badge <?= $total_notificaciones > 0 ? 'badge-cortar' : 'badge-completado' ?>">
                    <i class="fas <?= $total_notificaciones > 0 ? 'fa-exclamation-triangle' : 'fa-check-circle' ?>"></i>
                    <?= $total_notificaciones ?> pendiente(s)
                </span>
            </div>
            <div class="card-body">
                <?php if ($total_notificaciones == 0): ?>
                    <div class="empty">
                        <i class="fas fa-check-circle" style="color: #10b981;"></i>
                        No hay notificaciones de nuevas conexiones
                    </div>
                <?php else: ?>
                    <?php foreach ($notificaciones_conexion as $notif): ?>
                        <div class="notificacion-item">
                            <div style="display:flex; gap:1rem; align-items:flex-start; flex-wrap:wrap;">
                                <div class="icono"><i class="fas fa-plug"></i></div>
                                <div class="contenido">
                                    <div class="titulo">
                                        <span>🔌 Nueva conexión pendiente</span>
                                        <span class="tag"><i class="fas fa-clock"></i> Pendiente</span>
                                    </div>
                                    <div class="detalles">
                                        <div class="item"><i class="fas fa-user"></i> <span class="label">Cliente:</span> <?= htmlspecialchars($notif['cliente']) ?></div>
                                        <div class="item"><i class="fas fa-map-marker-alt"></i> <span class="label">Dirección:</span> <?= htmlspecialchars($notif['direccion']) ?></div>
                                        <div class="item"><i class="fas fa-phone"></i> <span class="label">Teléfono:</span> <?= htmlspecialchars($notif['telefono']) ?></div>
                                        <div class="item"><i class="fas fa-wifi"></i> <span class="label">Servicio:</span> <?= htmlspecialchars($notif['servicio']) ?></div>
                                        <div class="item"><i class="fas fa-dollar-sign"></i> <span class="label">Monto pagado:</span> <?= htmlspecialchars($notif['monto']) ?></div>
                                        <div class="item"><i class="fas fa-calendar-check"></i> <span class="label">Primer pago:</span> ✅ Realizado</div>
                                    </div>
                                    <div class="fecha"><i class="fas fa-clock"></i> <?= htmlspecialchars($notif['fecha']) ?></div>
                                    <div class="acciones">
                                        <button class="btn-atender" onclick="atenderNotificacion(this)">
                                            <i class="fas fa-check"></i> Atender conexión
                                        </button>
                                        <button class="btn-ver-mapa" onclick="verMapa('<?= htmlspecialchars($notif['direccion']) ?>')">
                                            <i class="fas fa-map-pin"></i> Ver en mapa
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- PESTAÑA: TRABAJOS ASIGNADOS -->
    <!-- ============================================ -->
    <div id="trabajos" class="tab-content">
        <div class="card">
            <div class="card-header">
                <span><i class="fas fa-tasks"></i> Trabajos asignados</span>
                <span class="badge badge-pendiente"><i class="fas fa-clock"></i> Pendientes: <?= $total_pendientes_trabajos ?></span>
            </div>
            <div class="card-body">
                <div class="filtros">
                    <input type="text" id="filtroTrabajos" placeholder="Filtrar por cliente o dirección" style="flex:1;">
                    <select id="filtroEstadoTrabajo">
                        <option value="todos"><i class="fas fa-list"></i> Todos</option>
                        <option value="pendiente"><i class="fas fa-clock"></i> Pendiente</option>
                        <option value="pagado"><i class="fas fa-check-circle"></i> Pagado</option>
                    </select>
                </div>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th><i class="fas fa-user"></i> Cliente</th>
                                <th><i class="fas fa-map-marker-alt"></i> Dirección</th>
                                <th><i class="fas fa-wifi"></i> Servicio</th>
                                <th><i class="fas fa-credit-card"></i> Estado Pago</th>
                                <th><i class="fas fa-calendar"></i> Último Pago</th>
                                <th><i class="fas fa-cog"></i> Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="trabajosBody">
                            <?php if (empty($trabajos)): ?>
                                <tr><td colspan="6" style="text-align:center;"><i class="fas fa-inbox"></i> No hay trabajos asignados</td></tr>
                            <?php else: ?>
                                <?php foreach ($trabajos as $t): ?>
                                <tr data-estado="<?= $t['estado_pago'] ?? 'pendiente' ?>">
                                    <td><strong><?= htmlspecialchars($t['cliente_nombre']) ?></strong></td>
                                    <td><?= htmlspecialchars($t['direccion'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($t['servicio_nombre'] ?? 'Sin servicio') ?></td>
                                    <td>
                                        <span class="badge <?= ($t['estado_pago'] ?? 'pendiente') == 'pagado' ? 'badge-completado' : 'badge-pendiente' ?>">
                                            <i class="fas <?= ($t['estado_pago'] ?? 'pendiente') == 'pagado' ? 'fa-check-circle' : 'fa-clock' ?>"></i>
                                            <?= ($t['estado_pago'] ?? 'pendiente') == 'pagado' ? 'Pagado' : 'Pendiente' ?>
                                        </span>
                                    </td>
                                    <td><?= $t['fecha_ultimo_pago'] ?? 'Nunca' ?></td>
                                    <td>
                                        <button class="contactar-btn" onclick="contactarCliente(<?= $t['cliente_id'] ?>, '<?= htmlspecialchars($t['cliente_nombre']) ?>', '<?= htmlspecialchars($t['telefono'] ?? '') ?>')">
                                            <i class="fas fa-phone"></i> Contactar
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- PESTAÑA: CORTES PENDIENTES -->
    <!-- ============================================ -->
    <div id="cortes" class="tab-content">
        <div class="card">
            <div class="card-header">
                <span><i class="fas fa-cut"></i> Clientes pendientes de corte</span>
                <span class="badge <?= $total_pendientes > 0 ? 'badge-cortar' : 'badge-completado' ?>">
                    <i class="fas <?= $total_pendientes > 0 ? 'fa-exclamation-triangle' : 'fa-check-circle' ?>"></i>
                    <?= $total_pendientes ?> cliente(s)
                </span>
            </div>
            <div class="card-body">
                <?php if ($total_pendientes == 0): ?>
                    <div class="empty"><i class="fas fa-check-circle" style="color: #10b981;"></i> No hay clientes pendientes de corte</div>
                <?php else: ?>
                    <?php foreach ($clientes_pendientes as $c): ?>
                        <div class="cliente-item">
                            <div class="info">
                                <div class="nombre"><i class="fas fa-user"></i> <?= htmlspecialchars($c['nombre']) ?></div>
                                <div class="dir"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($c['direccion']) ?></div>
                                <div class="tel"><i class="fas fa-phone"></i> <?= htmlspecialchars($c['telefono'] ?? 'Sin teléfono') ?></div>
                                <div style="font-size:0.75rem; color:#64748b; margin-top:4px; display:flex; align-items:center; gap:6px;">
                                    <i class="fas fa-wifi"></i> <?= htmlspecialchars($c['servicio']) ?>
                                </div>
                            </div>
                            <div class="acciones">
                                <button class="btn btn-danger btn-sm" onclick="cortarCliente(<?= $c['id'] ?>, '<?= htmlspecialchars($c['nombre']) ?>')">
                                    <i class="fas fa-power-off"></i> Cortar servicio
                                </button>
                                <button class="btn btn-primary btn-sm" onclick="contactarCliente(<?= $c['id'] ?>, '<?= htmlspecialchars($c['nombre']) ?>', '<?= htmlspecialchars($c['telefono'] ?? '') ?>')">
                                    <i class="fas fa-phone"></i> Contactar
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- PESTAÑA: CONTACTAR CLIENTE -->
    <!-- ============================================ -->
    <div id="contactar" class="tab-content">
        <div class="card">
            <div class="card-header"><i class="fas fa-phone"></i> Contactar con el cliente</div>
            <div class="card-body">
                <div class="form-grid">
                    <div class="input-group">
                        <label><i class="fas fa-user"></i> Seleccionar cliente</label>
                        <select id="contactCliente">
                            <option value="">-- Seleccione un cliente --</option>
                            <?php foreach ($clientes as $c): ?>
                                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nombre']) ?> - <?= htmlspecialchars($c['direccion'] ?? '') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="input-group">
                        <label><i class="fas fa-phone"></i> Teléfono</label>
                        <input type="text" id="contactTelefono" placeholder="Teléfono del cliente" readonly>
                    </div>
                    <div class="input-group">
                        <label><i class="fas fa-envelope"></i> Email</label>
                        <input type="email" id="contactEmail" placeholder="Email del cliente" readonly>
                    </div>
                </div>
                <div class="input-group" style="margin-bottom: 1rem;">
                    <label><i class="fas fa-comment"></i> Mensaje</label>
                    <textarea id="contactMensaje" rows="3" placeholder="Escribe el mensaje..."></textarea>
                </div>
                <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
                    <button id="btnSimularLlamada" class="btn btn-warning"><i class="fas fa-phone"></i> Simular llamada</button>
                    <button id="btnSimularMensaje" class="btn btn-primary"><i class="fas fa-envelope"></i> Simular mensaje</button>
                </div>
                <div id="contactResultado" style="margin-top: 1rem; padding: 1rem; background: #f1f5f9; border-radius: 12px; display: none;"></div>
            </div>
        </div>
    </div>

    <div class="footer">
        <i class="fas fa-tools"></i> Sistema de gestión para técnico de campo
    </div>
</div>

<script>
// ========== ATENDER NOTIFICACIÓN ==========
function atenderNotificacion(btn) {
    if (confirm('✅ ¿Ya realizaste la conexión para este cliente?')) {
        const notificacion = btn.closest('.notificacion-item');
        notificacion.style.opacity = '0.5';
        notificacion.style.transition = '0.5s';
        mostrarToast('✅ Conexión marcada como atendida', 'success');
        setTimeout(() => {
            notificacion.style.display = 'none';
            // Recargar para actualizar contador
            location.reload();
        }, 500);
    }
}

function verMapa(direccion) {
    if (direccion && direccion !== 'Sin dirección') {
        const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(direccion)}`;
        window.open(url, '_blank');
    } else {
        mostrarToast('❌ No hay dirección disponible', 'error');
    }
}

function mostrarToast(mensaje, tipo) {
    const toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.className += tipo === 'success' ? ' toast-success' : ' toast-error';
    toast.innerHTML = `<i class="fas ${tipo === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i> ${mensaje}`;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// ========== FILTROS ==========
function filtrarTrabajos() {
    const filtroTexto = document.getElementById('filtroTrabajos')?.value.toLowerCase() || '';
    const filtroEstado = document.getElementById('filtroEstadoTrabajo')?.value || 'todos';
    const rows = document.querySelectorAll('#trabajosBody tr');
    rows.forEach(row => {
        if (row.cells.length < 6) return;
        const nombre = row.cells[0]?.textContent.toLowerCase() || '';
        const direccion = row.cells[1]?.textContent.toLowerCase() || '';
        const estado = row.dataset.estado || '';
        const matchesSearch = nombre.includes(filtroTexto) || direccion.includes(filtroTexto);
        const matchesFilter = filtroEstado === 'todos' || estado === filtroEstado;
        row.style.display = matchesSearch && matchesFilter ? '' : 'none';
    });
}
document.getElementById('filtroTrabajos')?.addEventListener('input', filtrarTrabajos);
document.getElementById('filtroEstadoTrabajo')?.addEventListener('change', filtrarTrabajos);

// ========== CONTACTAR ==========
function actualizarContactoCliente() {
    const clienteId = parseInt(document.getElementById('contactCliente')?.value);
    const clientesData = <?= json_encode($clientes) ?>;
    if (clienteId) {
        const cliente = clientesData.find(c => c.id === clienteId);
        if (cliente) {
            document.getElementById('contactTelefono').value = cliente.telefono || '';
            document.getElementById('contactEmail').value = cliente.email || '';
        }
    } else {
        document.getElementById('contactTelefono').value = '';
        document.getElementById('contactEmail').value = '';
    }
}

function simularLlamada() {
    const clienteId = parseInt(document.getElementById('contactCliente')?.value);
    if (!clienteId) { 
        alert('⚠️ Seleccione un cliente primero'); 
        return; 
    }
    const clientesData = <?= json_encode($clientes) ?>;
    const cliente = clientesData.find(c => c.id === clienteId);
    if (!cliente) return;
    const div = document.getElementById('contactResultado');
    div.style.display = 'block';
    div.innerHTML = `<div style="background:#d1fae5; padding:12px; border-radius:12px; display:flex; align-items:center; gap:10px;">
        <i class="fas fa-phone" style="color:#059669; font-size:1.5rem;"></i>
        <div>
            <strong>Llamada a ${cliente.nombre}</strong><br>
            <span style="color:#64748b;">${cliente.telefono || 'Sin teléfono'}</span><br>
            <i class="fas fa-check-circle" style="color:#059669;"></i> Contactado exitosamente.
        </div>
    </div>`;
    setTimeout(() => { div.style.display = 'none'; }, 4000);
}

function simularMensaje() {
    const clienteId = parseInt(document.getElementById('contactCliente')?.value);
    const mensaje = document.getElementById('contactMensaje')?.value.trim();
    if (!clienteId) { 
        alert('⚠️ Seleccione un cliente primero'); 
        return; 
    }
    if (!mensaje) { 
        alert('⚠️ Escriba un mensaje'); 
        return; 
    }
    const clientesData = <?= json_encode($clientes) ?>;
    const cliente = clientesData.find(c => c.id === clienteId);
    if (!cliente) return;
    const div = document.getElementById('contactResultado');
    div.style.display = 'block';
    div.innerHTML = `<div style="background:#dbeafe; padding:12px; border-radius:12px; display:flex; align-items:flex-start; gap:10px;">
        <i class="fas fa-envelope" style="color:#2563eb; font-size:1.5rem;"></i>
        <div>
            <strong>Mensaje a ${cliente.nombre}</strong><br>
            <span style="color:#64748b;">${cliente.email || 'Sin email'}</span><br>
            <strong>Mensaje:</strong> ${escapeHtml(mensaje)}<br>
            <i class="fas fa-check-circle" style="color:#059669;"></i> Envío simulado.
        </div>
    </div>`;
    setTimeout(() => { div.style.display = 'none'; }, 5000);
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

function cortarCliente(id, nombre) {
    if (confirm(`⚠️ ¿Cortar el servicio de "${nombre}"?\nEl cliente perderá conexión a Internet.`)) {
        window.location.href = `../controllers/cortar_cliente.php?id=${id}`;
    }
}

function contactarCliente(id, nombre, telefono) {
    if (telefono) {
        alert(`📞 Contactar a ${nombre}\nTeléfono: ${telefono}`);
    } else {
        alert(`📞 ${nombre} no tiene teléfono registrado`);
    }
}

// ========== TABS ==========
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const tabId = this.getAttribute('data-tab');
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        document.getElementById(tabId).classList.add('active');
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        if (tabId === 'contactar') actualizarContactoCliente();
    });
});

document.getElementById('contactCliente')?.addEventListener('change', actualizarContactoCliente);
document.getElementById('btnSimularLlamada')?.addEventListener('click', simularLlamada);
document.getElementById('btnSimularMensaje')?.addEventListener('click', simularMensaje);
</script>
</body>
</html>