<?php
session_start();

// Verificar si está logueado y es técnico (rol 3)
if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 3) {
    header('Location: ../login.php');
    exit;
}

include __DIR__ . '/../config/conexion.php';
include __DIR__ . '/../controllers/funcion_log.php';

$log = new SistemaLog($conexion);

// Obtener ID del técnico logueado
$id_tecnico = $_SESSION['id_usuario'];
$nombre_tecnico = $_SESSION['usuario'] ?? 'Técnico';

// =============================================
// 📊 ESTADÍSTICAS DEL TÉCNICO (CORREGIDAS)
// =============================================

// 1. Total de solicitudes asignadas o pendientes generales
$sql_asignadas = "SELECT COUNT(*) as total FROM soporte WHERE tecnico_id = ? OR tecnico_id IS NULL";
$stmt = mysqli_prepare($conexion, $sql_asignadas);
mysqli_stmt_bind_param($stmt, "i", $id_tecnico);
mysqli_stmt_execute($stmt);
$total_asignadas = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'] ?? 0;
mysqli_stmt_close($stmt);

// 2. Solicitudes activas (pendientes + en_progreso)
$sql_activas = "SELECT COUNT(*) as total FROM soporte WHERE (tecnico_id = ? OR tecnico_id IS NULL) AND estado IN ('pendiente', 'en_progreso')";
$stmt = mysqli_prepare($conexion, $sql_activas);
mysqli_stmt_bind_param($stmt, "i", $id_tecnico);
mysqli_stmt_execute($stmt);
$total_activas = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'] ?? 0;
mysqli_stmt_close($stmt);

// 3. Solicitudes pendientes
$sql_pendientes = "SELECT COUNT(*) as total FROM soporte WHERE (tecnico_id = ? OR tecnico_id IS NULL) AND estado = 'pendiente'";
$stmt = mysqli_prepare($conexion, $sql_pendientes);
mysqli_stmt_bind_param($stmt, "i", $id_tecnico);
mysqli_stmt_execute($stmt);
$total_pendientes = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'] ?? 0;
mysqli_stmt_close($stmt);

// 4. Solicitudes en progreso
$sql_progreso = "SELECT COUNT(*) as total FROM soporte WHERE tecnico_id = ? AND estado = 'en_progreso'";
$stmt = mysqli_prepare($conexion, $sql_progreso);
mysqli_stmt_bind_param($stmt, "i", $id_tecnico);
mysqli_stmt_execute($stmt);
$total_progreso = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'] ?? 0;
mysqli_stmt_close($stmt);

// 5. Solicitudes resueltas (Solo del técnico logueado)
$sql_resueltas = "SELECT COUNT(*) as total FROM soporte WHERE tecnico_id = ? AND estado = 'resuelto'";
$stmt = mysqli_prepare($conexion, $sql_resueltas);
mysqli_stmt_bind_param($stmt, "i", $id_tecnico);
mysqli_stmt_execute($stmt);
$total_resueltas = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'] ?? 0;
mysqli_stmt_close($stmt);

// 6. Solicitudes cerradas (Solo del técnico logueado)
$sql_cerradas = "SELECT COUNT(*) as total FROM soporte WHERE tecnico_id = ? AND estado = 'cerrado'";
$stmt = mysqli_prepare($conexion, $sql_cerradas);
mysqli_stmt_bind_param($stmt, "i", $id_tecnico);
mysqli_stmt_execute($stmt);
$total_cerradas = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'] ?? 0;
mysqli_stmt_close($stmt);

// =============================================
// 📊 CONSULTAS POR PRIORIDAD (ACTIVAS)
// =============================================

// Prioridad Alta
$sql_prioridad_alta = "SELECT COUNT(*) as total FROM soporte WHERE (tecnico_id = ? OR tecnico_id IS NULL) AND prioridad = 'alta' AND estado IN ('pendiente', 'en_progreso')";
$stmt = mysqli_prepare($conexion, $sql_prioridad_alta);
mysqli_stmt_bind_param($stmt, "i", $id_tecnico);
mysqli_stmt_execute($stmt);
$total_prioridad_alta = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'] ?? 0;
mysqli_stmt_close($stmt);

// Prioridad Media
$sql_prioridad_media = "SELECT COUNT(*) as total FROM soporte WHERE (tecnico_id = ? OR tecnico_id IS NULL) AND prioridad = 'media' AND estado IN ('pendiente', 'en_progreso')";
$stmt = mysqli_prepare($conexion, $sql_prioridad_media);
mysqli_stmt_bind_param($stmt, "i", $id_tecnico);
mysqli_stmt_execute($stmt);
$total_prioridad_media = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'] ?? 0;
mysqli_stmt_close($stmt);

// Prioridad Baja
$sql_prioridad_baja = "SELECT COUNT(*) as total FROM soporte WHERE (tecnico_id = ? OR tecnico_id IS NULL) AND prioridad = 'baja' AND estado IN ('pendiente', 'en_progreso')";
$stmt = mysqli_prepare($conexion, $sql_prioridad_baja);
mysqli_stmt_bind_param($stmt, "i", $id_tecnico);
mysqli_stmt_execute($stmt);
$total_prioridad_baja = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'] ?? 0;
mysqli_stmt_close($stmt);

// ✅ TODAS las solicitudes activas para la tabla del técnico
$sql_ultimas = "SELECT s.*, c.nombre as cliente_nombre, c.apellido as cliente_apellido 
                FROM soporte s
                LEFT JOIN cliente c ON s.cliente_id = c.id
                WHERE (s.tecnico_id = ? OR s.tecnico_id IS NULL) 
                  AND s.estado IN ('pendiente', 'en_progreso')
                ORDER BY 
                    CASE s.prioridad
                        WHEN 'alta' THEN 1
                        WHEN 'media' THEN 2
                        WHEN 'baja' THEN 3
                    END,
                    s.fecha_creacion ASC";
$stmt = mysqli_prepare($conexion, $sql_ultimas);
mysqli_stmt_bind_param($stmt, "i", $id_tecnico);
mysqli_stmt_execute($stmt);
$ultimas_solicitudes = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
mysqli_stmt_close($stmt);

// =============================================
// 📊 MÉTRICAS PARA EL GRÁFICO (FILTRADO CONSISTENTE)
// =============================================
$sql_conteo_tipos = "
    SELECT 
        COUNT(*) AS total_general,
        SUM(CASE WHEN titulo LIKE '%Conexión%' OR titulo LIKE '%conexion%' THEN 1 ELSE 0 END) AS cant_primera,
        SUM(CASE WHEN titulo LIKE '%Reconexión%' OR titulo LIKE '%reconexion%' THEN 1 ELSE 0 END) AS cant_reconexion,
        SUM(CASE WHEN titulo LIKE '%Corte%' OR titulo LIKE '%corte%' THEN 1 ELSE 0 END) AS cant_corte,
        SUM(CASE 
            WHEN titulo = 'Reclamo' 
              OR (titulo NOT LIKE '%Conexión%' 
              AND titulo NOT LIKE '%conexion%' 
              AND titulo NOT LIKE '%Corte%' 
              AND titulo NOT LIKE '%corte%' 
              AND titulo NOT LIKE '%Reconexión%' 
              AND titulo NOT LIKE '%reconexion%')
            THEN 1 ELSE 0 
        END) AS cant_reclamos
    FROM soporte
    WHERE tecnico_id = ? OR tecnico_id IS NULL
";

$stmt_metricas = mysqli_prepare($conexion, $sql_conteo_tipos);
mysqli_stmt_bind_param($stmt_metricas, "i", $id_tecnico);
mysqli_stmt_execute($stmt_metricas);
$res_metricas = mysqli_stmt_get_result($stmt_metricas);
$data_m = mysqli_fetch_assoc($res_metricas);
mysqli_stmt_close($stmt_metricas);

$total_solicitudes = (int)($data_m['total_general'] ?? 0);
$cant_primera      = (int)($data_m['cant_primera'] ?? 0);
$cant_reconexion   = (int)($data_m['cant_reconexion'] ?? 0);
$cant_cortes       = (int)($data_m['cant_corte'] ?? 0);
$cant_reclamos     = (int)($data_m['cant_reclamos'] ?? 0);

// Cálculo de Porcentajes
$pct_primera    = $total_solicitudes > 0 ? round(($cant_primera / $total_solicitudes) * 100, 1) : 0;
$pct_reconexion = $total_solicitudes > 0 ? round(($cant_reconexion / $total_solicitudes) * 100, 1) : 0;
$pct_cortes     = $total_solicitudes > 0 ? round(($cant_cortes / $total_solicitudes) * 100, 1) : 0;
$pct_reclamos   = $total_solicitudes > 0 ? round(($cant_reclamos / $total_solicitudes) * 100, 1) : 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Técnico - Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <link rel="stylesheet" href="../css/responsive_global.css">
    <script src="../js/responsive_sidebar.js" defer></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #f0f4f8; overflow-x: hidden; }

        .app-container { display: flex; min-height: 100vh; }

        /* ============================================= */
        /* SIDEBAR - TÉCNICO */
        /* ============================================= */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #0f2b3d 0%, #1b4f6e 100%);
            color: white;
            padding: 2rem 1.5rem;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
        }

        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-track { background: transparent; }
        .sidebar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.3); border-radius: 10px; }

        .logo-area {
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(255,255,255,0.15);
        }

        .logo-area h2 {
            font-size: 1.5rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .logo-area h2 i { color: #60a5fa; }
        .logo-area span { font-size: 0.7rem; opacity: 0.6; display: block; margin-top: 4px; }

        .nav-section { margin-bottom: 1.5rem; }
        .nav-section-title {
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            opacity: 0.5;
            margin-bottom: 0.8rem;
            font-weight: 600;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.7rem 1rem;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.2s;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            margin-bottom: 0.2rem;
            font-size: 0.9rem;
            border: none;
            background: transparent;
            width: 100%;
            text-align: left;
        }

        .nav-item:hover { background: rgba(255,255,255,0.1); color: white; }
        .nav-item.active { background: rgba(255,255,255,0.15); color: white; }
        .nav-item i { width: 22px; font-size: 1.1rem; text-align: center; color: rgba(255,255,255,0.6); }
        .nav-item:hover i, .nav-item.active i { color: white; }

        .nav-item .badge {
            background: #ef4444;
            color: white;
            padding: 1px 8px;
            border-radius: 20px;
            font-size: 0.6rem;
            font-weight: 700;
            margin-left: auto;
        }

        .nav-divider { border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 0.5rem 0 1rem 0; }

        /* ============================================= */
        /* MAIN CONTENT */
        /* ============================================= */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            background: white;
            padding: 1rem 2rem;
            border-radius: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            flex-wrap: wrap;
            gap: 1rem;
        }

        .page-title { font-size: 1.3rem; font-weight: 700; color: #1e2a41; }
        .page-title i { color: #1b4f6e; margin-right: 10px; }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.9rem;
            color: #1e2a41;
        }
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
            font-size: 1rem;
        }

        /* ============================================= */
        /* ESTADÍSTICAS - COMPACTAS EN UNA SOLA FILA */
        /* ============================================= */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(5, 1fr); /* Forzar las 5 tarjetas en 1 sola fila */
            gap: 0.8rem;
            margin-bottom: 1.5rem;
        }

        .stat-card {
            background: white;
            padding: 0.7rem 0.9rem; /* Padding reducido */
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.06);
            transition: transform 0.2s, box-shadow 0.2s;
            border-left: 3px solid #1b4f6e;
        }

        .stat-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.08); }

        .stat-card .stat-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.2rem; }

        .stat-card .stat-icon {
            width: 32px; /* Iconos más pequeños */
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
        }
        .stat-card .stat-icon.green { background: #d1fae5; color: #059669; }
        .stat-card .stat-icon.orange { background: #fef3c7; color: #d97706; }
        .stat-card .stat-icon.red { background: #fee2e2; color: #dc2626; }
        .stat-card .stat-icon.blue { background: #dbeafe; color: #1b4f6e; }

        .stat-card .number { font-size: 1.3rem; font-weight: 700; color: #0f2b3d; line-height: 1.1; }
        .stat-card .number.success { color: #10b981; }
        .stat-card .number.warning { color: #f59e0b; }
        .stat-card .number.danger { color: #ef4444; }
        .stat-card .number.info { color: #3b82f6; }

        .stat-card .label { color: #64748b; font-size: 0.65rem; font-weight: 600; display: flex; align-items: center; gap: 4px; margin-top: 3px; }
        .stat-card .sub-info { font-size: 0.6rem; color: #94a3b8; margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

        /* Adaptabilidad para pantallas más pequeñas */
        @media (max-width: 1200px) {
            .stats-row { grid-template-columns: repeat(3, 1fr); } /* 3 columnas si la pantalla se vuelve estrecha */
        }
        @media (max-width: 768px) {
            .stats-row { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 480px) {
            .stats-row { grid-template-columns: 1fr; }
        }

        /* ============================================= */
        /* GRÁFICOS */
        /* ============================================= */
        .charts-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .chart-card {
            background: white;
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
        }

        .chart-title {
            font-size: 1rem;
            font-weight: 600;
            color: #1e2a41;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #f1f5f9;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .chart-title i { color: #1b4f6e; }

        .chart-container {
            position: relative;
            height: 280px;
        }

        /* Estilos para la tabla de solicitudes en tecnico.php */
        .solicitudes-section {
            background: white;
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            margin-top: 1.5rem;
        }

        .solicitudes-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #f1f5f9;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .solicitudes-header h3 {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #1e2a41;
            font-size: 1rem;
            font-weight: 600;
        }

        .solicitudes-header h3 i { color: #1b4f6e; }

        .btn-ver-todas {
            background: linear-gradient(135deg, #0f2b3d, #1b4f6e);
            color: white;
            border: none;
            padding: 0.4rem 1.2rem;
            border-radius: 30px;
            cursor: pointer;
            font-size: 0.75rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: 0.3s;
            text-decoration: none;
        }

        .btn-ver-todas:hover { opacity: 0.9; transform: scale(0.97); }

        .solicitudes-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.82rem;
        }

        .solicitudes-table th {
            text-align: left;
            padding: 0.6rem 0.6rem;
            background: #f8fafc;
            font-weight: 600;
            color: #1e2a41;
            font-size: 0.6rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #e2e8f0;
        }

        .solicitudes-table td {
            padding: 0.5rem 0.6rem;
            border-bottom: 1px solid #edf2f7;
            color: #1f2b48;
            vertical-align: middle;
        }

        .solicitudes-table tr:hover td { background: #f8fafc; }

        .badge-estado {
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 0.6rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .badge-estado.pendiente { background: #fef3c7; color: #92400e; }
        .badge-estado.progreso { background: #dbeafe; color: #1e40af; }

        .badge-prioridad {
            padding: 1px 8px;
            border-radius: 10px;
            font-size: 0.55rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .badge-prioridad.alta { background: #fee2e2; color: #991b1b; }
        .badge-prioridad.media { background: #fef3c7; color: #92400e; }
        .badge-prioridad.baja { background: #e0e7ff; color: #3730a3; }

        .empty-state {
            text-align: center;
            padding: 2rem;
            color: #94a3b8;
        }

        .empty-state i { font-size: 2rem; display: block; margin-bottom: 0.5rem; color: #cbd5e1; }

        /* ============================================= */
        /* FOOTER */
        /* ============================================= */
        .footer {
            margin-top: 2rem;
            padding-top: 1rem;
            text-align: center;
            font-size: 0.75rem;
            color: #94a3b8;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .status-dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            background: #10b981;
            border-radius: 50%;
            margin-right: 6px;
            animation: pulse-dot 2s infinite;
        }

        @keyframes pulse-dot { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }

        .update-time { font-size: 0.7rem; color: #94a3b8; }

        /* ============================================= */
        /* RESPONSIVE */
        /* ============================================= */
        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 1rem; }
            .stats-row { grid-template-columns: 1fr 1fr; }
            .charts-row { grid-template-columns: 1fr; }
            .solicitudes-table th, .solicitudes-table td { padding: 0.3rem; font-size: 0.65rem; }
            .top-bar { flex-direction: column; align-items: stretch; text-align: center; }
            .user-info { justify-content: center; }
            .footer { flex-direction: column; text-align: center; }
        }

        /* ============================================= */
/* REGLAS PARA IMPRESIÓN / EXPORTAR A PDF */
/* ============================================= */
@media print {
    /* Ocultar elementos innecesarios */
    .sidebar,
    .top-bar,
    .stats-row,
    .chart-card,
    .footer,
    .btn-ver-todas {
        display: none !important;
    }

    /* Resetear márgenes y fondos */
    body {
        background: white !important;
        padding: 0 !important;
        margin: 0 !important;
    }

    .main-content {
        margin-left: 0 !important;
        padding: 0 !important;
    }

    .solicitudes-section {
        box-shadow: none !important;
        padding: 0 !important;
        margin-top: 0 !important;
    }

    /* Título formateado para el reporte */
    .solicitudes-header h3::before {
        content: "REPORTE DE SOLICITUDES ACTIVAS - CHANGO VISION\a";
        white-space: pre;
        font-size: 1.2rem;
        font-weight: 800;
        color: #0f2b3d;
        display: block;
        margin-bottom: 8px;
    }

    /* Formato de la tabla */
    .solicitudes-table {
        width: 100% !important;
        border-collapse: collapse !important;
        font-size: 0.85rem !important;
    }

    .solicitudes-table th,
    .solicitudes-table td {
        border: 1px solid #cbd5e1 !important;
        padding: 8px !important;
        color: #000 !important;
    }

    .solicitudes-table th {
        background-color: #f1f5f9 !important;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
    }

    .badge-prioridad, .badge-estado {
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
        border: 1px solid #94a3b8 !important;
    }
}

    </style>
</head>
<body>

<div class="app-container">
    <!-- ============================================= -->
    <!-- SIDEBAR - TÉCNICO -->
    <!-- ============================================= -->
    <div class="sidebar">
        <div class="sidebar-mobile-header">
            <span class="sidebar-mobile-title"><i class="fas fa-tools"></i> Menú Técnico</span>
            <button class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Cerrar menú">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="logo-area">
            <h2><i class="fas fa-tools"></i> Técnico</h2>
            <span>Panel de Trabajo</span>
        </div>

        <div class="nav-section">
            <div class="nav-section-title">Soporte</div>
            <a href="soporte_tecnico.php" class="nav-item">
                <i class="fas fa-headset"></i>
                <span>Tareas Pendientes</span>
                <?php if ($total_activas > 0): ?>
                    <span class="badge"><?= $total_activas ?></span>
                <?php endif; ?>
            </a>
            <a href="soporte_historial.php" class="nav-item">
                <i class="fas fa-history"></i>
                <span>Historial de Trabajos</span>
            </a>
        </div>

        <hr class="nav-divider">

        <div class="nav-section">
            <div class="nav-section-title">Configuración</div>
            <a href="cambiar_datos.php" class="nav-item">
                <i class="fas fa-user-cog"></i>
                <span>Cambiar Datos</span>
            </a>
            <a href="../logout.php" class="nav-item" onclick="return confirm('¿Cerrar sesión?')">
                <i class="fas fa-sign-out-alt"></i>
                <span>Cerrar Sesión</span>
            </a>
        </div>
    </div>

    <!-- ============================================= -->
    <!-- MAIN CONTENT -->
    <!-- ============================================= -->
    <div class="main-content">
        <div class="top-bar">
            <div style="display:flex; align-items:center; gap:12px;">
                <button class="mobile-toggle-btn" id="mobileMenuBtn" aria-label="Abrir menú de navegación">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <i class="fas fa-calendar-day"></i>
                    <span id="fechaActual"><?= date('d/m/Y') ?></span>
                </div>
            </div>
            <div class="user-info">
                <i class="fas fa-user-cog" style="color:#1b4f6e;"></i>
                <span><?= htmlspecialchars($nombre_tecnico) ?></span>
                <div class="user-avatar">
                    <?= strtoupper(substr($nombre_tecnico, 0, 1)) ?>
                </div>
            </div>
        </div>

        <!-- ============================================= -->
        <!-- ESTADÍSTICAS -->
        <!-- ============================================= -->
        <div class="stats-row">
            <div class="stat-card" style="border-color: #10b981;">
                <div class="stat-header">
                    <div class="stat-icon green"><i class="fas fa-check-circle"></i></div>
                </div>
                <div class="number success"><?= $total_resueltas +$total_cerradas ?></div>
                <div class="label"><i class="fas fa-check" style="color:#10b981;"></i> Trabajos Completados</div>
                <div class="sub-info">Resueltos y cerrados</div>
            </div>

            <div class="stat-card" style="border-color: #f59e0b;">
                <div class="stat-header">
                    <div class="stat-icon orange"><i class="fas fa-clock"></i></div>
                </div>
                <div class="number warning"><?= $total_pendientes +$total_progreso ?></div>
                <div class="label"><i class="fas fa-spinner" style="color:#f59e0b;"></i> En Proceso</div>
                <div class="sub-info"><?= $total_pendientes ?> pendientes · <?= $total_progreso ?> en progreso</div>
            </div>

            <!-- 1. PRIORIDAD ALTA -->
            <div class="stat-card" style="border-left: 4px solid #ef4444;">
                <div class="stat-header">
                    <div class="stat-icon red"><i class="fas fa-exclamation-triangle"></i></div>
                </div>
                <div class="number danger"><?= $total_prioridad_alta ?></div>
                <div class="label"><i class="fas fa-circle" style="color:#ef4444; font-size:0.6rem;"></i> Prioridad Alta</div>
                <div class="sub-info">Atención urgente requerida</div>
            </div>

            <!-- 2. PRIORIDAD MEDIA -->
            <div class="stat-card" style="border-left: 4px solid #f59e0b;">
                <div class="stat-header">
                    <div class="stat-icon orange"><i class="fas fa-clock"></i></div>
                </div>
                <div class="number warning"><?= $total_prioridad_media ?></div>
                <div class="label"><i class="fas fa-circle" style="color:#f59e0b; font-size:0.6rem;"></i> Prioridad Media</div>
                <div class="sub-info">Tareas de atencion regular</div>
            </div>

            <!-- 3. PRIORIDAD BAJA -->
            <div class="stat-card" style="border-left: 4px solid #3b82f6;">
                <div class="stat-header">
                    <div class="stat-icon blue"><i class="fas fa-arrow-down"></i></div>
                </div>
                <div class="number info"><?= $total_prioridad_baja ?></div>
                <div class="label"><i class="fas fa-circle" style="color:#3b82f6; font-size:0.6rem;"></i> Prioridad Baja</div>
                <div class="sub-info">Tareas no urgentes o de rutina</div>
            </div>
        </div>

            
        <!-- ============================================= -->
<!-- GRÁFICO DE SOPORTE POR TIPO -->
<!-- ============================================= -->
<div class="chart-card">
    <div class="chart-title">
        <i class="fas fa-chart-pie" style="color:#1b4f6e;"></i>
        Tipo de Solicitudes (%)
    </div>
    <div class="chart-container" style="position: relative; height: 220px;">
        <canvas id="soporteChart"></canvas>
    </div>
    <div style="margin-top: 1rem; text-align: center; font-size: 0.75rem; display: flex; justify-content: center; gap: 0.8rem; flex-wrap: wrap;">
        <span style="color: #10b981; font-weight: 600;">● 1ª Conexión (<?= (float)($pct_primera ?? 0) ?>%)</span>
        <span style="color: #3b82f6; font-weight: 600;">● Reconexión (<?= (float)($pct_reconexion ?? 0) ?>%)</span>
        <span style="color: #ef4444; font-weight: 600;">● Cortes (<?= (float)($pct_cortes ?? 0) ?>%)</span>
        <span style="color: #f59e0b; font-weight: 600;">● Reclamos (<?= (float)($pct_reclamos ?? 0) ?>%)</span>
    </div>
</div>


        <!-- ============================================= -->
        <!-- SOLICITUDES ACTIVAS (TODAS) -->
        <!-- ============================================= -->
        <div class="solicitudes-section">
            <div class="solicitudes-header">
    <h3>
        <i class="fas fa-list"></i> Mis Solicitudes Activas
        <span style="font-size:0.7rem; color:#64748b; font-weight:400;">
            (<?= count($ultimas_solicitudes) ?> activas)
        </span>
    </h3>
    <div style="display: flex; gap: 8px;">
        <button onclick="exportarTablaPDF()" class="btn-ver-todas" style="background: #10b981; border: none; cursor: pointer;">
            <i class="fas fa-file-pdf"></i> Exportar a PDF
        </button>
        <a href="soporte_tecnico.php" class="btn-ver-todas">
            Ver todas <i class="fas fa-arrow-right"></i>
        </a>
    </div>
</div>

            <?php if (empty($ultimas_solicitudes)): ?>
                <div class="empty-state">
                    <i class="fas fa-check-circle" style="color:#10b981;"></i>
                    <p>No tienes solicitudes activas</p>
                    <span style="font-size:0.8rem; color:#94a3b8;">Todas tus solicitudes están resueltas o cerradas</span>
                </div>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table class="solicitudes-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Cliente</th>
                                <th>Título</th>
                                <th>Prioridad</th>
                                <th>Estado</th>
                                <th>Fecha</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ultimas_solicitudes as$s): 
                                $estado_clases = ['pendiente' => 'pendiente', 'en_progreso' => 'progreso'];$prioridad_clases = ['alta' => 'alta', 'media' => 'media', 'baja' => 'baja'];
                                $estados = ['pendiente' => 'Pendiente', 'en_progreso' => 'En Progreso'];$prioridad_iconos = [
                                    'alta' => '<i class="fas fa-circle" style="color:#ef4444;"></i>', 
                                    'media' => '<i class="fas fa-circle" style="color:#f59e0b;"></i>', 
                                    'baja' => '<i class="fas fa-circle" style="color:#3b82f6;"></i>'
                                ];
                            ?>
                            <tr>
                                <td>#<?= $s['id_soporte'] ?></td>
                                <td>
                                    <strong><?= htmlspecialchars($s['cliente_nombre'] ?? 'Cliente') ?> <?= htmlspecialchars($s['cliente_apellido'] ?? '') ?></strong>
                                    <br><small style="font-size:0.55rem; color:#94a3b8;">
                                        <i class="fas fa-phone"></i> <?= htmlspecialchars($s['cliente_telefono'] ?? '-') ?>
                                    </small>
                                </td>
                                <td><?= htmlspecialchars($s['titulo']) ?></td>
                                <td>
                                    <span class="badge-prioridad <?= $prioridad_clases[$s['prioridad']] ?? 'baja' ?>">
                                        <?= $prioridad_iconos[$s['prioridad']] ?? '<i class="fas fa-circle" style="color:#3b82f6;"></i>' ?> <?= ucfirst($s['prioridad'] ?? 'Baja') ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge-estado <?= $estado_clases[$s['estado']] ?? 'pendiente' ?>">
                                        <i class="fas <?= $s['estado'] === 'en_progreso' ? 'fa-spinner fa-spin' : 'fa-clock' ?>"></i>
                                        <?= $estados[$s['estado']] ?? 'Pendiente' ?>
                                    </span>
                                </td>
                                <td><?= date('d/m/Y', strtotime($s['fecha_creacion'])) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- ============================================= -->
        <!-- FOOTER -->
        <!-- ============================================= -->
        <div class="footer">
            <div>© 2026 Chango Vision - Panel Técnico</div>
            <div class="footer-status">
                <span><span class="status-dot"></span> Sistema Activo</span>
                <span><i class="fas fa-user-cog"></i> Técnico</span>
                <span class="update-time" id="updateTime">
                    <i class="fas fa-clock"></i> Actualizando...
                </span>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
let soporteChart = null;
let rendimientoChart = null;

// =============================================
// 📊 DATOS SANITIZADOS PARA EVITAR SYNTAXERROR
// =============================================
const datosSoporte = {
    primera: <?= (float)($pct_primera ?? 0) ?>,
    reconexion: <?= (float)($pct_reconexion ?? 0) ?>,
    cortes: <?= (float)($pct_cortes ?? 0) ?>,
    reclamos: <?= (float)($pct_reclamos ?? 0) ?>
};

// =============================================
// 📈 INICIALIZAR GRÁFICOS
// =============================================
function initCharts() {
    const elSoporte = document.getElementById('soporteChart');
    if (elSoporte) {
        const ctxSoporte = elSoporte.getContext('2d');
        soporteChart = new Chart(ctxSoporte, {
            type: 'pie',
            data: {
                labels: ['1ª Conexión', 'Reconexión', 'Cortes', 'Reclamos'],
                datasets: [{
                    data: [
                        datosSoporte.primera, 
                        datosSoporte.reconexion, 
                        datosSoporte.cortes, 
                        datosSoporte.reclamos
                    ],
                    backgroundColor: ['#10b981', '#3b82f6', '#ef4444', '#f59e0b'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { font: { size: 11 } }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return ' ' + context.label + ': ' + context.raw + '%';
                            }
                        }
                    }
                }
            }
        });
    }

    const elRendimiento = document.getElementById('rendimientoChart');
    if (elRendimiento) {
        const ctxRendimiento = elRendimiento.getContext('2d');
        rendimientoChart = new Chart(ctxRendimiento, {
            type: 'bar',
            data: {
                labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun'],
                datasets: [{
                    label: 'Trabajos Realizados',
                    data: [<?= rand(0, 10) ?>, <?= rand(0, 10) ?>, <?= rand(0, 10) ?>, <?= rand(0, 10) ?>, <?= rand(0, 10) ?>, <?= rand(0, 10) ?>],
                    backgroundColor: '#1b4f6e',
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'top' }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { stepSize: 1 }
                    }
                }
            }
        });
    }
}

// =============================================
// ACTUALIZAR HORA Y FECHA
// =============================================
function actualizarHora() {
    const ahora = new Date();
    const fecha = ahora.toLocaleDateString('es-AR');
    const hora = ahora.toLocaleTimeString('es-AR');
    
    const updateTimeEl = document.getElementById('updateTime');
    if (updateTimeEl) {
        updateTimeEl.innerHTML = `<i class="fas fa-clock"></i> ${fecha} ${hora}`;
    }
    
    const fechaActualEl = document.getElementById('fechaActual');
    if (fechaActualEl) {
        fechaActualEl.textContent = fecha;
    }
}

// =============================================
// INICIALIZAR EVENTOS
// =============================================
document.addEventListener('DOMContentLoaded', function() {
    initCharts();
    actualizarHora();
    setInterval(actualizarHora, 30000);
});

function exportarTablaPDF() {
    window.print();
}

</script>
<div class="sidebar-backdrop" id="sidebarBackdrop"></div>
</body>
</html>