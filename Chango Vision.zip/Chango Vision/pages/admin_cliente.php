<?php

// ACTIVAR ERRORES PARA VER EL PROBLEMA
ini_set('display_errors', 1);
error_reporting(E_ALL);

// SESIÓN
session_start();

// =============================================
// ✅ ROLES PERMITIDOS:
// 1 = Administrador
// 2 = Cobrador
// 4 = Administrador de Red
// =============================================
$id_rol = $_SESSION['id_rol'] ?? 0;
$roles_permitidos = [1, 2, 4];

if (!in_array($id_rol, $roles_permitidos)) {
    header('Location: ../login.php');
    exit;
}

// =============================================
// ✅ VARIABLES DE ROL PARA USAR EN EL CÓDIGO
// =============================================
$es_administrador = ($id_rol == 1);
$es_cobrador = ($id_rol == 2);
$es_admin_red = ($id_rol == 4);

// ✅ ADMINISTRADOR Y ADMIN RED PUEDEN HACER TODO
$puede_editar = ($id_rol == 1 || $id_rol == 4);
$puede_eliminar = ($id_rol == 1 || $id_rol == 4);
$puede_cortar = ($id_rol == 1 || $id_rol == 4);
$puede_pagar = ($id_rol == 1 || $id_rol == 2 || $id_rol == 4);

// =============================================
// ✅ DETERMINAR URL DE RETORNO SEGÚN ROL
// =============================================
switch ($id_rol) {
    case 1: // Administrador
        $url_volver = 'admin.php';
        break;
    case 2: // Cobrador
        $url_volver = 'cobrador_clientes.php';
        break;
    case 4: // Admin Red
        $url_volver = 'admin_red.php';
        break;
    default:
        $url_volver = 'login.php';
        break;
}

// CONEXIÓN
include __DIR__ . '/../config/conexion.php';

// Verificar conexión
if (!$conexion) {
    die(json_encode(['status' => 'error', 'message' => 'Error de conexión a BD']));
}

// ✅ INCLUIR Y CREAR INSTANCIA DE LOG
include __DIR__ . '/../controllers/funcion_log.php';
$log = new SistemaLog($conexion);

// OBTENER BARRIOS PARA EL FILTRO
$sql_barrios_filtro = "SELECT id_barrio, nombre FROM barrio ORDER BY nombre";
$result_barrios_filtro = mysqli_query($conexion, $sql_barrios_filtro);
$barrios_filtro = [];
while ($row = mysqli_fetch_assoc($result_barrios_filtro)) {
    $barrios_filtro[] = $row;
}

// FILTRO POR BARRIO RECIBIDO DESDE EL BOTÓN +
$filtro_barrio = isset($_GET['barrio']) ? (int)$_GET['barrio'] : 0;

// Condición SQL del barrio
$condicion_barrio = ($filtro_barrio > 0)
    ? " AND c.id_barrio = $filtro_barrio "
    : "";

// =============================================
// MÉTRICAS Y ESTADÍSTICAS DEL DÍA DE HOY
// =============================================
if ($id_rol == 2) {

    // 1. Total recaudado hoy en pesos
    $sql_recaudado = "SELECT COALESCE(SUM(monto), 0) AS total_hoy
                      FROM pago
                      WHERE DATE(fecha_pago) = CURDATE()
                        AND estado = 'Pagado'";

    $res_rec = mysqli_query($conexion, $sql_recaudado);
    $total_recaudado_hoy = mysqli_fetch_assoc($res_rec)['total_hoy'] ?? 0;


    // 2. Cantidad de clientes que pagaron hoy
    $sql_pagaron = "SELECT COUNT(DISTINCT id_cliente) AS pagaron_hoy
                    FROM pago
                    WHERE DATE(fecha_pago) = CURDATE()
                      AND estado = 'Pagado'";

    $res_pag = mysqli_query($conexion, $sql_pagaron);
    $clientes_pagaron_hoy = mysqli_fetch_assoc($res_pag)['pagaron_hoy'] ?? 0;


    // 3. Clientes pendientes de cobro
    $sql_no_pagaron = "SELECT COUNT(*) AS no_pagaron_hoy
                       FROM cliente c
                       WHERE c.eliminado = 0
                         AND c.estado = 'Activo'
                         AND c.estado_pago != 'suspendido'
                         AND (
                             SELECT COUNT(*)
                             FROM pago p
                             WHERE p.id_cliente = c.id
                               AND p.estado = 'Pagado'
                         ) = 1
                         AND c.fecha_ultimo_pago IS NOT NULL
                         {$condicion_barrio}";

    $res_no_pag = mysqli_query($conexion, $sql_no_pagaron);

    $clientes_no_pagaron_hoy = $res_no_pag
        ? (mysqli_fetch_assoc($res_no_pag)['no_pagaron_hoy'] ?? 0)
        : 0;
}

// PAGINACIÓN DINÁMICA
$registros_por_pagina = 5;

$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$pagina_actual = max(1, $pagina_actual);

$offset = ($pagina_actual - 1) * $registros_por_pagina;

// =============================================
// CONTAR CLIENTES SEGÚN EL ROL
// =============================================

if ($id_rol == 2) {

    // Cobrador: solamente clientes listos para segundo pago
    $sql_count = "SELECT COUNT(*) as total
                  FROM cliente c
                  WHERE c.eliminado = 0
                    AND c.estado = 'Activo'
                    AND c.estado_pago != 'suspendido'
                    AND (
                        SELECT COUNT(*)
                        FROM pago p
                        WHERE p.id_cliente = c.id
                          AND p.estado = 'Pagado'
                    ) = 1
                    AND c.fecha_ultimo_pago IS NOT NULL";

} else {

    // Administrador / Admin Red
    $sql_count = "SELECT COUNT(*) as total
                  FROM cliente c
                  WHERE c.eliminado = 0";
}


// =============================================
// APLICAR FILTRO POR BARRIO
// =============================================

if ($filtro_barrio > 0) {
    $sql_count .= " AND c.id_barrio = $filtro_barrio";
}


// =============================================
// EJECUTAR CONSULTA Y CALCULAR PAGINACIÓN
// =============================================

$result_count = mysqli_query($conexion, $sql_count);

if (!$result_count) {
    die("Error al contar clientes: " . mysqli_error($conexion));
}

$total_registros = mysqli_fetch_assoc($result_count)['total'] ?? 0;

$total_paginas = ceil($total_registros / $registros_por_pagina);
// FUNCIONES
function generarCodigoCliente($nombre, $apellido, $conexion) {
    $base = strtoupper(substr(trim($nombre), 0, 1) . substr(trim($apellido), 0, 1));
    if (empty($base)) $base = 'XX';
    
    $sql = "SELECT codigo_cliente FROM cliente WHERE codigo_cliente LIKE '$base%' ORDER BY codigo_cliente DESC";
    $result = mysqli_query($conexion, $sql);
    
    $max = 0;
    while ($row = mysqli_fetch_assoc($result)) {
        $num = intval(substr($row['codigo_cliente'], 2));
        if ($num > $max) $max = $num;
    }
    
    return $base . ($max + 1);
}

function calcularEstadoPago($cliente) {
    $estado_pago = $cliente['estado_pago'] ?? 'pendiente';
    $dias_mora = $cliente['dias_mora'] ?? 0;
    
    // ✅ Si el cliente está eliminado, mostrar como suspendido (sin botón reactivar)
    if (isset($cliente['eliminado']) && $cliente['eliminado'] == 1) {
        return ['estado' => 'suspendido', 'dias_mora' => 0, 'eliminado' => true];
    }
    
    // Si el cliente está suspendido, siempre mostrar suspendido
    if ($cliente['estado'] === 'Inactivo' || $estado_pago === 'suspendido') {
        return ['estado' => 'suspendido', 'dias_mora' => 0, 'eliminado' => false];
    }
    
    // Si está pagado
    if ($estado_pago === 'pagado') {
        return ['estado' => 'pagado', 'dias_mora' => 0, 'eliminado' => false];
    }
    
    // Si está pendiente con mora
    if ($estado_pago === 'pendiente' && $dias_mora > 0) {
        return ['estado' => 'mora', 'dias_mora' => $dias_mora, 'eliminado' => false];
    }
    
    // Pendiente sin mora
    return ['estado' => 'pendiente', 'dias_mora' => 0, 'eliminado' => false];
}
// PROCESAR AJAX (GET)
if (isset($_GET['ajax']) && $_GET['ajax'] === 'get_codigo') {
    header('Content-Type: application/json');
    
    $nombre = $_GET['nombre'] ?? '';
    $apellido = $_GET['apellido'] ?? '';
    
    if (empty($nombre) || empty($apellido)) {
        echo json_encode(['codigo' => '']);
        exit;
    }
    
    $base = strtoupper(substr(trim($nombre), 0, 1) . substr(trim($apellido), 0, 1));
    if (empty($base)) $base = 'XX';
    
    $sql = "SELECT codigo_cliente FROM cliente WHERE codigo_cliente LIKE '$base%' ORDER BY codigo_cliente DESC";
    $result = mysqli_query($conexion, $sql);
    
    $max = 0;
    while ($row = mysqli_fetch_assoc($result)) {
        $num = intval(substr($row['codigo_cliente'], 2));
        if ($num > $max) $max = $num;
    }
    
    echo json_encode(['codigo' => $base . ($max + 1)]);
    exit;
}

if (isset($_GET['ajax']) && $_GET['ajax'] === 'get_precio') {
    header('Content-Type: application/json');
    
    $id_cliente = intval($_GET['id_cliente'] ?? 0);
    
    if ($id_cliente <= 0) {
        echo json_encode(['precio' => null, 'meses_deuda' => 1]);
        exit;
    }
    
    $sql = "SELECT ts.precio_base, c.fecha_ultimo_pago, c.dias_mora
            FROM cliente c 
            LEFT JOIN tipo_servicio ts ON c.id_tipo = ts.id_tipo 
            WHERE c.id = ?";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id_cliente);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);
    
    // CALCULAR MESES DE DEUDA REALES
    $meses_deuda = 1;
    if (!empty($data['fecha_ultimo_pago'])) {
        $fecha_ultimo = new DateTime($data['fecha_ultimo_pago']);
        $hoy = new DateTime();
        if ($fecha_ultimo < $hoy) {
            $diff = $fecha_ultimo->diff($hoy);
            $meses_deuda = ($diff->y * 12) + $diff->m;
            if ($meses_deuda < 1) $meses_deuda = 1;
        }
    } elseif (!empty($data['dias_mora']) && $data['dias_mora'] > 0) {
        $meses_deuda = max(1, ceil($data['dias_mora'] / 30));
    }
    
    if ($meses_deuda > 12) $meses_deuda = 12;
    
    echo json_encode([
        'precio' => $data['precio_base'] ?? null,
        'meses_deuda' => $meses_deuda
    ]);
    exit;
}
// =============================================
// OBTENER BARRIOS PARA AJAX
// =============================================
if (isset($_GET['ajax']) && $_GET['ajax'] === 'get_barrios') {
    header('Content-Type: application/json');
    
    $result = $conexion->query("SELECT id_barrio, nombre FROM barrio ORDER BY nombre");
    $barrios = [];
    while ($row = $result->fetch_assoc()) {
        $barrios[] = $row;
    }
    
    echo json_encode(['status' => 'success', 'barrios' => $barrios]);
    exit;
}


// =============================================
// OBTENER CLIENTE POR ID PARA EDITAR
// =============================================
if (isset($_GET['ajax']) && $_GET['ajax'] === 'get_cliente') {
    header('Content-Type: application/json');
    
    if ($id_rol != 1 && $id_rol != 4) {
        echo json_encode(['status' => 'error', 'message' => 'No tienes permiso para editar clientes']);
        exit;
    }
    
    $id = intval($_GET['id'] ?? 0);
    
    if ($id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID inválido']);
        exit;
    }
    
    // ✅ VERIFICA QUE ESTA CONSULTA INCLUYA observacion
    $sql = "SELECT c.*, 
                   b.nombre as barrio_nombre, 
                   ts.nombre as tipo_servicio_nombre,
                   ts.dia_corte,
                   ts.precio_base,
                   (SELECT COUNT(*) FROM pago WHERE id_cliente = c.id) as total_pagos
            FROM cliente c
            LEFT JOIN barrio b ON c.id_barrio = b.id_barrio
            LEFT JOIN tipo_servicio ts ON c.id_tipo = ts.id_tipo
            WHERE c.id = ?";
    
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $cliente = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);
    
    if ($cliente) {
        // ✅ VERIFICA QUE ESTE LLEGANDO observacion
        echo json_encode(['status' => 'success', 'data' => $cliente]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Cliente no encontrado']);
    }
    exit;
}
// =============================================
// PROCESAR POST (AJAX)
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['ajax'] == 1) {
    header('Content-Type: application/json');
    
    $accion = $_POST['accion'] ?? '';
    
    // =============================================
    // VALIDAR CAMPOS ÚNICOS
    // =============================================
    function validarCamposUnicos($conexion, $dni, $telefono, $email, $id_excluir = 0) {
        $errores = [];
        
        $sql = "SELECT id FROM cliente WHERE dni = ? AND id != ?";
        $stmt = mysqli_prepare($conexion, $sql);
        mysqli_stmt_bind_param($stmt, "si", $dni, $id_excluir);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if (mysqli_num_rows($result) > 0) {
            $errores[] = 'El DNI ya está registrado en otro cliente';
        }
        mysqli_stmt_close($stmt);
        
        if (!empty($telefono)) {
            $sql = "SELECT id FROM cliente WHERE telefono = ? AND id != ?";
            $stmt = mysqli_prepare($conexion, $sql);
            mysqli_stmt_bind_param($stmt, "si", $telefono, $id_excluir);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            if (mysqli_num_rows($result) > 0) {
                $errores[] = 'El teléfono ya está registrado en otro cliente';
            }
            mysqli_stmt_close($stmt);
        }
        
        if (!empty($email)) {
            $sql = "SELECT id FROM cliente WHERE email = ? AND id != ?";
            $stmt = mysqli_prepare($conexion, $sql);
            mysqli_stmt_bind_param($stmt, "si", $email, $id_excluir);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            if (mysqli_num_rows($result) > 0) {
                $errores[] = 'El email ya está registrado en otro cliente';
            }
            mysqli_stmt_close($stmt);
        }
        
        return $errores;
    }
    
// =============================================
    // COBRADOR: GUARDAR OBSERVACIÓN DE COBRO
    // =============================================
    if ($accion === 'guardar_observacion_cobro') {
        if ($id_rol != 2 && $id_rol != 1 && $id_rol != 4) {
            echo json_encode(['status' => 'error', 'message' => 'Sin permisos']);
            exit;
        }

        $id_cliente = intval($_POST['id_cliente'] ?? 0);
        $pago_realizado = intval($_POST['pago_realizado'] ?? 0); // 1 = Pagó, 0 = No pagó
        $observacion = trim($_POST['observacion'] ?? '');

        if ($id_cliente <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'ID de cliente inválido']);
            exit;
        }

        // Formatear la nota de cobro con fecha y estado
        $fecha_actual = date('d/m/Y H:i');
        $estado_texto = ($pago_realizado == 1) ? 'PAGÓ' : 'NO PAGÓ';
        $nota_completa = "[$fecha_actual - Cobrador ($estado_texto)]: $observacion";

        // Concatenar con las observaciones previas si existen
        $sql_actual = "SELECT observacion FROM cliente WHERE id = ?";
        $stmt_act = mysqli_prepare($conexion, $sql_actual);
        mysqli_stmt_bind_param($stmt_act, "i", $id_cliente);
        mysqli_stmt_execute($stmt_act);
        $res_act = mysqli_stmt_get_result($stmt_act)->fetch_assoc();
        mysqli_stmt_close($stmt_act);

        $obs_previa = $res_act['observacion'] ?? '';
        $nueva_observacion = !empty($obs_previa) ? $obs_previa . "\n" . $nota_completa : $nota_completa;

        // Actualizar observación en la tabla cliente
        $sql = "UPDATE cliente SET observacion = ?, observacion_pago = ? WHERE id = ?";
        $stmt = mysqli_prepare($conexion, $sql);
        mysqli_stmt_bind_param($stmt, "ssi", $nueva_observacion, $nota_completa, $id_cliente);

        if (mysqli_stmt_execute($stmt)) {
            $log->registrarAccion(
                $_SESSION['id_usuario'] ?? 0,
                $_SESSION['usuario'] ?? 'Cobrador',
                'Observación de Cobro',
                "Cobrador registró observación ($estado_texto) para cliente ID: $id_cliente",
                $observacion,
                'info'
            );

            echo json_encode([
                'status' => 'success',
                'message' => '✅ Observación guardada correctamente',
                'pago_realizado' => $pago_realizado,
                'id_cliente' => $id_cliente
            ]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Error al guardar observación: ' . mysqli_error($conexion)]);
        }

        mysqli_stmt_close($stmt);
        exit;
    }


    // =============================================
    // CREAR BARRIO RÁPIDO
    // =============================================
    if ($accion === 'crear_barrio_rapido') {
        $nombre = trim($_POST['nombre'] ?? '');
        
        if (empty($nombre)) {
            echo json_encode(['status' => 'error', 'message' => 'El nombre del barrio es obligatorio']);
            exit;
        }
        
        $check = $conexion->query("SELECT id_barrio FROM barrio WHERE nombre = '$nombre'");
        if ($check && $check->num_rows > 0) {
            echo json_encode(['status' => 'error', 'message' => 'El barrio "' . $nombre . '" ya existe']);
            exit;
        }
        
        $stmt = $conexion->prepare("INSERT INTO barrio (nombre) VALUES (?)");
        $stmt->bind_param("s", $nombre);
        
        if ($stmt->execute()) {
            $id_barrio = $stmt->insert_id;
            echo json_encode([
                'status' => 'success', 
                'message' => 'Barrio creado correctamente',
                'id' => $id_barrio,
                'nombre' => $nombre
            ]);
        } else {
            echo json_encode([
                'status' => 'error', 
                'message' => 'Error al crear barrio: ' . $conexion->error
            ]);
        }
        
        $stmt->close();
        exit;
    }
    
// =============================================
// REGISTRAR CLIENTE - CON VERIFICACIÓN DE CLIENTE ELIMINADO
// =============================================
if ($accion === 'registrar') {

    // Obtener datos del formulario
    $nombre = trim($_POST['nombre'] ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $dni = trim($_POST['dni'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $observacion = trim($_POST['observacion'] ?? '');
    $id_barrio = intval($_POST['id_barrio'] ?? 0);
    
    // FORZAR: Si el select envió el nombre en lugar del ID, buscar el ID
    if ($id_barrio == 0 && !empty($_POST['id_barrio']) && !is_numeric($_POST['id_barrio'])) {
        $nombre_barrio = trim($_POST['id_barrio']);
        $buscar = $conexion->query("SELECT id_barrio FROM barrio WHERE nombre = '$nombre_barrio'");
        if ($buscar && $buscar->num_rows > 0) {
            $id_barrio = $buscar->fetch_assoc()['id_barrio'];
        }
    }
    
    $id_tipo = intval($_POST['id_tipo'] ?? 0);
    $no_local = isset($_POST['no_local']) ? 1 : 0;
    $estado_pago = 'pendiente';
    $dias_mora = 0;
    $estado = 'Activo';
    $observacion_pago = '';
    $fecha_ultimo_pago = null;
    $foto_dni = '';
    
    // SUBIR FOTO DE DNI
    if (isset($_FILES['foto_dni']) && $_FILES['foto_dni']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = __DIR__ . '/../uploads/dni/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $ext = strtolower(pathinfo($_FILES['foto_dni']['name'], PATHINFO_EXTENSION));
        $foto_dni = 'dni_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
        $ruta_completa = $upload_dir . $foto_dni;
        if (move_uploaded_file($_FILES['foto_dni']['tmp_name'], $ruta_completa)) {
            $no_local = 1;
        } else {
            $foto_dni = '';
        }
    }
    
    // VALIDACIONES
    $errores = [];
    if (empty($nombre)) $errores[] = 'El nombre es obligatorio';
    if (empty($apellido)) $errores[] = 'El apellido es obligatorio';
    if (empty($dni)) $errores[] = 'El DNI es obligatorio';
    if ($id_barrio <= 0) $errores[] = 'Debe seleccionar un barrio';
    if ($id_tipo <= 0) $errores[] = 'Debe seleccionar un tipo de servicio';
    
    if (!empty($dni) && !preg_match('/^[0-9]{7,8}$/', $dni)) {
        $errores[] = 'El DNI debe tener entre 7 y 8 dígitos numéricos';
    }
    
    if (!empty($errores)) {
        echo json_encode(['status' => 'error', 'message' => implode(' | ', $errores)]);
        exit;
    }
    
    // =============================================
    // ✅ VERIFICAR SI EL CLIENTE YA EXISTE (INCLUYENDO ELIMINADOS)
    // =============================================
    $sql_check = "SELECT id, nombre, apellido, codigo_cliente, eliminado, fecha_eliminacion, 
                         motivo_eliminacion, id_tipo, fecha_ultimo_pago
                  FROM cliente 
                  WHERE dni = ?";
    $stmt_check = mysqli_prepare($conexion, $sql_check);
    mysqli_stmt_bind_param($stmt_check, "s", $dni);
    mysqli_stmt_execute($stmt_check);
    $result_check = mysqli_stmt_get_result($stmt_check);
    $cliente_existente = mysqli_fetch_assoc($result_check);
    mysqli_stmt_close($stmt_check);
    
    // =============================================
    // ✅ SI EL CLIENTE YA EXISTE Y ESTÁ ELIMINADO
    // =============================================
    if ($cliente_existente && $cliente_existente['eliminado'] == 1) {
        $id_cliente_eliminado = $cliente_existente['id'];
        
        // Obtener deuda del cliente eliminado
        $sql_deuda = "SELECT 
                         ts.precio_base,
                         c.fecha_ultimo_pago,
                         DATEDIFF(CURDATE(), c.fecha_ultimo_pago) AS dias_desde_ultimo_pago,
                         FLOOR(DATEDIFF(CURDATE(), c.fecha_ultimo_pago) / 30) AS meses_deuda
                      FROM cliente c
                      LEFT JOIN tipo_servicio ts ON c.id_tipo = ts.id_tipo
                      WHERE c.id = ?";
        $stmt_deuda = mysqli_prepare($conexion, $sql_deuda);
        mysqli_stmt_bind_param($stmt_deuda, "i", $id_cliente_eliminado);
        mysqli_stmt_execute($stmt_deuda);
        $result_deuda = mysqli_stmt_get_result($stmt_deuda);
        $datos_deuda = mysqli_fetch_assoc($result_deuda);
        mysqli_stmt_close($stmt_deuda);
        
        $precio_base = $datos_deuda['precio_base'] ?? 0;
        $meses_deuda = $datos_deuda['meses_deuda'] ?? 0;
        $deuda_total = $precio_base * $meses_deuda;
        
        // ✅ SI TIENE DEUDA, NO PERMITIR REGISTRO HASTA PAGAR
        if ($deuda_total > 0) {
            // Obtener detalle de meses adeudados
            $deudas_detalle = [];
            if (!empty($datos_deuda['fecha_ultimo_pago'])) {
                $fecha_ultimo = new DateTime($datos_deuda['fecha_ultimo_pago']);
                for ($i = 0; $i < $meses_deuda; $i++) {
                    $fecha_mes = clone $fecha_ultimo;
                    $fecha_mes->modify("+".($i+1)." months");
                    $deudas_detalle[] = [
                        'mes' => $fecha_mes->format('n'),
                        'anio' => $fecha_mes->format('Y'),
                        'nombre_mes' => ucfirst($fecha_mes->format('F')),
                        'monto' => $precio_base
                    ];
                }
            }
            
            echo json_encode([
                'status' => 'cliente_eliminado_con_deuda',
                'message' => 'Este cliente fue eliminado anteriormente y tiene deuda pendiente. Debe pagar para reactivarlo.',
                'data' => [
                    'id_cliente' => $id_cliente_eliminado,
                    'nombre' => $cliente_existente['nombre'],
                    'apellido' => $cliente_existente['apellido'],
                    'codigo_cliente' => $cliente_existente['codigo_cliente'],
                    'fecha_eliminacion' => $cliente_existente['fecha_eliminacion'],
                    'motivo_eliminacion' => $cliente_existente['motivo_eliminacion'],
                    'precio_base' => $precio_base,
                    'meses_deuda' => $meses_deuda,
                    'deuda_total' => $deuda_total,
                    'deudas_detalle' => $deudas_detalle
                ]
            ]);
            exit;
        }
        
        // ✅ SI NO TIENE DEUDA, REACTIVAR EL CLIENTE
        if ($deuda_total == 0) {
            // Reactivar cliente eliminado
            $sql_reactivar = "UPDATE cliente SET 
                                eliminado = 0,
                                fecha_eliminacion = NULL,
                                motivo_eliminacion = NULL,
                                `estado` = 'Activo',
                                estado_pago = 'pendiente',
                                dias_mora = 0,
                                nombre = ?,
                                apellido = ?,
                                email = ?,
                                telefono = ?,
                                id_barrio = ?,
                                id_tipo = ?,
                                no_local = ?,
                                observacion = ?,
                                foto_dni = ?
                              WHERE id = ?";
            
            $stmt_reactivar = mysqli_prepare($conexion, $sql_reactivar);
            mysqli_stmt_bind_param($stmt_reactivar, "ssssiiissi", 
                $nombre,
                $apellido,
                $email,
                $telefono,
                $id_barrio,
                $id_tipo,
                $no_local,
                $observacion,
                $foto_dni,
                $id_cliente_eliminado
            );
            
            if (mysqli_stmt_execute($stmt_reactivar)) {
                $log->registrarAccion(
                    $_SESSION['id_usuario'],
                    $_SESSION['usuario'] ?? 'Admin',
                    'Reactivar Cliente Eliminado',
                    "Se reactivó al cliente: $nombre $apellido (Código: {$cliente_existente['codigo_cliente']})",
                    "Cliente estaba eliminado, se reactivó sin deuda",
                    'success'
                );
                
                echo json_encode([
                    'status' => 'success',
                    'message' => '✅ Cliente reactivado correctamente. Código: ' . $cliente_existente['codigo_cliente']
                ]);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Error al reactivar cliente: ' . mysqli_error($conexion)]);
            }
            
            mysqli_stmt_close($stmt_reactivar);
            exit;
        }
    }
    
    // =============================================
    // ✅ SI EL CLIENTE YA EXISTE Y ESTÁ ACTIVO (NO ELIMINADO)
    // =============================================
    if ($cliente_existente && $cliente_existente['eliminado'] == 0) {
        echo json_encode(['status' => 'error', 'message' => 'El DNI ya está registrado en un cliente activo']);
        exit;
    }
    
    // =============================================
    // ✅ SI EL CLIENTE NO EXISTE, CREARLO NORMALMENTE
    // =============================================
    // Validar campos únicos (solo para clientes activos)
    $errores_unicos = validarCamposUnicos($conexion, $dni, $telefono, $email, 0);
    $errores = array_merge($errores, $errores_unicos);
    
    if (!empty($errores)) {
        echo json_encode(['status' => 'error', 'message' => implode(' | ', $errores)]);
        exit;
    }
    
    $codigo = generarCodigoCliente($nombre, $apellido, $conexion);
    
    $sql = "INSERT INTO cliente (codigo_cliente, nombre, apellido, dni, email, telefono, `estado`, estado_pago, observacion_pago, observacion, id_barrio, fecha_ultimo_pago, foto_dni, no_local, id_tipo, dias_mora) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = mysqli_prepare($conexion, $sql);
    $fecha_ultimo_pago_null = null;
    
    mysqli_stmt_bind_param($stmt, "ssssssssssissiii", 
        $codigo,
        $nombre,
        $apellido,
        $dni,
        $email,
        $telefono,
        $estado,
        $estado_pago,
        $observacion_pago,
        $observacion,
        $id_barrio,
        $fecha_ultimo_pago_null,
        $foto_dni,
        $no_local,
        $id_tipo,
        $dias_mora
    );
    
    if (mysqli_stmt_execute($stmt)) {
        $id_cliente = mysqli_insert_id($conexion);
        
        $log->registrarAccion(
            $_SESSION['id_usuario'],
            $_SESSION['usuario'] ?? 'Admin',
            'Crear Cliente',
            "Se creó el cliente: $nombre $apellido (Código: $codigo)",
            '',
            'success'
        );
        
        // CREAR SERVICIO AUTOMÁTICAMENTE
        if ($id_tipo > 0) {
            $sql_tipo = "SELECT nombre, precio_base, dia_corte FROM tipo_servicio WHERE id_tipo = ?";
            $stmt_tipo = mysqli_prepare($conexion, $sql_tipo);
            mysqli_stmt_bind_param($stmt_tipo, "i", $id_tipo);
            mysqli_stmt_execute($stmt_tipo);
            $tipo = mysqli_stmt_get_result($stmt_tipo)->fetch_assoc();
            
            if ($tipo) {
                $sql_servicio = "INSERT INTO servicio (nombre, precio, dia_corte, estado_pago, id_cliente) 
                                 VALUES (?, ?, ?, 'pendiente', ?)";
                $stmt_servicio = mysqli_prepare($conexion, $sql_servicio);
                mysqli_stmt_bind_param($stmt_servicio, "sdii", $tipo['nombre'], $tipo['precio_base'], $tipo['dia_corte'], $id_cliente);
                mysqli_stmt_execute($stmt_servicio);
                $id_servicio = mysqli_insert_id($conexion);
                
                $sql_update = "UPDATE cliente SET id_servicio = ? WHERE id = ?";
                $stmt_update = mysqli_prepare($conexion, $sql_update);
                mysqli_stmt_bind_param($stmt_update, "ii", $id_servicio, $id_cliente);
                mysqli_stmt_execute($stmt_update);
            }
        }
        
        echo json_encode(['status' => 'success', 'message' => "✅ Cliente registrado. Código: $codigo"]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error SQL: ' . mysqli_error($conexion)]);
    }
    
    mysqli_stmt_close($stmt);
    exit;
}

    // =============================================
    // EDITAR CLIENTE
    // =============================================
    if ($accion === 'editar') {
        // ✅ ADMIN Y ADMIN RED PUEDEN EDITAR
        if ($id_rol != 1 && $id_rol != 4) {
            echo json_encode(['status' => 'error', 'message' => 'No tienes permiso para editar clientes']);
            exit;
        }
        
        $id = intval($_POST['id'] ?? 0);
        $nombre = trim($_POST['nombre'] ?? '');
        $apellido = trim($_POST['apellido'] ?? '');
        $dni = trim($_POST['dni'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $telefono = trim($_POST['telefono'] ?? '');
        $id_barrio = intval($_POST['id_barrio'] ?? 0);
        $id_tipo = intval($_POST['id_tipo'] ?? 0);
        $no_local = isset($_POST['no_local']) ? 1 : 0;
          $observacion = trim($_POST['observacion'] ?? '');
        $foto_dni = $_POST['foto_dni_actual'] ?? '';
        $estado = $_POST['estado'] ?? 'Activo';
        $observacion_pago = $_POST['observacion_pago'] ?? '';
        
        if ($foto_dni === '0' || $foto_dni === 0) {
            $foto_dni = '';
        }
        
        $errores = [];
        
        if ($id <= 0) $errores[] = 'ID de cliente inválido';
        if (empty($nombre)) $errores[] = 'El nombre es obligatorio';
        if (empty($apellido)) $errores[] = 'El apellido es obligatorio';
        if (empty($dni)) $errores[] = 'El DNI es obligatorio';
        if ($id_barrio <= 0) $errores[] = 'Debe seleccionar un barrio';
        if ($id_tipo <= 0) $errores[] = 'Debe seleccionar un tipo de servicio';
        
        if (!empty($dni) && !preg_match('/^[0-9]{7,8}$/', $dni)) {
            $errores[] = 'El DNI debe tener entre 7 y 8 dígitos numéricos';
        }
        if (!empty($telefono) && !preg_match('/^[0-9]{7,15}$/', $telefono)) {
            $errores[] = 'El teléfono debe contener solo números (7 a 15 dígitos)';
        }
        if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errores[] = 'El email no tiene un formato válido';
        }
        
        $errores_unicos = validarCamposUnicos($conexion, $dni, $telefono, $email, $id);
        $errores = array_merge($errores, $errores_unicos);
        
        if (!empty($errores)) {
            echo json_encode(['status' => 'error', 'message' => implode(' | ', $errores)]);
            exit;
        }
        
        if (isset($_FILES['foto_dni']) && $_FILES['foto_dni']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = __DIR__ . '/../uploads/dni/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $ext = pathinfo($_FILES['foto_dni']['name'], PATHINFO_EXTENSION);
            $foto_dni = 'dni_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
            move_uploaded_file($_FILES['foto_dni']['tmp_name'], $upload_dir . $foto_dni);
        }
        
        // ✅ CORREGIDO: UPDATE con la cantidad exacta de variables y tipos
        $sql = "UPDATE cliente SET 
                    nombre = ?,
                    apellido = ?,
                    dni = ?,
                    email = ?,
                    telefono = ?,
                    id_barrio = ?,
                    id_tipo = ?,
                    foto_dni = ?,
                    no_local = ?,
                    `estado` = ?,
                    observacion_pago = ?,
                    observacion = ?
                WHERE id = ?";
        
        $stmt = mysqli_prepare($conexion, $sql);
        
        // Tipos corregidos: 5s, 2i, 1s, 1i, 3s, 1i -> "sssssiisisssi" (13 parámetros en total)
mysqli_stmt_bind_param($stmt, "sssssiisisssi", 
    $nombre,           // s (1)
    $apellido,         // s (2)
    $dni,              // s (3)
    $email,            // s (4)
    $telefono,         // s (5)
    $id_barrio,        // i (6)
    $id_tipo,          // i (7)
    $foto_dni,         // s (8)
    $no_local,         // i (9)
    $estado,           // s (10)
    $observacion_pago, // s (11)
    $observacion,      // s (12)
    $id                // i (13)
);
        
        if (mysqli_stmt_execute($stmt)) {
            $log->registrarAccion(
                $_SESSION['id_usuario'],
                $_SESSION['usuario'] ?? 'Admin',
                'Editar Cliente',
                "Se editó el cliente: $nombre $apellido",
                '',
                'info'
            );

            echo json_encode(['status' => 'success', 'message' => '✅ Cliente actualizado correctamente']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Error al actualizar: ' . mysqli_error($conexion)]);
        }
        
        mysqli_stmt_close($stmt);
        exit;
    }
    
// =============================================
// ELIMINAR CLIENTE (VALIDANDO QUE NO TENGA DEUDAS)
// =============================================
if ($accion === 'eliminar') {
    // ✅ ADMIN Y ADMIN RED PUEDEN ELIMINAR
    if ($id_rol != 1 &&$id_rol != 4) {
        echo json_encode(['status' => 'error', 'message' => 'No tienes permiso para eliminar clientes']);
        exit;
    }
    
    $id = intval($_POST['id'] ?? 0);
    $motivo = trim($_POST['motivo_eliminacion'] ?? 'Eliminado por administrador');
    
    if ($id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID inválido']);
        exit;
    }
    
    // OBTENER DATOS DEL CLIENTE Y SU PRECIO BASE
    $sql_cliente = "SELECT c.nombre, c.apellido, c.codigo_cliente, c.estado, c.fecha_ultimo_pago, ts.precio_base 
                    FROM cliente c 
                    LEFT JOIN tipo_servicio ts ON c.id_tipo = ts.id_tipo 
                    WHERE c.id = ? AND c.eliminado = 0";
    $stmt_cliente = mysqli_prepare($conexion,$sql_cliente);
    mysqli_stmt_bind_param($stmt_cliente, "i", $id);
    mysqli_stmt_execute($stmt_cliente);
    $result_cliente = mysqli_stmt_get_result($stmt_cliente);
    $cliente_data = mysqli_fetch_assoc($result_cliente);
    mysqli_stmt_close($stmt_cliente);
    
    if (!$cliente_data) {
        echo json_encode(['status' => 'error', 'message' => 'Cliente no encontrado']);
        exit;
    }
    
    // ✅ CALCULAR SI TIENE DEUDAS PENDIENTES
    $precio_base = floatval($cliente_data['precio_base'] ?? 0);$meses_deuda = 0;
    
    if (!empty($cliente_data['fecha_ultimo_pago']) && $precio_base > 0) {$fecha_ultimo = new DateTime($cliente_data['fecha_ultimo_pago']);$fecha_hoy = new DateTime();
        
        if ($fecha_ultimo <$fecha_hoy) {
            $diff =$fecha_ultimo->diff($fecha_hoy);$meses_deuda = ($diff->y * 12) +$diff->m;
        }
    }
    
    $deuda_total = $precio_base * $meses_deuda;
    
    // ❌ BLOQUEAR SI TIENE DEUDAS PENDIENTES
    if ($deuda_total > 0) {
        echo json_encode([
            'status' => 'error', 
            'message' => '❌ No se puede eliminar al cliente porque tiene deudas pendientes. Debe registrar el pago de los meses adeudados primero.'
        ]);
        exit;
    }
    
    $nombre_cliente = $cliente_data['nombre'] . ' ' .$cliente_data['apellido'];
    $codigo_cliente =$cliente_data['codigo_cliente'];
    
    // ✅ SOFT DELETE - Marcar como eliminado (Solo si no debe nada)
    $fecha_eliminacion = date('Y-m-d H:i:s');$sql = "UPDATE cliente SET 
                eliminado = 1,
                fecha_eliminacion = ?,
                motivo_eliminacion = ?,
                `estado` = 'Inactivo',
                estado_pago = 'suspendido'
            WHERE id = ?";
    
    $stmt = mysqli_prepare($conexion,$sql);
    mysqli_stmt_bind_param($stmt, "ssi", $fecha_eliminacion, $motivo,$id);
    
    if (mysqli_stmt_execute($stmt)) {$log->registrarAccion(
            $_SESSION['id_usuario'],$_SESSION['usuario'] ?? 'Admin',
            'Eliminar Cliente',
            "Se eliminó el cliente: $nombre_cliente (Código: $codigo_cliente)",
            "Motivo: $motivo",
            'warning'
        );
        
        echo json_encode([
            'status' => 'success', 
            'message' => '✅ Cliente eliminado correctamente',
            'id_cliente' => $id
        ]);
    } else {
        echo json_encode([
            'status' => 'error', 
            'message' => 'Error al eliminar: ' . mysqli_error($conexion)
        ]);
    }
    
    mysqli_stmt_close($stmt);
    exit;
}
    
    // =============================================
// REGISTRAR PAGO - CON MÚLTIPLES MESES (HASTA 12)
// =============================================
if ($accion === 'registrar_pago') {
    header('Content-Type: application/json');
    try {
        $id_cliente = intval($_POST['id_cliente'] ?? 0);
        $fecha_pago = !empty($_POST['fecha_pago']) ? $_POST['fecha_pago'] . ' ' . date('H:i:s') : date('Y-m-d H:i:s');
        $metodo_pago = $_POST['metodo_pago'] ?? 'efectivo';
        $observaciones = trim($_POST['observaciones'] ?? '');
        $cantidad_meses = intval($_POST['cantidad_meses'] ?? 1);
        
        // Limitar a 12 meses máximo
        if ($cantidad_meses > 12) $cantidad_meses = 12;
        if ($cantidad_meses < 1) $cantidad_meses = 1;

        if ($id_cliente <= 0) throw new Exception('ID de cliente inválido.');

        // OBTENER DATOS DEL CLIENTE
        $sql = "SELECT c.nombre, c.apellido, c.id_tipo, c.id_servicio, c.fecha_ultimo_pago, ts.dia_corte 
                FROM cliente c
                LEFT JOIN tipo_servicio ts ON c.id_tipo = ts.id_tipo
                WHERE c.id = ?";
        $stmt = mysqli_prepare($conexion, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id_cliente);
        mysqli_stmt_execute($stmt);
        $cliente = mysqli_stmt_get_result($stmt)->fetch_assoc();
        mysqli_stmt_close($stmt);

        if (!$cliente) throw new Exception('Cliente no encontrado.');

        // OBTENER PRECIO BASE
        $sql = "SELECT precio_base FROM tipo_servicio WHERE id_tipo = ?";
        $stmt = mysqli_prepare($conexion, $sql);
        mysqli_stmt_bind_param($stmt, "i", $cliente['id_tipo']);
        mysqli_stmt_execute($stmt);
        $tipo = mysqli_stmt_get_result($stmt)->fetch_assoc();
        $monto = $tipo['precio_base'] ?? 0;
        mysqli_stmt_close($stmt);

        if ($monto <= 0) throw new Exception('El cliente no tiene un precio base configurado.');

// =============================================
// DETERMINAR EL PRIMER PERÍODO QUE DEBE PAGAR
// =============================================

$dia_corte = intval($cliente['dia_corte'] ?? 15);

$fecha_hoy = date('Y-m-d');

// Si ya tiene meses pagados por adelantado,
// continuar desde la fecha que tiene cubierta.
if (!empty($cliente['fecha_ultimo_pago']) &&
    strtotime($cliente['fecha_ultimo_pago']) > strtotime($fecha_hoy)) {

    $fecha_primer_pago = $cliente['fecha_ultimo_pago'];

} else {

    // Cliente sin pagos adelantados:
    // determinar el período correspondiente según el día de facturación.
    $anio_actual = (int)date('Y');
    $mes_actual = (int)date('m');
    $dia_actual = (int)date('d');

    if ($dia_actual >= $dia_corte) {

        $mes_actual++;

        if ($mes_actual > 12) {
            $mes_actual = 1;
            $anio_actual++;
        }
    }

    $fecha_primer_pago = sprintf(
        '%04d-%02d-%02d',
        $anio_actual,
        $mes_actual,
        $dia_corte
    );
}
        // =============================================
        // CONTAR PAGOS PREVIOS
        // =============================================
        $sql_count_pagos = "SELECT COUNT(*) as total FROM pago WHERE id_cliente = ?";
        $stmt_cp = mysqli_prepare($conexion, $sql_count_pagos);
        mysqli_stmt_bind_param($stmt_cp, "i", $id_cliente);
        mysqli_stmt_execute($stmt_cp);
        $total_pagos_previos = mysqli_stmt_get_result($stmt_cp)->fetch_assoc()['total'] ?? 0;
        mysqli_stmt_close($stmt_cp);

        $es_primer_pago = ($total_pagos_previos == 0);

        // =============================================
        // REGISTRAR PAGOS POR CADA MES
        // =============================================
        $pagos_registrados = 0;
        $fecha_ultimo_pago_registrado = $fecha_primer_pago;

        for ($i = 0; $i < $cantidad_meses; $i++) {
            $fecha_mes = date('Y-m-d', strtotime($fecha_primer_pago . " +$i months"));
            $mes = (int)date('n', strtotime($fecha_mes));
            $anio = (int)date('Y', strtotime($fecha_mes));

            $sql_check = "SELECT id_pago FROM pago WHERE id_cliente = ? AND mes = ? AND anio = ?";
            $stmt_check = mysqli_prepare($conexion, $sql_check);
            mysqli_stmt_bind_param($stmt_check, "iii", $id_cliente, $mes, $anio);
            mysqli_stmt_execute($stmt_check);
            $pago_existente = mysqli_stmt_get_result($stmt_check)->fetch_assoc();
            mysqli_stmt_close($stmt_check);

            if ($pago_existente) {
                $sql_pago = "UPDATE pago SET monto = ?, estado = 'Pagado', metodo_pago = ?, observaciones = ? WHERE id_pago = ?";
                $stmt_pago = mysqli_prepare($conexion, $sql_pago);
                mysqli_stmt_bind_param($stmt_pago, "dssi", $monto, $metodo_pago, $observaciones, $pago_existente['id_pago']);
            } else {
                $sql_pago = "INSERT INTO pago (id_cliente, monto, mes, anio, estado, metodo_pago, observaciones) 
                             VALUES (?, ?, ?, ?, 'Pagado', ?, ?)";
                $stmt_pago = mysqli_prepare($conexion, $sql_pago);
                mysqli_stmt_bind_param($stmt_pago, "idiiss", $id_cliente, $monto, $mes, $anio, $metodo_pago, $observaciones);
            }

            if (!mysqli_stmt_execute($stmt_pago)) {
                throw new Exception('Error al procesar el pago del mes ' . ($i + 1));
            }
            mysqli_stmt_close($stmt_pago);
            $pagos_registrados++;
            $fecha_ultimo_pago_registrado = $fecha_mes;
        }

        // =============================================
        // ACTUALIZAR CLIENTE
        // =============================================
        $fecha_nueva_ultimo_pago = date('Y-m-d', strtotime($fecha_ultimo_pago_registrado . " +1 month"));

        $sql_update = "UPDATE cliente SET 
                `estado` = 'Activo',
                estado_pago = 'pagado', 
                dias_mora = 0, 
                fecha_ultimo_pago = ? 
                WHERE id = ?";
        $stmt_update = mysqli_prepare($conexion, $sql_update);
        mysqli_stmt_bind_param($stmt_update, "si", $fecha_nueva_ultimo_pago, $id_cliente);
        mysqli_stmt_execute($stmt_update);
        mysqli_stmt_close($stmt_update);

        // =============================================
// SI ES PRIMER PAGO → CREAR TAREA EN SOPORTE
// =============================================
if ($es_primer_pago) {
    $sql_tecnicos = "SELECT id_usuario FROM usuario WHERE id_rol = 3 ORDER BY id_usuario ASC LIMIT 1";
    $result_tecnicos = mysqli_query($conexion, $sql_tecnicos);
    $tecnico = mysqli_fetch_assoc($result_tecnicos);
    $tecnico_id = $tecnico['id_usuario'] ?? null;

    $titulo = "Nueva conexión - " . $cliente['nombre'] . " " . $cliente['apellido'];
    $descripcion = "Realizar la conexión del servicio para el cliente: " . $cliente['nombre'] . " " . $cliente['apellido'] . ".";
    $prioridad = "alta";
    $estado_soporte = "pendiente";

    $sql_soporte = "INSERT INTO soporte (cliente_id, tecnico_id, titulo, descripcion, prioridad, estado) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt_soporte = mysqli_prepare($conexion, $sql_soporte);
    mysqli_stmt_bind_param($stmt_soporte, "iissss", $id_cliente, $tecnico_id, $titulo, $descripcion, $prioridad, $estado_soporte);
    mysqli_stmt_execute($stmt_soporte);
    mysqli_stmt_close($stmt_soporte);
}

        // =============================================
        // LOG DE LA ACCIÓN
        // =============================================
        $monto_total = $monto * $cantidad_meses;
        $log->registrarAccion(
            $_SESSION['id_usuario'] ?? 0,
            $_SESSION['usuario'] ?? 'Sistema',
            'Registrar Pago',
            "Pago de $" . number_format($monto_total, 0, ',', '.') . " para: {$cliente['nombre']} {$cliente['apellido']} ({$cantidad_meses} meses)",
            "Método: $metodo_pago - " . ($es_primer_pago ? 'PRIMER PAGO - Tarea de conexión creada' : 'Pago mensual'),
            'success'
        );

        $mensaje = "✅ Pago procesado correctamente. ";
        $mensaje .= "Monto total: $" . number_format($monto_total, 0, ',', '.');
        $mensaje .= " (" . $cantidad_meses . " mes(es) x $" . number_format($monto, 0, ',', '.') . ")";

        if ($es_primer_pago) {
            $mensaje .= " 🛠️ Tarea de conexión creada en Soporte Técnico.";
        }

        echo json_encode([
    'status' => 'success',
    'message' => $mensaje,
    'primer_pago' => $es_primer_pago,
    'meses_pagados' => $pagos_registrados,
    'monto_total' => $monto_total,
    'id_cliente' => $id_cliente, // ✅ AGREGAR ESTO
        'fecha_proximo_pago' => $fecha_nueva_ultimo_pago
]);


    } catch (Exception $e) {
        $log->registrarAccion(
            $_SESSION['id_usuario'] ?? 0,
            $_SESSION['usuario'] ?? 'Sistema',
            'Error al Registrar Pago',
            "Error al registrar pago para cliente ID: $id_cliente",
            "Error: " . $e->getMessage(),
            'error'
        );

        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
    exit;
}

// =============================================
// REACTIVAR SERVICIO (BUSCANDO DEUDA REAL EN TABLA PAGO)
// =============================================
if ($accion === 'reactivar_servicio') {
    if ($id_rol != 1 &&$id_rol != 4) {
        echo json_encode(['status' => 'error', 'message' => 'No tienes permiso para reactivar servicios']);
        exit;
    }
    
    $id = intval($_POST['id'] ?? 0);
    
    if ($id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID inválido']);
        exit;
    }
    
    // 1. OBTENER LA FECHA DE DEUDA MÁS ANTIGUA REGISTRADA EN LA TABLA PAGO
    $sql_deuda_antigua = "SELECT MIN(STR_TO_DATE(CONCAT(anio, '-', LPAD(mes, 2, '0'), '-15'), '%Y-%m-%d')) AS fecha_deuda 
                          FROM pago 
                          WHERE id_cliente = ? AND estado = 'Pendiente'";
    $stmt_deuda = mysqli_prepare($conexion,$sql_deuda_antigua);
    mysqli_stmt_bind_param($stmt_deuda, "i", $id);
    mysqli_stmt_execute($stmt_deuda);
    $res_deuda = mysqli_stmt_get_result($stmt_deuda)->fetch_assoc();
    mysqli_stmt_close($stmt_deuda);$dias_mora_reales = 0;
    
    if (!empty($res_deuda['fecha_deuda'])) {
        // Si existen deudas pendientes en la tabla `pago`, calcula la mora desde la más antigua
        $fecha_antigua = new DateTime($res_deuda['fecha_deuda']);$hoy = new DateTime();
        if ($fecha_antigua < $hoy) {$dias_mora_reales = $hoy->diff($fecha_antigua)->days;
        }
    } else {
        // Si no hay registros pendientes, calcula desde fecha_ultimo_pago
        $sql_cli = "SELECT fecha_ultimo_pago FROM cliente WHERE id = ?";
        $stmt_cli = mysqli_prepare($conexion,$sql_cli);
        mysqli_stmt_bind_param($stmt_cli, "i", $id);
        mysqli_stmt_execute($stmt_cli);
        $cli_data = mysqli_stmt_get_result($stmt_cli)->fetch_assoc();
        mysqli_stmt_close($stmt_cli);
        
        if (!empty($cli_data['fecha_ultimo_pago'])) {$fecha_ultimo = new DateTime($cli_data['fecha_ultimo_pago']);$hoy = new DateTime();
            if ($fecha_ultimo < $hoy) {$dias_mora_reales = $hoy->diff($fecha_ultimo)->days;
            }
        }
    }


    // =============================================
// EN admin_cliente.php -> DENTRO DE reactivar_servicio
// =============================================
if (mysqli_stmt_execute($stmt)) {
    // 🛠️ Crear tarea automática de reconexión
    $sql_tecnicos = "SELECT id_usuario FROM usuario WHERE id_rol = 3 ORDER BY id_usuario ASC LIMIT 1";
    $result_tecnicos = mysqli_query($conexion, $sql_tecnicos);
    $tecnico = mysqli_fetch_assoc($result_tecnicos);
    $tecnico_id = $tecnico['id_usuario'] ?? null;

    $titulo_rec = "Reconexión de servicio - " . $cli_data['nombre'] . " " . $cli_data['apellido'];
    $desc_rec = "Realizar la reconexión del servicio tras reactivar al cliente.";

    $sql_soporte_rec = "INSERT INTO soporte (cliente_id, tecnico_id, titulo, descripcion, prioridad, estado) 
                        VALUES (?, ?, ?, ?, 'alta', 'pendiente')";
    $stmt_rec = mysqli_prepare($conexion, $sql_soporte_rec);
    mysqli_stmt_bind_param($stmt_rec, "iiss", $id, $tecnico_id, $titulo_rec, $desc_rec);
    mysqli_stmt_execute($stmt_rec);
    mysqli_stmt_close($stmt_rec);

    echo json_encode([
        'status' => 'success', 
        'message' => '✅ Servicio reactivado. Tarea de reconexión creada en Soporte Técnico.',
        'id_cliente' => $id
    ]);
}
    
    // 2. ACTUALIZAR ESTADO Y DÍAS DE MORA REALES
    $sql = "UPDATE cliente SET 
                `estado` = 'Activo', 
                estado_pago = 'pendiente', 
                dias_mora = ?
            WHERE id = ?";
    
    $stmt = mysqli_prepare($conexion,$sql);
    mysqli_stmt_bind_param($stmt, "ii", $dias_mora_reales,$id);
    
    if (mysqli_stmt_execute($stmt)) {
        echo json_encode([
            'status' => 'success', 
            'message' => '✅ Servicio reactivado. Días de mora recalculados correctamente.',
            'id_cliente' => $id
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error al reactivar']);
    }
    
    mysqli_stmt_close($stmt);
    exit;


}

// =============================================
// REACTIVAR CLIENTE ELIMINADO PARA PODER PAGAR
// =============================================
if ($accion === 'reactivar_para_pago') {
    $id = intval($_POST['id'] ?? 0);
    
    if ($id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID inválido']);
        exit;
    }
    
    // Verificar que el cliente existe y está eliminado
    $sql_verificar = "SELECT id, nombre, apellido, codigo_cliente, eliminado 
                      FROM cliente 
                      WHERE id = ? AND eliminado = 1";
    $stmt_verificar = mysqli_prepare($conexion, $sql_verificar);
    mysqli_stmt_bind_param($stmt_verificar, "i", $id);
    mysqli_stmt_execute($stmt_verificar);
    $cliente_data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_verificar));
    mysqli_stmt_close($stmt_verificar);
    
    if (!$cliente_data) {
        echo json_encode(['status' => 'error', 'message' => 'Cliente no encontrado o no está eliminado']);
        exit;
    }
    
    // Reactivar temporalmente para poder registrar el pago
    $sql = "UPDATE cliente SET 
                eliminado = 0,
                fecha_eliminacion = NULL,
                motivo_eliminacion = NULL,
                `estado` = 'Activo'
            WHERE id = ?";
    
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    
    if (mysqli_stmt_execute($stmt)) {
        $log->registrarAccion(
            $_SESSION['id_usuario'],
            $_SESSION['usuario'] ?? 'Admin',
            'Reactivar para Pago',
            "Se reactivó temporalmente al cliente: {$cliente_data['nombre']} {$cliente_data['apellido']} para registrar pago",
            "Cliente eliminado, se reactiva para pago de deuda",
            'info'
        );
        
        echo json_encode([
            'status' => 'success', 
            'message' => 'Cliente reactivado temporalmente para pago',
            'id_cliente' => $id
        ]);
    } else {
        echo json_encode([
            'status' => 'error', 
            'message' => 'Error al reactivar: ' . mysqli_error($conexion)
        ]);
    }
    
    mysqli_stmt_close($stmt);
    exit;
}

   // =============================================
// CORTAR SERVICIO
// =============================================
if ($accion === 'cortar_servicio') {
    // ✅ ADMIN Y ADMIN RED PUEDEN CORTAR SERVICIOS
    if ($id_rol != 1 && $id_rol != 4) {
        echo json_encode(['status' => 'error', 'message' => 'No tienes permiso para cortar servicios']);
        exit;
    }
    
    $id = intval($_POST['id'] ?? 0);
    $motivo = trim($_POST['motivo'] ?? 'Falta de pago');
    
    if ($id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID inválido']);
        exit;
    }
    
    // Verificar que el cliente existe y NO está eliminado
    $sql_verificar = "SELECT id, nombre, apellido, estado, eliminado FROM cliente WHERE id = ? AND eliminado = 0";
    $stmt_verificar = mysqli_prepare($conexion, $sql_verificar);
    mysqli_stmt_bind_param($stmt_verificar, "i", $id);
    mysqli_stmt_execute($stmt_verificar);
    $cliente_data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_verificar));
    mysqli_stmt_close($stmt_verificar);
    
    if (!$cliente_data) {
        echo json_encode(['status' => 'error', 'message' => 'Cliente no encontrado o eliminado']);
        exit;
    }
    
    // ✅ CORTAR SERVICIO (solo cambia estado, NO eliminado)
    $sql = "UPDATE cliente SET `estado` = 'Inactivo', estado_pago = 'suspendido', dias_mora = 0 WHERE id = ?";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    
    if (mysqli_stmt_execute($stmt)) {
        // Crear tarea en soporte
        $sql_tecnicos = "SELECT id_usuario FROM usuario WHERE id_rol = 3 ORDER BY id_usuario ASC LIMIT 1";
        $result_tecnicos = mysqli_query($conexion, $sql_tecnicos);
        $tecnico = mysqli_fetch_assoc($result_tecnicos);
        $tecnico_id = $tecnico['id_usuario'] ?? null;
        
        $titulo = "Corte de servicio - " . $cliente_data['nombre'] . " " . $cliente_data['apellido'];
        $descripcion = "Realizar el corte del servicio por: " . $motivo . ". Cliente: " . $cliente_data['nombre'] . " " . $cliente_data['apellido'] . ".";
        $prioridad = "alta";
        $estado_soporte = "pendiente";
        
        $sql_soporte = "INSERT INTO soporte (cliente_id, tecnico_id, titulo, descripcion, prioridad, estado) 
                        VALUES (?, ?, ?, ?, ?, ?)";
        $stmt_soporte = mysqli_prepare($conexion, $sql_soporte);
        mysqli_stmt_bind_param($stmt_soporte, "iissss", $id, $tecnico_id, $titulo, $descripcion, $prioridad, $estado_soporte);
        mysqli_stmt_execute($stmt_soporte);
        mysqli_stmt_close($stmt_soporte);
        
        $log->registrarAccion(
            $_SESSION['id_usuario'],
            $_SESSION['usuario'] ?? 'Admin',
            'Cortar Servicio',
            "Se cortó el servicio de: {$cliente_data['nombre']} {$cliente_data['apellido']} (Motivo: $motivo)",
            "Tarea de corte creada en Soporte Técnico",
            'warning'
        );
        
        echo json_encode([
            'status' => 'success', 
            'message' => '✅ Servicio cortado correctamente. 🛠️ Tarea de corte creada en Soporte Técnico.',
            'id_cliente' => $id
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error al cortar servicio: ' . mysqli_error($conexion)]);
    }
    
    mysqli_stmt_close($stmt);
    exit;
}
  }

// =============================================
// OBTENER CLIENTES SEGÚN EL ROL
// =============================================

if ($id_rol == 2) {
    // =============================================
    // COBRADOR:
    // Solo mostrar clientes que:
    // 1. Ya hicieron el primer pago
    // 2. Tienen exactamente 1 pago registrado
    // 3. Ya llegó la fecha del segundo pago
    // =============================================

    $sql = "SELECT c.*, 
                   b.nombre as barrio_nombre, 
                   ts.nombre as tipo_servicio_nombre,
                   ts.dia_corte,
                   ts.precio_base,
                   (
                       SELECT COUNT(*) 
                       FROM pago p 
                       WHERE p.id_cliente = c.id
                         AND p.estado = 'Pagado'
                   ) as total_pagos
            FROM cliente c
            LEFT JOIN barrio b ON c.id_barrio = b.id_barrio
            LEFT JOIN tipo_servicio ts ON c.id_tipo = ts.id_tipo
            WHERE c.eliminado = 0
              AND c.estado = 'Activo'
              AND c.estado_pago != 'suspendido'
              AND (
                  SELECT COUNT(*)
                  FROM pago p
                  WHERE p.id_cliente = c.id
                    AND p.estado = 'Pagado'
              ) = 1
              AND c.fecha_ultimo_pago IS NOT NULL
              {$condicion_barrio}
              -- AND DATE(c.fecha_ultimo_pago) <= CURDATE() // <-- COMENTADA
            ORDER BY c.nombre ASC
            LIMIT $offset, $registros_por_pagina";

} else {

    // =============================================
    // ADMINISTRADOR / ADMIN RED:
    // Ven todos los clientes activos
    // =============================================

    $sql = "SELECT c.*, 
                   b.nombre as barrio_nombre, 
                   ts.nombre as tipo_servicio_nombre,
                   ts.dia_corte,
                   ts.precio_base,
                   (
                       SELECT COUNT(*) 
                       FROM pago p 
                       WHERE p.id_cliente = c.id
                   ) as total_pagos
            FROM cliente c
            LEFT JOIN barrio b ON c.id_barrio = b.id_barrio
            LEFT JOIN tipo_servicio ts ON c.id_tipo = ts.id_tipo
            WHERE c.eliminado = 0
{$condicion_barrio}
ORDER BY c.nombre ASC
            LIMIT $offset, $registros_por_pagina";
}

$result = mysqli_query($conexion, $sql);
$clientes = $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];

// OBTENER BARRIOS Y SERVICIOS PARA EL HTML
$result_barrios = mysqli_query($conexion, "SELECT * FROM barrio ORDER BY nombre");
$barrios = $result_barrios ? mysqli_fetch_all($result_barrios, MYSQLI_ASSOC) : [];

$result_servicios = mysqli_query($conexion, "SELECT * FROM tipo_servicio WHERE estado = 'Activo' ORDER BY nombre");
$tipos_servicio = $result_servicios ? mysqli_fetch_all($result_servicios, MYSQLI_ASSOC) : [];

// =============================================
// ESTADÍSTICAS CONSOLIDADAS DE CLIENTES Y PAGOS
// - Se cuenta el total real de clientes (no solo la página actual).
// - Un cliente con al menos un pago Pendiente en `pago` se considera pendiente,
//   aunque `cliente.estado_pago` haya quedado desactualizado.
// - Mora y pendiente se muestran como categorías separadas.
// - Los servicios cortados se identifican por estado Inactivo/suspendido.
// =============================================
$stats = [
    'total' => 0,
    'pagado' => 0,
    'pendiente' => 0,
    'mora' => 0,
    'suspendido' => 0,
    'cortado' => 0
];

$sql_stats = "
    SELECT
        COUNT(*) AS total,
        COALESCE(SUM(
            CASE WHEN (
                LOWER(TRIM(COALESCE(c.estado_pago, ''))) = 'pendiente'
                OR EXISTS (
                    SELECT 1
                    FROM pago pp
                    WHERE pp.id_cliente = c.id
                      AND LOWER(TRIM(COALESCE(pp.estado, ''))) = 'pendiente'
                )
            ) AND COALESCE(c.dias_mora, 0) <= 0
              AND LOWER(TRIM(COALESCE(c.estado, ''))) <> 'inactivo'
              AND LOWER(TRIM(COALESCE(c.estado_pago, ''))) <> 'suspendido'
            THEN 1 ELSE 0 END
        ), 0) AS pendiente,
        COALESCE(SUM(
            CASE WHEN (
                LOWER(TRIM(COALESCE(c.estado_pago, ''))) = 'pendiente'
                OR EXISTS (
                    SELECT 1
                    FROM pago pm
                    WHERE pm.id_cliente = c.id
                      AND LOWER(TRIM(COALESCE(pm.estado, ''))) = 'pendiente'
                )
            ) AND COALESCE(c.dias_mora, 0) > 0
              AND LOWER(TRIM(COALESCE(c.estado, ''))) <> 'inactivo'
              AND LOWER(TRIM(COALESCE(c.estado_pago, ''))) <> 'suspendido'
            THEN 1 ELSE 0 END
        ), 0) AS mora,
        COALESCE(SUM(
            CASE WHEN LOWER(TRIM(COALESCE(c.estado_pago, ''))) = 'pagado'
              AND LOWER(TRIM(COALESCE(c.estado, ''))) <> 'inactivo'
              AND LOWER(TRIM(COALESCE(c.estado_pago, ''))) <> 'suspendido'
              AND NOT EXISTS (
                  SELECT 1
                  FROM pago pa
                  WHERE pa.id_cliente = c.id
                    AND LOWER(TRIM(COALESCE(pa.estado, ''))) = 'pendiente'
              )
            THEN 1 ELSE 0 END
        ), 0) AS pagado,
        COALESCE(SUM(
            CASE WHEN LOWER(TRIM(COALESCE(c.estado, ''))) = 'inactivo'
               OR LOWER(TRIM(COALESCE(c.estado_pago, ''))) = 'suspendido'
            THEN 1 ELSE 0 END
        ), 0) AS cortado
    FROM cliente c
    WHERE COALESCE(c.eliminado, 0) = 0
";
$result_stats = mysqli_query($conexion, $sql_stats);

if ($result_stats) {
    $fila_stats = mysqli_fetch_assoc($result_stats) ?: [];
    foreach (['total', 'pagado', 'pendiente', 'mora', 'cortado'] as $campo) {
        $stats[$campo] = (int)($fila_stats[$campo] ?? 0);
    }
}
$stats['suspendido'] = $stats['cortado'];
$totalClientes = $stats['total'];

// ✅ PASAR PERMISOS A LA VISTA
$permisos = [
    'puede_editar' => ($id_rol == 1 || $id_rol == 4),
    'puede_eliminar' => ($id_rol == 1 || $id_rol == 4),
    'puede_cortar' => ($id_rol == 1 || $id_rol == 4),
    'puede_pagar' => ($id_rol == 1 || $id_rol == 2 || $id_rol == 4)
];
if (isset($_GET['ajax']) && $_GET['ajax'] === 'get_cliente_detalle') {
    header('Content-Type: application/json');
    
    $id = intval($_GET['id'] ?? 0);
    
    if ($id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID inválido']);
        exit;
    }
    
    // Obtener datos del cliente
    $sql = "SELECT c.*, 
                   b.nombre as barrio_nombre, 
                   ts.nombre as tipo_servicio_nombre,
                   ts.dia_corte,
                   ts.precio_base
            FROM cliente c
            LEFT JOIN barrio b ON c.id_barrio = b.id_barrio
            LEFT JOIN tipo_servicio ts ON c.id_tipo = ts.id_tipo
            WHERE c.id = ?";
    
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);
    
    if ($data) { 

    // =============================================
    // OBTENER MESES DE DEUDA PENDIENTES
    // =============================================
    $deudas = [];

    $fecha_ultimo_pago = $data['fecha_ultimo_pago'] ?? null;
    $precio_base = floatval($data['precio_base'] ?? 0);

    if (!empty($fecha_ultimo_pago) && $precio_base > 0) {

        $fecha_inicio = new DateTime($fecha_ultimo_pago);
        $hoy = new DateTime();

        // Comenzamos desde el mes del último pago
        $fecha_mes = new DateTime(
            $fecha_inicio->format('Y-m-01')
        );

        // Mes actual
        $fecha_actual = new DateTime(
            $hoy->format('Y-m-01')
        );

        $nombres_meses = [
            1 => 'Enero',
            2 => 'Febrero',
            3 => 'Marzo',
            4 => 'Abril',
            5 => 'Mayo',
            6 => 'Junio',
            7 => 'Julio',
            8 => 'Agosto',
            9 => 'Septiembre',
            10 => 'Octubre',
            11 => 'Noviembre',
            12 => 'Diciembre'
        ];

        while ($fecha_mes <= $fecha_actual) {

            $mes = intval($fecha_mes->format('n'));
            $anio = intval($fecha_mes->format('Y'));

            $deudas[] = [
                'mes' => $mes,
                'anio' => $anio,
                'nombre_mes' => $nombres_meses[$mes],
                'monto' => $precio_base
            ];

            $fecha_mes->modify('+1 month');
        }
    }

    // Enviar las deudas al JavaScript
    $data['deudas_pendientes'] = $deudas;

    echo json_encode([
        'status' => 'success',
        'data' => $data
    ]);

} else { 

    echo json_encode([
        'status' => 'error',
        'message' => 'Cliente no encontrado'
    ]);

}

exit;
}


?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes - Chango Vision</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../css/admin_cliente.css">
    <link rel="stylesheet" href="../css/responsive_global.css">
</head>
<body>

<div class="container">
    <div class="header">
    <h1><i class="fas fa-users"></i> Clientes</h1>
    <div class="header-actions" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
        
<?php if ($es_cobrador): ?>
<button type="button" onclick="abrirModal('modalNuevaTarea')" style="background-color: #ffffff; color: #0b4e75; border-radius: 50px; padding: 8px 22px; border: none; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; font-weight: 600; font-size: 15px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); transition: all 0.2s ease;">
    <span style="font-size: 18px; font-weight: 400; line-height: 1;">+</span>
    <span>Nueva Reclamo</span>
</button>
<?php endif; ?>

        <?php if ($id_rol != 2): ?>
    <button class="btn-primary" onclick="abrirModal()">
        <i class="fas fa-user-plus"></i> Nuevo Cliente
    </button>
<?php endif; ?>

        <!-- BOTÓN VOLVER -->
        <a href="<?= $url_volver ?>" class="btn-outline-light">
            <i class="fas fa-arrow-left"></i> Volver
        </a>
    </div>
</div>

    <div class="stats-container">
        
    <!-- ============================================= -->
    <!-- ESTADÍSTICAS PARA ADMINISTRADOR Y ADMIN RED   -->
    <!-- ============================================= -->
    <?php if ($id_rol == 1 || $id_rol == 4): ?>
    <div class="stats-container">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number" style="color:#3b82f6;"><?= $totalClientes ?></div>
                <div class="stat-label">Total Clientes</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" style="color:#10b981;"><?= $stats['pagado'] ?? 0 ?></div>
                <div class="stat-label"><span class="stat-dot" style="background:#10b981;"></span> Al día</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" style="color:#f59e0b;"><?= $stats['pendiente'] ?? 0 ?></div>
                <div class="stat-label"><span class="stat-dot" style="background:#f59e0b;"></span> Pendiente</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" style="color:#ef4444;"><?= $stats['mora'] ?? 0 ?></div>
                <div class="stat-label"><span class="stat-dot" style="background:#ef4444;"></span> En mora</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" style="color:#64748b;"><?= $stats['suspendido'] ?? 0 ?></div>
                <div class="stat-label"><span class="stat-dot" style="background:#64748b;"></span> Servicios cortados</div>
            </div>
        </div>
        
    </div>
    <?php endif; ?>

    <!-- ============================================= -->
    <!-- ESTADÍSTICAS DEDICADAS PARA COBRADOR         -->
    <!-- (Con el mismo diseño visual de tarjetas)     -->
    <!-- ============================================= -->
    <?php if ($id_rol == 2): ?>
    <div class="stats-container">
        <div class="stats-grid">
            <!-- Total Recaudado Hoy -->
            <div class="stat-card">
                <div class="stat-number" id="cobradorTotalRecaudado" style="color:#10b981;">
                    $<?= number_format($total_recaudado_hoy, 0, ',', '.') ?>
                </div>
                <div class="stat-label">
                    <span class="stat-dot" style="background:#10b981;"></span> Recaudado Hoy
                </div>
            </div>

            <!-- Clientes que Pagaron Hoy -->
            <div class="stat-card">
                <div class="stat-number" id="cobradorClientesPagaron" style="color:#3b82f6;">
                    <?= $clientes_pagaron_hoy ?>
                </div>
                <div class="stat-label">
                    <span class="stat-dot" style="background:#3b82f6;"></span> Pagaron Hoy
                </div>
            </div>

            <!-- Clientes Pendientes de Cobro -->
            <div class="stat-card">
                <div class="stat-number" id="cobradorClientesNoPagaron" style="color:#ef4444;">
                    <?= $clientes_no_pagaron_hoy ?>
                </div>
                <div class="stat-label">
                    <span class="stat-dot" style="background:#ef4444;"></span> Pendientes de Cobro
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

</div>




   <div class="search-container">
    <div class="search-box">
        <i class="fas fa-search"></i>
        <input type="text" id="searchInput" placeholder="Buscar por nombre, código, DNI...">
    </div>
</div>

<!-- ============================================= -->
<!-- FILTROS MÚLTIPLES -->
<!-- ============================================= -->
<div class="filters-container">
    <!-- FILTRO POR ESTADO -->
    <div class="filter-group">
        <label><i class="fas fa-circle"></i> Estado:</label>
        <select id="filterEstado" class="filter-select">
            <option value="todos">📋 Todos</option>
            <option value="pagado">✅ Al día</option>
            <option value="pendiente">⏳ Pendiente</option>
            <option value="mora">⚠️ En mora</option>
            <option value="suspendido">⏸️ Suspendido</option>
        </select>
    </div>

    <!-- FILTRO POR BARRIO -->
    <div class="filter-group">
        <label><i class="fas fa-map-marker-alt"></i> Barrio:</label>
        <select id="filterBarrio" class="filter-select">
            <option value="todos">📍 Todos</option>
            <?php foreach ($barrios_filtro as $b): ?>
                <option value="<?= $b['id_barrio'] ?>"><?= htmlspecialchars($b['nombre']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- FILTRO POR SERVICIO (opcional) -->
    <div class="filter-group">
        <label><i class="fas fa-wifi"></i> Servicio:</label>
        <select id="filterServicio" class="filter-select">
            <option value="todos">📡 Todos</option>
            <?php foreach ($tipos_servicio as $ts): ?>
                <option value="<?= $ts['id_tipo'] ?>"><?= htmlspecialchars($ts['nombre']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- BOTÓN LIMPIAR FILTROS -->
    <button class="btn-clear-filters" onclick="limpiarFiltros()">
        <i class="fas fa-undo"></i> Limpiar
    </button>

    <!-- CONTADOR DE RESULTADOS -->
    <span class="filter-results-count" id="filterResultsCount">
        <strong id="resultCount"><?= $total_registros ?></strong> clientes
    </span>
</div>

    <div class="table-wrapper">
        <table class="client-table">
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>DNI</th>
                    <th>Teléfono</th>
                    <th>Barrio</th>
                    <th>Servicio</th>
                    <th>Días Mora</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>

            
            <tbody id="clientesTableBody">
                <?php if (empty($clientes)): ?>
                    <tr><td colspan="10" style="text-align:center; padding:2rem;">No hay clientes registrados</td></tr>
                <?php else: ?>
        <?php 
        // =============================================
        // ✅ CORRECCIÓN: OBTENER PAGOS DEL MES ACTUAL
        // =============================================
        $mes_actual = (int)date('m');
        $anio_actual = (int)date('Y');
        $pagos_del_mes = [];

        if (!empty($clientes)) {
            // Extraer los IDs de los clientes de la página actual
            $ids_clientes = array_column($clientes, 'id');
            $ids_str = implode(',', $ids_clientes);
            
            // Consultar qué clientes ya pagaron este mes
            $sql_pagos_mes = "SELECT id_cliente FROM pago WHERE id_cliente IN ($ids_str) AND mes = $mes_actual AND anio = $anio_actual AND estado = 'Pagado'";
            $result_pagos_mes = mysqli_query($conexion, $sql_pagos_mes);
            
            if ($result_pagos_mes) {
                while ($row = mysqli_fetch_assoc($result_pagos_mes)) {
                    $pagos_del_mes[$row['id_cliente']] = true;
                }
            }
        }
        ?>
                    
<?php foreach ($clientes as $cliente):
    $resultado = calcularEstadoPago($cliente);
    $estado = $resultado['estado'];
    $dias_mora = $resultado['dias_mora'];
    $dia_corte = $cliente['dia_corte'] ?? 15;
    $total_pagos = $cliente['total_pagos'] ?? 0;
    $hoy = (int)date('d');
    $mes_actual = (int)date('m');
    $anio_actual = (int)date('Y');
    
$ya_pago_este_mes = isset($pagos_del_mes[$cliente['id']]);

$es_admin_o_adminred = ($_SESSION['id_rol'] == 1 || $_SESSION['id_rol'] == 4);

// =============================================
// VERIFICAR SI EL CLIENTE TIENE MESES PAGADOS
// POR ADELANTADO
// =============================================

$fecha_hoy = date('Y-m-d');

$tiene_pago_vigente = false;

if (!empty($cliente['fecha_ultimo_pago'])) {

    $fecha_limite_pago = date(
        'Y-m-d',
        strtotime($cliente['fecha_ultimo_pago'])
    );

    // Si la fecha cubierta todavía no llegó,
    // el cliente tiene pagos por adelantado.
    if (strtotime($fecha_limite_pago) > strtotime($fecha_hoy)) {
        $tiene_pago_vigente = true;
    }
}
   
// =============================================
// ✅ CALCULAR MESES DE DEUDA (para auto-selección en pago)
// =============================================

// =============================================
// ✅ CALCULAR MESES DE DEUDA Y REGLAS DE BOTONES
// =============================================
$meses_deuda = 1;

if ($estado === 'mora' || $dias_mora > 0) {
    if (!empty($cliente['fecha_ultimo_pago'])) {
        $fecha_ultimo = new DateTime($cliente['fecha_ultimo_pago']);
        $fecha_hoy_dt = new DateTime();
        $diferencia = $fecha_ultimo->diff($fecha_hoy_dt);
        $meses_deuda = ($diferencia->y * 12) + $diferencia->m;
        if ($meses_deuda < 1) $meses_deuda = 1;
    } else {
        $meses_deuda = max(1, ceil($dias_mora / 30));
    }
    if ($meses_deuda > 12) $meses_deuda = 12;

    // 🔴 SI TIENE MORA: No considerar que está al día
    $ya_pago_este_mes = false; 
    $tiene_pago_vigente = false;
}

// ---------------------------------------------
// REGLA 1: BOTÓN PAGAR
// ---------------------------------------------
$mostrar_pagar = false;

if ($estado !== 'suspendido') {
    if ($total_pagos == 0) {
        // Primer pago / Instalación (solo Admin / Admin Red)
        $mostrar_pagar = $es_admin_o_adminred;
    } elseif ($id_rol == 2) {
        // El cobrador solo ve en su lista los pendientes de cobro
        $mostrar_pagar = true;
    } else {
        // Para Admin / Admin Red:
        if ($estado === 'mora' || $dias_mora > 0 || !$tiene_pago_vigente || $cliente['estado_pago'] === 'pendiente') {
            $mostrar_pagar = true;
        }
    }
}



// =============================================
// ✅ OCULTAR BOTÓN SI EL CLIENTE YA ESTÁ AL DÍA
// =============================================
if (($tiene_pago_vigente || $cliente['estado_pago'] === 'pagado') && $id_rol != 2) {
    // Para el Admin/Admin Red: Si el pago ya fue registrado y está al día, ocultar el botón Pagar
    $mostrar_boton_pagar = false;
}


// ---------------------------------------------
// REGLA 2: BOTÓN CORTE
// ---------------------------------------------
$mostrar_cortar = false;
$dias_tolerancia = 1;

if ($es_admin_o_adminred && $estado !== 'suspendido' && $cliente['estado'] !== 'Inactivo') {
    $limite_corte = $dia_corte + $dias_tolerancia;

    // Mostrar botón de corte si tiene mora o superó el día límite
    if ($estado === 'mora' || $dias_mora > 0 || ($hoy > $limite_corte && !$tiene_pago_vigente)) {
        $mostrar_cortar = true;
    }
}

// ---------------------------------------------
// PRÓXIMA FECHA DE COBRO
// ---------------------------------------------
if ($tiene_pago_vigente && !empty($cliente['fecha_ultimo_pago'])) {
    $fecha_cobro = $cliente['fecha_ultimo_pago'];
} else {
    $fecha_cobro = date('Y-m-' . str_pad($dia_corte, 2, '0', STR_PAD_LEFT));
    if ($hoy >= $dia_corte) {
        $fecha_cobro = date('Y-m-' . str_pad($dia_corte, 2, '0', STR_PAD_LEFT), strtotime('+1 month'));
    }
}
  // =============================================
// ✅ DESAPARECER BOTONES SOLO SI NO HAY MÁS CUOTAS
// =============================================
// Si no quieres bloquear cobros futuros a Administradores/Cobradores, solo oculta el corte:
if ($ya_pago_este_mes) {
    $mostrar_cortar = false;
}


// =============================================
// REGLA: ¿MOSTRAR BOTÓN CORTE?
// =============================================

$mostrar_cortar = false;

// Días de tolerancia después de la facturación
$dias_tolerancia = 1;

// Solo Administrador y Admin Red
if ($es_admin_o_adminred) {

    // No cortar si está suspendido
    if ($estado === 'suspendido') {

        $mostrar_cortar = false;

    // No cortar si tiene meses pagados por adelantado
    } elseif ($tiene_pago_vigente) {

        $mostrar_cortar = false;

    // No cortar si todavía no realizó ningún pago (primer pago pendiente)
    } elseif ($total_pagos == 0) {

        $mostrar_cortar = false;

    } else {
        // ✅ Si ya pasó el día de corte + tolerancia, o si tiene mora, mostrar el botón de corte
        $limite_corte = $dia_corte + $dias_tolerancia;

        if ($hoy > $limite_corte || $dias_mora > 0) {
            $mostrar_cortar = true;
        } else {
            // ✅ NUEVO: Si recién se reactiva y está pendiente fuera de término, permitir cortar también
            $mostrar_cortar = true; 
        }
    }
}

    // =============================================
    // ✅ ESTILOS PARA LA TABLA
    // =============================================
    $clases = [
        'pagado' => 'badge-pagado',
        'pendiente' => 'badge-pendiente',
        'mora' => 'badge-mora',
        'suspendido' => 'badge-suspendido'
    ];
    $iconos = [
        'pagado' => 'fa-check-circle',
        'pendiente' => 'fa-clock',
        'mora' => 'fa-exclamation-triangle',
        'suspendido' => 'fa-pause-circle'
    ];
    $etiquetas = [
        'pagado' => 'Al día',
        'pendiente' => 'Pendiente',
        'mora' => 'En mora',
        'suspendido' => 'Suspendido'
    ];
?>


<tr data-cliente-id="<?= $cliente['id'] ?>"
    data-estado-pago="<?= $estado ?>"
    data-barrio-id="<?= $cliente['id_barrio'] ?? '' ?>"
    data-servicio-id="<?= $cliente['id_tipo'] ?? '' ?>"
    data-total-pagos="<?= $total_pagos ?>"
    data-ya-pago="<?= $ya_pago_este_mes ? '1' : '0' ?>">
    <td><span class="badge badge-codigo"><i class="fas fa-tag"></i> <?= htmlspecialchars($cliente['codigo_cliente'] ?? '-') ?></span></td>
    <td><strong><?= htmlspecialchars($cliente['nombre'] ?? '') ?></strong></td>
    <td><?= htmlspecialchars($cliente['apellido'] ?? '') ?></td>
    <td><?= htmlspecialchars($cliente['dni'] ?? '-') ?></td>
    <td><?= htmlspecialchars($cliente['telefono'] ?? '-') ?></td>
    <td><span class="badge badge-barrio"><?= htmlspecialchars($cliente['barrio_nombre'] ?? 'Sin barrio') ?></span></td>
    <td><span class="badge badge-servicio"><?= htmlspecialchars($cliente['tipo_servicio_nombre'] ?? 'Sin servicio') ?></span></td>
    <td>
        <span class="badge <?= $clases[$estado] ?? 'badge-pendiente' ?>">
            <i class="fas <?= $iconos[$estado] ?? 'fa-clock' ?>"></i>
            <?= $etiquetas[$estado] ?? 'Pendiente' ?>
            <?php if ($estado === 'mora'): ?>
                <span style="background:#991b1b; color:white; padding:1px 8px; border-radius:12px; margin-left:4px; font-size:0.6rem;">
                    <?= $dias_mora ?> día(s)
                </span>
            <?php endif; ?>
        </span>
        <div style="font-size:0.55rem; color:#94a3b8; margin-top:2px;">
            Cobro: <?= date('d/m/Y', strtotime($fecha_cobro)) ?>
            <?php if ($total_pagos == 0): ?>
                <span style="color:#059669; font-weight:600;">(Primer pago)</span>
            <?php endif; ?>
            <?php if ($ya_pago_este_mes && !$tiene_pago_vigente): ?>
    <span style="color:#10b981; font-weight:600;">(Pagado este mes)</span>
<?php elseif ($tiene_pago_vigente): ?>
    <span style="color:#3b82f6; font-weight:600;">(Próximo cobro)</span>
<?php endif; ?>
        </div>
    </td>
    <td style="white-space:nowrap;">
        <!-- BOTON VER DETALLES (OCULTO PARA COBRADOR) -->
<?php if ($id_rol != 2): ?>
    <button class="btn-ver-detalle" onclick="verDetalleCliente(<?= $cliente['id'] ?>)">
        <i class="fas fa-eye"></i>
    </button>
<?php endif; ?>
        
        <!-- BOTON EDITAR (SOLO ADMIN Y ADMIN RED) -->
        <?php if ($id_rol == 1 || $id_rol == 4): ?>
            <button class="btn-edit" onclick="editarCliente(<?= $cliente['id'] ?>)"><i class="fas fa-edit"></i></button>
            <button class="btn-delete" onclick="eliminarCliente(<?= $cliente['id'] ?>)" title="Eliminar cliente">
        <i class="fas fa-trash"></i>
    </button>
            <?php endif; ?>
        

        
<?php
// Usar una única lógica para evitar contradicciones
$mostrar_boton_pagar = $mostrar_pagar;
?>

<?php if ($mostrar_boton_pagar): ?>
    <button class="btn-pago" onclick="registrarPago(<?= $cliente['id'] ?>, '<?= $fecha_cobro ?>', <?= $meses_deuda ?>)">
        <i class="fas fa-dollar-sign"></i> Pagar
    </button>
<?php elseif ($ya_pago_este_mes || $estado === 'pagado'): ?>
    <span class="estado-pagado" style="font-size:0.7rem; color:#10b981; padding:4px 12px; background:#f0fdf4; border-radius:6px; display:inline-block; border:1px solid #bbf7d0;">
        <i class="fas fa-check-circle"></i> Al día
    </span>
<?php elseif ($estado !== 'suspendido' && !$mostrar_boton_pagar && !$ya_pago_este_mes): ?>
    <span style="font-size:0.55rem; color:#94a3b8; padding:4px 8px; background:#f1f5f9; border-radius:6px; display:inline-block;">
        <i class="fas fa-clock"></i> <?= date('d/m', strtotime($fecha_cobro)) ?>
    </span>
<?php endif; ?>
<!-- BOTÓN OBSERVACIÓN DE COBRO (EXCLUSIVO PARA COBRADOR ROL 2) -->
<?php if ($id_rol == 2): ?>
    <button class="btn-obs-cobro" 
            style="background:#6366f1; color:white; border:none; padding:4px 8px; border-radius:6px; cursor:pointer; font-size:0.75rem; margin-right:4px;"
            onclick="abrirModalObsCobro(<?= $cliente['id'] ?>, '<?= htmlspecialchars($cliente['nombre'] . ' ' . $cliente['apellido']) ?>')" 
            title="Cargar observación de cobro">
        <i class="fas fa-clipboard-list"></i> Obs.
    </button>
<?php endif; ?>

<!-- ============================================= -->
    <!-- BOTON REACTIVAR - SOLO PARA SUSPENDIDOS (NO ELIMINADOS) -->
    <!-- ============================================= -->
    <?php if ($estado === 'suspendido' && ($id_rol == 1 || $id_rol == 4)): ?>
        <button class="btn-reactivar" onclick="reactivarServicio(<?= $cliente['id'] ?>)">
            <i class="fas fa-play"></i> Reactivar
        </button>
    <?php endif; ?>

    <!-- ============================================= -->
    <!-- ESTADO SUSPENDIDO (SIN BOTON REACTIVAR) -->
    <!-- ============================================= -->
    <?php if ($estado === 'suspendido' && !($id_rol == 1 || $id_rol == 4)): ?>
        <span style="font-size:0.6rem; color:#94a3b8; padding:4px 8px; background:#e2e8f0; border-radius:6px; display:inline-block; font-weight:600;">
            <i class="fas fa-pause-circle"></i> Suspendido
        </span>
    <?php endif; ?>
        
       <!-- ============================================= -->
    <!-- BOTON CORTE - APARECE SOLO CUANDO CORRESPONDE -->
    <!-- ============================================= -->
    <?php if (
        ($id_rol == 1 || $id_rol == 4) &&
        $estado !== 'suspendido' &&
        $mostrar_cortar &&
        !$tiene_pago_vigente
    ): ?>
        <button class="btn-corte" onclick="cortarServicio(<?= $cliente['id'] ?>)">
            <i class="fas fa-ban"></i> Corte
        </button>
    <?php endif; ?>
    
    <!-- ============================================= -->
    <!-- ESTADO SUSPENDIDO (RESPALDO) -->
    <!-- ============================================= -->
    <?php if ($estado === 'suspendido'): ?>
        <span style="font-size:0.6rem; color:#94a3b8; padding:4px 8px; background:#e2e8f0; border-radius:6px; display:inline-block; font-weight:600;">
            <i class="fas fa-pause-circle"></i> Suspendido
        </span>
    <?php endif; ?>
</td>


                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

<!-- ============================================= -->
<!-- PAGINACIÓN - PARTE INFERIOR (FUERA DE LA TABLA) -->
<!-- ============================================= -->

<?php if ($total_paginas > 1): ?>

<div class="pagination-wrapper">

    <div class="pagination-info">
        <!-- Información de registros -->
    </div>

    <div class="pagination">

        <!-- ANTERIOR -->
        <?php if ($pagina_actual > 1): ?>

            <a href="?pagina=<?= $pagina_actual - 1 ?>&barrio=<?= $filtro_barrio ?>"
               class="prev-next">
                <i class="fas fa-chevron-left"></i> Anterior
            </a>

        <?php else: ?>

            <span class="disabled prev-next">
                <i class="fas fa-chevron-left"></i> Anterior
            </span>

        <?php endif; ?>


        <!-- NÚMEROS DE PÁGINAS -->
        <?php

        $rango = 2;

        $inicio = max(1, $pagina_actual - $rango);
        $fin = min($total_paginas, $pagina_actual + $rango);


        // PRIMERA PÁGINA
        if ($inicio > 1) {

            echo '<a href="?pagina=1&barrio=' . $filtro_barrio . '">1</a>';

            if ($inicio > 2) {
                echo '<span class="dots">…</span>';
            }
        }

        ?>


        <!-- PÁGINAS INTERMEDIAS -->
        <?php for ($i = $inicio; $i <= $fin; $i++): ?>

            <?php if ($i == $pagina_actual): ?>

                <span class="active">
                    <?= $i ?>
                </span>

            <?php else: ?>

                <a href="?pagina=<?= $i ?>&barrio=<?= $filtro_barrio ?>">
                    <?= $i ?>
                </a>

            <?php endif; ?>

        <?php endfor; ?>


        <?php

        // ÚLTIMA PÁGINA
        if ($fin < $total_paginas) {

            if ($fin < $total_paginas - 1) {
                echo '<span class="dots">…</span>';
            }

            echo '<a href="?pagina=' . $total_paginas . '&barrio=' . $filtro_barrio . '">'
                . $total_paginas .
                '</a>';
        }

        ?>


        <!-- SIGUIENTE -->
        <?php if ($pagina_actual < $total_paginas): ?>

            <a href="?pagina=<?= $pagina_actual + 1 ?>&barrio=<?= $filtro_barrio ?>"
               class="prev-next">
                Siguiente <i class="fas fa-chevron-right"></i>
            </a>

        <?php else: ?>

            <span class="disabled prev-next">
                Siguiente <i class="fas fa-chevron-right"></i>
            </span>

        <?php endif; ?>

    </div>


    <!-- BOTÓN PARA SUBIR -->
    <div class="pagination-go-top">

        <a href="#"
           onclick="window.scrollTo({top: 0, behavior: 'smooth'}); return false;">

            <i class="fas fa-arrow-up"></i> Subir

        </a>

    </div>

</div>

<?php endif; ?>
    
     
</tbody>


<!-- MODAL CLIENTE -->
<div id="clienteModal" class="modal-overlay">
    <div class="modal-container">
        <div class="modal-header">
            <h3 id="modalTitle"><i class="fas fa-user-plus"></i> Nuevo Cliente</h3>
            <button class="close-modal" onclick="cerrarModal()">&times;</button>
        </div>
        <div class="modal-body">
            <form id="formCliente" method="POST" action="" enctype="multipart/form-data">
                <input type="hidden" name="accion" id="formAccion" value="registrar">
                <input type="hidden" name="id" id="clienteId">
                <input type="hidden" name="foto_dni_actual" id="fotoDniActual">
                <input type="hidden" name="ajax" value="1">

                <!-- FILA 1: NOMBRE Y APELLIDO -->
                <div class="form-row">
                    <div class="form-group">
                        <label>Nombre <span class="obligatorio">*</span></label>
                        <input type="text" id="nombreCliente" name="nombre" placeholder="Ej: Juan" required oninput="validarCampo(this, 'texto'); actualizarCodigo();">
                    </div>
                    <div class="form-group">
                        <label>Apellido <span class="obligatorio">*</span></label>
                        <input type="text" id="apellidoCliente" name="apellido" placeholder="Ej: Pérez" required oninput="validarCampo(this, 'texto'); actualizarCodigo();">
                    </div>
                </div>

                <!-- CÓDIGO DE CLIENTE (AUTOMÁTICO) -->
                <div class="form-group">
                    <label><i class="fas fa-tag"></i> Código de Cliente</label>
                    <div id="codigoPreview" class="codigo-generado codigo-loading">
                        <i class="fas fa-spinner fa-spin"></i> Escriba nombre y apellido
                    </div>
                </div>

                <!-- FILA 2: DNI Y EMAIL -->
                <div class="form-row">
                    <div class="form-group">
                        <label>DNI <span class="obligatorio">*</span></label>
                        <input type="text" id="dniCliente" name="dni" placeholder="Ej: 12345678" required oninput="validarDNI(this)">
                        <div class="mensaje-error" id="dniError">El DNI debe tener 7 u 8 dígitos numéricos</div>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" id="emailCliente" name="email" placeholder="Ej: juan@example.com" oninput="validarEmail(this)">
                        <div class="mensaje-error" id="emailError">Ingrese un email válido</div>
                    </div>
                </div>

                <!-- FILA 3: TELÉFONO Y BARRIO -->
                <div class="form-row">
                    <div class="form-group">
                        <label>Teléfono</label>
                        <input type="text" id="telefonoCliente" name="telefono" placeholder="Ej: 123456789" oninput="validarTelefono(this)">
                        <div class="mensaje-error" id="telefonoError">El teléfono debe contener solo números</div>
                    </div>
                    <div class="form-group">
                        <label>Barrio <span class="obligatorio">*</span></label>
                        <div style="display: flex; gap: 8px;">
                            <select id="barrioCliente" name="id_barrio" required style="flex:1; padding: 0.7rem; border: 1.5px solid #dce5ec; border-radius: 10px; font-size: 0.9rem;">
                                <option value="">-- Seleccionar --</option>
                                <?php foreach ($barrios as $b): ?>
                                    <option value="<?= $b['id_barrio'] ?>"><?= htmlspecialchars($b['nombre']) ?></option>
                                <?php endforeach; ?>
                            </select>
                           <button type="button" onclick="abrirModalBarrio()" 
    style="padding: 0.7rem 1rem; border-radius: 10px; background: linear-gradient(135deg, #059669, #10b981); border: none; color: white; cursor: pointer; font-weight: 700; font-size: 1.2rem; min-width: 44px; display: flex; align-items: center; justify-content: center; transition: 0.3s;"
    onmouseover="this.style.opacity='0.8'" onmouseout="this.style.opacity='1'">
    <i class="fas fa-plus"></i>
</button>
                        </div>
                        <div class="info-text"><i class="fas fa-info-circle"></i> Selecciona un barrio de la lista. Si no existe, haz clic en <strong>+</strong> para agregarlo</div>
                    </div>
                </div>

                <!-- FILA 4: TIPO SERVICIO Y FECHA DE COBRO -->
                <div class="form-row">
                    <div class="form-group">
                        <label>Tipo Servicio <span class="obligatorio">*</span></label>
                        <select id="tipoServicioCliente" name="id_tipo" required>
                            <option value="">-- Seleccionar --</option>
                            <?php foreach ($tipos_servicio as $ts): ?>
                                <option value="<?= $ts['id_tipo'] ?>"><?= htmlspecialchars($ts['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                </div>

                <!-- NO ES DEL LUGAR (CHECKBOX) -->
                <div class="form-group">
                    <div class="checkbox-group">
                        <input type="checkbox" id="noLocal" name="no_local" value="1">
                        <label for="noLocal"><i class="fas fa-map-marker-alt"></i> No es del lugar</label>
                    </div>
                </div>

                <!-- ============================================= -->
<!-- ✅ CAMPO: OBSERVACIÓN DEL CLIENTE -->
<!-- ============================================= -->
<div class="form-group">
    <label><i class="fas fa-comment"></i> Observación</label>
    <textarea id="observacionCliente" name="observacion" rows="3" 
        placeholder="Ej: Cliente refiere que el servicio se corta, tiene deuda de 2 meses, vive en el 3er piso, etc..."
        style="width: 100%; padding: 0.7rem; border: 1.5px solid #dce5ec; border-radius: 10px; 
               font-size: 0.9rem; resize: vertical; font-family: inherit; transition: 0.3s;"
        onfocus="this.style.borderColor='#1b4f6e'; this.style.boxShadow='0 0 0 3px rgba(27,79,110,0.1)'"
        onblur="this.style.borderColor='#dce5ec'; this.style.boxShadow='none'"></textarea>
    <div class="info-text"><i class="fas fa-info-circle"></i> Puedes agregar una observación sobre el cliente (opcional)</div>
</div>

                <!-- FOTO DNI (ARCHIVO) -->
<div id="fotoDniContainer" class="foto-dni-container" style="display:none;">
    <div class="form-group">
        <label><i class="fas fa-image"></i> Foto DNI <span class="obligatorio">*</span></label>
        <input type="file" id="fotoDni" name="foto_dni" accept="image/*">
        <div class="info-text"><i class="fas fa-info-circle"></i> Solo para clientes que no son del lugar</div>
        <div id="fotoDniPreview" style="margin-top:8px; display:none;"></div>
    </div>
</div>

                <!-- BOTÓN GUARDAR -->
                <button type="submit" class="btn-submit"><i class="fas fa-save"></i> Guardar Cliente</button>
            </form>
        </div>
    </div>
</div>

<!-- MODAL BARRIO RÁPIDO -->
<div id="barrioModal" class="modal-overlay">
    <div class="modal-container" style="max-width: 450px;">
        <div class="modal-header" style="background: linear-gradient(135deg, #0f2b3d, #1b4f6e);">
            <h3><i class="fas fa-map-marker-alt"></i> Nuevo Barrio</h3>
            <button class="close-modal" onclick="cerrarModalBarrio()">&times;</button>
        </div>
        <div class="modal-body">
            <form id="formBarrioRapido">
                <input type="hidden" name="accion" value="crear_barrio_rapido">
                <input type="hidden" name="ajax" value="1">

                <div class="form-group">
                    <label><i class="fas fa-location-dot"></i> Nombre del Barrio <span class="obligatorio">*</span></label>
                    <input type="text" id="nombreBarrioRapido" name="nombre" placeholder="Ej: Centro, Alto Verde" required>
                </div>

                <button type="submit" class="btn-submit" style="background: linear-gradient(135deg, #0f2b3d, #1b4f6e);">
                    <i class="fas fa-save"></i> Guardar Barrio
                </button>
            </form>
        </div>
    </div>
</div>

<!-- MODAL PAGO CON SELECCIÓN DE MESES (HASTA 12) -->
<div id="pagoModal" class="modal-overlay">
    <div class="modal-container" style="max-width: 650px;">
        <div class="modal-header" style="background: linear-gradient(135deg, #0f2b3d, #1b4f6e);">
            <h3><i class="fas fa-coins"></i> Registrar Pago</h3>
            <button class="close-modal" onclick="cerrarPagoModal()">&times;</button>
        </div>
        <div class="modal-body">
            <form id="formPago" method="POST" action="">
                <input type="hidden" name="accion" value="registrar_pago">
                <input type="hidden" name="id_cliente" id="pagoClienteId">
                <input type="hidden" name="ajax" value="1">
                <input type="hidden" name="cantidad_meses" id="pagoCantidadMeses" value="1">

                <!-- DATOS DEL CLIENTE -->
                <div class="form-group" style="background: #f8fafd; padding: 0.8rem; border-radius: 10px; border: 1px solid #e9eef3; margin-bottom: 1rem;">
                    <label style="color: #1b4f6e; font-weight: 700; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.5px;">
                        <i class="fas fa-user"></i> Datos del Cliente
                    </label>
                    <div style="display: flex; flex-direction: column; gap: 4px; margin-top: 6px;">
                        <p style="font-weight:600; color: #0f2b3d; font-size: 1rem; display: flex; align-items: center; gap: 8px;">
                            <i class="fas fa-user-circle" style="color: #1b4f6e;"></i>
                            <span id="pagoNombreApellido">Cargando...</span>
                        </p>
                        <p style="font-weight:500; color: #64748b; font-size: 0.8rem; display: flex; align-items: center; gap: 8px; margin-left: 28px;">
                            <i class="fas fa-tag" style="color: #1b4f6e;"></i>
                            Codigo: <span id="pagoCodigoCliente">Cargando...</span>
                        </p>
                    </div>
                </div>

                <!-- FECHA DE COBRO -->
                <div class="form-group" style="background: #f0f7ff; padding: 0.8rem; border-radius: 10px; border: 1px solid #dbeafe;">
                    <label style="color: #1b4f6e; font-weight: 700; font-size: 0.75rem;">
                        <i class="fas fa-calendar-check" style="color: #1b4f6e;"></i> Proxima fecha de cobro
                    </label>
                    <p id="pagoFechaCobro" style="font-weight:700; font-size:1.1rem; color: #1b4f6e;">Cargando...</p>
                    <span style="font-size:0.65rem; color:#64748b;">El pago corresponde al periodo vigente</span>
                </div>

                <!-- SELECCION DE MESES (CON + y -) -->
<div class="form-group" style="margin-top: 1rem;">
    <label style="color: #1b4f6e; font-weight: 700; font-size: 0.75rem; display: block; margin-bottom: 0.5rem;">
        <i class="fas fa-calendar-alt"></i> ¿Cuantos meses quieres pagar?
    </label>
    
    <div style="display: flex; align-items: center; justify-content: center; gap: 15px; background: #f8fafd; padding: 0.8rem; border-radius: 10px; border: 1px solid #e9eef3;">
        <!-- BOTON RESTAR -->
        <button type="button" onclick="cambiarMeses(-1)" style="
            width: 44px; 
            height: 44px; 
            border-radius: 50%; 
            border: 2px solid #dbeafe; 
            background: white; 
            color: #1b4f6e; 
            font-size: 1.5rem; 
            font-weight: 700; 
            cursor: pointer; 
            transition: 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        " 
        onmouseover="this.style.background='#eef2ff'; this.style.borderColor='#1b4f6e'" 
        onmouseout="this.style.background='white'; this.style.borderColor='#dbeafe'">
            <i class="fas fa-minus"></i>
        </button>
        
        <!-- NUMERO DE MESES -->
        <div style="text-align: center; min-width: 100px;">
            <span id="mesesDisplay" style="font-size: 2.2rem; font-weight: 700; color: #0f2b3d; display: block; line-height: 1.2;">
                1
            </span>
            <span style="font-size: 0.7rem; color: #64748b;">mes(es)</span>
        </div>
        
        <!-- BOTON SUMAR -->
        <button type="button" onclick="cambiarMeses(1)" style="
            width: 44px; 
            height: 44px; 
            border-radius: 50%; 
            border: 2px solid #dbeafe; 
            background: white; 
            color: #1b4f6e; 
            font-size: 1.5rem; 
            font-weight: 700; 
            cursor: pointer; 
            transition: 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        " 
        onmouseover="this.style.background='#eef2ff'; this.style.borderColor='#1b4f6e'" 
        onmouseout="this.style.background='white'; this.style.borderColor='#dbeafe'">
            <i class="fas fa-plus"></i>
        </button>
    </div>
    
    <!-- INDICADOR DE SELECCION ACTUAL -->
    <div style="margin-top: 8px; text-align: center; font-size:0.7rem; color:#64748b;">
        <i class="fas fa-hand-pointer"></i> Seleccionado: <strong id="mesesSeleccionadosLabel">1 mes</strong>
    </div>
</div>
                <!-- DETALLE DE MESES A PAGAR -->
                <div id="detalleMesesContainer" style="display: block; margin-top: 0.8rem; background: #f8fafd; padding: 0.8rem; border-radius: 10px; border: 1px solid #e9eef3;">
                    <label style="color: #1b4f6e; font-weight: 700; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.5px; display: block; margin-bottom: 0.5rem;">
                        <i class="fas fa-list"></i> Detalle de meses a pagar
                    </label>
                    <div id="listaMeses" style="max-height: 250px; overflow-y: auto;">
                        <div style="text-align:center; padding:0.5rem; color:#94a3b8; font-size:0.8rem;">
                            <i class="fas fa-spinner fa-spin"></i> Cargando fechas...
                        </div>
                    </div>
                </div>

                <!-- MONTO TOTAL A PAGAR -->
                <div class="form-group" style="margin-top: 1rem; background: #f0fdf4; padding: 0.8rem; border-radius: 10px; border: 1px solid #bbf7d0;">
                    <label style="color: #1b4f6e; font-weight: 700; font-size: 0.75rem;">Monto total a pagar</label>
                    <p id="pagoMontoDisplay" style="font-weight:700; font-size:1.8rem; color: #0f2b3d;">Cargando...</p>
                    <span id="pagoMontoDetalle" style="font-size:0.7rem; color:#64748b;"></span>
                </div>
                <!-- FECHA DE PAGO Y METODO -->
                <div class="form-row" style="margin-top: 0.5rem;">
                    <div class="form-group" style="flex:1;">
                        <label style="color: #1b4f6e; font-weight: 700; font-size: 0.75rem;">Fecha Pago *</label>
                        <input type="date" id="pagoFecha" name="fecha_pago" value="<?= date('Y-m-d') ?>" required style="border: 1.5px solid #dce5ec; border-radius: 8px; padding: 0.6rem; width: 100%; font-size: 0.9rem; transition: 0.3s;">
                    </div>
                    <div class="form-group" style="flex:1;">
                        <label style="color: #1b4f6e; font-weight: 700; font-size: 0.75rem;">Metodo *</label>
                        <select id="pagoMetodo" name="metodo_pago" required style="border: 1.5px solid #dce5ec; border-radius: 8px; padding: 0.6rem; width: 100%; font-size: 0.9rem; transition: 0.3s; background: white;">
                            <option value="efectivo">Efectivo</option>
                            <option value="transferencia">Transferencia</option>
                            <option value="tarjeta">Tarjeta</option>
                        </select>
                    </div>
                </div>

                <!-- OBSERVACIONES -->
                <div class="form-group">
                    <label style="color: #1b4f6e; font-weight: 700; font-size: 0.75rem;">Observaciones</label>
                    <textarea id="pagoObservaciones" name="observaciones" rows="2" placeholder="Observaciones del pago..." style="border: 1.5px solid #dce5ec; border-radius: 8px; padding: 0.6rem; width: 100%; font-size: 0.9rem; resize: vertical; transition: 0.3s;"></textarea>
                </div>

                <!-- BOTON REGISTRAR -->
                <button type="submit" class="btn-submit" style="background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white; width: 100%; padding: 0.8rem; border: none; border-radius: 10px; cursor: pointer; font-weight: 600; transition: 0.3s; font-size: 1rem; display: flex; align-items: center; justify-content: center; gap: 8px;">
                    <i class="fas fa-check-circle"></i> Registrar Pago
                </button>
            </form>
        </div>
    </div>
</div>

<!-- MODAL NUEVA TAREA / RECLAMO -->
<div id="modalNuevaTarea" class="modal-overlay">
    <div class="modal-container" style="max-width: 550px;">
        <div class="modal-header" style="background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white;">
            <h3><i class="fas fa-plus-circle"></i> Nuevo Reclamo</h3>
            <button type="button" class="close-modal" onclick="cerrarModal('modalNuevaTarea')">&times;</button>
        </div>
        <div class="modal-body" style="padding: 1.5rem;">
            <form method="POST" action="soporte_tecnico.php">
                <input type="hidden" name="accion" value="crear_solicitud">
                <input type="hidden" name="cliente_id" id="clienteIdNuevaTarea" value="" required>

                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display:block; font-size:0.75rem; font-weight:700; color:#1b4f6e; margin-bottom:4px;">
                        Buscar Cliente <span style="color:#ef4444;">*</span>
                    </label>
                    <div class="cliente-search-wrapper" style="position:relative;">
                        <input type="text" id="clienteSearchNuevaTarea" placeholder="Escribe el nombre del cliente..." autocomplete="off" style="width:100%; padding:0.6rem; border:1.5px solid #dce5ec; border-radius:10px; font-size:0.85rem;">
                        <div class="cliente-dropdown" id="clienteDropdownNuevaTarea" style="position:absolute; top:100%; left:0; right:0; background:white; border:1.5px solid #dce5ec; border-radius:0 0 10px 10px; max-height:180px; overflow-y:auto; z-index:1000; display:none;"></div>
                    </div>
                    <div id="clienteSelectedNuevaTarea" style="display:none; align-items:center; gap:10px; padding:0.6rem; background:#f0fdf4; border:1.5px solid #bbf7d0; border-radius:10px; margin-top:6px;">
                        <div class="info" style="flex:1;"><span class="nombre" id="clienteNombreNuevaTarea" style="font-weight:600; color:#065f46;"></span></div>
                        <button type="button" class="btn-remove" onclick="limpiarClienteTarea()" style="background:none; border:none; color:#ef4444; cursor:pointer; font-size:1.2rem;">&times;</button>
                    </div>
                </div>

                <?php if ($es_cobrador): ?>
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display:block; font-size:0.75rem; font-weight:700; color:#1b4f6e; margin-bottom:4px;">
                        <i class="fas fa-map-marker-alt"></i> Ubicación GPS (Google Maps)
                    </label>
                    <div style="display: flex; gap: 8px;">
                        <input type="url" name="ubicacion_url" id="ubicacionUrlInputTarea" placeholder="https://www.google.com/maps?q=..." style="flex: 1; padding:0.6rem; border:1.5px solid #dce5ec; border-radius:10px; font-size:0.85rem;">
                        <button type="button" id="btnObtenerGpsTarea" onclick="obtenerUbicacionCobradorTarea()" style="background:#1b4f6e; color:white; padding:0 12px; border:none; border-radius:10px; font-size:0.75rem; display:inline-flex; align-items:center; gap:6px; cursor:pointer; white-space:nowrap;">
                            <i class="fas fa-crosshairs"></i> Obtener GPS
                        </button>
                    </div>
                    <small id="statusUbicacionTarea" style="display:block; font-size:0.65rem; margin-top:4px; color:#64748b;"></small>
                </div>
                <?php endif; ?>

                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display:block; font-size:0.75rem; font-weight:700; color:#1b4f6e; margin-bottom:4px;">
                        Descripción / Motivo <span style="color:#ef4444;">*</span>
                    </label>
                    <textarea name="descripcion" placeholder="Detalle la tarea a realizar..." required style="width:100%; padding:0.6rem; border:1.5px solid #dce5ec; border-radius:10px; font-size:0.85rem; font-family:inherit; min-height:80px; resize:vertical;"></textarea>
                </div>

                <div class="form-group" style="margin-bottom: 1.2rem;">
                    <label style="display:block; font-size:0.75rem; font-weight:700; color:#1b4f6e; margin-bottom:4px;">
                        Prioridad <span style="color:#ef4444;">*</span>
                    </label>
                    <select name="prioridad" required style="width:100%; padding:0.6rem; border:1.5px solid #dce5ec; border-radius:10px; font-size:0.85rem;">
                        <option value="baja">Baja</option>
                        <option value="media" selected>Media</option>
                        <option value="alta">Alta</option>
                    </select>
                </div>

                <button type="submit" style="background: linear-gradient(135deg, #0f2b3d, #1b4f6e); color: white; width: 100%; padding: 0.8rem; border: none; border-radius: 10px; cursor: pointer; font-weight: 600; font-size: 0.95rem; display: flex; align-items: center; justify-content: center; gap: 8px;">
                    <i class="fas fa-save"></i> Guardar Tarea
                </button>
            </form>
        </div>
    </div>
</div>

<!-- MODAL ELIMINAR CLIENTE - ESTILO FORMAL ROJO -->
<div id="eliminarModal" class="modal-overlay">
    <div class="modal-container modal-formal" style="max-width: 600px;">
        <div class="modal-header modal-header-formal">
            <h3><i class="fas fa-user-slash"></i> Eliminar Cliente</h3>
            <button class="close-modal" onclick="cerrarModalEliminar()">&times;</button>
        </div>
        <div class="modal-body modal-body-formal">
            <form id="formEliminar" method="POST" action="">
                <input type="hidden" name="accion" value="eliminar">
                <input type="hidden" name="id" id="eliminarClienteId">
                <input type="hidden" name="ajax" value="1">

                <!-- INFORMACIÓN DEL CLIENTE -->
                <div class="seccion-formal">
                    <h5 class="seccion-titulo">
                        <i class="fas fa-user"></i> Información del Cliente
                    </h5>
                    <div class="grid-datos">
                        <div class="dato-item" style="grid-column: span 2;">
                            <span class="dato-label">Nombre completo</span>
                            <span class="dato-valor" id="eliminarClienteNombre">Cargando...</span>
                        </div>
                        <div class="dato-item">
                            <span class="dato-label">Código</span>
                            <span class="dato-valor" id="eliminarClienteCodigo">Cargando...</span>
                        </div>
                        <div class="dato-item">
                            <span class="dato-label">DNI</span>
                            <span class="dato-valor" id="eliminarClienteDni">-</span>
                        </div>
                        <div class="dato-item">
                            <span class="dato-label">Teléfono</span>
                            <span class="dato-valor" id="eliminarClienteTelefono">-</span>
                        </div>
                        <div class="dato-item">
                            <span class="dato-label">Barrio</span>
                            <span class="dato-valor" id="eliminarClienteBarrio">-</span>
                        </div>
                    </div>
                </div>

                <!-- ESTADO DE PAGOS -->
                <div class="seccion-formal">
                    <h5 class="seccion-titulo">
                        <i class="fas fa-file-invoice"></i> Estado de Cuenta
                    </h5>
                    <div class="grid-datos">
                        <div class="dato-item">
                            <span class="dato-label">Total de pagos</span>
                            <span class="dato-valor" id="eliminarTotalPagos">Cargando...</span>
                        </div>
                        <div class="dato-item">
                            <span class="dato-label">Precio base</span>
                            <span class="dato-valor" id="eliminarTotalPagado">Cargando...</span>
                        </div>
                    </div>
                </div>

                <!-- DEUDAS PENDIENTES -->
                <div id="eliminarDeudasContainer" class="seccion-formal seccion-deuda" style="display: none;">
                    <h5 class="seccion-titulo seccion-titulo-deuda">
                        <i class="fas fa-exclamation-circle"></i> Deudas Pendientes
                    </h5>
                    <div class="tabla-deudas-wrapper">
                        <table class="tabla-deudas">
                            <thead>
                                <tr>
                                    <th>Período</th>
                                    <th style="text-align: right;">Monto</th>
                                </tr>
                            </thead>
                            <tbody id="listaDeudasModal">
                                <!-- Se llena dinámicamente -->
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- ADVERTENCIA -->
                <div class="alerta-formal alerta-warning">
                    <div class="alerta-icono">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="alerta-contenido">
                        <h4>Acción irreversible</h4>
                        <p id="eliminarMensajeRestriccion">
                            Cargando información...
                        </p>
                    </div>
                </div>

                <!-- MOTIVO -->
                <div class="form-group" style="margin-top: 1.2rem;">
                    <label style="color: #7f1d1d; font-weight: 600; font-size: 0.78rem; display: block; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.5px;">
                        <i class="fas fa-comment-alt"></i> Motivo de eliminación <span style="color: #dc2626;">*</span>
                    </label>
                    <textarea id="eliminarMotivo" name="motivo_eliminacion" rows="3" 
                        placeholder="Especifique el motivo por el cual se elimina este cliente..."
                        style="width: 100%; padding: 0.7rem; border: 1.5px solid #fecaca; border-radius: 8px; 
                               font-size: 0.88rem; resize: vertical; font-family: inherit; transition: 0.2s;
                               background: #ffffff;"
                        onfocus="this.style.borderColor='#991b1b'; this.style.boxShadow='0 0 0 3px rgba(153,27,27,0.08)'"
                        onblur="this.style.borderColor='#fecaca'; this.style.boxShadow='none'"
                        required></textarea>
                    <div style="font-size: 0.72rem; color: #64748b; margin-top: 6px; display: flex; align-items: center; gap: 6px;">
                        <i class="fas fa-info-circle"></i> Este motivo quedará registrado en el historial del sistema
                    </div>
                </div>

                <!-- BOTONES -->
                <div class="modal-acciones">
                    <button type="button" class="btn-formal btn-formal-secondary" onclick="cerrarModalEliminar()">
                        <i class="fas fa-times"></i> Cancelar
                    </button>
                    <button id="eliminarBtnSubmit" type="submit" class="btn-formal btn-formal-primary">
                        <i class="fas fa-trash-alt"></i> Confirmar Eliminación
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ============================================= -->
<!-- MODAL DE ADVERTENCIA PARA CORTE DE SERVICIO -->
<!-- ============================================= -->
<div id="modalConfirmarCorte" class="modal-overlay">
    <div class="modal-container modal-formal" style="max-width: 480px;">
        <div class="modal-header modal-header-formal" style="background: linear-gradient(135deg, #991b1b, #dc2626);">
            <h3><i class="fas fa-exclamation-triangle"></i> Confirmar Corte de Servicio</h3>
            <button class="close-modal" onclick="cerrarModalConfirmarCorte()">&times;</button>
        </div>
        <div class="modal-body modal-body-formal" style="padding: 1.5rem;">
            
            <!-- ALERTA VISUAL -->
            <div class="alerta-formal alerta-warning" style="margin-bottom: 1.5rem;">
                <div class="alerta-icono">
                    <i class="fas fa-ban"></i>
                </div>
                <div class="alerta-contenido">
                    <h4>¿Estás seguro de suspender el servicio?</h4>
                    <p style="margin: 4px 0 0 0; font-size: 0.85rem;">
                        Esta acción cambiará el estado del cliente a <strong>Suspendido</strong> y generará automáticamente una tarea de corte para el área técnica.
                    </p>
                </div>
            </div>

            <!-- BOTONES -->
            <div class="modal-acciones" style="display: flex; gap: 10px;">
                <button type="button" class="btn-formal btn-formal-secondary" onclick="cerrarModalConfirmarCorte()" style="flex: 1;">
                    <i class="fas fa-times"></i> Cancelar
                </button>
                <button type="button" id="btnEjecutarCorte" class="btn-formal btn-formal-primary" style="flex: 1; background: linear-gradient(135deg, #991b1b, #dc2626); border: none; color: white;" onclick="ejecutarCorteServicio()">
                    <i class="fas fa-check"></i> Sí, Cortar Servicio
                </button>
            </div>
            
        </div>
    </div>
</div>

<!-- ============================================= -->
<!-- MODAL VER DETALLES DEL CLIENTE -->
<!-- ============================================= -->
<div id="modalDetalleCliente" class="modal-overlay">
    <div class="modal-container" style="max-width: 900px;">
        <div class="modal-header" style="background: linear-gradient(135deg, #0f2b3d, #1b4f6e);">
            <h3><i class="fas fa-user-circle"></i> Detalles del Cliente</h3>
            <button class="close-modal" onclick="cerrarModal('modalDetalleCliente')">&times;</button>
        </div>
        <div class="modal-body" id="detalleClienteContenido" style="padding: 1.5rem;">
            <div style="text-align:center; padding:2rem; color:#94a3b8;">
                <i class="fas fa-spinner fa-spin" style="font-size:2rem;"></i>
                <p>Cargando detalles...</p>
            </div>
        </div>
    </div>
</div>

<!-- ============================================= -->
<!-- MODAL VER DNI -->
<!-- ============================================= -->
<div id="modalVerDNI" class="modal-overlay">
    <div class="modal-container" style="max-width: 500px;">
        <div class="modal-header" style="background: linear-gradient(135deg, #7c3aed, #6d28d9);">
            <h3><i class="fas fa-id-card"></i> Foto de DNI</h3>
            <button class="close-modal" onclick="cerrarModalDNI()">&times;</button>
        </div>
        <div class="modal-body" style="text-align:center; padding:1.5rem;">
            <div id="dniImagenContainer">
                <img id="dniImagen" src="#" alt="DNI" style="max-width: 100%; max-height: 400px; border-radius: 10px; border: 2px solid #e9eef3; display: none;">
                <div id="dniSinFoto" style="display: none; padding: 2rem; color: #94a3b8;">
                    <i class="fas fa-user-slash" style="font-size: 3rem; display: block; margin-bottom: 1rem; color: #cbd5e1;"></i>
                    <p>No hay foto disponible</p>
                </div>
            </div>
            <div style="margin-top: 1.5rem;">
                <button onclick="cerrarModalDNI()" style="padding:0.5rem 1.5rem; border:1.5px solid #dce5ec; border-radius:8px; background:white; color:#1b4f6e; font-weight:600; cursor:pointer; transition:0.3s;">
                    <i class="fas fa-times"></i> Cerrar
                </button>
            </div>
        </div>

    </div>
</div>

<!-- MODAL OBSERVACIÓN DE COBRO PARA EL COBRADOR -->
<div id="modalObsCobro" class="modal-overlay">
    <div class="modal-container" style="max-width: 500px;">
        <div class="modal-header" style="background: linear-gradient(135deg, #4f46e5, #6366f1);">
            <h3><i class="fas fa-clipboard-check"></i> Cargar Observación de Cobro</h3>
            <button class="close-modal" onclick="cerrarModalObsCobro()">&times;</button>
        </div>
        <div class="modal-body" style="padding: 1.5rem;">
            <form id="formObsCobro" onsubmit="guardarObservacionCobro(event)">
                <input type="hidden" id="obsCobroClienteId" name="id_cliente">
                <!-- Se fuerza pago_realizado a 0 (No pagó) -->
                <input type="hidden" name="pago_realizado" value="0">

                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="font-weight:600; color:#1e293b; display:block; margin-bottom:4px;">Cliente:</label>
                    <p id="obsCobroClienteNombre" style="font-weight:700; color:#4f46e5; font-size:1.05rem; margin:0;"></p>
                </div>

                <!-- NOTA EXPLICATIVA SOBRE EL ESTADO -->
                <div class="form-group" style="margin-bottom: 1.2rem;">
                    <div style="background:#fef2f2; border:1px solid #fecaca; padding:10px; border-radius:8px; text-align:center; font-weight:600; color:#991b1b;">
                        <i class="fas fa-times-circle" style="color:#dc2626; margin-right: 6px;"></i> Registro de No Pago / Deuda Pendiente
                    </div>
                </div>

                <!-- CAMPO DE TEXTO PARA LA OBSERVACIÓN -->
                <div class="form-group" style="margin-bottom: 1.2rem;">
                    <label style="font-weight:600; color:#1e293b; display:block; margin-bottom:6px;">Detalle / Motivo de No Pago:</label>
                    <textarea id="obsCobroTexto" name="observacion" rows="3" required
                        placeholder="Ej: Mencionó que pagará el día 15 / No se encontraba en el domicilio..."
                        style="width:100%; padding:0.7rem; border:1.5px solid #cbd5e1; border-radius:8px; font-size:0.9rem; font-family:inherit;"></textarea>
                </div>

                <button type="submit" id="btnGuardarObsCobro" class="btn-submit" style="background: linear-gradient(135deg, #4f46e5, #6366f1); color:white; width:100%; padding:0.8rem; border:none; border-radius:8px; font-weight:600; cursor:pointer;">
                    <i class="fas fa-save"></i> Guardar Observación
                </button>
            </form>
        </div>
    </div>
</div>

<script>
    const idRol = <?= (int)$id_rol ?>;
    const listaClientesGlobal = <?= json_encode($clientes) ?>;
</script>


</script>
<script src="../js/admin_cliente.js"></script>
</body>
</html>