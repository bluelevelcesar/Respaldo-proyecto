
// =============================================
// VARIABLES
// =============================================
let timeoutCodigo = null;

// =============================================
// TOAST NOTIFICACIONES
// =============================================
function mostrarToast(mensaje, tipo = 'success') {
    const old = document.querySelector('.toast');
    if (old) old.remove();

    const toast = document.createElement('div');
    toast.className = `toast ${tipo === 'error' ? 'toast-error' : ''}`;
    toast.innerHTML = `
        <div class="toast-title">${tipo === 'success' ? '✅ Éxito' : '❌ Error'}</div>
        <div class="toast-message">${mensaje}</div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

// =============================================
// VALIDACIONES EN TIEMPO REAL
// =============================================
function validarCampo(input, tipo) {
    if (!input) return;
    const valor = input.value.trim();
    if (tipo === 'texto') {
        if (valor.length > 0 && /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(valor)) {
            input.classList.remove('campo-invalido');
            input.classList.add('campo-valido');
        } else {
            input.classList.remove('campo-valido');
            if (valor.length > 0) input.classList.add('campo-invalido');
        }
    }
}

function validarDNI(input) {
    if (!input) return;
    const valor = input.value.trim();
    const error = document.getElementById('dniError');
    
    if (valor.length === 0) {
        input.classList.remove('campo-invalido', 'campo-valido');
        if (error) error.classList.remove('mostrar');
        return;
    }
    
    if (/^[0-9]{7,8}$/.test(valor)) {
        input.classList.remove('campo-invalido');
        input.classList.add('campo-valido');
        if (error) error.classList.remove('mostrar');
    } else {
        input.classList.remove('campo-valido');
        input.classList.add('campo-invalido');
        if (error) error.classList.add('mostrar');
    }
}

function validarTelefono(input) {
    if (!input) return;
    const valor = input.value.trim();
    const error = document.getElementById('telefonoError');
    
    if (valor.length === 0) {
        input.classList.remove('campo-invalido', 'campo-valido');
        if (error) error.classList.remove('mostrar');
        return;
    }
    
    if (/^[0-9]{7,15}$/.test(valor)) {
        input.classList.remove('campo-invalido');
        input.classList.add('campo-valido');
        if (error) error.classList.remove('mostrar');
    } else {
        input.classList.remove('campo-valido');
        input.classList.add('campo-invalido');
        if (error) error.classList.add('mostrar');
    }
}

function validarEmail(input) {
    if (!input) return;
    const valor = input.value.trim();
    const error = document.getElementById('emailError');
    
    if (valor.length === 0) {
        input.classList.remove('campo-invalido', 'campo-valido');
        if (error) error.classList.remove('mostrar');
        return;
    }
    
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(valor)) {
        input.classList.remove('campo-invalido');
        input.classList.add('campo-valido');
        if (error) error.classList.remove('mostrar');
    } else {
        input.classList.remove('campo-valido');
        input.classList.add('campo-invalido');
        if (error) error.classList.add('mostrar');
    }
}

// =============================================
// ACTUALIZAR CÓDIGO
// =============================================
function actualizarCodigo() {
    const nombre = document.getElementById('nombreCliente')?.value.trim() || '';
    const apellido = document.getElementById('apellidoCliente')?.value.trim() || '';
    const preview = document.getElementById('codigoPreview');
    const accion = document.getElementById('formAccion')?.value || '';
    
    if (accion === 'editar') return;
    if (!preview) return;
    
    if (!nombre || !apellido) {
        preview.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Escriba nombre y apellido';
        preview.className = 'codigo-generado codigo-loading';
        return;
    }
    
    preview.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generando...';
    preview.className = 'codigo-generado codigo-loading';
    
    if (timeoutCodigo) clearTimeout(timeoutCodigo);
    
    timeoutCodigo = setTimeout(() => {
        fetch(`?ajax=get_codigo&nombre=${encodeURIComponent(nombre)}&apellido=${encodeURIComponent(apellido)}`)
            .then(r => r.json())
            .then(data => {
                if (data.codigo) {
                    preview.innerHTML = `<i class="fas fa-tag"></i> ${data.codigo}`;
                    preview.className = 'codigo-generado';
                }
            })
            .catch(() => {
                preview.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Error';
                preview.className = 'codigo-generado codigo-loading';
            });
    }, 300);
}

function abrirModal(idModal = 'clienteModal') {
    if (idModal !== 'clienteModal') {
        const modalEspecifico = document.getElementById(idModal);
        if (modalEspecifico) modalEspecifico.classList.add('active');
        return;
    }

    const modal = document.getElementById('clienteModal');
    if (modal) modal.classList.add('active');
    
    const formAccion = document.getElementById('formAccion');
    if (formAccion) formAccion.value = 'registrar';
    
    const modalTitle = document.getElementById('modalTitle');
    if (modalTitle) modalTitle.innerHTML = '<i class="fas fa-user-plus"></i> Nuevo Cliente';
    
    const campos = ['clienteId', 'nombreCliente', 'apellidoCliente', 'dniCliente', 'emailCliente', 'telefonoCliente', 'observacionCliente'];
    campos.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
    
    const selects = ['barrioCliente', 'tipoServicioCliente'];
    selects.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
    
    const noLocal = document.getElementById('noLocal');
    if (noLocal) {
        noLocal.checked = false;
        const fotoContainer = document.getElementById('fotoDniContainer');
        if (fotoContainer) fotoContainer.classList.remove('mostrar');
        if (fotoContainer) {
            fotoContainer.classList.remove('mostrar');
            fotoContainer.style.display = 'none';
        }
    }
    
    const fotoDni = document.getElementById('fotoDni');
    if (fotoDni) fotoDni.value = '';
    if (fotoDni) {
        fotoDni.value = '';
        fotoDni.removeAttribute('required');
    }
    
    const fotoDniActual = document.getElementById('fotoDniActual');
    if (fotoDniActual) fotoDniActual.value = '';
    
    const previewExistente = document.getElementById('fotoDniPreview');
    if (previewExistente) previewExistente.remove();
    if (previewExistente) {
        previewExistente.innerHTML = '';
        previewExistente.style.display = 'none';
    }
    
    const labelFoto = document.querySelector('#fotoDniContainer .form-group label');
    if (labelFoto) {
        labelFoto.innerHTML = `<i class="fas fa-image"></i> Foto DNI`;
    }
    
    document.querySelectorAll('.campo-invalido, .campo-valido').forEach(el => {
        el.classList.remove('campo-invalido', 'campo-valido');
    });
    document.querySelectorAll('.mensaje-error').forEach(el => el.classList.remove('mostrar'));
    
    const preview = document.getElementById('codigoPreview');
    if (preview) {
        preview.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Escriba nombre y apellido';
        preview.className = 'codigo-generado codigo-loading';
    }
}

function cerrarModal(id = 'clienteModal') {
    const modal = document.getElementById(id);
    if (modal) modal.classList.remove('active');
    if (timeoutCodigo && id === 'clienteModal') clearTimeout(timeoutCodigo);
}

// =============================================
// MODAL BARRIO RÁPIDO
// =============================================
function abrirModalBarrio() {
    const modal = document.getElementById('barrioModal');
    if (modal) modal.classList.add('active');
    
    const nombre = document.getElementById('nombreBarrioRapido');
    if (nombre) nombre.value = '';
    
    setTimeout(() => {
        if (nombre) nombre.focus();
    }, 100);
}

function cerrarModalBarrio() {
    const modal = document.getElementById('barrioModal');
    if (modal) modal.classList.remove('active');
}

// =============================================
// FUNCIÓN PARA RECARGAR BARRIOS
// =============================================
async function cargarBarrios(seleccionarId = null) {
    try {
        const response = await fetch('?ajax=get_barrios');
        const data = await response.json();
        
        if (data.status === 'success') {
            const select = document.getElementById('barrioCliente');
            if (!select) return;
            
            select.innerHTML = '<option value="">-- Seleccionar --</option>';
            data.barrios.forEach(b => {
                const option = document.createElement('option');
                option.value = b.id_barrio;
                option.textContent = b.nombre;
                select.appendChild(option);
            });
            
            if (seleccionarId) {
                select.value = seleccionarId;
            }
        }
    } catch (error) {
        console.error('Error al cargar barrios:', error);
    }
}

// =============================================
// MOSTRAR/OCULTAR FOTO DNI
// =============================================
const noLocalEl = document.getElementById('noLocal');
if (noLocalEl) {
    noLocalEl.addEventListener('change', function() {
        const container = document.getElementById('fotoDniContainer');
        const fotoInput = document.getElementById('fotoDni');
        const fotoDniActual = document.getElementById('fotoDniActual');
        const preview = document.getElementById('fotoDniPreview');
        
        if (container) {
            if (this.checked) {
                container.classList.add('mostrar');
                // ✅ AGREGAR ESTO PARA QUE EL CAMPO DE FOTO SEA REQUERIDO SI ESTÁ MARCADO
                const fotoInput = document.getElementById('fotoDni');
                if (fotoInput) {
                container.style.display = 'block';
                // Si no tiene foto actual previa, marcar required
                if (fotoInput && (!fotoDniActual || !fotoDniActual.value)) {
                    fotoInput.setAttribute('required', 'required');
                }
            } else {
                container.classList.remove('mostrar');
                const fotoInput = document.getElementById('fotoDni');
                container.style.display = 'none';
                if (fotoInput) {
                    fotoInput.removeAttribute('required');
                    fotoInput.value = '';
                }
                if (preview) {
                    preview.innerHTML = '';
                    preview.style.display = 'none';
                }
            }
        }
    });
}

// =============================================
// VISTA PREVIA DE FOTO DNI (AL CARGAR ARCHIVO)
// =============================================
const fotoDniInput = document.getElementById('fotoDni');
if (fotoDniInput) {
    fotoDniInput.addEventListener('change', function() {
        let preview = document.getElementById('fotoDniPreview');
        const container = document.getElementById('fotoDniContainer');
        if (!preview && container) {
            preview = document.createElement('div');
            preview.id = 'fotoDniPreview';
            preview.style.marginTop = '8px';
            container.appendChild(preview);
        }
        
        const file = this.files && this.files[0];
        if (file) {
            if (!file.type.startsWith('image/')) {
                mostrarToast('Por favor, selecciona un archivo de imagen válido (JPG, PNG, WebP)', 'error');
                this.value = '';
                if (preview) {
                    preview.innerHTML = '';
                    preview.style.display = 'none';
                }
                return;
            }
            
            const reader = new FileReader();
            reader.onload = function(e) {
                if (preview) {
                    preview.style.display = 'block';
                    preview.style.cssText = 'margin-top: 10px; padding: 10px; background: #f0fdf4; border-radius: 8px; border: 1.5px dashed #86efac; animation: fadeIn 0.3s ease;';
                    const tamanoKB = (file.size / 1024).toFixed(1);
                    preview.innerHTML = `
                        <div style="text-align: center;">
                            <div style="margin-bottom: 6px; font-size: 0.75rem; color: #166534; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 6px;">
                                <i class="fas fa-check-circle" style="color:#10b981;"></i> Vista previa de la foto seleccionada
                            </div>
                            <img src="${e.target.result}" alt="Vista previa DNI" style="max-width: 100%; max-height: 180px; border-radius: 6px; object-fit: contain; border: 1px solid #bbf7d0; box-shadow: 0 2px 4px rgba(0,0,0,0.06); background: white;">
                            <div style="display: flex; align-items: center; justify-content: space-between; margin-top: 8px; padding-top: 6px; border-top: 1px solid #dcfce7;">
                                <span style="font-size: 0.75rem; color: #1e293b; max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${file.name}">
                                    <i class="fas fa-file-image" style="color: #64748b;"></i> ${file.name} <strong>(${tamanoKB} KB)</strong>
                                </span>
                                <button type="button" onclick="quitarFotoSeleccionada()" style="background: #fee2e2; border: 1px solid #fca5a5; color: #dc2626; padding: 4px 10px; border-radius: 6px; cursor: pointer; font-size: 0.72rem; font-weight: 600; display: flex; align-items: center; gap: 4px;">
                                    <i class="fas fa-times"></i> Quitar
                                </button>
                            </div>
                        </div>
                    `;
                }
            };
            reader.readAsDataURL(file);
        } else {
            quitarFotoSeleccionada();
        }
    });
}

function quitarFotoSeleccionada() {
    const fotoDni = document.getElementById('fotoDni');
    if (fotoDni) fotoDni.value = '';
    
    const preview = document.getElementById('fotoDniPreview');
    const fotoDniActual = document.getElementById('fotoDniActual');
    
    // Si en edición existe una foto previamente guardada, restaurar la vista de esa foto
    if (fotoDniActual && fotoDniActual.value && fotoDniActual.value !== '0' && fotoDniActual.value !== 'null') {
        if (preview) {
            preview.style.display = 'block';
            preview.style.cssText = 'margin-top: 10px; padding: 10px; background: #f8fafc; border-radius: 8px; border: 1px solid #cbd5e1;';
            preview.innerHTML = `
                <div style="text-align:center;">
                    <img src="../uploads/dni/${fotoDniActual.value}" alt="DNI" style="max-width:100%; max-height:160px; border-radius:6px; object-fit:contain; border:1px solid #e2e8f0; background:white;" onerror="this.parentElement.innerHTML='<span style=\\'color:#ef4444; font-size:0.8rem;\\'>No se pudo cargar la imagen</span>'">
                    <div style="display:flex; align-items:center; justify-content:space-between; margin-top:8px;">
                        <span style="font-size:0.75rem; color:#475569;"><i class="fas fa-check-circle" style="color:#10b981;"></i> Archivo actual: ${fotoDniActual.value}</span>
                        <button type="button" onclick="eliminarFotoDNI()" style="background:#fee2e2; border:1px solid #fca5a5; color:#dc2626; padding:4px 10px; border-radius:6px; cursor:pointer; font-size:0.72rem; font-weight:600;">
                            <i class="fas fa-trash"></i> Eliminar
                        </button>
                    </div>
                </div>
            `;
        }
    } else {
        if (preview) {
            preview.innerHTML = '';
            preview.style.display = 'none';
        }
    }
}


// =============================================
// REGISTRAR PAGO - MODIFICADO PARA GUARDAR FECHA ISO
// =============================================
async function registrarPago(id, fechaCobro) {
    const modal = document.getElementById('pagoModal');
    if (modal) modal.classList.add('active');
    
    const pagoClienteId = document.getElementById('pagoClienteId');
    if (pagoClienteId) pagoClienteId.value = id;
    
    fechaCobroActual = fechaCobro;
    
    try {
        const response = await fetch(`?ajax=get_cliente&id=${id}`);
        const data = await response.json();
        if (data.status === 'success') {
            const cliente = data.data;
            const nombreApellido = document.getElementById('pagoNombreApellido');
            if (nombreApellido) {
                nombreApellido.textContent = (cliente.nombre || '') + ' ' + (cliente.apellido || '');
            }
            const codigoCliente = document.getElementById('pagoCodigoCliente');
            if (codigoCliente) {
                codigoCliente.textContent = cliente.codigo_cliente || 'Sin código';
            }
        }
    } catch (error) {
        console.error('Error al obtener datos del cliente:', error);
        document.getElementById('pagoNombreApellido').textContent = 'Error al cargar';
        document.getElementById('pagoCodigoCliente').textContent = 'Error';
    }
    
    const fechaCobroDisplay = document.getElementById('pagoFechaCobro');
    if (fechaCobroDisplay && fechaCobro) {
        const fecha = new Date(fechaCobro + 'T00:00:00');
        fechaCobroDisplay.textContent = fecha.toLocaleDateString('es-AR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });
        // ✅ Guardar la fecha ISO en un atributo data
        fechaCobroDisplay.dataset.fechaISO = fechaCobro;
    }
    
    const montoDisplay = document.getElementById('pagoMontoDisplay');
    if (montoDisplay) montoDisplay.textContent = 'Cargando...';
    
    const fecha = document.getElementById('pagoFecha');
    if (fecha) fecha.value = new Date().toISOString().split('T')[0];
    
    try {
        const response = await fetch(`?ajax=get_precio&id_cliente=${id}`);
        const data = await response.json();
        if (data.precio && montoDisplay) {
            precioBase = data.precio;
            // ✅ Mostrar con 1 mes por defecto
            mesesSeleccionados = 1;
            document.getElementById('pagoCantidadMeses').value = 1;
            
            // ✅ Resaltar botón de 1 mes
            document.querySelectorAll('.btn-meses').forEach(btn => {
                btn.style.background = 'white';
                btn.style.color = '#1b4f6e';
                btn.style.borderColor = '#dbeafe';
                btn.style.boxShadow = 'none';
                btn.style.transform = 'scale(1)';
            });
            const btn1 = document.querySelector('.btn-meses[data-meses="1"]');
            if (btn1) {
                btn1.style.background = '#1b4f6e';
                btn1.style.color = 'white';
                btn1.style.borderColor = '#1b4f6e';
                btn1.style.boxShadow = '0 4px 12px rgba(27,79,110,0.3)';
                btn1.style.transform = 'scale(1.02)';
            }
            
            // ✅ ACTUALIZAR MONTO Y FECHAS
            actualizarMontoTotal();
            mostrarDetalleMeses();
        } else if (montoDisplay) {
            montoDisplay.textContent = 'Sin precio';
        }
    } catch {
        if (montoDisplay) montoDisplay.textContent = 'Error';
    }
}

// =============================================
// VARIABLES GLOBALES PARA EL CORTE
// =============================================
let clienteIdACortar = null;

// =============================================
// 1. ABRE EL MODAL DE ADVERTENCIA DE CORTE
// =============================================
function cortarServicio(id) {
    clienteIdACortar = id;
    const modal = document.getElementById('modalConfirmarCorte');
    if (modal) {
        modal.classList.add('active');
    }
}

// =============================================
// 2. CIERRA EL MODAL DE ADVERTENCIA
// =============================================
function cerrarModalConfirmarCorte() {
    const modal = document.getElementById('modalConfirmarCorte');
    if (modal) {
        modal.classList.remove('active');
    }
    clienteIdACortar = null;
}

// =============================================
// 3. EJECUTA EL CORTE DE FORMA ASÍNCRONA
// =============================================
async function ejecutarCorteServicio() {
    if (!clienteIdACortar) return;
    
    const btnEjecutar = document.getElementById('btnEjecutarCorte');
    if (btnEjecutar) {
        btnEjecutar.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Procesando...';
        btnEjecutar.disabled = true;
    }
    
    const formData = new FormData();
    formData.append('accion', 'cortar_servicio');
    formData.append('id', clienteIdACortar);
    formData.append('motivo', 'Falta de pago');
    formData.append('ajax', 1);
    
    try {
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData
        });
        const data = await response.json();
        
        if (data.status === 'success') {
            mostrarToast(data.message, 'success');
            cerrarModalConfirmarCorte();
            // Recargar la página limpiamente
            setTimeout(() => location.reload(), 1000);
        } else {
            mostrarToast(data.message || 'Error al cortar servicio', 'error');
            if (btnEjecutar) {
                btnEjecutar.innerHTML = '<i class="fas fa-check"></i> Sí, Cortar Servicio';
                btnEjecutar.disabled = false;
            }
        }
    } catch (error) {
        console.error('Error de conexión:', error);
        mostrarToast('Error de conexión', 'error');
        if (btnEjecutar) {
            btnEjecutar.innerHTML = '<i class="fas fa-check"></i> Sí, Cortar Servicio';
            btnEjecutar.disabled = false;
        }
    }
}

function abrirModalEliminar(id) {
    const modal = document.getElementById('eliminarModal');
    if (!modal) return;
    
    modal.classList.add('active');
    
    const clienteId = document.getElementById('eliminarClienteId');
    if (clienteId) clienteId.value = id;
    
    const motivo = document.getElementById('eliminarMotivo');
    if (motivo) motivo.value = '';
    
    const submitBtn = document.getElementById('eliminarBtnSubmit');
    
    // Resetear textos
    document.getElementById('eliminarTotalPagos').textContent = 'Cargando...';
    document.getElementById('eliminarTotalPagado').textContent = 'Cargando...';
    document.getElementById('eliminarMensajeRestriccion').textContent = 'Cargando información...';
    
    const deudasContainer = document.getElementById('eliminarDeudasContainer');
    const listaDeudasModal = document.getElementById('listaDeudasModal');
    if (deudasContainer) deudasContainer.style.display = 'none';

    fetch(`admin_cliente.php?ajax=get_cliente_detalle&id=${id}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                const cliente = data.data;
                
                document.getElementById('eliminarClienteNombre').textContent = 
                    (cliente.nombre || '') + ' ' + (cliente.apellido || '');
                document.getElementById('eliminarClienteCodigo').innerHTML = 
                    `<i class="fas fa-tag"></i> ${cliente.codigo_cliente || 'Sin código'}`;
                document.getElementById('eliminarClienteDni').textContent = cliente.dni || '-';
                document.getElementById('eliminarClienteTelefono').textContent = cliente.telefono || '-';
                document.getElementById('eliminarClienteBarrio').textContent = cliente.barrio_nombre || 'Sin barrio';
                
                document.getElementById('eliminarTotalPagos').textContent = 'Total pagos: ' + (cliente.total_pagos || 0);
                document.getElementById('eliminarTotalPagado').textContent = '$' + (parseFloat(cliente.precio_base) || 0).toLocaleString('es-AR');
                
                // ✅ VERIFICAR SI TIENE DEUDAS PENDIENTES
                let tieneDeudas = false;
                if (cliente.deudas_pendientes && cliente.deudas_pendientes.length > 0) {
                    tieneDeudas = true;
                    if (deudasContainer) deudasContainer.style.display = 'block';
                    
                    let htmlDeudas = '';
                    cliente.deudas_pendientes.forEach(d => {
                        htmlDeudas += `
                            <tr>
                                <td style="padding: 10px 12px; border-bottom: 1px solid #e5e7eb; color: #374151; font-size: 0.85rem;">
                                    ${d.nombre_mes} ${d.anio}
                                </td>
                                <td style="padding: 10px 12px; border-bottom: 1px solid #e5e7eb; text-align: right; color: #991b1b; font-weight: 600; font-size: 0.85rem;">
                                    $${parseFloat(d.monto).toLocaleString('es-AR')}
                                </td>
                            </tr>
                        `;
                    });
                    if (listaDeudasModal) listaDeudasModal.innerHTML = htmlDeudas;
                } else {
                    if (deudasContainer) deudasContainer.style.display = 'none';
                }

                // ✅ BLOQUEAR O PERMITIR SEGÚN LA DEUDA
                if (tieneDeudas) {
                    document.getElementById('eliminarMensajeRestriccion').innerHTML = `
                        <strong style="color: #991b1b;">Acción bloqueada:</strong> Este cliente posee <strong>deudas pendientes</strong>. 
                        Debe registrar el pago total de sus deudas antes de poder eliminarlo del sistema.
                    `;
                    if (submitBtn) {
                        submitBtn.disabled = true;
                        submitBtn.style.opacity = '0.5';
                        submitBtn.style.cursor = 'not-allowed';
                    }
                    if (motivo) motivo.disabled = true;
                } else {
                    document.getElementById('eliminarMensajeRestriccion').innerHTML = `
                        Esta acción es <strong>permanente</strong> e <strong>irreversible</strong>. 
                        El cliente quedará marcado como <strong>"Eliminado"</strong> en el sistema.
                    `;
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.style.opacity = '1';
                        submitBtn.style.cursor = 'pointer';
                    }
                    if (motivo) motivo.disabled = false;
                }

            } else {
                document.getElementById('eliminarMensajeRestriccion').textContent = 'Error al cargar información del cliente';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('eliminarMensajeRestriccion').textContent = 'Error de conexión';
        });
}
// =============================================
// CERRAR MODAL DE ELIMINACIÓN
// =============================================
function cerrarModalEliminar() {
    const modal = document.getElementById('eliminarModal');
    if (modal) modal.classList.remove('active');
}

// =============================================
// ELIMINAR CLIENTE - ABRE EL MODAL
// =============================================
function eliminarCliente(id) {
    abrirModalEliminar(id);
}

// =============================================
// PROCESAR FORMULARIO DE ELIMINACIÓN
// =============================================
document.addEventListener('DOMContentLoaded', function() {
    const formEliminar = document.getElementById('formEliminar');
    if (formEliminar) {
        formEliminar.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const submitBtn = document.getElementById('eliminarBtnSubmit');
            const originalText = submitBtn ? submitBtn.innerHTML : 'Eliminar';
            
            if (submitBtn) {
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Eliminando...';
                submitBtn.disabled = true;
                submitBtn.style.opacity = '0.5';
                submitBtn.style.pointerEvents = 'none';
            }
            
            try {
                const formData = new FormData(this);
                formData.append('ajax', 1);
                
                const response = await fetch(window.location.href, {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.status === 'success') {
                    mostrarToast(data.message || '✅ Cliente eliminado correctamente', 'success');
                    cerrarModalEliminar();
                    setTimeout(() => location.reload(), 1500);
                } else {
                    mostrarToast(data.message || 'Error al eliminar cliente', 'error');
                    if (submitBtn) {
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                        submitBtn.style.opacity = '1';
                        submitBtn.style.pointerEvents = 'auto';
                    }
                }
            } catch (error) {
                console.error('Error:', error);
                mostrarToast('Error de conexión', 'error');
                if (submitBtn) {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                    submitBtn.style.opacity = '1';
                    submitBtn.style.pointerEvents = 'auto';
                }
            }
        });
    }
});

// =============================================
// ACTUALIZAR FUNCIÓN ELIMINAR EN LA TABLA
// =============================================
// NOTA: Asegúrate de que los botones de eliminar en la tabla llamen a eliminarCliente(id)

async function editarCliente(id) {
    try {
        const response = await fetch(`?ajax=get_cliente&id=${id}`);
        const data = await response.json();
        
        if (data.status === 'error') {
            mostrarToast(data.message, 'error');
            return;
        }
        
        const cliente = data.data;
        
        abrirModal();
        
        const formAccion = document.getElementById('formAccion');
        if (formAccion) formAccion.value = 'editar';
        
        const modalTitle = document.getElementById('modalTitle');
        if (modalTitle) modalTitle.innerHTML = '<i class="fas fa-edit"></i> Editar Cliente';
        
        // ✅ CAMPOS DEL FORMULARIO
        const fields = {
            clienteId: cliente.id,
            nombreCliente: cliente.nombre || '',
            apellidoCliente: cliente.apellido || '',
            dniCliente: cliente.dni || '',
            emailCliente: cliente.email || '',
            telefonoCliente: cliente.telefono || '',
            fotoDniActual: cliente.foto_dni || '',
            observacionCliente: cliente.observacion || ''
        };
        
        Object.keys(fields).forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = fields[id];
        });
        
        // ✅ VALIDAR CAMPOS
        validarDNI(document.getElementById('dniCliente'));
        if (cliente.email) validarEmail(document.getElementById('emailCliente'));
        if (cliente.telefono) validarTelefono(document.getElementById('telefonoCliente'));
        
        // ✅ SELECTS
        const barrioSelect = document.getElementById('barrioCliente');
        if (barrioSelect) barrioSelect.value = cliente.id_barrio || '';
        
        const servicioSelect = document.getElementById('tipoServicioCliente');
        if (servicioSelect) servicioSelect.value = cliente.id_tipo || '';
        
        // ✅ CHECKBOX NO LOCAL
        const noLocal = document.getElementById('noLocal');
        if (noLocal) noLocal.checked = (cliente.no_local == 1);
        
        // ✅ MOSTRAR/OCULTAR CONTENEDOR DE FOTO DNI
        const fotoContainer = document.getElementById('fotoDniContainer');
        if (fotoContainer) {
            if (cliente.no_local == 1) {
                fotoContainer.classList.add('mostrar');
                fotoContainer.style.display = 'block';
            } else {
                fotoContainer.classList.remove('mostrar');
                fotoContainer.style.display = 'none';
            }
        }
        
        // ✅ INDICAR QUE YA HAY UNA IMAGEN SUBIDA
        const fotoDniInput = document.getElementById('fotoDni');
        if (fotoDniInput) {
            fotoDniInput.value = '';
            fotoDniInput.removeAttribute('required');
        }
        const fotoDniActual = document.getElementById('fotoDniActual');
        let previewContainer = document.getElementById('fotoDniPreview');
        if (!previewContainer && fotoContainer) {
            previewContainer = document.createElement('div');
            previewContainer.id = 'fotoDniPreview';
            fotoContainer.appendChild(previewContainer);
        }
        
        if (cliente.foto_dni && cliente.foto_dni !== '' && cliente.foto_dni !== '0' && cliente.foto_dni !== 'null') {
            // Hay una imagen guardada
            if (fotoDniActual) fotoDniActual.value = cliente.foto_dni;
            
            // ✅ MOSTRAR NOMBRE DE LA IMAGEN ACTUAL
            const labelFoto = document.querySelector('#fotoDniContainer .form-group label');
            if (labelFoto) {
                labelFoto.innerHTML = `<i class="fas fa-image"></i> Foto DNI <span style="color:#10b981; font-weight:400; font-size:0.7rem;">(✅ Archivo actual: ${cliente.foto_dni})</span>`;
                labelFoto.innerHTML = `<i class="fas fa-image"></i> Foto DNI <span style="color:#10b981; font-weight:400; font-size:0.7rem;">(✅ Archivo actual)</span>`;
            }
            
            // ✅ CREAR VISTA PREVIA DE LA IMAGEN
            const previewContainer = document.createElement('div');
            previewContainer.id = 'fotoDniPreview';
            previewContainer.style.cssText = 'margin-top: 8px; padding: 8px; background: #f0fdf4; border-radius: 8px; border: 1px solid #bbf7d0;';
            previewContainer.innerHTML = `
                <div style="display:flex; align-items:center; gap:12px;">
                    <i class="fas fa-check-circle" style="color:#10b981;"></i>
                    <span style="font-size:0.8rem; color:#0f2b3d;">Imagen cargada: <strong>${cliente.foto_dni}</strong></span>
                    <button type="button" onclick="eliminarFotoDNI()" style="margin-left:auto; background:#fee2e2; border:1px solid #fca5a5; color:#dc2626; padding:4px 12px; border-radius:6px; cursor:pointer; font-size:0.7rem; font-weight:600;">
                        <i class="fas fa-trash"></i> Eliminar
                    </button>
                </div>
            `;
            
            // Remover preview anterior si existe
            const previewExistente = document.getElementById('fotoDniPreview');
            if (previewExistente) previewExistente.remove();
            
            fotoContainer.appendChild(previewContainer);
            if (previewContainer) {
                previewContainer.style.display = 'block';
                previewContainer.style.cssText = 'margin-top: 10px; padding: 10px; background: #f8fafc; border-radius: 8px; border: 1px solid #cbd5e1;';
                previewContainer.innerHTML = `
                    <div style="text-align:center;">
                        <img src="../uploads/dni/${cliente.foto_dni}" alt="DNI" style="max-width:100%; max-height:160px; border-radius:6px; object-fit:contain; border:1px solid #e2e8f0; background:white;" onerror="this.parentElement.innerHTML='<span style=\\'color:#ef4444; font-size:0.8rem;\\'>No se pudo cargar la imagen</span>'">
                        <div style="display:flex; align-items:center; justify-content:space-between; margin-top:8px;">
                            <span style="font-size:0.75rem; color:#475569;"><i class="fas fa-check-circle" style="color:#10b981;"></i> Archivo actual: ${cliente.foto_dni}</span>
                            <button type="button" onclick="eliminarFotoDNI()" style="background:#fee2e2; border:1px solid #fca5a5; color:#dc2626; padding:4px 10px; border-radius:6px; cursor:pointer; font-size:0.72rem; font-weight:600;">
                                <i class="fas fa-trash"></i> Eliminar
                            </button>
                        </div>
                    </div>
                `;
            }
        } else {
            if (fotoDniActual) fotoDniActual.value = '';
            if (previewContainer) {
                previewContainer.innerHTML = '';
                previewContainer.style.display = 'none';
            }
            const labelFoto = document.querySelector('#fotoDniContainer .form-group label');
            if (labelFoto) {
                labelFoto.innerHTML = `<i class="fas fa-image"></i> Foto DNI`;
            }
        }
        
        // ✅ CÓDIGO PREVIEW
        const preview = document.getElementById('codigoPreview');
        if (preview) {
            preview.innerHTML = `<i class="fas fa-tag"></i> ${cliente.codigo_cliente || 'Sin código'}`;
            preview.className = 'codigo-generado';
            preview.style.background = '#f1f5f9';
            preview.style.color = '#64748b';
            preview.style.borderColor = '#d1d5db';
            preview.style.cursor = 'default';
        }
        
    } catch (error) {
        console.error('Error:', error);
        mostrarToast('Error al cargar los datos del cliente', 'error');
    }
}

// =============================================
// FORMULARIO REGISTRO - CON MANEJO DE CLIENTE ELIMINADO
// =============================================
const formCliente = document.getElementById('formCliente');
if (formCliente) {
    formCliente.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const submitBtn = this.querySelector('.btn-submit');
        const originalText = submitBtn ? submitBtn.innerHTML : 'Guardar';
        if (submitBtn) {
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verificando...';
            submitBtn.disabled = true;
        }
        
        try {
            const formData = new FormData(this);
            formData.append('ajax', 1);
            
            const response = await fetch(window.location.href, {
                method: 'POST',
                body: formData
            });
            
            const text = await response.text();
            
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                console.error('Respuesta no JSON:', text);
                mostrarToast('Error: El servidor no devolvió JSON válido', 'error');
                if (submitBtn) {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }
                return;
            }
            
            // =============================================
            // ✅ MANEJAR CLIENTE ELIMINADO CON DEUDA
            // =============================================
            if (data.status === 'cliente_eliminado_con_deuda') {
                mostrarModalClienteEliminadoConDeuda(data);
                if (submitBtn) {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }
                return;
            }
            
            if (data.status === 'success') {
                mostrarToast(data.message, 'success');
                cerrarModal('clienteModal');
                setTimeout(() => location.reload(), 1500);
            } else {
                mostrarToast(data.message, 'error');
                if (submitBtn) {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }
            }
        } catch (error) {
            console.error('Error:', error);
            mostrarToast('Error de conexión: ' + error.message, 'error');
            if (submitBtn) {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }
        }
    });
}

// =============================================
// MOSTRAR MODAL DE CLIENTE ELIMINADO CON DEUDA
// =============================================
function mostrarModalClienteEliminadoConDeuda(data) {
    const info = data.data;
    
    // Formatear fecha
    const fechaEliminacion = info.fecha_eliminacion 
        ? new Date(info.fecha_eliminacion).toLocaleDateString('es-AR', {
            day: '2-digit',
            month: 'long',
            year: 'numeric'
        })
        : 'No registrada';
    
    // Construir filas de deudas
    const filasDeudas = info.deudas_detalle.map(deuda => `
        <tr>
            <td style="padding: 10px 12px; border-bottom: 1px solid #e5e7eb; color: #374151; font-size: 0.85rem;">
                ${deuda.nombre_mes} ${deuda.anio}
            </td>
            <td style="padding: 10px 12px; border-bottom: 1px solid #e5e7eb; text-align: right; color: #374151; font-weight: 600; font-size: 0.85rem;">
                $${deuda.monto.toLocaleString('es-AR')}
            </td>
        </tr>
    `).join('');
    
    const modalHTML = `
        <div id="modalClienteEliminado" class="modal-overlay active">
            <div class="modal-container modal-formal" style="max-width: 640px;">
                <div class="modal-header modal-header-formal">
                    <h3><i class="fas fa-user-slash"></i> Cliente Eliminado</h3>
                    <button class="close-modal" onclick="cerrarModalClienteEliminado()">&times;</button>
                </div>
                <div class="modal-body modal-body-formal">
                    
                    <!-- ALERTA PRINCIPAL -->
                    <div class="alerta-formal alerta-warning">
                        <div class="alerta-icono">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div class="alerta-contenido">
                            <h4>Registro previamente eliminado</h4>
                            <p>
                                El DNI ingresado corresponde a un cliente que fue dado de baja del sistema. 
                                No es posible registrar un nuevo cliente con estos datos hasta regularizar su situación.
                            </p>
                        </div>
                    </div>
                    
                    <!-- DATOS DEL CLIENTE -->
                    <div class="seccion-formal">
                        <h5 class="seccion-titulo">
                            <i class="fas fa-user"></i> Información del Cliente
                        </h5>
                        <div class="grid-datos">
                            <div class="dato-item">
                                <span class="dato-label">Nombre completo</span>
                                <span class="dato-valor">${info.nombre} ${info.apellido}</span>
                            </div>
                            <div class="dato-item">
                                <span class="dato-label">Código de cliente</span>
                                <span class="dato-valor">${info.codigo_cliente}</span>
                            </div>
                            <div class="dato-item">
                                <span class="dato-label">Fecha de eliminación</span>
                                <span class="dato-valor">${fechaEliminacion}</span>
                            </div>
                            <div class="dato-item">
                                <span class="dato-label">Motivo de eliminación</span>
                                <span class="dato-valor">${info.motivo_eliminacion || 'No especificado'}</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- DEUDA PENDIENTE -->
                    <div class="seccion-formal seccion-deuda">
                        <h5 class="seccion-titulo seccion-titulo-deuda">
                            <i class="fas fa-file-invoice-dollar"></i> Deuda Pendiente
                        </h5>
                        
                        <div class="resumen-deuda">
                            <div class="resumen-item">
                                <span class="resumen-label">Períodos adeudados</span>
                                <span class="resumen-valor">${info.meses_deuda} mes(es)</span>
                            </div>
                            <div class="resumen-item resumen-total">
                                <span class="resumen-label">Total a pagar</span>
                                <span class="resumen-valor-total">$${info.deuda_total.toLocaleString('es-AR')}</span>
                            </div>
                        </div>
                        
                        <div class="tabla-deudas-wrapper">
                            <table class="tabla-deudas">
                                <thead>
                                    <tr>
                                        <th>Período</th>
                                        <th style="text-align: right;">Monto</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${filasDeudas}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <!-- INSTRUCCIONES -->
                    <div class="seccion-formal seccion-info">
                        <h5 class="seccion-titulo">
                            <i class="fas fa-info-circle"></i> Acción Requerida
                        </h5>
                        <p class="texto-instruccion">
                            Para reactivar a este cliente en el sistema, es necesario registrar el pago 
                            de la deuda pendiente. Una vez abonada, el cliente podrá ser registrado nuevamente 
                            con normalidad.
                        </p>
                    </div>
                    
                    <!-- BOTONES -->
                    <div class="modal-acciones">
                        <button type="button" class="btn-formal btn-formal-secondary" onclick="cerrarModalClienteEliminado()">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                        <button type="button" class="btn-formal btn-formal-primary" onclick="abrirPagoParaClienteEliminado(${info.id_cliente})">
                            <i class="fas fa-credit-card"></i> Registrar Pago
                        </button>
                    </div>
                    
                </div>
            </div>
        </div>
    `;
    
    const modalAnterior = document.getElementById('modalClienteEliminado');
    if (modalAnterior) modalAnterior.remove();
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    cerrarModal('clienteModal');

    // Cerrar modal de cliente
    cerrarModal('clienteModal');
}

// =============================================
// CERRAR MODAL DE CLIENTE ELIMINADO
// =============================================
function cerrarModalClienteEliminado() {
    const modal = document.getElementById('modalClienteEliminado');
    if (modal) modal.remove();
}

// =============================================
// ABRIR PAGO PARA CLIENTE ELIMINADO
// =============================================
function abrirPagoParaClienteEliminado(idCliente) {
    cerrarModalClienteEliminado();
    
    // Primero reactivar el cliente (solo para poder registrar el pago)
    const formData = new FormData();
    formData.append('accion', 'reactivar_para_pago');
    formData.append('id', idCliente);
    formData.append('ajax', 1);
    
    fetch(window.location.href, { method: 'POST', body: formData })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Abrir modal de pago
                const fechaCobro = new Date().toISOString().split('T')[0];
                registrarPago(idCliente, fechaCobro);
            } else {
                mostrarToast(data.message || 'Error al reactivar cliente', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            mostrarToast('Error de conexión', 'error');
        });
}

// =============================================
// FORMULARIO PAGO - CON ACTUALIZACIÓN DE BOTONES
// =============================================
const formPago = document.getElementById('formPago');
if (formPago) {
    formPago.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const submitBtn = this.querySelector('.btn-submit');
        if (submitBtn) {
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Registrando...';
            submitBtn.disabled = true;
        }
        
        try {
            const formData = new FormData(this);
            formData.append('ajax', 1);
            
            const response = await fetch(window.location.href, { method: 'POST', body: formData });
            const data = await response.json();
            
            console.log('Respuesta del servidor:', data); // ✅ PARA DEBUG
            
            if (data.status === 'success') {
                let mensaje = data.message || 'Pago registrado correctamente';
                if (data.primer_pago) {
                    mensaje += ' Se notificó al técnico para la conexión.';
                }
                mostrarToast(mensaje, 'success');
                
                // ✅ OBTENER EL ID DEL CLIENTE CORRECTAMENTE
                const clienteId = data.id_cliente || document.getElementById('pagoClienteId').value;
                console.log('ID del cliente a actualizar:', clienteId); // ✅ PARA DEBUG
                
               // =============================================
// ACTUALIZAR BOTONES EN LA TABLA
// =============================================
if (clienteId) {
    actualizarBotonesDespuesDePagar(
        clienteId,
        data.fecha_proximo_pago || null
    );
}
                cerrarPagoModal();
                
                // Recargar después de 2 segundos para sincronizar todo
                setTimeout(() => location.reload(), 2000);
            } else {
                mostrarToast(data.message || 'Error al registrar pago', 'error');
                if (submitBtn) {
                    submitBtn.innerHTML = '<i class="fas fa-check-circle"></i> Registrar Pago';
                    submitBtn.disabled = false;
                }
            }
        } catch (error) {
            console.error('Error de conexión:', error);
            mostrarToast('Error de conexión', 'error');
            if (submitBtn) {
                submitBtn.innerHTML = '<i class="fas fa-check-circle"></i> Registrar Pago';
                submitBtn.disabled = false;
            }
        }
    });
}
// =============================================
// CERRAR MODAL DE PAGO
// =============================================
function cerrarPagoModal() {
    const modal = document.getElementById('pagoModal');
    if (modal) modal.classList.remove('active');
}

function abrirModalObsCobro(idCliente, nombreCliente) {
    const modal = document.getElementById('modalObsCobro');
    if (!modal) return;

    document.getElementById('obsCobroClienteId').value = idCliente;
    document.getElementById('obsCobroClienteNombre').textContent = nombreCliente;
    document.getElementById('obsCobroTexto').value = '';

    modal.classList.add('active');
}

function cerrarModalObsCobro() {
    const modal = document.getElementById('modalObsCobro');
    if (modal) modal.classList.remove('active');
}

async function guardarObservacionCobro(e) {
    e.preventDefault();

    const btn = document.getElementById('btnGuardarObsCobro');
    const textoOriginal = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Guardando...';
    btn.disabled = true;

    const form = document.getElementById('formObsCobro');
    const formData = new FormData(form);
    formData.append('accion', 'guardar_observacion_cobro');
    formData.append('ajax', '1');

    try {
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.status === 'success') {
            mostrarToast(data.message, 'success');
            cerrarModalObsCobro();

            // Actualizar métrica de no pagaron
            const elNoPagaron = document.getElementById('cobradorClientesNoPagaron');
            if (elNoPagaron) {
                let actual = parseInt(elNoPagaron.textContent) || 0;
                elNoPagaron.textContent = actual + 1;
            }
        } else {
            mostrarToast(data.message || 'Error al guardar la observación', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        mostrarToast('Error de conexión con el servidor', 'error');
    } finally {
        btn.innerHTML = textoOriginal;
        btn.disabled = false;
    }
}

// =============================================
// REACTIVAR SERVICIO (SOLO PARA SUSPENDIDOS)
// =============================================
async function reactivarServicio(id) {
    if (!confirm('¿Deseas reactivar el servicio de este cliente? El cliente quedará como "Pendiente" y podrá realizar un pago.')) return;
    
    const formData = new FormData();
    formData.append('accion', 'reactivar_servicio');
    formData.append('id', id);
    formData.append('ajax', 1);
    
    try {
        const response = await fetch(window.location.href, { method: 'POST', body: formData });
        const data = await response.json();
        
        if (data.status === 'success') {
            mostrarToast(data.message, 'success');
            // Recargar la página limpiamente para mostrar los botones correctos
            setTimeout(() => location.reload(), 1000);
        } else {
            mostrarToast(data.message || 'Error al reactivar servicio', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        mostrarToast('Error de conexión', 'error');
    }
}

// =============================================
// ACTUALIZAR BOTONES DESPUÉS DE REACTIVAR
// =============================================
function actualizarBotonesDespuesDeReactivar(clienteId) {
    console.log('🔥 ACTUALIZANDO BOTONES DESPUÉS DE REACTIVAR - Cliente ID:', clienteId);
    
    const fila = document.querySelector(`tr[data-cliente-id="${clienteId}"]`);
    if (!fila) {
        console.warn('❌ Fila NO encontrada para cliente:', clienteId);
        return;
    }
    
    console.log('✅ Fila encontrada:', fila);
    
    const accionesCell = fila.querySelector('td:last-child');
    if (!accionesCell) {
        console.warn('❌ Celda de acciones no encontrada');
        return;
    }
    
    // ✅ 1. ELIMINAR EL BOTÓN DE REACTIVAR
    const btnReactivar = accionesCell.querySelector('.btn-reactivar');
    if (btnReactivar) {
        btnReactivar.remove();
        console.log('✅ Botón Reactivar eliminado');
    }
    
    // ✅ 2. ELIMINAR EL SPAN DE "SUSPENDIDO"
    const spansSuspendido = accionesCell.querySelectorAll('span[style*="background:#e2e8f0"]');
    spansSuspendido.forEach(span => span.remove());
    
    // ✅ 3. ACTUALIZAR EL BADGE DE ESTADO A "PENDIENTE"
    const estadoBadge = fila.querySelector('.badge.badge-suspendido');
    if (estadoBadge) {
        estadoBadge.className = 'badge badge-pendiente';
        estadoBadge.innerHTML = '<i class="fas fa-clock"></i> Pendiente';
        console.log('✅ Badge actualizado a Pendiente');
    }
    
    // ✅ 4. ACTUALIZAR EL DATASET DE LA FILA
    fila.dataset.estadoPago = 'pendiente';
    
    // ✅ 5. AGREGAR EL BOTÓN DE PAGO
    const btnPagoExistente = accionesCell.querySelector('.btn-pago');
    if (!btnPagoExistente) {
        const nuevoBtnPago = document.createElement('button');
        nuevoBtnPago.className = 'btn-pago';
        nuevoBtnPago.innerHTML = '<i class="fas fa-coins"></i> Pagar';
        nuevoBtnPago.onclick = function() {
            const fechaCobroDiv = fila.querySelector('td:nth-child(8) div');
            let fechaCobro = '';
            if (fechaCobroDiv) {
                const texto = fechaCobroDiv.textContent;
                const match = texto.match(/(\d{2}\/\d{2}\/\d{4})/);
                if (match) {
                    const partes = match[1].split('/');
                    fechaCobro = `${partes[2]}-${partes[1]}-${partes[0]}`;
                }
            }
            registrarPago(clienteId, fechaCobro);
        };
        accionesCell.appendChild(nuevoBtnPago);
        console.log('✅ Botón Pagar agregado');
    }
    
    // ✅ 6. ACTUALIZAR LA FECHA DE COBRO
    const fechaCobroDiv = fila.querySelector('td:nth-child(8) div');
    if (fechaCobroDiv) {
        const textoActual = fechaCobroDiv.textContent;
        const match = textoActual.match(/(\d{2}\/\d{2}\/\d{4})/);
        if (match) {
            fechaCobroDiv.innerHTML = `Cobro: ${match[1]} <span style="color:#f59e0b; font-weight:600;">(Pendiente)</span>`;
        }
    }
    
    console.log('✅ ACTUALIZACIÓN COMPLETA para cliente:', clienteId);
}
// =============================================
// FORMULARIO BARRIO RÁPIDO
// =============================================
document.addEventListener('DOMContentLoaded', function() {
    const formBarrioRapido = document.getElementById('formBarrioRapido');
    if (formBarrioRapido) {
        formBarrioRapido.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const submitBtn = this.querySelector('.btn-submit');
            const originalText = submitBtn ? submitBtn.innerHTML : 'Guardar';
            if (submitBtn) {
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Guardando...';
                submitBtn.disabled = true;
            }
            
            try {
                const formData = new FormData(this);
                formData.append('ajax', 1);
                
                const response = await fetch(window.location.href, {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                console.log('Respuesta:', data);
                
                if (data.status === 'success') {
                    mostrarToast('✅ Barrio creado correctamente', 'success');
                    cerrarModalBarrio();
                    
                    await cargarBarrios(data.id);
                    
                    if (submitBtn) {
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                    }
                } else {
                    mostrarToast(data.message || 'Error al crear barrio', 'error');
                    if (submitBtn) {
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                    }
                }
            } catch (error) {
                console.error('Error:', error);
                mostrarToast('Error de conexión', 'error');
                if (submitBtn) {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }
            }
        });
    }
});

// =============================================
// FILTROS MÚLTIPLES
// =============================================
const searchInput = document.getElementById('searchInput');
const filterEstado = document.getElementById('filterEstado');
const filterBarrio = document.getElementById('filterBarrio');
const filterServicio = document.getElementById('filterServicio');
const resultCount = document.getElementById('resultCount');

// Eventos de filtro
if (searchInput) {
    searchInput.addEventListener('input', filtrarTabla);
}

if (filterEstado) {
    filterEstado.addEventListener('change', filtrarTabla);
}

if (filterBarrio) {
    filterBarrio.addEventListener('change', filtrarTabla);
}

if (filterServicio) {
    filterServicio.addEventListener('change', filtrarTabla);
}

function filtrarTabla() {
    const searchTerm = document.getElementById('searchInput')?.value.toLowerCase() || '';
    const estadoFiltro = document.getElementById('filterEstado')?.value || 'todos';
    const barrioFiltro = document.getElementById('filterBarrio')?.value || 'todos';
    const servicioFiltro = document.getElementById('filterServicio')?.value || 'todos';
    const rows = document.querySelectorAll('#clientesTableBody tr');
    
    // Verificar si hay fila de "No hay clientes"
    if (rows.length === 1 && rows[0].cells.length === 1) {
        return;
    }
    
    let visibleCount = 0;
    
    rows.forEach(row => {
        // Obtener datos de las celdas
        const codigo = row.cells[0]?.textContent.toLowerCase() || '';
        const nombre = row.cells[1]?.textContent.toLowerCase() || '';
        const apellido = row.cells[2]?.textContent.toLowerCase() || '';
        const dni = row.cells[3]?.textContent.toLowerCase() || '';
        const barrio = row.cells[5]?.textContent.toLowerCase() || '';
        const servicio = row.cells[6]?.textContent.toLowerCase() || '';
        const estado = row.dataset.estadoPago || '';
        
        // Buscar el ID del barrio en el dataset (lo agregamos en el PHP)
        const barrioId = row.dataset.barrioId || '';
        const servicioId = row.dataset.servicioId || '';
        
        // Coincidencia por texto
        const matchSearch = codigo.includes(searchTerm) || 
                           nombre.includes(searchTerm) || 
                           apellido.includes(searchTerm) || 
                           dni.includes(searchTerm);
        
        // Coincidencia por estado
        const matchEstado = estadoFiltro === 'todos' || estado === estadoFiltro;
        
        // Coincidencia por barrio
        const matchBarrio = barrioFiltro === 'todos' || barrioId === barrioFiltro;
        
        // Coincidencia por servicio
        const matchServicio = servicioFiltro === 'todos' || servicioId === servicioFiltro;
        
        const mostrar = matchSearch && matchEstado && matchBarrio && matchServicio;
        
        row.style.display = mostrar ? '' : 'none';
        if (mostrar) visibleCount++;
    });
    
    // Actualizar contador
    if (resultCount) {
        resultCount.textContent = visibleCount;
    }
}

// =============================================
// LIMPIAR FILTROS
// =============================================
function limpiarFiltros() {
    const searchInput = document.getElementById('searchInput');
    const filterEstado = document.getElementById('filterEstado');
    const filterBarrio = document.getElementById('filterBarrio');
    const filterServicio = document.getElementById('filterServicio');
    
    if (searchInput) searchInput.value = '';
    if (filterEstado) filterEstado.value = 'todos';
    if (filterBarrio) filterBarrio.value = 'todos';
    if (filterServicio) filterServicio.value = 'todos';
    
    filtrarTabla();
}
// =============================================
// CERRAR MODALES CON ESC
// =============================================
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        cerrarModal();
        cerrarPagoModal();
      
        cerrarModalBarrio();
    }
});

document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            this.classList.remove('active');
        }
    });
});


function cerrarModalDetalleCliente() {
    document.getElementById('modalDetalleCliente').classList.remove('active');
}

function verDetalleCliente(id) {
    // Mostrar modal con carga
    document.getElementById('modalDetalleCliente').classList.add('active');
    document.getElementById('detalleClienteContenido').innerHTML = `
        <div style="text-align:center; padding:2rem; color:#94a3b8;">
            <i class="fas fa-spinner fa-spin" style="font-size:2rem;"></i>
            <p>Cargando detalles del cliente...</p>
        </div>
    `;
    
    // Obtener datos via AJAX
    fetch(`admin_cliente.php?ajax=get_cliente_detalle&id=${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.text();
        })
        .then(text => {
            console.log('Respuesta del servidor:', text);
            
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                throw new Error('La respuesta no es JSON válido: ' + text.substring(0, 200));
            }
            
            if (data.status === 'success') {
                mostrarDetallesCliente(data.data);
            } else {
                document.getElementById('detalleClienteContenido').innerHTML = `
                    <div style="text-align:center; padding:2rem; color:#ef4444;">
                        <i class="fas fa-exclamation-triangle" style="font-size:2rem;"></i>
                        <p>${data.message || 'Error al cargar los detalles'}</p>
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error completo:', error);
            document.getElementById('detalleClienteContenido').innerHTML = `
                <div style="text-align:center; padding:2rem; color:#ef4444;">
                    <i class="fas fa-circle-exclamation" style="font-size:2rem;"></i>
                    <p>Error: ${error.message}</p>
                    <p style="font-size:0.7rem; color:#94a3b8; margin-top:8px;">
                        Revisa la consola para más detalles (F12)
                    </p>
                </div>
            `;
        });
}
// =============================================
// FUNCIÓN PARA CERRAR MODAL CON VALIDACIÓN
// =============================================
function cerrarModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.remove('active');
    } else {
        console.warn('Modal no encontrado:', id);
    }
}

function verDetalleCliente(id) {
    // ✅ VALIDAR QUE EL MODAL EXISTA
    const modal = document.getElementById('modalDetalleCliente');
    if (!modal) {
        console.error('Modal no encontrado: modalDetalleCliente');
        return;
    }
    
    // Mostrar modal con carga
    modal.classList.add('active');
    
    const contenido = document.getElementById('detalleClienteContenido');
    if (!contenido) {
        console.error('Contenido no encontrado: detalleClienteContenido');
        return;
    }
    
    contenido.innerHTML = `
        <div style="text-align:center; padding:2rem; color:#94a3b8;">
            <i class="fas fa-spinner fa-spin" style="font-size:2rem;"></i>
            <p>Cargando detalles del cliente...</p>
        </div>
    `;
    
    // Obtener datos via AJAX
    fetch(`admin_cliente.php?ajax=get_cliente_detalle&id=${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.text();
        })
        .then(text => {
            console.log('Respuesta del servidor:', text);
            
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                throw new Error('La respuesta no es JSON válido: ' + text.substring(0, 200));
            }
            
            if (data.status === 'success') {
                mostrarDetallesCliente(data.data);
            } else {
                const contenidoEl = document.getElementById('detalleClienteContenido');
                if (contenidoEl) {
                    contenidoEl.innerHTML = `
                        <div style="text-align:center; padding:2rem; color:#ef4444;">
                            <i class="fas fa-exclamation-triangle" style="font-size:2rem;"></i>
                            <p>${data.message || 'Error al cargar los detalles'}</p>
                        </div>
                    `;
                }
            }
        })
        .catch(error => {
            console.error('Error completo:', error);
            const contenidoEl = document.getElementById('detalleClienteContenido');
            if (contenidoEl) {
                contenidoEl.innerHTML = `
                    <div style="text-align:center; padding:2rem; color:#ef4444;">
                        <i class="fas fa-circle-exclamation" style="font-size:2rem;"></i>
                        <p>Error: ${error.message}</p>
                        <p style="font-size:0.7rem; color:#94a3b8; margin-top:8px;">
                            Revisa la consola para más detalles (F12)
                        </p>
                    </div>
                `;
            }
        });
}

function mostrarDetallesCliente(c) {
    const estadoClases = {
        'Activo': 'activo',
        'Inactivo': 'inactivo'
    };
    const estadoPagoClases = {
        'Al día': 'al_dia',
        'pagado': 'al_dia',
        'Pendiente': 'pendiente',
        'pendiente': 'pendiente',
        'Mora': 'mora',
        'mora': 'mora',
        'Suspendido': 'suspendido',
        'suspendido': 'suspendido'
    };
    const estadoPagoEtiquetas = {
        'Al día': 'Al día',
        'pagado': 'Al día',
        'Pendiente': 'Pendiente',
        'pendiente': 'Pendiente',
        'Mora': 'En mora',
        'mora': 'En mora',
        'Suspendido': 'Suspendido',
        'suspendido': 'Suspendido'
    };
    const estadoPagoIconos = {
        'Al día': 'fa-check-circle',
        'pagado': 'fa-check-circle',
        'Pendiente': 'fa-clock',
        'pendiente': 'fa-clock',
        'Mora': 'fa-exclamation-triangle',
        'mora': 'fa-exclamation-triangle',
        'Suspendido': 'fa-pause-circle',
        'suspendido': 'fa-pause-circle'
    };
    
    const estadoPago = c.estado_pago || 'Pendiente';
    
    // ✅ VERIFICACIÓN FLEXIBLE: Acepta no_local como 1 o "1"
    const esNoLocal = (c.no_local == 1 || c.no_local === '1' || c.no_local === true);
    
    // ✅ VERIFICAR SI TIENE FOTO VÁLIDA
    const fotoValida = c.foto_dni && c.foto_dni !== '' && c.foto_dni !== '0' && c.foto_dni !== 'null' && c.foto_dni !== null;
    
    // Si tiene foto y no es del lugar (o simplemente si ya tiene la foto adjunta), mostrar botón
    const tieneFotoDNI = esNoLocal && fotoValida;

    const contenido = document.getElementById('detalleClienteContenido');
    if (!contenido) return;
    
    // ✅ CONSTRUIR OBSERVACIONES POR SEPARADO
    let htmlObservacion = '';
    if (c.observacion && c.observacion !== '' && c.observacion !== 'null') {
        htmlObservacion = `
        <div style="margin-top:1.5rem; background:#fef3c7; padding:1rem; border-radius:10px; border:1px solid #fde68a;">
            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                <i class="fas fa-comment" style="color:#1b4f6e;"></i> Observación
            </label>
            <p style="color:#1f2b48; font-size:0.85rem; margin:0;">
                <i class="fas fa-quote-left" style="color:#f59e0b; margin-right:6px;"></i>
                ${c.observacion}
            </p>
        </div>
        `;
    }
    
    // ✅ CONSTRUIR OBSERVACIONES DE PAGO POR SEPARADO
    let htmlObservacionPago = '';
    if (c.observacion_pago && c.observacion_pago !== '' && c.observacion_pago !== 'null') {
        htmlObservacionPago = `
        <div style="margin-top:1.5rem; background:#fef3c7; padding:1rem; border-radius:10px; border:1px solid #fde68a;">
            <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                <i class="fas fa-comment" style="color:#1b4f6e;"></i> Observaciones de Pago
            </label>
            <p style="color:#1f2b48; font-size:0.85rem; margin:0;">
                <i class="fas fa-quote-left" style="color:#f59e0b; margin-right:6px;"></i>
                ${c.observacion_pago}
            </p>
        </div>
        `;
    }
    
    contenido.innerHTML = `
        <!-- ============================================= -->
        <!-- INFORMACIÓN PERSONAL - 3 COLUMNAS -->
        <!-- ============================================= -->
        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:1rem; margin-bottom:1.5rem; background:#f8fafd; padding:1.2rem; border-radius:12px; border:1px solid #e9eef3;">
            <div style="grid-column: span 3; border-bottom: 1.5px solid #e9eef3; padding-bottom:0.5rem; margin-bottom:0.5rem;">
                <span style="font-weight:700; color:#1b4f6e; font-size:0.8rem; text-transform:uppercase; letter-spacing:0.5px;">
                    <i class="fas fa-id-card" style="color:#1b4f6e;"></i> Información Personal
                </span>
            </div>
            <div class="detalle-item">
                <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                    <i class="fas fa-tag" style="color:#1b4f6e;"></i> Código
                </label>
                <p style="font-weight:700; color:#0f2b3d; font-size:0.95rem;">${c.codigo_cliente || '-'}</p>
            </div>
            <div class="detalle-item">
                <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                    <i class="fas fa-user" style="color:#1b4f6e;"></i> Nombre Completo
                </label>
                <p style="font-weight:600; color:#0f2b3d; font-size:0.95rem;">${c.nombre || ''} ${c.apellido || ''}</p>
            </div>
            <div class="detalle-item">
                <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                    <i class="fas fa-id-card" style="color:#1b4f6e;"></i> DNI
                </label>
                <p style="font-weight:500; color:#0f2b3d; font-size:0.9rem;">${c.dni || '-'}</p>
            </div>
            <div class="detalle-item">
                <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                    <i class="fas fa-phone" style="color:#1b4f6e;"></i> Teléfono
                </label>
                <p style="font-weight:500; color:#0f2b3d; font-size:0.9rem;">${c.telefono || '-'}</p>
            </div>
            <div class="detalle-item">
                <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                    <i class="fas fa-envelope" style="color:#1b4f6e;"></i> Email
                </label>
                <p style="font-weight:500; color:#0f2b3d; font-size:0.9rem;">${c.email || '-'}</p>
            </div>
            <div class="detalle-item">
                <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                    <i class="fas fa-map-marker-alt" style="color:#1b4f6e;"></i> Barrio
                </label>
                <p style="font-weight:500; color:#0f2b3d; font-size:0.9rem;">${c.barrio_nombre || 'Sin barrio'}</p>
            </div>
        </div>
        
        <!-- ============================================= -->
        <!-- INFORMACIÓN DEL SERVICIO Y ESTADOS - 3 COLUMNAS -->
        <!-- ============================================= -->
        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:1rem; background:#f8fafd; padding:1.2rem; border-radius:12px; border:1px solid #e9eef3;">
            <!-- TÍTULO -->
            <div style="grid-column: span 3; border-bottom: 1.5px solid #e9eef3; padding-bottom:0.5rem; margin-bottom:0.5rem;">
                <span style="font-weight:700; color:#1b4f6e; font-size:0.8rem; text-transform:uppercase; letter-spacing:0.5px;">
                    <i class="fas fa-wifi" style="color:#1b4f6e;"></i> Información del Servicio y Estados
                </span>
            </div>
            
            <!-- TIPO DE SERVICIO -->
            <div class="detalle-item">
                <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                    <i class="fas fa-signal" style="color:#1b4f6e;"></i> Tipo de Servicio
                </label>
                <p style="font-weight:600; color:#0f2b3d; font-size:0.9rem;">${c.tipo_servicio_nombre || 'Sin servicio'}</p>
            </div>
            
            <!-- PRECIO BASE -->
            <div class="detalle-item">
                <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                    <i class="fas fa-dollar-sign" style="color:#1b4f6e;"></i> Precio Base
                </label>
                <p style="font-weight:600; color:#0f2b3d; font-size:0.9rem;">$${c.precio_base || '0'}</p>
            </div>
            
            <!-- ESTADO -->
            <div class="detalle-item">
                <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                    <i class="fas fa-circle" style="color:#1b4f6e;"></i> Estado
                </label>
                <span class="badge-estado ${estadoClases[c.estado] || 'activo'}">
                    <i class="fas ${c.estado === 'Activo' ? 'fa-check-circle' : 'fa-times-circle'}"></i>
                    ${c.estado || 'Activo'}
                </span>
            </div>
            
            <!-- ESTADO DE PAGO -->
            <div class="detalle-item">
                <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                    <i class="fas fa-coins" style="color:#1b4f6e;"></i> Estado de Pago
                </label>
                <span class="badge-pago ${estadoPagoClases[estadoPago] || 'pendiente'}">
                    <i class="fas ${estadoPagoIconos[estadoPago] || 'fa-clock'}"></i>
                    ${estadoPagoEtiquetas[estadoPago] || estadoPago}
                </span>
            </div>
            
            <!-- ÚLTIMO PAGO -->
            <div class="detalle-item">
                <label style="font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">
                    <i class="fas fa-calendar-check" style="color:#1b4f6e;"></i> Último Pago
                </label>
                <p style="font-weight:600; color:#0f2b3d; font-size:0.9rem;">
                    ${c.fecha_ultimo_pago ? new Date(c.fecha_ultimo_pago).toLocaleDateString('es-AR') : 'Sin pagos'}
                </p>
            </div>
            
            <!-- BOTÓN VER DNI - CENTRADO -->
            <div style="grid-column: span 3; text-align:center; padding-top:0.8rem; border-top: 2px solid #e9eef3; margin-top:0.3rem;">
                ${tieneFotoDNI ? `
                    <button onclick="verDNIDesdeDetalle('${c.foto_dni}')" style="
                        padding: 0.6rem 2.5rem; 
                        background: linear-gradient(135deg, #7c3aed, #6d28d9); 
                        color: white; 
                        border: none; 
                        border-radius: 10px; 
                        cursor: pointer; 
                        font-weight: 700; 
                        font-size: 0.85rem; 
                        transition: 0.3s; 
                        display: inline-flex; 
                        align-items: center; 
                        gap: 10px;
                        box-shadow: 0 4px 12px rgba(124,58,237,0.3);
                    " 
                    onmouseover="this.style.transform='scale(1.03)'; this.style.boxShadow='0 6px 20px rgba(124,58,237,0.5)'" 
                    onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 4px 12px rgba(124,58,237,0.3)'">
                        <i class="fas fa-id-card" style="font-size: 1rem;"></i> 
                        Ver DNI
                    </button>
                    <span style="font-size:0.6rem; color:#94a3b8; display:block; margin-top:6px;">
                        <i class="fas fa-info-circle"></i> Este cliente no es del lugar, se requiere verificación de DNI
                    </span>
                ` : ''}
            </div>
        </div>
        
        <!-- ============================================= -->
        <!-- ✅ OBSERVACIÓN DEL CLIENTE (campo observacion) -->
        <!-- ============================================= -->
        ${htmlObservacion}
        
        <!-- ============================================= -->
        <!-- ✅ OBSERVACIONES DE PAGO (campo observacion_pago) -->
        <!-- ============================================= -->
        ${htmlObservacionPago}
        
        <!-- ============================================= -->
        <!-- BOTÓN CERRAR -->
        <!-- ============================================= -->
        <div style="margin-top:1.5rem; text-align:right;">
            <button onclick="cerrarModal('modalDetalleCliente')" style="padding:0.5rem 1.5rem; border:1.5px solid #dce5ec; border-radius:8px; background:white; color:#1b4f6e; font-weight:600; cursor:pointer; transition:0.3s;">
                <i class="fas fa-times"></i> Cerrar
            </button>
        </div>
    `;
}

// =============================================
// VER DNI DESDE EL MODAL DE DETALLES
// =============================================
function verDNIDesdeDetalle(fotoDni) {
    const modal = document.getElementById('modalVerDNI');
    const imagen = document.getElementById('dniImagen');
    const sinFoto = document.getElementById('dniSinFoto');
    
    if (!modal) {
        console.error('Modal Ver DNI no encontrado');
        return;
    }
    
    modal.classList.add('active');
    imagen.style.display = 'none';
    sinFoto.style.display = 'none';
    
    if (fotoDni && fotoDni !== '' && fotoDni !== '0' && fotoDni !== 'null') {
        const rutaImagen = '../uploads/dni/' + fotoDni;
        
        sinFoto.style.display = 'block';
        sinFoto.innerHTML = `
            <i class="fas fa-spinner fa-spin" style="font-size: 3rem; display: block; margin-bottom: 1rem; color: #7c3aed;"></i>
            <p style="font-weight:600; color:#1b4f6e;">Cargando imagen...</p>
        `;
        
        fetch(rutaImagen, { method: 'HEAD' })
            .then(response => {
                if (response.ok) {
                    imagen.src = rutaImagen + '?t=' + new Date().getTime();
                    imagen.style.display = 'block';
                    sinFoto.style.display = 'none';
                } else {
                    sinFoto.style.display = 'block';
                    sinFoto.innerHTML = `
                        <i class="fas fa-exclamation-triangle" style="font-size: 3rem; display: block; margin-bottom: 1rem; color: #ef4444;"></i>
                        <p style="font-weight:600; color:#991b1b;">La imagen del DNI no se encuentra en el servidor</p>
                        <p style="font-size: 0.7rem; margin-top: 0.5rem; color: #94a3b8;">Archivo: ${fotoDni}</p>
                    `;
                }
            })
            .catch(() => {
                sinFoto.style.display = 'block';
                sinFoto.innerHTML = `
                    <i class="fas fa-exclamation-circle" style="font-size: 3rem; display: block; margin-bottom: 1rem; color: #ef4444;"></i>
                    <p style="font-weight:600; color:#991b1b;">Error al cargar la imagen del DNI</p>
                `;
            });
    } else {
        sinFoto.style.display = 'block';
        sinFoto.innerHTML = `
            <i class="fas fa-user-slash" style="font-size: 3rem; display: block; margin-bottom: 1rem; color: #cbd5e1;"></i>
            <p style="font-weight:600; color:#64748b;">Este cliente no tiene foto de DNI registrada</p>
            <p style="font-size: 0.7rem; margin-top: 0.5rem; color: #94a3b8;">Solo aplica para clientes que no son del lugar</p>
        `;
    }
}

// =============================================
// CERRAR MODAL DNI
// =============================================
function cerrarModalDNI() {
    const modal = document.getElementById('modalVerDNI');
    if (modal) {
        modal.classList.remove('active');
    }
    document.getElementById('dniImagen').src = '#';
}

// =============================================
// CERRAR MODAL DETALLES
// =============================================
function cerrarModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.remove('active');
    }
}

// =============================================
// SELECCIÓN DE MESES PARA PAGO (HASTA 12)
// =============================================
let mesesSeleccionados = 1;
let precioBase = 0;
let fechaCobroActual = '';


// =============================================
// CAMBIAR MESES (INCREMENTAR/DECREMENTAR)
// =============================================
function cambiarMeses(delta) {
    // Obtener el valor actual
    let mesesActuales = parseInt(document.getElementById('pagoCantidadMeses').value) || 1;
    
    // Calcular nuevo valor
    let nuevosMeses = mesesActuales + delta;
    
    // Limitar entre 1 y 12
    if (nuevosMeses < 1) nuevosMeses = 1;
    if (nuevosMeses > 12) nuevosMeses = 12;
    
    // Actualizar
    seleccionarMeses(nuevosMeses);
}

// =============================================
// SELECCIÓN DE MESES PARA PAGO (HASTA 12) - CON DISPLAY
// =============================================
function seleccionarMeses(meses) {
    mesesSeleccionados = meses;
    
    // Actualizar input hidden
    document.getElementById('pagoCantidadMeses').value = meses;
    
    // ✅ ACTUALIZAR DISPLAY DEL NÚMERO
    const mesesDisplay = document.getElementById('mesesDisplay');
    if (mesesDisplay) {
        mesesDisplay.textContent = meses;
    }
    
    // ✅ Actualizar label
    const label = document.getElementById('mesesSeleccionadosLabel');
    if (label) {
        label.textContent = meses + ' mes' + (meses > 1 ? 'es' : '');
    }
    
    // Actualizar monto total y detalle
    actualizarMontoTotal();
    mostrarDetalleMeses();
}

function actualizarMontoTotal() {
    const montoDisplay = document.getElementById('pagoMontoDisplay');
    const montoDetalle = document.getElementById('pagoMontoDetalle');
    
    if (precioBase > 0) {
        const total = precioBase * mesesSeleccionados;
        montoDisplay.textContent = '$' + total.toLocaleString('es-AR');
        montoDetalle.textContent = '(' + precioBase.toLocaleString('es-AR') + ' x ' + mesesSeleccionados + ' meses)';
    } else {
        montoDisplay.textContent = 'Cargando...';
        montoDetalle.textContent = '';
    }
}

function mostrarDetalleMeses() {
    const container = document.getElementById('detalleMesesContainer');
    const lista = document.getElementById('listaMeses');
    
    if (!container || !lista) return;
    
    container.style.display = 'block';
    
    const fechaCobroElement = document.getElementById('pagoFechaCobro');
    let fechaISO = fechaCobroElement?.dataset?.fechaISO || '';
    
    let fechaBase;
    if (fechaISO) {
        fechaBase = new Date(fechaISO + 'T00:00:00');
    } else {
        fechaBase = new Date();
    }
    
    if (isNaN(fechaBase.getTime())) {
        fechaBase = new Date();
    }
    
    let html = '<ul style="list-style: none; padding: 0; margin: 0;">';
    
    const mesesAMostrar = Math.max(1, mesesSeleccionados);
    
    // 📍 CALCULAR LA FECHA DE INICIO: Restar (mesesAMostrar - 1) meses a la fecha de cobro base
    let fechaInicio = new Date(fechaBase);
    fechaInicio.setMonth(fechaInicio.getMonth() - (mesesAMostrar - 1));

    for (let i = 0; i < mesesAMostrar; i++) {
        const fechaMes = new Date(fechaInicio);
        fechaMes.setMonth(fechaMes.getMonth() + i);
        
        const mesStr = fechaMes.toLocaleDateString('es-AR', { 
            month: 'long', 
            year: 'numeric' 
        });
        const fechaCompleta = fechaMes.toLocaleDateString('es-AR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });
        const montoMes = precioBase || 0;
        
        const esUltimoMes = (i === mesesAMostrar - 1);
        const estiloFila = esUltimoMes ? 'background: #f0f7ff; border-radius: 6px;' : '';
        const iconoMes = esUltimoMes ? '★ ' : '● ';
        
        html += `
            <li style="padding: 6px 8px; display: flex; justify-content: space-between; border-bottom: 1px solid #e9eef3; ${estiloFila}">
                <span>
                    ${iconoMes}
                    <strong>${mesStr.charAt(0).toUpperCase() + mesStr.slice(1)}</strong>
                    <span style="font-size:0.6rem; color:#94a3b8; margin-left:6px;">${fechaCompleta}</span>
                    ${esUltimoMes ? '<span style="font-size:0.55rem; background:#1b4f6e; color:white; padding:1px 8px; border-radius:10px; margin-left:6px;">ACTUAL</span>' : ''}
                </span>
                <span style="font-weight: 600; color: #0f2b3d;">$${montoMes.toLocaleString('es-AR')}</span>
            </li>
        `;
    }
    
    const total = (precioBase || 0) * mesesAMostrar;
    html += `
        <li style="padding: 10px 8px; display: flex; justify-content: space-between; font-weight: 700; color: #1b4f6e; border-top: 2px solid #1b4f6e; background: #f8fafd; border-radius: 0 0 6px 6px; margin-top: 4px;">
            <span><i class="fas fa-calculator" style="margin-right:6px;"></i> TOTAL A PAGAR</span>
            <span style="font-size:1.2rem;">$${total.toLocaleString('es-AR')}</span>
        </li>
    `;
    html += '</ul>';
    lista.innerHTML = html;
    
    if (mesesAMostrar > 6) {
        lista.style.maxHeight = '250px';
        lista.style.overflowY = 'auto';
    } else {
        lista.style.maxHeight = 'none';
        lista.style.overflowY = 'visible';
    }
}   

// =============================================
// REGISTRAR PAGO - CON AUTO-SELECCIÓN DE MESES DE DEUDA
// =============================================
// Consolidada: Usar únicamente esta definición de registrarPago
async function registrarPago(id, fechaCobro, mesesDeuda = 1) {
    const modal = document.getElementById('pagoModal');
    if (modal) modal.classList.add('active');
    
    const pagoClienteId = document.getElementById('pagoClienteId');
    if (pagoClienteId) pagoClienteId.value = id;
    
    fechaCobroActual = fechaCobro;
    
    try {
        const response = await fetch(`?ajax=get_cliente&id=${id}`);
        const data = await response.json();
        if (data.status === 'success') {
            const cliente = data.data;
            const nombreApellido = document.getElementById('pagoNombreApellido');
            if (nombreApellido) {
                nombreApellido.textContent = (cliente.nombre || '') + ' ' + (cliente.apellido || '');
            }
            const codigoCliente = document.getElementById('pagoCodigoCliente');
            if (codigoCliente) {
                codigoCliente.textContent = cliente.codigo_cliente || 'Sin codigo';
            }
        }
    } catch (error) {
        console.error('Error al obtener datos del cliente:', error);
    }
    
    const fechaCobroDisplay = document.getElementById('pagoFechaCobro');
    if (fechaCobroDisplay && fechaCobro) {
        const fecha = new Date(fechaCobro + 'T00:00:00');
        fechaCobroDisplay.textContent = fecha.toLocaleDateString('es-AR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });
        fechaCobroDisplay.dataset.fechaISO = fechaCobro;
    }
    
    const montoDisplay = document.getElementById('pagoMontoDisplay');
    if (montoDisplay) montoDisplay.textContent = 'Cargando...';
    
    const fecha = document.getElementById('pagoFecha');
    if (fecha) fecha.value = new Date().toISOString().split('T')[0];
    
    try {
        const response = await fetch(`?ajax=get_precio&id_cliente=${id}`);
        const data = await response.json();
        if (data.precio && montoDisplay) {
            precioBase = data.precio;
            
            let mesesIniciales = parseInt(data.meses_deuda) || parseInt(mesesDeuda) || 1;
            if (mesesIniciales < 1) mesesIniciales = 1;
            if (mesesIniciales > 12) mesesIniciales = 12;
            
            mesesSeleccionados = mesesIniciales;
            document.getElementById('pagoCantidadMeses').value = mesesIniciales;
            
            const mesesDisplay = document.getElementById('mesesDisplay');
            if (mesesDisplay) mesesDisplay.textContent = mesesIniciales;
            
            const label = document.getElementById('mesesSeleccionadosLabel');
            if (label) label.textContent = mesesIniciales + ' mes' + (mesesIniciales > 1 ? 'es' : '');
            
            actualizarMontoTotal();
            mostrarDetalleMeses();
        } else if (montoDisplay) {
            montoDisplay.textContent = 'Sin precio';
        }
    } catch {
        if (montoDisplay) montoDisplay.textContent = 'Error';
    }
}


// =============================================
// CERRAR MODAL DE PAGO
// =============================================
function cerrarPagoModal() {
    const modal = document.getElementById('pagoModal');
    if (modal) modal.classList.remove('active');
}


function actualizarBotonesDespuesDePagar(clienteId, fechaProximoCobro) {

    console.log(
        '🔥 ACTUALIZANDO BOTONES DESPUÉS DE PAGAR - Cliente ID:',
        clienteId
    );

    console.log(
        '📅 Fecha próximo cobro:',
        fechaProximoCobro
    );

    // Buscar la fila del cliente
    const fila = document.querySelector(
        `tr[data-cliente-id="${clienteId}"]`
    );

    if (!fila) {
        console.warn(
            '❌ Fila NO encontrada para cliente:',
            clienteId
        );
        return;
    }

    console.log('✅ Fila encontrada:', fila);

    // Dentro de actualizarBotonesDespuesDePagar (sección para idRol === 2):
if (idRol === 2) {
    console.log('👤 Usuario cobrador. Ocultando cliente y actualizando métricas del día.');

    fila.style.transition = 'opacity 0.4s ease';
    fila.style.opacity = '0';

    setTimeout(() => {
        fila.remove();

        // 1. ACTUALIZAR CONTADORES Y MÉTRICAS
        const elPagaron = document.getElementById('cobradorClientesPagaron');
        const elNoPagaron = document.getElementById('cobradorClientesNoPagaron');
        const elRecaudado = document.getElementById('cobradorTotalRecaudado');

        if (elPagaron) {
            let actualPagaron = parseInt(elPagaron.textContent) || 0;
            elPagaron.textContent = actualPagaron + 1;
        }

        if (elNoPagaron) {
            let actualNoPagaron = parseInt(elNoPagaron.textContent) || 0;
            elNoPagaron.textContent = Math.max(0, actualNoPagaron - 1);
        }

        if (elRecaudado) {
            const montoTexto = document.getElementById('pagoMontoDisplay')?.textContent || '$0';
            let montoRegistrado = parseFloat(montoTexto.replace(/[^0-9]/g, '')) || 0;
            let totalActual = parseFloat(elRecaudado.textContent.replace(/[^0-9]/g, '')) || 0;
            let nuevoTotal = totalActual + montoRegistrado;
            elRecaudado.textContent = '$' + nuevoTotal.toLocaleString('es-AR');
        }

        // 2. VERIFICAR SI QUEDAN CLIENTES EN LA LISTA
        const filasRestantes = document.querySelectorAll('#clientesTableBody tr[data-cliente-id]');
        const resultCount = document.getElementById('resultCount');

        if (resultCount) {
            resultCount.textContent = filasRestantes.length;
        }

        if (filasRestantes.length === 0) {
            const tbody = document.getElementById('clientesTableBody');
            if (tbody) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="100%" style="text-align:center; padding:30px;">
                            <div style="color:#6b7280;">
                                <i class="fas fa-check-circle" style="font-size:2rem; margin-bottom:10px; color:#10b981;"></i>
                                <div>¡Excelente trabajo! No quedan clientes pendientes de cobro por hoy.</div>
                            </div>
                        </td>
                    </tr>
                `;
            }
        }
    }, 400);

    return;
}

    // =====================================================
    // ADMINISTRADOR / ADMIN RED
    // =====================================================

    const accionesCell =
        fila.querySelector('td:last-child');

    if (!accionesCell) {

        console.warn(
            '❌ Celda de acciones no encontrada'
        );

        return;
    }

    // 1. Ocultar botones
    const botones =
        accionesCell.querySelectorAll(
            '.btn-pago, .btn-corte, .btn-edit, .btn-delete'
        );

    botones.forEach(btn => {
        btn.style.display = 'none';
    });

    // 2. Eliminar estados anteriores
    const spansViejos =
        accionesCell.querySelectorAll(
            '.badge-estado-pago, .estado-pago-span'
        );

    spansViejos.forEach(span => {
        span.remove();
    });

    // 3. Crear nuevo estado "Al día"
    const nuevoSpan =
        document.createElement('span');

    nuevoSpan.className =
        'badge-estado-pago';

    nuevoSpan.style.cssText = `
        font-size: 0.7rem;
        color: #10b981;
        padding: 4px 12px;
        background: #f0fdf4;
        border-radius: 6px;
        display: inline-block;
        border: 1px solid #bbf7d0;
        font-weight: 600;
    `;

    nuevoSpan.innerHTML =
        '<i class="fas fa-check-circle"></i> Al día';

    accionesCell.appendChild(nuevoSpan);

    // 4. Actualizar badge de estado
    const estadoBadge =
        fila.querySelector(
            '.badge-pagado, .badge-pendiente, .badge-mora, .badge-suspendido'
        );

    if (estadoBadge) {

        estadoBadge.className =
            'badge badge-pagado';

        estadoBadge.innerHTML =
            '<i class="fas fa-check-circle"></i> Al día';

        console.log(
            '✅ Badge actualizado a Al día'
        );
    }

    // 5. Actualizar fecha de cobro
    const fechaCobroDiv =
        fila.querySelector('td:nth-child(8) div');

    if (fechaCobroDiv && fechaProximoCobro) {

        const fecha =
            new Date(
                fechaProximoCobro + 'T00:00:00'
            );

        const fechaFormateada =
            fecha.toLocaleDateString('es-AR');

        fechaCobroDiv.innerHTML = `
            Cobro: ${fechaFormateada}
            <span style="color:#059669; font-weight:600;">
                (Pagado)
            </span>
        `;

        console.log(
            '✅ Fecha de cobro actualizada'
        );
    }

    // 6. Actualizar dataset
    fila.dataset.yaPago = '1';
    fila.dataset.estadoPago = 'pagado';

    console.log(
        '✅ ACTUALIZACIÓN COMPLETA para cliente:',
        clienteId
    );
}

// =============================================
// ACTUALIZAR BOTONES DESPUÉS DE CORTAR
// =============================================
function actualizarBotonesDespuesDeCortar(clienteId) {
    const fila = document.querySelector(`tr[data-cliente-id="${clienteId}"]`);
    if (!fila) return;
    
    const accionesCell = fila.querySelector('td:last-child');
    if (!accionesCell) return;
    
    // Ocultar botón de pagar
    const btnPagar = accionesCell.querySelector('.btn-pago');
    if (btnPagar) {
        btnPagar.style.display = 'none';
    }
    
    // Ocultar botón de corte
    const btnCorte = accionesCell.querySelector('.btn-corte');
    if (btnCorte) {
        btnCorte.style.display = 'none';
    }
    
    // Actualizar estado a "Suspendido"
    const estadoBadge = fila.querySelector('.badge.badge-pagado, .badge.badge-pendiente, .badge.badge-mora, .badge.badge-suspendido');
    if (estadoBadge) {
        estadoBadge.className = 'badge badge-suspendido';
        estadoBadge.innerHTML = '<i class="fas fa-pause-circle"></i> Suspendido';
    }
    
    // Mostrar etiqueta "Suspendido"
    const suspendidoSpan = accionesCell.querySelector('span[style*="background:#e2e8f0"]');
    if (!suspendidoSpan) {
        const nuevoSpan = document.createElement('span');
        nuevoSpan.style.cssText = 'font-size:0.6rem; color:#94a3b8; padding:4px 8px; background:#e2e8f0; border-radius:6px; display:inline-block; font-weight:600;';
        nuevoSpan.innerHTML = '<i class="fas fa-pause-circle"></i> Suspendido';
        accionesCell.appendChild(nuevoSpan);
    }
    
    // Actualizar atributo
    fila.dataset.estadoPago = 'suspendido';
}

// =============================================
// ELIMINAR FOTO DNI
// =============================================
function eliminarFotoDNI() {
    if (!confirm('¿Eliminar la foto de DNI actual?')) return;
    
    // Limpiar el campo oculto
    const fotoDniActual = document.getElementById('fotoDniActual');
    if (fotoDniActual) fotoDniActual.value = '';
    
    // Limpiar el input file
    const fotoDniInput = document.getElementById('fotoDni');
    if (fotoDniInput) fotoDniInput.value = '';
    
    // Remover preview
    // Limpiar preview
    const preview = document.getElementById('fotoDniPreview');
    if (preview) preview.remove();
    if (preview) {
        preview.innerHTML = '';
        preview.style.display = 'none';
    }
    
    // Restaurar label original
    const labelFoto = document.querySelector('#fotoDniContainer .form-group label');
    if (labelFoto) {
        labelFoto.innerHTML = `<i class="fas fa-image"></i> Foto DNI`;
    }
    
    mostrarToast('Foto de DNI eliminada', 'success');
}


// =============================================
// AUTOCOMPLETADO Y LÓGICA PARA MODAL NUEVA TAREA
// =============================================
function seleccionarClienteTarea(id, nombreCompleto) {
    const hiddenInput = document.getElementById('clienteIdNuevaTarea');
    const labelNombre = document.getElementById('clienteNombreNuevaTarea');
    const selectedBox = document.getElementById('clienteSelectedNuevaTarea');
    const dropdown = document.getElementById('clienteDropdownNuevaTarea');
    const searchInput = document.getElementById('clienteSearchNuevaTarea');

    if (hiddenInput) hiddenInput.value = id;
    if (labelNombre) labelNombre.textContent = nombreCompleto;
    if (selectedBox) selectedBox.style.display = 'flex';
    if (dropdown) dropdown.style.display = 'none';
    if (searchInput) searchInput.value = '';
}

function limpiarClienteTarea() {
    const hiddenInput = document.getElementById('clienteIdNuevaTarea');
    const selectedBox = document.getElementById('clienteSelectedNuevaTarea');
    const searchInput = document.getElementById('clienteSearchNuevaTarea');

    if (hiddenInput) hiddenInput.value = '';
    if (selectedBox) selectedBox.style.display = 'none';
    if (searchInput) searchInput.value = '';
}

document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('clienteSearchNuevaTarea');
    const dropdown = document.getElementById('clienteDropdownNuevaTarea');

    if (searchInput && dropdown) {
        searchInput.addEventListener('input', function() {
            const term = this.value.toLowerCase().trim();
            if (!term) {
                dropdown.style.display = 'none';
                return;
            }

            // Filtrar sobre los clientes cargados en la variable global
            if (typeof listaClientesGlobal === 'undefined') return;

            const filtrados = listaClientesGlobal.filter(c => 
                (c.nombre && c.nombre.toLowerCase().includes(term)) || 
                (c.apellido && c.apellido.toLowerCase().includes(term)) ||
                (c.codigo_cliente && c.codigo_cliente.toLowerCase().includes(term)) ||
                (c.dni && c.dni.includes(term))
            );

            if (filtrados.length === 0) {
                dropdown.innerHTML = '<div style="padding:0.6rem 0.8rem; color:#94a3b8; font-size:0.8rem;">No se encontraron clientes</div>';
            } else {
                dropdown.innerHTML = filtrados.slice(0, 8).map(c => `
                    <div onclick="seleccionarClienteTarea(${c.id}, '${c.nombre} ${c.apellido}')" 
                         style="padding:0.6rem 0.8rem; cursor:pointer; border-bottom:1px solid #f0f4f8; font-size:0.85rem; color:#0f2b3d; font-weight:600;"
                         onmouseover="this.style.background='#f8fafd'" 
                         onmouseout="this.style.background='white'">
                        ${c.nombre} ${c.apellido} 
                        <span style="font-size:0.75rem; color:#64748b;">(${c.codigo_cliente || 'Sin código'})</span>
                    </div>
                `).join('');
            }
            dropdown.style.display = 'block';
        });

        // Cerrar desplegable si se hace clic fuera
        document.addEventListener('click', function(e) {
            if (!searchInput.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.style.display = 'none';
            }
        });
    }
});



// ABRIR Y CERRAR MODALES
function abrirModal(idModal = 'clienteModal') {
    const modal = document.getElementById(idModal);
    if (modal) {
        modal.classList.add('active');
    }
}

function cerrarModal(id = 'clienteModal') {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.remove('active');
    }
}

// OBTENER UBICACIÓN GPS DESDE EL MODAL DE TAREAS
let watchGpsTareaId = null;

function obtenerUbicacionCobradorTarea() {
    const inputUrl = document.getElementById('ubicacionUrlInputTarea');
    const statusText = document.getElementById('statusUbicacionTarea');
    const btn = document.getElementById('btnObtenerGpsTarea');

    if (!navigator.geolocation) {
        if (statusText) {
            statusText.style.color = '#ef4444';
            statusText.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Geolocalización no soportada.';
        }
        return;
    }

    if (watchGpsTareaId !== null) {
        navigator.geolocation.clearWatch(watchGpsTareaId);
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> GPS...';
    if (statusText) {
        statusText.style.color = '#1b4f6e';
        statusText.innerHTML = '<i class="fas fa-satellite"></i> Obteniendo señal de alta precisión...';
    }

    let mejorLectura = null;
    const opcionesGps = {
        enableHighAccuracy: true,
        timeout: 20000,
        maximumAge: 0
    };

    watchGpsTareaId = navigator.geolocation.watchPosition(
        (pos) => {
            const lat = pos.coords.latitude;
            const lng = pos.coords.longitude;
            const precision = pos.coords.accuracy;

            if (!mejorLectura || precision < mejorLectura.precision) {
                mejorLectura = { lat, lng, precision };
            }

            if (precision <= 50) {
                finalizarGpsTarea(mejorLectura.lat, mejorLectura.lng, mejorLectura.precision);
            }
        },
        (err) => {
            if (watchGpsTareaId !== null) navigator.geolocation.clearWatch(watchGpsTareaId);
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-crosshairs"></i> Reintentar GPS';
            if (statusText) {
                statusText.style.color = '#ef4444';
                statusText.innerHTML = '<i class="fas fa-exclamation-circle"></i> Error al conectar con GPS.';
            }
        },
        opcionesGps
    );

    setTimeout(() => {
        if (mejorLectura) {
            finalizarGpsTarea(mejorLectura.lat, mejorLectura.lng, mejorLectura.precision);
        }
    }, 12000);

    function finalizarGpsTarea(lat, lng, precision) {
        if (watchGpsTareaId !== null) {
            navigator.geolocation.clearWatch(watchGpsTareaId);
            watchGpsTareaId = null;
        }

        if (inputUrl) {
            inputUrl.value = `https://www.google.com/maps?q=${lat},${lng}`;
        }

        btn.disabled = false;
        btn.style.background = '#10b981';
        btn.innerHTML = '<i class="fas fa-check"></i> Listo';

        if (statusText) {
            statusText.style.color = '#10b981';
            statusText.innerHTML = `<i class="fas fa-check-circle"></i> Margen de precisión: ~${Math.round(precision)}m`;
        }
    }
}